# Admin Request Approval Flow

## Overview
This document explains how admin request approval/rejection works and how it affects visibility for other roles.

## Flow Diagram

```
1. NGO/Volunteer/Donor creates request
   ↓
   admin_status = 'pending'
   
2. Admin views request in "Manage Requests" page
   ↓
   Admin clicks on request → Views details
   
3. Admin action:
   a) Verify → admin_status = 'verified'
   b) Accept → admin_status = 'accepted', status = 'approved'
   c) Reject → admin_status = 'rejected'
   ↓
   Database updated via update_request_status.php
   
4. Other roles (Donors/Volunteers/NGOs) browse help requests
   ↓
   Fetch endpoints filter by admin_status = 'accepted'
   ↓
   Only approved requests are visible
```

## Database Schema

### ngoraisehelp Table
- `admin_status`: Controls visibility
  - `'pending'` - Waiting for admin review (not visible to public)
  - `'verified'` - Admin verified, under review (not visible to public)
  - `'accepted'` - Approved by admin (VISIBLE to other roles)
  - `'rejected'` - Rejected by admin (not visible to public)
- `status` (optional): Public status
  - `'approved'` - Approved request
  - `'active'` - Active request
- `admin_id`: ID of admin who reviewed
- `admin_reviewed_at`: Timestamp of review
- `rejection_reason`: Reason if rejected

## API Endpoints

### 1. Admin Updates Request Status
**Endpoint:** `update_request_status.php`
**Method:** POST

**Request:**
```json
{
  "request_id": "123",
  "request_type": "ngo",
  "status": "APPROVED",
  "admin_id": 1,
  "rejection_reason": null
}
```

**Status Values:**
- `"PENDING"` → Sets admin_status='verified' (verify action)
- `"APPROVED"` → Sets admin_status='accepted', status='approved' (accept action)
- `"REJECTED"` → Sets admin_status='rejected' (reject action)

**Response:**
```json
{
  "status": true,
  "message": "Request status updated to APPROVED successfully"
}
```

### 2. Public Browse Endpoints (Filter by admin_status='accepted')

#### Get NGO Requests (for Donors/Volunteers to browse)
**Endpoint:** `get_all_ngo_requests.php`
**Filter:** `WHERE admin_status = 'accepted'`

#### Get Volunteer Requests (for NGOs/Donors to browse)
**Endpoint:** `get_all_volunteer_requests.php`
**Filter:** `WHERE admin_status = 'accepted'`

#### Get Donor Campaigns (for NGOs/Volunteers to browse)
**Endpoint:** `get_all_donor_campaigns.php`
**Filter:** `WHERE admin_status = 'accepted'`

## Android Implementation

### AdminRequestDetails.kt
- Shows request details
- Has three buttons:
  1. **Verify Request** → Calls `performAction("verify")` → Status: "PENDING"
  2. **Accept** → Calls `performAction("accept")` → Status: "APPROVED"
  3. **Reject** → Shows dialog → Calls `performAction("reject")` → Status: "REJECTED"

### Status Mapping in Android
```kotlin
val status = when (action) {
    "verify" -> "PENDING"
    "accept" -> "APPROVED"
    "reject" -> "REJECTED"
    else -> return@launch
}
```

## Visibility Rules

### ✅ Visible to Other Roles
- Requests where `admin_status = 'accepted'`
- These requests appear in:
  - Donor's "Browse Causes" screen
  - Volunteer's "Browse Opportunities" screen
  - NGO's "Browse Help Requests" screen

### ❌ Not Visible to Other Roles
- Requests where `admin_status = 'pending'`
- Requests where `admin_status = 'verified'`
- Requests where `admin_status = 'rejected'`

## Testing Checklist

- [ ] Admin can view pending requests in "Manage Requests"
- [ ] Admin can click on request to see details
- [ ] Admin can verify a request (status changes to 'verified')
- [ ] Admin can accept a request (status changes to 'accepted', request becomes visible)
- [ ] Admin can reject a request (status changes to 'rejected', request hidden)
- [ ] Accepted requests appear in public browse endpoints
- [ ] Rejected/pending requests do NOT appear in public browse endpoints
- [ ] Database columns are updated correctly
- [ ] Notifications are created when status changes

## Troubleshooting

### Issue: Accepted requests not showing in browse
**Solution:** 
1. Check database: `SELECT admin_status FROM ngoraisehelp WHERE id = ?`
2. Should be `'accepted'` for visible requests
3. Check PHP fetch endpoints filter: `WHERE admin_status = 'accepted'`

### Issue: Update fails silently
**Solution:**
1. Check Android logcat for error messages
2. Check PHP error logs
3. Verify request_id exists in database
4. Verify admin_id is valid
5. Check column existence (admin_status, status, admin_id, etc.)

### Issue: Rejected requests still visible
**Solution:**
1. Verify fetch endpoints filter by `admin_status = 'accepted'`
2. Check database values are correct
3. Clear app cache and refresh

## Recent Fixes

1. ✅ Fixed `update_request_status.php` to check column existence before updating
2. ✅ Added dynamic query building based on available columns
3. ✅ Improved error handling and logging
4. ✅ Verified fetch endpoints filter correctly
5. ✅ Status mapping verified: approved → admin_status='accepted'

