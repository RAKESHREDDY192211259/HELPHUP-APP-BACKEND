﻿# Backend Connections Summary

## Base URL
**All API endpoints use:** `http://10.22.186.166/helphup/api/`

---

## âœ… CONNECTED BACKEND ENDPOINTS

### ðŸ” Authentication & Registration

#### 1. **NGO Login** âœ…
- **File:** `NgoLogin.kt`
- **Endpoint:** `ngo_login.php`
- **Method:** POST (HttpURLConnection)
- **Request:** `{ email, password }`
- **Response:** `{ status, message }`
- **Status:** âœ… Connected

#### 2. **NGO Registration** âœ…
- **File:** `NgoRegistration.kt`
- **Endpoint:** `ngo_register.php`
- **Method:** POST (Multipart - HttpURLConnection)
- **Request:** `{ full_name, phone, email, address, org_name, reg_number, password }` + file upload
- **Response:** `{ status, message }`
- **Status:** âœ… Connected

#### 3. **NGO Forgot Password** âœ…
- **File:** `NgoForgotPassword.kt`
- **Endpoint:** `ngoforgot.php`
- **Method:** POST (Retrofit)
- **Request:** `{ email }`
- **Response:** `{ status, message }`
- **Status:** âœ… Connected

#### 4. **Volunteer Login** âœ…
- **File:** `VolunteerLogin.kt`
- **Endpoint:** `volunteer_login.php`
- **Method:** POST (Retrofit)
- **Request:** `{ email, password }`
- **Response:** `{ status, message, volunteer: { id, name, email } }`
- **Status:** âœ… Connected

#### 5. **Volunteer Registration** âœ…
- **File:** `VolunteerRegistration.kt`
- **Endpoint:** `volunteer_register.php`
- **Method:** POST (Retrofit)
- **Request:** `{ full_name, email, password, skills: [], availability: [] }`
- **Response:** `{ status, message }`
- **Status:** âœ… Connected

#### 6. **Donor Login** âœ…
- **File:** `DonorLogin.kt`
- **Endpoint:** `donor_login.php`
- **Method:** POST (Retrofit)
- **Request:** `{ email, password }`
- **Response:** `{ status, message, donor_id, full_name }`
- **Status:** âœ… Connected

#### 7. **Donor Registration** âœ…
- **File:** `DonorRegistration.kt`
- **Endpoint:** `donor_register.php`
- **Method:** POST (Retrofit)
- **Request:** `{ full_name, phone, email, address, password }`
- **Response:** `{ status, message }`
- **Status:** âœ… Connected

---

### ðŸ“ Help Request / Campaign Creation

#### 8. **NGO Raise Help** âœ…
- **File:** `NgoRaiseHelp.kt`
- **Endpoint:** `ngo_raise_help.php`
- **Method:** POST (Retrofit)
- **Request:** 
  ```json
  {
    "ngo_id": Int,
    "request_title": String,
    "category": String,
    "urgency_level": String,
    "required_amount": String,
    "date_needed": String,
    "contact_number": String,
    "description": String
  }
  ```
- **Response:** `{ status, message }`
- **Status:** âœ… Connected

#### 9. **Volunteer Raise Help** âœ…
- **File:** `VolunteerRaiseHelp.kt`
- **Endpoint:** `volunteer_raise_help.php`
- **Method:** POST (Retrofit)
- **Request:**
  ```json
  {
    "volunteer_id": Int,
    "request_title": String,
    "category": String,
    "description": String,
    "location": String,
    "help_date": String,
    "start_time": String,
    "volunteers_needed": Int
  }
  ```
- **Response:** `{ status, message }`
- **Status:** âœ… Connected

#### 10. **Donor Raise Donation Campaign** âœ…
- **File:** `DonorRaiseDonation.kt`
- **Endpoint:** `Donor_raise_help.php`
- **Method:** POST (Retrofit)
- **Request:**
  ```json
  {
    "donor_id": Int,
    "campaign_title": String,
    "fundraising_goal": String,
    "category": String,
    "cover_image_url": String?,
    "video_url": String?,
    "duration": String,
    "end_date": String,
    "beneficiary_name": String,
    "relationship": String,
    "contact_email": String
  }
  ```
- **Response:** `{ status, message }`
- **Status:** âœ… Connected

---

## âŒ NOT CONNECTED (Frontend Only)

### Screens with NO backend connections:
1. **NgoDashboard.kt** - Static UI only
2. **VolunteerDashboard.kt** - Static UI only
3. **DonorDashboard.kt** - Static UI only
4. **NgoProfile.kt** - Static UI only
5. **VolunteerProfile.kt** - Static UI only
6. **DonorProfileScreen.kt** - Static UI only
7. **NgoEditProfile.kt** - No API call (just navigation)
8. **VolunteerEditDetails.kt** - No API call (just navigation)
9. **DonorEditDetails.kt** - No API call (just navigation)
10. **NgoHelpOthers.kt** - Static UI only
11. **VolunteerHelpOthers.kt** - Static UI only
12. **DonorBrowseCause.kt** - Static UI only
13. **NgoCommunitySupport.kt** - Static UI only
14. **VolunteerCommunitySupport.kt** - Static UI only
15. **DonorCommunitySupport.kt** - Static UI only
16. **NgoPaymentMethods.kt** - Static UI only
17. **VolunteerPaymentMethods.kt** - Static UI only
18. **DonorPaymentMethods.kt** - Static UI only
19. **NgoPaymentDetails.kt** - Static UI only
20. **VolunteerPaymentDetails.kt** - Static UI only
21. **DonorPaymentDetails.kt** - Static UI only
22. **NgoPaymentConfirmation.kt** - Static UI only
23. **VolunteerSupportConfirmation.kt** - Static UI only
24. **DonorSupportConfirmation.kt** - Static UI only
25. **NgoNotifications.kt** - Static UI only
26. **VolunteerNotifications.kt** - Static UI only
27. **DonorNotification.kt** - Static UI only
28. **NgoDonorsHistory.kt** - Static UI only
29. **NgoVolunteersHistory.kt** - Static UI only
30. **VolunteerHistory.kt** - Static UI only
31. **DonorDonationHistory.kt** - Static UI only
32. **DonorImpact.kt** - Static UI only
33. **VolunteerDonationRecords.kt** - Static UI only (if exists)
34. **DonorBrowseCauseDetailsScreen.kt** - Static UI only (if exists)
35. **VolunteerHelpRequestSubmitted.kt** - Static UI only (if exists)
36. **VolunteerViewHelpRequestDetails.kt** - Static UI only (if exists)

---

## ðŸ“Š Summary Statistics

- **Total Backend Endpoints:** 10
- **Connected Endpoints:** 10 âœ…
- **Not Connected Screens:** ~36 (Frontend UI only)

### By Category:
- **Authentication:** 7 endpoints âœ…
- **Help Requests/Campaigns:** 3 endpoints âœ…
- **Payment Processing:** 0 endpoints âŒ
- **Profile Management:** 0 endpoints âŒ
- **History/Records:** 0 endpoints âŒ
- **Notifications:** 0 endpoints âŒ
- **Browse/View Details:** 0 endpoints âŒ

---

## ðŸ”§ Technical Details

### Network Libraries Used:
1. **Retrofit** - Used in 9 endpoints
   - Volunteer Login
   - Volunteer Registration
   - Volunteer Raise Help
   - Donor Login
   - Donor Registration
   - Donor Raise Donation
   - NGO Forgot Password
   - NGO Raise Help

2. **HttpURLConnection** - Used in 1 endpoint
   - NGO Login
   - NGO Registration (Multipart upload)

### Response Format:
All endpoints return JSON with:
```json
{
  "status": boolean,
  "message": string
}
```

Some endpoints include additional data:
- Login endpoints return user data
- Registration endpoints return success/error messages

---

## âš ï¸ Notes

1. **Hardcoded User IDs:** Some endpoints use hardcoded IDs (e.g., `ngoId = 1` in NgoRaiseHelp)
2. **No Session Management:** No token-based authentication visible
3. **No Error Handling:** Basic try-catch, but no detailed error parsing
4. **Network Configuration:** All endpoints use the same base URL
5. **Missing Features:** Payment, profile updates, history fetching, notifications are not connected

---

## ðŸš€ Recommendations

1. **Add Backend Connections For:**
   - Profile update endpoints
   - Payment processing
   - History/records fetching
   - Notifications fetching
   - Browse/search endpoints

2. **Improve Current Connections:**
   - Add proper session/token management
   - Implement proper user ID retrieval (not hardcoded)
   - Add better error handling
   - Add loading states consistently

3. **Security:**
   - Move base URL to config file
   - Add HTTPS support
   - Implement proper authentication tokens

