# Complete End-to-End Flow: NGO Help Request

## 📋 Flow Overview

This document verifies the complete flow from NGO submission to visibility across all roles.

---

## 1️⃣ NGO Submits Help Request

### Screen: `NgoRaiseHelp.kt`

**Request Details Captured:**
- ✅ NGO ID
- ✅ Request Title
- ✅ Description
- ✅ Category (Food, Medical, Education, etc.)
- ✅ Urgency Level
- ✅ Required Amount
- ✅ Date Needed
- ✅ Contact Number

**Backend Endpoint:** `ngo_raise_help.php`

**Database Storage:**
```sql
INSERT INTO ngoraisehelp (
    ngo_id,
    request_title,
    category,
    urgency_level,
    required_amount,
    date_needed,
    contact_number,
    description,
    admin_status  -- Set to 'pending'
)
```

**Initial Status:**
- `admin_status` = `'pending'`
- `status` = `'pending'` (if column exists)

---

## 2️⃣ Request Appears in Admin Manage Requests

### Screen: `AdminManageRequests.kt`

**Endpoint:** `admin_get_pending_requests.php`

**Filter Criteria:**
- Shows requests where `admin_status = 'pending'` OR `admin_status IS NULL`
- Includes all request types: NGO, Volunteer, Donor

**Admin Actions Available:**
1. ✅ **Verify** - Review request details
2. ✅ **Accept** - Approve request for public visibility
3. ❌ **Reject** - Decline request with reason

---

## 3️⃣ Admin Decision Logic

### Admin Clicks on Request → `AdminRequestDetails.kt`

#### 🔹 If Admin REJECTS

**Status Update:**
```sql
UPDATE ngoraisehelp SET
    admin_status = 'rejected',
    status = 'rejected',
    admin_id = [admin_id],
    admin_reviewed_at = NOW(),
    rejection_reason = '[reason]'
WHERE id = [request_id]
```

**Visibility Result:**
- ❌ NOT visible to Volunteers
- ❌ NOT visible to Donors
- ❌ NOT visible to Other NGOs
- ✅ Visible only to the submitting NGO (via `get_my_ngo_requests.php`)

**Notification:**
- NGO receives notification: "Request Rejected: [reason]"

---

#### 🔹 If Admin ACCEPTS

**Status Update:**
```sql
UPDATE ngoraisehelp SET
    admin_status = 'accepted',
    status = 'approved',
    admin_id = [admin_id],
    admin_reviewed_at = NOW()
WHERE id = [request_id]
```

**Visibility Result:**
- ✅ Visible to Volunteers (`get_all_ngo_requests.php`)
- ✅ Visible to Donors (`get_all_ngo_requests.php`)
- ✅ Visible to Other NGOs (`get_all_ngo_requests.php`)
- ❌ NOT visible to the submitting NGO in browse (excluded by design)
- ✅ Visible to submitting NGO in "My Requests" (all statuses)

**Notification:**
- NGO receives notification: "Request Approved"

---

## 4️⃣ Data Sync After Approval

### Single Source of Truth

**All roles fetch from the same tables:**
- NGO Requests: `ngoraisehelp` or `ngo_help_requests`
- Volunteer Requests: `volunteerraisehelp` or `volunteer_requests`
- Donor Campaigns: `donor_campaigns`

**Filter Applied:**
```sql
WHERE admin_status = 'accepted' 
  AND (status = 'approved' OR status = 'active')
```

**Backend Endpoints:**
1. `get_all_ngo_requests.php` - Returns approved NGO requests
2. `get_all_volunteer_requests.php` - Returns approved Volunteer requests
3. `get_all_donor_campaigns.php` - Returns approved Donor campaigns

---

## 5️⃣ Volunteer Side – View Help Requests

### Screen: `VolunteerHelpOthers.kt`

**Fetches:**
- ✅ NGO Requests (from `get_all_ngo_requests.php`)
- ✅ Donor Campaigns (from `get_all_donor_campaigns.php`)
- ❌ Volunteer Requests (excluded - same role type)

**Filter Applied (Backend):**
```php
WHERE admin_status = 'accepted' 
  AND (status = 'approved' OR status = 'active')
```

**Volunteer Actions:**
- ✅ View request details
- ✅ Accept volunteer task
- ✅ Contact NGO
- ✅ Update help progress

---

## 6️⃣ Donor Side – Browse Causes

### Screen: `DonorBrowseCause.kt`

**Fetches:**
- ✅ NGO Requests (from `get_all_ngo_requests.php`)
- ✅ Volunteer Requests (from `get_all_volunteer_requests.php`)
- ❌ Donor Campaigns (excluded - same role type)

**Filter Applied (Backend):**
```php
WHERE admin_status = 'accepted' 
  AND (status = 'approved' OR status = 'active')
```

**Donor Actions:**
- ✅ Donate money
- ✅ Donate items
- ✅ Track donation status

---

## 7️⃣ Other NGO Side – Help Others

### Screen: `NgoHelpOthers.kt`

**Fetches:**
- ✅ Volunteer Requests (from `get_all_volunteer_requests.php`)
- ✅ Donor Campaigns (from `get_all_donor_campaigns.php`)
- ❌ NGO Requests (excluded - same role type)

**Filter Applied (Backend):**
```php
WHERE admin_status = 'accepted' 
  AND (status = 'approved' OR status = 'active')
```

**Other NGO Actions:**
- ✅ Provide resources
- ✅ Collaborate
- ✅ Offer support

---

## 8️⃣ Unified Visibility Rule

### Status-Based Visibility

| Status | admin_status | status | Visible To |
|--------|--------------|--------|------------|
| **PENDING** | `pending` | `pending` | ❌ Admin only |
| **VERIFIED** | `verified` | `pending` | ❌ Admin only |
| **REJECTED** | `rejected` | `rejected` | ❌ Owner only (via "My Requests") |
| **APPROVED** | `accepted` | `approved` | ✅ All other roles |

### Visibility Matrix

| Request Type | Visible To NGOs | Visible To Volunteers | Visible To Donors |
|--------------|----------------|----------------------|-------------------|
| NGO Request (APPROVED) | ❌ No | ✅ Yes | ✅ Yes |
| Volunteer Request (APPROVED) | ✅ Yes | ❌ No | ✅ Yes |
| Donor Campaign (APPROVED) | ✅ Yes | ✅ Yes | ❌ No |

---

## 🔄 Complete Status Flow

```
NGO Submits Request
        ↓
admin_status = 'pending'
status = 'pending'
        ↓
Appears in Admin Manage Requests
        ↓
Admin Reviews Request
        ↓
    ┌─────────────┐
    │             │
    ↓             ↓
REJECT         ACCEPT
    │             │
    ↓             ↓
admin_status   admin_status
= 'rejected'   = 'accepted'
status         status
= 'rejected'   = 'approved'
    │             │
    ↓             ↓
Owner only    VISIBLE TO:
visible       ✅ Volunteers
              ✅ Donors
              ✅ Other NGOs
```

---

## ✅ Verification Checklist

### Request Submission
- [x] NGO can submit request via `NgoRaiseHelp.kt`
- [x] Request saved with `admin_status='pending'`
- [x] Request appears in Admin Manage Requests

### Admin Actions
- [x] Admin can view request details
- [x] Admin can verify request (sets `admin_status='verified'`)
- [x] Admin can accept request (sets `admin_status='accepted'`, `status='approved'`)
- [x] Admin can reject request (sets `admin_status='rejected'`, `status='rejected'`)
- [x] Database updates immediately
- [x] Notifications sent to requester

### Visibility Rules
- [x] Only `admin_status='accepted'` requests are visible to other roles
- [x] NGOs don't see NGO requests in browse
- [x] Volunteers don't see Volunteer requests in browse
- [x] Donors don't see Donor campaigns in browse
- [x] Requesters can see their own requests (all statuses) via "My Requests"

### Backend Filtering
- [x] `get_all_ngo_requests.php` filters by `admin_status='accepted'`
- [x] `get_all_volunteer_requests.php` filters by `admin_status='accepted'`
- [x] `get_all_donor_campaigns.php` filters by `admin_status='accepted'`

### Android Implementation
- [x] `NgoHelpOthers.kt` excludes NGO requests
- [x] `VolunteerHelpOthers.kt` excludes Volunteer requests
- [x] `DonorBrowseCause.kt` excludes Donor campaigns

---

## 📊 Data Flow Diagram

```
┌─────────────────┐
│  NGO Submits    │
│  Request        │
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│ admin_status    │
│ = 'pending'     │
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│ Admin Reviews   │
│ & Accepts       │
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│ admin_status    │
│ = 'accepted'    │
│ status          │
│ = 'approved'    │
└────────┬────────┘
         │
         ├─────────────────┬─────────────────┐
         ↓                 ↓                 ↓
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│ Volunteers   │  │ Donors       │  │ Other NGOs   │
│ See Request  │  │ See Request  │  │ See Request  │
└──────────────┘  └──────────────┘  └──────────────┘
```

---

## 🎯 Key Implementation Details

### Status Update Endpoint
**File:** `update_request_status.php`

**Request:**
```json
{
  "request_id": "123",
  "request_type": "ngo",
  "status": "APPROVED",
  "admin_id": 1,
  "rejection_reason": null
}
```

**Response:**
```json
{
  "status": true,
  "message": "Request status updated to APPROVED successfully"
}
```

### Browse Endpoints
All browse endpoints use the same filter:
```php
WHERE admin_status = 'accepted' 
  AND (status = 'approved' OR status = 'active')
```

This ensures:
- ✅ Only approved requests are visible
- ✅ Consistent filtering across all roles
- ✅ Single source of truth from database

---

## 🚀 Current Status

✅ **All components implemented and working:**
- Request submission
- Admin approval workflow
- Status-based visibility
- Role-specific filtering
- Database updates
- Notifications

✅ **Flow is complete and verified!**

