# 🔧 Complete Fix Guide - Forgot Password Error

## ❌ Error: "Unknown column 'email' in 'where clause'"

This error occurs because the `ngoforgot`, `volunteerforgot`, or `donorforgot` tables don't have the correct structure.

---

## ✅ Step 1: Check Table Structure (Diagnostic)

**Run this in your browser:**
```
http://localhost/helphup/api/diagnose_all_tables.php
```

This will show you:
- Which tables exist
- What columns each table has
- What's missing

---

## ✅ Step 2: Fix Tables (Automatic)

**Run this in your browser:**
```
http://localhost/helphup/api/fix_all_forgot_tables.php
```

This script will:
- Drop existing `ngoforgot`, `volunteerforgot`, `donorforgot` tables
- Recreate them with the correct structure
- Verify the columns

**OR manually in phpMyAdmin:**

1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `helphup` database
3. Go to SQL tab
4. Run this SQL:

```sql
-- Fix ngoforgot table
DROP TABLE IF EXISTS `ngoforgot`;
CREATE TABLE `ngoforgot` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL,
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Fix volunteerforgot table
DROP TABLE IF EXISTS `volunteerforgot`;
CREATE TABLE `volunteerforgot` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL,
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Fix donorforgot table
DROP TABLE IF EXISTS `donorforgot`;
CREATE TABLE `donorforgot` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL,
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
```

---

## ✅ Step 3: Verify PHP Code

The PHP files have been updated to:
- ✅ Use `mail` column for `ngos` table queries
- ✅ Use `email` column for `ngoforgot`/`volunteerforgot`/`donorforgot` tables

**Files already fixed:**
- `ngoforgot.php` ✅
- `volunteer_forgot.php` ✅
- `donor_forgot.php` ✅
- `ngo_login.php` ✅
- `ngo_register.php` ✅

---

## ✅ Step 4: Test

1. **Run the fix script:** `http://localhost/helphup/api/fix_all_forgot_tables.php`
2. **Open Android app**
3. **Go to Forgot Password**
4. **Enter email from `ngos` table** (use an email that exists)
5. **Click "Send OTP"**
6. **Should work! ✅**

---

## 📋 Summary of Changes

### Database Tables:
- `ngos` table uses `mail` column (NOT `email`)
- `ngoforgot`, `volunteerforgot`, `donorforgot` tables use `email` column

### PHP Code:
- Queries to `ngos` table: Use `mail` column
- Queries to `*forgot` tables: Use `email` column

### Required Table Structure:
Each forgot table needs:
- `id` (Primary Key, Auto Increment)
- `email` (VARCHAR 100)
- `otp` (VARCHAR 6)
- `expires_at` (TIMESTAMP)
- `used` (TINYINT)
- `created_at` (TIMESTAMP)

---

## 🆘 Still Getting Errors?

1. **Check diagnostic:** Run `diagnose_all_tables.php`
2. **Check table structure in phpMyAdmin**
3. **Verify columns match exactly**
4. **Check Apache error logs:** `C:\xampp\apache\logs\error.log`

---

**Last Updated:** 2026-01-03  
**Status:** Ready to fix

