# Complete Help Request Flow - All Roles

## Overview
This document describes the complete flow for all help request types: NGO requests, Volunteer requests, and Donor campaigns.

---

## 1️⃣ Volunteer Help Request Flow

### Submission
**Screen:** `VolunteerRaiseHelp.kt`
**Endpoint:** `volunteer_raise_help.php`
**Database:** `volunteer_requests` or `volunteerraisehelp` table

**Initial Status:**
- `admin_status` = `'pending'`
- `status` = `'pending'`

### Admin Review
**Screen:** `AdminManageRequests.kt` ✅
- Volunteer requests appear in "Manage Requests" page
- Admin can filter by "Volunteer" to see only volunteer requests
- Admin clicks on request → `AdminRequestDetails.kt`

### Admin Actions
**Screen:** `AdminRequestDetails.kt`

**Actions Available:**
1. ✅ **Verify** → Sets `admin_status='verified'`
2. ✅ **Accept** → Sets `admin_status='accepted'`, `status='approved'`
3. ❌ **Reject** → Sets `admin_status='rejected'`, `status='rejected'`

**Endpoint:** `update_request_status.php`
- Request type: `"volunteer"`
- Same accept/reject flow as NGO requests

### After Approval
**Visibility:**
- ✅ Visible to NGOs (in `NgoHelpOthers.kt`)
- ✅ Visible to Donors (in `DonorBrowseCause.kt`)
- ❌ NOT visible to Volunteers (same role type excluded)

---

## 2️⃣ Donor Campaign Flow

### Submission
**Screen:** `DonorRaiseDonation.kt`
**Endpoint:** `Donor_raise_help.php`
**Database:** `donor_campaigns` table

**Initial Status:**
- `admin_status` = `'pending'`
- `status` = `'pending'`

### Admin Review
**Screen:** `AdminManageCampaigns.kt` ✅ (Separate page for campaigns)
- Donor campaigns appear in "Manage Campaigns" page
- Admin can view all pending donor campaigns
- Admin clicks on campaign → `AdminRequestDetails.kt` (same detail screen)

### Admin Actions
**Screen:** `AdminRequestDetails.kt`

**Actions Available:**
1. ✅ **Verify** → Sets `admin_status='verified'`
2. ✅ **Accept** → Sets `admin_status='accepted'`, `status='approved'`
3. ❌ **Reject** → Sets `admin_status='rejected'`, `status='rejected'`

**Endpoint:** `update_request_status.php`
- Request type: `"donor"`
- Same accept/reject flow as NGO and Volunteer requests

### After Approval
**Visibility:**
- ✅ Visible to NGOs (in `NgoHelpOthers.kt`)
- ✅ Visible to Volunteers (in `VolunteerHelpOthers.kt`)
- ❌ NOT visible to Donors (same role type excluded)

---

## 3️⃣ NGO Help Request Flow (Reference)

### Submission
**Screen:** `NgoRaiseHelp.kt`
**Endpoint:** `ngo_raise_help.php`
**Database:** `ngoraisehelp` or `ngo_help_requests` table

**Initial Status:**
- `admin_status` = `'pending'`
- `status` = `'pending'`

### Admin Review
**Screen:** `AdminManageRequests.kt` ✅
- NGO requests appear in "Manage Requests" page
- Admin can filter by "NGO" to see only NGO requests
- Admin clicks on request → `AdminRequestDetails.kt`

### Admin Actions
**Screen:** `AdminRequestDetails.kt`

**Actions Available:**
1. ✅ **Verify** → Sets `admin_status='verified'`
2. ✅ **Accept** → Sets `admin_status='accepted'`, `status='approved'`
3. ❌ **Reject** → Sets `admin_status='rejected'`, `status='rejected'`

**Endpoint:** `update_request_status.php`
- Request type: `"ngo"`

### After Approval
**Visibility:**
- ✅ Visible to Volunteers (in `VolunteerHelpOthers.kt`)
- ✅ Visible to Donors (in `DonorBrowseCause.kt`)
- ❌ NOT visible to NGOs (same role type excluded)

---

## 📊 Admin Pages Summary

### Admin Manage Requests
**Screen:** `AdminManageRequests.kt`
**Shows:**
- ✅ NGO requests
- ✅ Volunteer requests
- ❌ Donor campaigns (excluded - go to Manage Campaigns)

**Filters:**
- All
- NGO
- Volunteer

### Admin Manage Campaigns
**Screen:** `AdminManageCampaigns.kt`
**Shows:**
- ✅ Donor campaigns only

**Purpose:**
- Separate page for managing donor campaigns
- Same accept/reject flow as requests

---

## 🔄 Unified Accept/Reject Flow

### Endpoint: `update_request_status.php`

**Works for ALL request types:**
- NGO requests (`request_type: "ngo"`)
- Volunteer requests (`request_type: "volunteer"`)
- Donor campaigns (`request_type: "donor"`)

**Request Format:**
```json
{
  "request_id": "123",
  "request_type": "ngo|volunteer|donor",
  "status": "APPROVED|REJECTED|PENDING",
  "admin_id": 1,
  "rejection_reason": "optional reason"
}
```

**Response:**
```json
{
  "status": true,
  "message": "Request status updated successfully"
}
```

**Status Mapping:**
- `"APPROVED"` → `admin_status='accepted'`, `status='approved'`
- `"REJECTED"` → `admin_status='rejected'`, `status='rejected'`
- `"PENDING"` → `admin_status='verified'`, `status='pending'`

---

## ✅ Complete Flow Verification

### Volunteer Request Flow
- [x] Volunteer submits request → `admin_status='pending'`
- [x] Request appears in Admin Manage Requests
- [x] Admin can verify/accept/reject
- [x] On accept → Visible to NGOs and Donors
- [x] Same accept/reject logic as NGO requests

### Donor Campaign Flow
- [x] Donor submits campaign → `admin_status='pending'`
- [x] Campaign appears in Admin Manage Campaigns (separate page)
- [x] Admin can verify/accept/reject
- [x] On accept → Visible to NGOs and Volunteers
- [x] Same accept/reject logic as NGO requests

### NGO Request Flow
- [x] NGO submits request → `admin_status='pending'`
- [x] Request appears in Admin Manage Requests
- [x] Admin can verify/accept/reject
- [x] On accept → Visible to Volunteers and Donors
- [x] Standard accept/reject logic

---

## 🎯 Key Points

1. **Volunteer requests** → Go to **Admin Manage Requests** (same page as NGO requests)
2. **Donor campaigns** → Go to **Admin Manage Campaigns** (separate page)
3. **Same accept/reject flow** → All use `update_request_status.php`
4. **Same visibility rules** → Only accepted requests visible to other roles
5. **Role exclusion** → Same role type cannot see their own requests/campaigns

---

## 📋 Admin Dashboard Navigation

```
Admin Dashboard
    ├── Manage Requests
    │   ├── NGO Requests
    │   └── Volunteer Requests
    └── Manage Campaigns
        └── Donor Campaigns
```

Both pages use the same `AdminRequestDetails.kt` screen for viewing details and accepting/rejecting.

