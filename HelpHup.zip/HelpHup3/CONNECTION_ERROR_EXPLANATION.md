﻿# ðŸ” Why "Connection Refused" Error Occurs

## âŒ Error Message
```
Connection failed: No connection could be made because the target machine actively refused it
```

---

## ðŸŽ¯ Root Cause

This error means your **Android app cannot connect to the PHP server** (Apache/XAMPP).

---

## ðŸ”´ Common Reasons

### 1. **Apache Server Not Running** â­ (Most Common - 90% of cases)

**What happens:**
- Your Android app tries to connect to: `http://10.22.186.166/helphup/api/ngoforgot.php`
- But Apache (web server) is not running on your PC
- The connection is refused because there's no server listening on port 80

**Fix:**
- Open XAMPP Control Panel
- Click **Start** next to Apache
- Wait for "Running" status

---

### 2. **Wrong IP Address**

**What happens:**
- Your PC's IP address changed (dynamic IP)
- App is using old IP: `10.22.186.166`
- Current IP might be different

**How to check:**
```bash
ipconfig
```
Look for "IPv4 Address" - it should match the IP in your app code

**Fix:**
- Update BASE_URL in Android code to match current IP
- Or use `10.0.2.2` if using Android Emulator (maps to localhost)

---

### 3. **Firewall Blocking Connection**

**What happens:**
- Windows Firewall blocks incoming connections to Apache
- Even if Apache is running, firewall prevents external access

**Fix:**
- Windows Firewall â†’ Allow Apache HTTP Server
- Or temporarily disable firewall for testing

---

### 4. **Different Network (WiFi)**

**What happens:**
- Android device and PC are on different WiFi networks
- Can't reach each other over network

**Fix:**
- Make sure both devices are on same WiFi network
- Or use Android Emulator (uses `10.0.2.2`)

---

### 5. **Port Not Available**

**What happens:**
- Port 80 (default Apache port) is already in use by another service
- Apache can't start or runs on different port

**Fix:**
- Check XAMPP logs for port conflicts
- Close other web servers (IIS, etc.)
- Or change Apache port in XAMPP config

---

## ðŸ§ª How to Diagnose

### Step 1: Check Apache Status
1. Open XAMPP Control Panel
2. Look at Apache row
3. Status should be **"Running"** (green)

### Step 2: Test in Browser
Open in browser (on your PC):
```
http://localhost/helphup/api/ngoforgot.php
```

**Expected Results:**
- âœ… **If it works:** Apache is running, problem is network/IP
- âŒ **If it doesn't work:** Apache is not running or port conflict

### Step 3: Test with IP
Open in browser:
```
http://10.22.186.166/helphup/api/ngoforgot.php
```

**Expected Results:**
- âœ… **If it works:** Server is accessible, check Android app IP
- âŒ **If it doesn't work:** Firewall or network issue

### Step 4: Check Current IP
```bash
ipconfig
```
Compare with IP in Android code: `10.22.186.166`

---

## ðŸ“Š Error Flow Diagram

```
Android App
    â†“
Tries to connect: http://10.22.186.166/helphup/api/ngoforgot.php
    â†“
Is Apache running? â†’ NO â†’ âŒ Connection Refused
    â†“
Is IP correct? â†’ NO â†’ âŒ Connection Refused
    â†“
Is Firewall blocking? â†’ YES â†’ âŒ Connection Refused
    â†“
Is same network? â†’ NO â†’ âŒ Connection Refused
    â†“
âœ… Success!
```

---

## âœ… Quick Fix Checklist

1. [ ] **Apache is Running**
   - XAMPP Control Panel â†’ Apache â†’ "Running" (green)

2. [ ] **Test in Browser**
   - `http://localhost/helphup/api/` works

3. [ ] **IP Address Correct**
   - `ipconfig` shows same IP as in app code

4. [ ] **Same Network**
   - PC and Android device on same WiFi

5. [ ] **Firewall Allows Apache**
   - Windows Firewall â†’ Allow Apache

---

## ðŸŽ¯ Most Likely Cause

**95% of the time, it's because Apache is not running.**

Simply start Apache in XAMPP Control Panel and the error will go away!

---

## ðŸ’¡ Prevention Tips

1. **Auto-start Apache:**
   - XAMPP Control Panel â†’ Config â†’ Autostart Apache

2. **Check Apache before testing:**
   - Always verify Apache is running before testing app

3. **Use Emulator for testing:**
   - Android Emulator uses `10.0.2.2` (always works)
   - No network/firewall issues

---

**Last Updated:** 2026-01-03

