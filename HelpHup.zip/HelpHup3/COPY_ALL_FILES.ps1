# PowerShell Script to Copy ALL Updated PHP Files to XAMPP Server
# Run this script as Administrator

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Copying ALL Updated PHP Files to XAMPP" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDir = Join-Path $scriptDir "xampp_files"
$targetDir = "C:\xampp\htdocs\helphup\api"

Write-Host "Source: $sourceDir" -ForegroundColor Yellow
Write-Host "Target: $targetDir" -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path $sourceDir)) {
    Write-Host "ERROR: Source directory not found: $sourceDir" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $targetDir)) {
    Write-Host "Creating target directory: $targetDir" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
}

$files = @(
    "ngo_verify_otp.php",
    "donor_verify_otp.php",
    "volunteer_verify_otp.php",
    "ngo_reset_password.php",
    "donor_reset_password.php",
    "volunteer_reset_password.php",
    "ngoforgot.php",
    "donor_forgot.php",
    "volunteer_forgot.php",
    "debug_otp.php",
    "setup_password_reset_table.php",
    "migrate_to_separate_tables.php",
    "test_otp_flow.php"
)

Write-Host "Files to copy:" -ForegroundColor Cyan
foreach ($file in $files) {
    Write-Host "  - $file" -ForegroundColor Gray
}
Write-Host ""

$successCount = 0
$failCount = 0

foreach ($file in $files) {
    $sourceFile = Join-Path $sourceDir $file
    $targetFile = Join-Path $targetDir $file
    
    if (Test-Path $sourceFile) {
        Copy-Item -Path $sourceFile -Destination $targetFile -Force
        Write-Host "Copied: $file" -ForegroundColor Green
        $successCount++
    } else {
        Write-Host "Not found: $file" -ForegroundColor Red
        $failCount++
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Copy Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Successfully copied: $successCount files" -ForegroundColor Green
if ($failCount -gt 0) {
    Write-Host "Failed: $failCount files" -ForegroundColor Red
}
Write-Host ""

Write-Host "Verifying files..." -ForegroundColor Yellow
foreach ($file in $files) {
    $targetFile = Join-Path $targetDir $file
    if (Test-Path $targetFile) {
        Write-Host "  OK: $file" -ForegroundColor Green
    } else {
        Write-Host "  MISSING: $file" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Cyan
Write-Host "  1. Create tables: http://localhost/helphup/api/setup_password_reset_table.php" -ForegroundColor Yellow
Write-Host "  2. Test: http://localhost/helphup/api/debug_otp.php?email=your@email.com" -ForegroundColor Yellow
Write-Host ""
