﻿# ðŸ“‹ Copy Files to XAMPP Server - Quick Fix for 404 Error

## âš ï¸ Problem
Getting **HTTP 404 Not Found** when verifying OTP means the PHP files are not on your XAMPP server.

## âœ… Solution: Copy Files to Server

### Step 1: Locate Your Files
Your files are in:
```
C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\
```

### Step 2: Copy to XAMPP Server
Copy these files to:
```
C:\xampp\htdocs\helphup\api\
```

**Files to Copy:**
1. âœ… `ngo_verify_otp.php`
2. âœ… `ngo_reset_password.php`
3. âœ… `donor_verify_otp.php`
4. âœ… `donor_reset_password.php`
5. âœ… `volunteer_verify_otp.php`
6. âœ… `volunteer_reset_password.php`

### Step 3: Verify Files Are There
After copying, your `api` folder should have:
```
C:\xampp\htdocs\helphup\api\
â”œâ”€â”€ config.php
â”œâ”€â”€ ngoforgot.php
â”œâ”€â”€ ngo_verify_otp.php          â† NEW FILE
â”œâ”€â”€ ngo_reset_password.php       â† NEW FILE
â”œâ”€â”€ donor_forgot.php
â”œâ”€â”€ donor_verify_otp.php         â† NEW FILE
â”œâ”€â”€ donor_reset_password.php     â† NEW FILE
â”œâ”€â”€ volunteer_forgot.php
â”œâ”€â”€ volunteer_verify_otp.php     â† NEW FILE
â””â”€â”€ volunteer_reset_password.php â† NEW FILE
```

### Step 4: Test in Browser
Open in browser to verify:
```
http://localhost/helphup/api/ngo_verify_otp.php
```

**Expected:** Should show blank page or JSON error (not 404)

---

## ðŸš€ Quick Copy Method

### Option 1: Manual Copy
1. Open File Explorer
2. Go to: `C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\`
3. Select all 6 files (verify_otp and reset_password for ngo, donor, volunteer)
4. Copy (Ctrl+C)
5. Go to: `C:\xampp\htdocs\helphup\api\`
6. Paste (Ctrl+V)

### Option 2: Command Line (Faster)
Open Command Prompt (as Administrator) and run:

```cmd
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\ngo_verify_otp.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\ngo_reset_password.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\donor_verify_otp.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\donor_reset_password.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\volunteer_verify_otp.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\volunteer_reset_password.php" "C:\xampp\htdocs\helphup\api\"
```

---

## âœ… Verification Checklist

After copying, verify:

- [ ] File exists: `C:\xampp\htdocs\helphup\api\ngo_verify_otp.php`
- [ ] File exists: `C:\xampp\htdocs\helphup\api\ngo_reset_password.php`
- [ ] Apache is running in XAMPP
- [ ] Test URL works: `http://localhost/helphup/api/ngo_verify_otp.php` (should not show 404)
- [ ] Try OTP verification in app again

---

## ðŸ” Still Getting 404?

### Check 1: File Path
Make sure files are in:
```
C:\xampp\htdocs\helphup\api\ngo_verify_otp.php
```
NOT in:
```
C:\xampp\htdocs\helphup\api\xampp_files\ngo_verify_otp.php  âŒ WRONG
```

### Check 2: Apache Running
- Open XAMPP Control Panel
- Make sure Apache shows "Running" (green)

### Check 3: File Permissions
- Right-click file â†’ Properties
- Make sure "Read" is checked

### Check 4: Test Direct URL
Open in browser:
```
http://10.26.77.227/helphup/api/ngo_verify_otp.php
```
Should NOT show 404.

---

## ðŸ“ Quick Test

After copying files, test in browser:

1. **Test Verify OTP:**
   ```
   http://localhost/helphup/api/ngo_verify_otp.php
   ```
   Should show JSON error (not 404) - this is normal, means file exists!

2. **Test Reset Password:**
   ```
   http://localhost/helphup/api/ngo_reset_password.php
   ```
   Should show JSON error (not 404) - this is normal!

---

**After copying, the 404 error should be fixed!** âœ…

