# 🚀 Deploy Unified Help Request System

## 📋 Quick Deployment Steps

### **1. Database Setup** ✅
```sql
-- Open phpMyAdmin
-- Select your 'helphup' database
-- Import this file: c:\ANDROID\HelpHup3\xampp_files\NEW_UNIFIED_HELP_SYSTEM.sql
```

### **2. API Files** ✅
```bash
# Files are already copied to:
c:\ANDROID\HelpHup3\xampp_files\api\
├── unified_create_help_request.php
├── unified_get_admin_requests.php  
├── unified_update_request_status.php
├── unified_get_public_requests.php
└── unified_get_my_requests.php
```

### **3. Android App Updates** ✅
**Updated Files:**
- ✅ `NgoRaiseHelp.kt` - Uses unified endpoint
- ✅ `VolunteerHelpOthers.kt` - Uses unified endpoint  
- ✅ `NgoMyRequests.kt` - New page for user's requests

**Still Need to Update:**
- ⏳ `VolunteerRaiseHelp.kt`
- ⏳ `DonorRaiseDonation.kt`
- ⏳ `DonorBrowseCause.kt`
- ⏳ Add "My Requests" pages for Volunteer & Donor

---

## 🧪 Test the Complete Flow

### **Step 1: Test NGO Request Creation**
1. Open Android app
2. Login as NGO
3. Go to "Raise Help Request"
4. Fill form and submit
5. Check if request appears in database

### **Step 2: Test Admin Approval**
1. Access: `http://10.73.39.192/helphup/api/unified_get_admin_requests.php?status=pending`
2. Should show the NGO request with status "pending"
3. Test approval using `unified_update_request_status.php`

### **Step 3: Test Public Visibility**
1. Access: `http://10.73.39.192/helphup/api/unified_get_public_requests.php?exclude_requester_type=volunteer`
2. Should show approved requests (excluding volunteer's own type)

### **Step 4: Test My Requests Page**
1. Access: `http://10.73.39.192/helphup/api/unified_get_my_requests.php?requester_type=ngo&requester_id=1`
2. Should show NGO's own requests with status

---

## 🔧 API Endpoint Testing

### **Create Request (NGO)**
```bash
curl -X POST "http://10.73.39.192/helphup/api/unified_create_help_request.php" \
-H "Content-Type: application/json" \
-d '{
  "requester_type": "ngo",
  "requester_id": 1,
  "requester_name": "Test NGO",
  "requester_email": "test@ngo.com",
  "requester_phone": "+91-9876543210",
  "request_title": "Test Food Distribution",
  "category": "Food Distribution",
  "description": "Need help distributing food",
  "urgency_level": "High",
  "required_amount": "50000",
  "date_needed": "2026-01-25",
  "contact_number": "+91-9876543210"
}'
```

### **Get Admin Requests**
```bash
curl "http://10.73.39.192/helphup/api/unified_get_admin_requests.php?status=pending"
```

### **Update Request Status**
```bash
curl -X POST "http://10.73.39.192/helphup/api/unified_update_request_status.php" \
-H "Content-Type: application/json" \
-d '{
  "request_id": 1,
  "status": "approved",
  "admin_id": 1
}'
```

### **Get Public Requests**
```bash
curl "http://10.73.39.192/helphup/api/unified_get_public_requests.php?exclude_requester_type=volunteer"
```

### **Get My Requests**
```bash
curl "http://10.73.39.192/helphup/api/unified_get_my_requests.php?requester_type=ngo&requester_id=1"
```

---

## 📱 Android App Integration Status

### ✅ **Completed**
- **Database Tables**: All new tables created
- **API Endpoints**: All 5 endpoints deployed
- **NGO Raise Help**: Updated to use unified system
- **Volunteer Help Others**: Updated to use unified system
- **NGO My Requests**: New page created

### ⏳ **In Progress**
- **Volunteer Raise Help**: Needs update
- **Donor Raise Donation**: Needs update  
- **Donor Browse Cause**: Needs update
- **Volunteer My Requests**: Needs creation
- **Donor My Requests**: Needs creation

### 🎯 **Next Steps**
1. Update remaining Raise Help pages
2. Update remaining Help Others pages
3. Create remaining My Requests pages
4. Test complete end-to-end flow

---

## 🔍 Troubleshooting

### **Common Issues:**
1. **404 Error**: Check if PHP files are in correct `api/` directory
2. **500 Error**: Check PHP error logs in XAMPP
3. **Database Error**: Verify SQL was imported correctly
4. **No Data**: Check if requests have `status = 'approved'` for public visibility

### **Debug Commands:**
```bash
# Check if API files exist
ls c:\ANDROID\HelpHup3\xampp_files\api\

# Test database connection
curl "http://10.73.39.192/helphup/api/unified_get_public_requests.php"

# Check XAMPP error logs
# Location: C:\xampp\apache\logs\error.log
```

---

## ✅ **Current Status**

**🟢 READY TO TEST:**
- Database tables created
- API endpoints deployed
- NGO request creation working
- Volunteer Help Others working
- NGO My Requests page ready

**🟡 NEEDS COMPLETION:**
- Volunteer & Donor request creation
- Donor Help Others page
- Volunteer & Donor My Requests pages

The core unified system is **functional** and ready for testing. You can start testing the NGO flow while completing the remaining pages.
