# 📧 How to Get OTP Sent to Your Email

## Overview
Currently, your system is using PHP `mail()` which doesn't work on XAMPP. To send OTPs to actual email addresses, you need to set up Gmail SMTP using PHPMailer.

---

## ✅ Step-by-Step Instructions

### **Step 1: Get Gmail App Password** (5 minutes)

1. **Go to Google Account Security:**
   - Open: https://myaccount.google.com/security
   - Sign in with your Gmail account

2. **Enable 2-Step Verification** (if not already enabled):
   - Scroll to "2-Step Verification"
   - Click "Get started" and follow the prompts
   - You'll need your phone to verify

3. **Generate App Password:**
   - After enabling 2-Step Verification, go back to Security page
   - Scroll down and click on **"App passwords"**
   - You may need to sign in again
   - Select app: **"Mail"**
   - Select device: **"Other (Custom name)"**
   - Type: **"HelpHup"**
   - Click **"Generate"**

4. **Copy the 16-character password:**
   - You'll see a password like: `abcd efgh ijkl mnop`
   - **Copy this password** (remove spaces: `abcdefghijklmnop`)
   - ⚠️ **Save it somewhere safe - you won't see it again!**

---

### **Step 2: Download PHPMailer** (2 minutes)

1. **Download PHPMailer:**
   - Go to: https://github.com/PHPMailer/PHPMailer/archive/refs/heads/master.zip
   - Or search: "PHPMailer GitHub" and download the ZIP

2. **Extract the ZIP file:**
   - Right-click → Extract All
   - You'll see a folder named `PHPMailer-master`

3. **Copy PHPMailer folder:**
   - Open the extracted folder
   - Inside, you'll see a folder named `PHPMailer`
   - Copy this `PHPMailer` folder
   - Paste it to: `C:\xampp\htdocs\helphup\api\PHPMailer\`
   
   **Final structure should be:**
   ```
   C:\xampp\htdocs\helphup\api\
   ├── PHPMailer\
   │   ├── src\
   │   │   ├── Exception.php
   │   │   ├── PHPMailer.php
   │   │   └── SMTP.php
   │   └── ...
   ├── email_config.php
   ├── config.php
   └── ...
   ```

---

### **Step 3: Update email_config.php** (3 minutes)

1. **Open the file:**
   - Navigate to: `C:\xampp\htdocs\helphup\api\email_config.php`
   - Open with Notepad or any text editor

2. **Change line 10:**
   ```php
   // FROM:
   define('USE_PHP_MAIL', true);
   
   // TO:
   define('USE_PHP_MAIL', false);  // Use SMTP instead
   ```

3. **Update Gmail credentials (lines 19-20):**
   ```php
   // Replace these lines:
   define('SMTP_USERNAME', 'your-email@gmail.com');  // Replace with your Gmail
   define('SMTP_PASSWORD', 'your-app-password');     // Replace with Gmail App Password
   
   // WITH your actual Gmail and App Password:
   define('SMTP_USERNAME', 'youremail@gmail.com');  // Your Gmail address
   define('SMTP_PASSWORD', 'abcdefghijklmnop');     // The 16-char app password from Step 1
   ```

4. **Update FROM email (line 13):**
   ```php
   // Change:
   define('SMTP_FROM_EMAIL', 'noreply@helphup.com');
   
   // To:
   define('SMTP_FROM_EMAIL', 'youremail@gmail.com'); // Same as SMTP_USERNAME
   ```

5. **Save the file**

---

### **Step 4: Restart Apache** (1 minute)

1. **Open XAMPP Control Panel**
2. **Click "Stop"** next to Apache (wait until it stops)
3. **Click "Start"** next to Apache (wait until it shows "Running" in green)

---

### **Step 5: Test Email Sending** (2 minutes)

1. **Create a test file** (optional but recommended):
   - Create file: `C:\xampp\htdocs\helphup\api\test_email.php`
   - Copy this code:

   ```php
   <?php
   require_once 'email_config.php';
   
   $testEmail = $_GET['email'] ?? 'your-email@gmail.com';
   $testOTP = '123456';
   
   echo "Testing email to: $testEmail<br>";
   echo "Sending OTP: $testOTP<br><br>";
   
   $result = sendOTPEmail($testEmail, $testOTP, 'Test User');
   
   if ($result['success']) {
       echo "<h2 style='color: green;'>✅ SUCCESS!</h2>";
       echo "<p>" . $result['message'] . "</p>";
       echo "<p>Check your inbox for the email.</p>";
   } else {
       echo "<h2 style='color: red;'>❌ FAILED</h2>";
       echo "<p>" . $result['message'] . "</p>";
   }
   ?>
   ```

2. **Test in browser:**
   - Open: `http://localhost/helphup/api/test_email.php?email=your-email@gmail.com`
   - Replace `your-email@gmail.com` with your actual Gmail
   - You should see "SUCCESS!" message
   - Check your Gmail inbox (and spam folder)

---

### **Step 6: Test in Your App**

1. **Open your Android app**
2. **Go to Forgot Password screen**
3. **Enter your email address**
4. **Click "Send OTP"**
5. **Check your email inbox** - you should receive the OTP!

---

## ✅ Verification Checklist

- [ ] Gmail 2-Step Verification enabled
- [ ] Gmail App Password generated and copied
- [ ] PHPMailer folder copied to `C:\xampp\htdocs\helphup\api\PHPMailer\`
- [ ] `email_config.php` updated:
  - [ ] `USE_PHP_MAIL = false`
  - [ ] `SMTP_USERNAME` = your Gmail
  - [ ] `SMTP_PASSWORD` = your app password
  - [ ] `SMTP_FROM_EMAIL` = your Gmail
- [ ] Apache restarted
- [ ] Test email sent successfully
- [ ] OTP received in email from app

---

## 🔧 Troubleshooting

### **Error: "PHPMailer not found"**
- **Solution:** Make sure PHPMailer folder is at: `C:\xampp\htdocs\helphup\api\PHPMailer\`
- Check that `PHPMailer/src/PHPMailer.php` exists

### **Error: "SMTP connect() failed"**
- **Solution:** 
  - Check your Gmail and App Password are correct
  - Make sure 2-Step Verification is enabled
  - Try generating a new App Password

### **Error: "Authentication failed"**
- **Solution:**
  - Use the 16-character App Password (not your regular Gmail password)
  - Make sure there are no spaces in the password
  - Regenerate App Password if needed

### **Email goes to Spam**
- **Solution:** This is normal for first-time emails
- Check your Spam/Junk folder
- Mark as "Not Spam" to train Gmail

### **Still not working?**
1. Check Apache error log: `C:\xampp\apache\logs\error.log`
2. Make sure Apache is running
3. Verify file paths are correct
4. Try the test_email.php file first

---

## 📝 Quick Reference

**File to edit:** `C:\xampp\htdocs\helphup\api\email_config.php`

**Key settings:**
```php
define('USE_PHP_MAIL', false);  // Must be false for SMTP
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-16-char-app-password');
define('SMTP_FROM_EMAIL', 'your-email@gmail.com');
```

**PHPMailer location:** `C:\xampp\htdocs\helphup\api\PHPMailer\`

---

## 🎉 Success!

Once set up correctly, when users request OTP:
- ✅ OTP will be generated
- ✅ Email will be sent to their inbox
- ✅ They'll receive a beautiful HTML email with the OTP
- ✅ No more "Email sending failed" error!

---

**Time Required:** ~15 minutes  
**Difficulty:** Easy ⭐⭐

