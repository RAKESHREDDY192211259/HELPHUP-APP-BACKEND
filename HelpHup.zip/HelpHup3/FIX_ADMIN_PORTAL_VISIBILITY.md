# Fix: Volunteer & Donor Requests Not Showing in Admin Portal

## Problem
Volunteer requests and donor campaigns are being submitted and saved to the database, but they're not appearing in the admin portal for acceptance/rejection.

## Root Cause
The `volunteer_requests` and `donor_campaigns` tables might be missing the `admin_status` column, which is required for:
1. Filtering pending requests in admin portal
2. Tracking admin actions (accept/reject)
3. Making requests visible to other roles after approval

## Solution

### Step 1: Run SQL Script (Recommended)

Run this SQL script in phpMyAdmin to add missing columns:

**File:** `xampp_files/add_admin_status_to_tables.sql`

**How to run:**
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `helphup` database
3. Click "SQL" tab
4. Copy and paste the entire content from `add_admin_status_to_tables.sql`
5. Click "Go"

**What it does:**
- Adds `admin_status` column to `volunteer_requests` table
- Adds `admin_status` column to `donor_campaigns` table
- Adds `admin_id` column (tracks which admin reviewed)
- Adds `admin_reviewed_at` column (timestamp of review)
- Adds `rejection_reason` column (for rejected requests)
- Updates existing records to set `admin_status='pending'`

---

### Step 2: Run PHP Fix Script (Alternative)

If you prefer to run via browser:

**File:** `xampp_files/check_and_fix_admin_status.php`

**How to run:**
1. Make sure XAMPP Apache is running
2. Open browser
3. Go to: `http://localhost/helphup/api/check_and_fix_admin_status.php`
4. You'll see JSON response confirming columns were added

---

### Step 3: Verify Tables

After running the script, verify in phpMyAdmin:

```sql
-- Check volunteer_requests columns
SHOW COLUMNS FROM volunteer_requests;

-- Should see:
-- admin_status VARCHAR(20)
-- admin_id INT(11)
-- admin_reviewed_at TIMESTAMP
-- rejection_reason TEXT

-- Check donor_campaigns columns
SHOW COLUMNS FROM donor_campaigns;

-- Should see same columns as above
```

---

### Step 4: Update Existing Records

If you already have submitted requests that don't have `admin_status`:

```sql
-- Update volunteer_requests
UPDATE volunteer_requests 
SET admin_status = 'pending' 
WHERE admin_status IS NULL;

-- Update donor_campaigns
UPDATE donor_campaigns 
SET admin_status = 'pending' 
WHERE admin_status IS NULL;
```

---

## Verification

### Check Pending Counts

```sql
-- Count pending volunteer requests
SELECT COUNT(*) as pending_volunteer_requests 
FROM volunteer_requests 
WHERE admin_status = 'pending' OR admin_status IS NULL;

-- Count pending donor campaigns
SELECT COUNT(*) as pending_donor_campaigns 
FROM donor_campaigns 
WHERE admin_status = 'pending' OR admin_status IS NULL;
```

### Test in Admin Portal

1. **Admin Manage Requests** page should show:
   - Volunteer requests with `admin_status='pending'`
   - NGO requests with `admin_status='pending'`

2. **Admin Manage Campaigns** page should show:
   - Donor campaigns with `admin_status='pending'`

---

## Code Changes Made

### 1. volunteer_raise_help.php
- ✅ Improved error handling
- ✅ Checks if `admin_status` column exists before INSERT
- ✅ Auto-adds column if missing (with fallback)

### 2. Donor_raise_help.php
- ✅ Improved error handling
- ✅ Checks if `admin_status` column exists before INSERT
- ✅ Auto-adds column if missing (with fallback)

### 3. SQL Scripts Created
- ✅ `add_admin_status_to_tables.sql` - Safe column addition script
- ✅ `check_and_fix_admin_status.php` - PHP-based fix script

---

## After Fixing

Once the columns are added:

1. ✅ **New submissions** will automatically set `admin_status='pending'`
2. ✅ **Existing submissions** will be updated to `admin_status='pending'`
3. ✅ **Admin portal** will show all pending requests/campaigns
4. ✅ **Accept/Reject** will work correctly

---

## Troubleshooting

### Issue: Still not showing in admin portal

**Check 1:** Verify columns exist
```sql
SHOW COLUMNS FROM volunteer_requests LIKE 'admin_status';
SHOW COLUMNS FROM donor_campaigns LIKE 'admin_status';
```

**Check 2:** Verify records have admin_status
```sql
SELECT request_id, admin_status FROM volunteer_requests LIMIT 5;
SELECT campaign_id, admin_status FROM donor_campaigns LIMIT 5;
```

**Check 3:** Test admin endpoint directly
- Browser: `http://localhost/helphup/api/admin_get_pending_requests.php?request_type=volunteer`
- Should return JSON with pending volunteer requests

**Check 4:** Check Android Logcat
- Look for API call errors
- Check response status and data

---

## Expected Behavior After Fix

### Volunteer Request Flow
1. Volunteer submits request → Saved with `admin_status='pending'`
2. Admin opens "Manage Requests" → Sees volunteer request
3. Admin clicks request → Views details
4. Admin accepts/rejects → Status updated
5. If accepted → Visible to NGOs and Donors

### Donor Campaign Flow
1. Donor submits campaign → Saved with `admin_status='pending'`
2. Admin opens "Manage Campaigns" → Sees donor campaign
3. Admin clicks campaign → Views details
4. Admin accepts/rejects → Status updated
5. If accepted → Visible to NGOs and Volunteers

---

## Summary

✅ **Fixed:** Added automatic column checking in INSERT statements
✅ **Created:** SQL script to safely add missing columns
✅ **Created:** PHP script to check and fix columns
✅ **Improved:** Error handling in submission endpoints

**Next Steps:**
1. Run the SQL script or PHP fix script
2. Verify columns exist
3. Test submission and admin portal visibility

