# 🔧 Fix "Connection Refused" Error

## ❌ Error Message
```
Connection failed: No connection could be made because the target machine actively refused it
```

## ✅ Solution

This error means **Apache server is not running** in XAMPP.

### Step 1: Start Apache Server

1. **Open XAMPP Control Panel**
   - Look for XAMPP icon in system tray, OR
   - Search "XAMPP Control Panel" in Windows Start menu

2. **Start Apache**
   - Find **Apache** in the list
   - Click **Start** button next to Apache
   - Wait until it shows **"Running"** in green color

3. **Verify Apache is Running**
   - The status should show: `Apache | Running`
   - Port should show: `80` or `8080`

### Step 2: Test Server

Open in browser:
```
http://localhost/helphup/api/ngoforgot.php
```

If you see JSON response or error page, Apache is running correctly.

### Step 3: Try Again in App

Go back to your Android app and try "Forgot Password" again.

---

## 🔍 Additional Checks

### If Apache Won't Start:

1. **Port 80 is in use**
   - Close other web servers (IIS, other Apache instances)
   - Or change Apache port in XAMPP config

2. **Check Error Log**
   - Click **Logs** button next to Apache in XAMPP
   - Look for error messages

3. **Run as Administrator**
   - Right-click XAMPP Control Panel
   - Select "Run as administrator"

---

## ✅ Quick Checklist

- [ ] XAMPP Control Panel is open
- [ ] Apache shows "Running" (green)
- [ ] Port 80/8080 is active
- [ ] Test URL works in browser: `http://localhost/helphup/api/`
- [ ] Try forgot password again in app

---

**Most Common Cause:** Apache is not running. Just start it in XAMPP Control Panel!

