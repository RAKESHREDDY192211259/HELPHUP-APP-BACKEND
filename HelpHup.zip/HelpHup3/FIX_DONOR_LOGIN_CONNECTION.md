﻿# Fix: Donor Login Connection Error

## ðŸš¨ Error Message
"Connection failed: No connection could be made because the target machine actively refused it"

## âœ… Quick Fix Steps

### Step 1: Check XAMPP Apache Status

1. **Open XAMPP Control Panel**
2. **Check Apache status:**
   - âœ… Green = Running (Good!)
   - âŒ Not running = **START IT!**

**If Apache is not running:**
1. Click "Start" next to Apache
2. Wait until status shows green
3. Try login again

---

### Step 2: Verify IP Address

The app uses: `http://10.26.77.227/helphup/api/`

**Check if this IP is correct:**
1. On your PC, open Command Prompt (cmd)
2. Type: `ipconfig`
3. Look for "IPv4 Address" under your WiFi adapter
4. It should match: `10.26.77.227`

**If IP is different:**
- Update BASE_URL in the app code, OR
- Use the correct IP address

---

### Step 3: Test Connection from Phone Browser

1. **Make sure phone and PC are on SAME WiFi network**
2. **Open browser on phone**
3. **Type this URL:**
   ```
   http://10.26.77.227/helphup/api/donor_login.php
   ```
4. **Expected result:**
   - Should show: `{"status":false,"message":"Email and password are required"}`
   - If you see this â†’ Server is working! âœ…
   - If you see error â†’ Server not accessible âŒ

---

### Step 4: Check Windows Firewall

**If browser test fails:**

1. **Open Windows Defender Firewall**
2. **Click "Allow an app through firewall"**
3. **Find "Apache HTTP Server"**
4. **Check both "Private" and "Public" boxes**
5. **Click OK**

**OR temporarily disable firewall to test:**
- If login works after disabling â†’ Firewall is blocking
- Re-enable firewall and add Apache exception

---

### Step 5: Verify XAMPP Configuration

**Check Apache is listening on correct port:**
1. Open XAMPP Control Panel
2. Click "Config" next to Apache
3. Select "httpd.conf"
4. Look for: `Listen 80`
5. Should be listening on port 80

---

## ðŸ” Verification Checklist

- [ ] XAMPP Apache is **RUNNING** (green status)
- [ ] IP address is **10.26.77.227**
- [ ] Phone and PC on **SAME WiFi**
- [ ] Browser test works (shows JSON response)
- [ ] Windows Firewall allows Apache
- [ ] PHP files are in: `C:\xampp\htdocs\helphup\api\`

---

## ðŸ“‹ Common Issues

### Issue 1: Apache Won't Start
**Cause:** Port 80 might be in use
**Fix:**
1. Check if Skype or other app is using port 80
2. Close those apps
3. Try starting Apache again
4. Or change Apache port in httpd.conf

### Issue 2: IP Changed
**Cause:** WiFi IP address changed
**Fix:**
1. Run `ipconfig` to get new IP
2. Update BASE_URL in app code
3. Or use static IP

### Issue 3: Different WiFi Networks
**Cause:** Phone and PC on different networks
**Fix:**
1. Connect both to same WiFi
2. Verify same network name (SSID)

---

## ðŸ§ª Quick Test Commands

### Test 1: Check Apache Running
```
http://localhost/helphup/api/donor_login.php
```
Should return JSON (even if error, it's JSON)

### Test 2: Check IP Accessible
```
http://10.26.77.227/helphup/api/donor_login.php
```
From phone browser - should return JSON

### Test 3: Check File Exists
```
http://localhost/helphup/api/config.php
```
Should show blank or error (not 404)

---

## âœ… After Fixing

Once connection works:
1. âœ… Login should work
2. âœ… No more connection errors
3. âœ… Can access donor dashboard

---

## ðŸ“ž Still Not Working?

Check error logs:
1. **Apache Error Log:** `C:\xampp\apache\logs\error.log`
2. **PHP Error Log:** Check XAMPP logs
3. **Android Logcat:** Look for detailed error messages

**Most Common Fix:**
- âœ… **START XAMPP APACHE** - This fixes 90% of connection issues!

