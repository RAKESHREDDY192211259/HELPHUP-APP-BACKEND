# 🔧 Fix Forgot Password Tables - Column Error

## ❌ Error: "Unknown column 'email' in 'where clause'"

This error means the `ngoforgot`, `volunteerforgot`, or `donorforgot` tables don't have the correct columns.

---

## ✅ Solution: Check Table Structure First

### Step 1: Check Current Table Structure

**Run this in your browser:**
```
http://localhost/helphup/api/check_forgot_tables.php
```

This will show you:
- Which tables exist
- What columns each table has
- What columns are missing

---

## ✅ Solution: Fix Tables in phpMyAdmin

### Step 1: Open phpMyAdmin
```
http://localhost/phpmyadmin
```

### Step 2: Select Database
- Click on `helphup` database in the left sidebar

### Step 3: Go to SQL Tab
- Click the "SQL" tab at the top

### Step 4: Run This SQL

**Option A: Recreate Tables (Recommended - if you don't have important data)**

Copy and paste this SQL:

```sql
-- Fix ngoforgot table
DROP TABLE IF EXISTS `ngoforgot`;
CREATE TABLE `ngoforgot` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL,
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `idx_email_otp` (`email`, `otp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Fix volunteerforgot table
DROP TABLE IF EXISTS `volunteerforgot`;
CREATE TABLE `volunteerforgot` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL,
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `idx_email_otp` (`email`, `otp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Fix donorforgot table
DROP TABLE IF EXISTS `donorforgot`;
CREATE TABLE `donorforgot` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL,
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `idx_email_otp` (`email`, `otp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
```

**Click "Go" to execute**

---

**Option B: Add Missing Columns (If tables exist but columns are missing)**

If you want to keep existing data, you can add columns:

```sql
-- Add email column if missing
ALTER TABLE `ngoforgot` ADD COLUMN IF NOT EXISTS `email` VARCHAR(100) NOT NULL AFTER `id`;
ALTER TABLE `volunteerforgot` ADD COLUMN IF NOT EXISTS `email` VARCHAR(100) NOT NULL AFTER `id`;
ALTER TABLE `donorforgot` ADD COLUMN IF NOT EXISTS `email` VARCHAR(100) NOT NULL AFTER `id`;

-- Add otp column if missing
ALTER TABLE `ngoforgot` ADD COLUMN IF NOT EXISTS `otp` VARCHAR(6) NOT NULL AFTER `email`;
ALTER TABLE `volunteerforgot` ADD COLUMN IF NOT EXISTS `otp` VARCHAR(6) NOT NULL AFTER `email`;
ALTER TABLE `donorforgot` ADD COLUMN IF NOT EXISTS `otp` VARCHAR(6) NOT NULL AFTER `email`;

-- Add expires_at column if missing
ALTER TABLE `ngoforgot` ADD COLUMN IF NOT EXISTS `expires_at` TIMESTAMP NOT NULL AFTER `otp`;
ALTER TABLE `volunteerforgot` ADD COLUMN IF NOT EXISTS `expires_at` TIMESTAMP NOT NULL AFTER `otp`;
ALTER TABLE `donorforgot` ADD COLUMN IF NOT EXISTS `expires_at` TIMESTAMP NOT NULL AFTER `otp`;

-- Add used column if missing
ALTER TABLE `ngoforgot` ADD COLUMN IF NOT EXISTS `used` TINYINT(1) DEFAULT 0 AFTER `expires_at`;
ALTER TABLE `volunteerforgot` ADD COLUMN IF NOT EXISTS `used` TINYINT(1) DEFAULT 0 AFTER `expires_at`;
ALTER TABLE `donorforgot` ADD COLUMN IF NOT EXISTS `used` TINYINT(1) DEFAULT 0 AFTER `expires_at`;
```

**Note:** MySQL doesn't support `ADD COLUMN IF NOT EXISTS`, so you may need to check manually or use Option A.

---

## ✅ Verify Fix

After running the SQL:

1. **Check tables in phpMyAdmin:**
   - Click on `helphup` database
   - Click on `ngoforgot` table
   - Check "Structure" tab
   - Verify columns: `id`, `email`, `otp`, `expires_at`, `used`, `created_at`

2. **Test forgot password:**
   - Open Android app
   - Go to Forgot Password
   - Enter email
   - Click "Send OTP"
   - Should work without errors!

---

## 📋 Required Table Structure

Each forgot table should have:

| Column | Type | Description |
|--------|------|-------------|
| `id` | INT(11) AUTO_INCREMENT | Primary key |
| `email` | VARCHAR(100) | User email address |
| `otp` | VARCHAR(6) | 6-digit OTP code |
| `expires_at` | TIMESTAMP | Expiration time |
| `used` | TINYINT(1) | 0 = unused, 1 = used |
| `created_at` | TIMESTAMP | Creation time |

---

## 🆘 Still Getting Errors?

1. **Check table structure:**
   - Run `check_forgot_tables.php` script
   - Compare with required structure

2. **Check PHP code:**
   - Make sure PHP files use correct column names
   - Files: `ngoforgot.php`, `volunteer_forgot.php`, `donor_forgot.php`

3. **Check database name:**
   - Should be `helphup` (check `config.php`)

---

**Last Updated:** 2026-01-03  
**Status:** Ready to fix

