# 🔧 CRITICAL FIX: Table Name Mismatch

## Problem Found:
Your PHP files are using **singular** table names:
- `ngo`
- `donor` 
- `volunteer`

But your database has **plural** table names:
- `ngos`
- `donors`
- `volunteers`

## Solution: Update All PHP Files

You need to change table names in these files:

### Files to Update:
1. `ngo_login.php` - Change `ngo` to `ngos`
2. `ngo_register.php` - Change `ngo` to `ngos`
3. `ngoforgot.php` - Change `ngo` to `ngos`
4. `donor_login.php` - Change `donor` to `donors`
5. `donor_register.php` - Change `donor` to `donors`
6. `donor_forgot.php` - Change `donor` to `donors`
7. `volunteer_login.php` - Change `volunteer` to `volunteers`
8. `volunteer_register.php` - Change `volunteer` to `volunteers`
9. `volunteer_forgot.php` - Change `volunteer` to `volunteers`

### Quick Fix:
Find and replace in all PHP files:
- `FROM ngo` → `FROM ngos`
- `FROM donor` → `FROM donors`
- `FROM volunteer` → `FROM volunteers`
- `INSERT INTO ngo` → `INSERT INTO ngos`
- `INSERT INTO donor` → `INSERT INTO donors`
- `INSERT INTO volunteer` → `INSERT INTO volunteers`

## Location:
Update files in: `C:\xampp\htdocs\helphup\api\` (or `C:\xampp\htdocs\HELPHUP\api\`)

