﻿# ðŸ”§ Forgot Password Setup Guide

## âŒ Error Fix: Table 'helphup.password_reset_tokens' doesn't exist

The forgot password feature requires the `password_reset_tokens` table to be created in your database.

---

## âœ… Solution 1: Automatic Setup (Recommended)

**Easiest Method - Run the setup script:**

1. **Make sure XAMPP Apache and MySQL are running**

2. **Open your browser and go to:**
   ```
   http://localhost/helphup/api/setup_password_reset_table.php
   ```
   OR if using network IP:
   ```
   http://10.22.186.166/helphup/api/setup_password_reset_table.php
   ```

3. **The script will:**
   - Check if the table exists
   - Create it if it doesn't exist
   - Show you the table structure
   - Display success/error messages

4. **You should see:** âœ… Table `password_reset_tokens` created successfully!

---

## âœ… Solution 2: Manual Setup (Using phpMyAdmin)

**If you prefer to create it manually:**

1. **Open phpMyAdmin:**
   ```
   http://localhost/phpmyadmin
   ```

2. **Select the database:** Click on `helphup` in the left sidebar

3. **Go to SQL tab:** Click on the "SQL" tab at the top

4. **Copy and paste this SQL:**
   ```sql
   CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
     `id` INT(11) NOT NULL AUTO_INCREMENT,
     `email` VARCHAR(100) NOT NULL,
     `user_type` VARCHAR(20) NOT NULL,
     `otp` VARCHAR(6) NOT NULL,
     `expires_at` TIMESTAMP NOT NULL,
     `used` TINYINT(1) DEFAULT 0,
     `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     PRIMARY KEY (`id`),
     INDEX `idx_email_type` (`email`, `user_type`),
     INDEX `idx_email_otp` (`email`, `otp`)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
   ```

5. **Click "Go" button** to execute

6. **You should see:** "Table created successfully" message

---

## âœ… Solution 3: Using SQL File

1. **Open phpMyAdmin:**
   ```
   http://localhost/phpmyadmin
   ```

2. **Select the database:** Click on `helphup` in the left sidebar

3. **Go to SQL tab:** Click on the "SQL" tab at the top

4. **Click "Choose File"** button

5. **Select the file:**
   ```
   C:\xampp\htdocs\helphup\api\create_password_reset_table.sql
   ```

6. **Click "Go" button** to execute

---

## âœ… Verify Table Was Created

After creating the table, verify it exists:

1. **In phpMyAdmin:**
   - Select `helphup` database
   - Look for `password_reset_tokens` in the table list
   - Click on it to see the structure

2. **Expected columns:**
   - `id` (Primary Key, Auto Increment)
   - `email` (VARCHAR 100)
   - `user_type` (VARCHAR 20)
   - `otp` (VARCHAR 6)
   - `expires_at` (TIMESTAMP)
   - `used` (TINYINT)
   - `created_at` (TIMESTAMP)

---

## ðŸ§ª Test Forgot Password

After creating the table:

1. **Open your Android app**
2. **Go to Forgot Password screen**
3. **Enter an email that exists in your database** (e.g., from `ngos`, `volunteers`, or `donors` table)
4. **Click "Send OTP"**

**Expected Results:**
- âœ… If email exists: "OTP generated successfully. OTP: [6-digit code]"
- âŒ If email doesn't exist: "Email not found"
- âŒ If table still missing: Check that you created the table correctly

---

## ðŸ“ Table Purpose

The `password_reset_tokens` table stores:
- **OTP codes** for password reset
- **Email addresses** requesting reset
- **User type** (ngo, volunteer, donor)
- **Expiration time** (15 minutes)
- **Usage status** (used/unused)

---

## ðŸ” Troubleshooting

**If you still get "Table doesn't exist" error:**

1. **Check database name:**
   - Make sure you created the table in the correct database
   - The database should be named `helphup` (check `config.php`)

2. **Check table name:**
   - Table name must be exactly: `password_reset_tokens` (lowercase)
   - Check for typos

3. **Refresh/Reload:**
   - Clear browser cache
   - Restart XAMPP Apache
   - Try the forgot password again

4. **Check MySQL is running:**
   - XAMPP Control Panel â†’ MySQL should be "Running"
   - Green status indicator

---

## âœ… Success Indicators

After setup, you should be able to:
- âœ… Click "Send OTP" without database errors
- âœ… See OTP in the response (if email not configured)
- âœ… OTP stored in `password_reset_tokens` table
- âœ… No more "Table doesn't exist" errors

---

**Last Updated:** 2026-01-02  
**Status:** Ready for setup

