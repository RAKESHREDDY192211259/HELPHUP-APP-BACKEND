# NGO Help Request – End-to-End Flow Documentation

## 📋 Overview

This document describes the complete flow of NGO Help Requests from submission to visibility across all roles in the HelpHup platform.

---

## 🔄 Complete Flow Diagram

```
1️⃣ NGO Submits Help Request
        ↓
   Status = PENDING
   admin_status = 'pending'
        ↓
2️⃣ Admin Manage Requests (Admin Panel)
        ↓
   ┌─────────────────┐
   │ Admin Reviews   │
   └─────────────────┘
        ↓
   ┌───────────────┐      ┌───────────────┐
   │ Admin REJECTS │      │ Admin ACCEPTS │
   └───────────────┘      └───────────────┘
        ↓                        ↓
   Status = REJECTED      Status = APPROVED
   admin_status = 'rejected'    admin_status = 'accepted'
        ↓                        ↓
   ❌ Only visible      ✅ Visible to ALL roles:
   to owner NGO         • Volunteers
                        • Donors
                        • Other NGOs
```

---

## 1️⃣ NGO Submits Help Request

### Screen
- **File:** `NgoRaiseHelp.kt`
- **Route:** `Routes.NGO_RAISE_HELP`

### Process
1. NGO user fills the help request form with:
   - Request Title
   - Category (Food, Medical, Education, etc.)
   - Urgency Level
   - Required Amount
   - Date Needed
   - Contact Number
   - Description

2. **API Endpoint:** `ngo_raise_help.php`
   - **Method:** POST
   - **Request Body:**
     ```json
     {
       "ngo_id": 1,
       "request_title": "Emergency Food Supplies",
       "category": "Food",
       "urgency_level": "High",
       "required_amount": "5000",
       "date_needed": "2024-01-15",
       "contact_number": "+1234567890",
       "description": "Need food supplies for 100 families"
     }
     ```

3. **Database Insert:**
   - Table: `ngo_help_requests` or `ngoraisehelp`
   - Initial Status:
     - `admin_status` = `'pending'`
     - `status` = `'pending'`
   - Request is stored but **NOT visible** to other roles yet

---

## 2️⃣ Request Goes to Admin Panel

### Screen
- **File:** `AdminManageRequests.kt`
- **Route:** `Routes.ADMIN_MANAGE_REQUESTS`

### Process
1. Admin views all pending requests
2. **API Endpoint:** `admin_get_pending_requests.php`
   - Returns requests where `admin_status = 'pending'` or `admin_status = 'verified'`

3. Admin can:
   - ✅ **Verify** request details
   - ✅ **Accept** request
   - ❌ **Reject** request

---

## 3️⃣ Admin Decision Logic

### 🔹 If Admin REJECTS

**API Endpoint:** `admin_reject_request.php`

**Database Update:**
```sql
UPDATE ngo_help_requests 
SET 
    admin_status = 'rejected',
    status = 'rejected',
    rejection_reason = 'Reason provided by admin',
    admin_id = [admin_id],
    admin_reviewed_at = NOW()
WHERE request_id = [request_id]
```

**Result:**
- ❌ **NOT visible** to Volunteers
- ❌ **NOT visible** to Donors
- ❌ **NOT visible** to Other NGOs
- ✅ **ONLY visible** to the owner NGO (via `get_my_ngo_requests.php`)
- ✅ **Notification sent** to NGO with rejection reason

---

### 🔹 If Admin ACCEPTS

**API Endpoint:** `admin_accept_request.php`

**Database Update:**
```sql
UPDATE ngo_help_requests 
SET 
    admin_status = 'accepted',
    status = 'approved',
    admin_id = [admin_id],
    admin_reviewed_at = NOW()
WHERE request_id = [request_id]
```

**Result:**
- ✅ Status = `'approved'`
- ✅ admin_status = `'accepted'`
- ✅ Request becomes **PUBLIC & ACTIVE**
- ✅ **Visible to ALL roles** (Volunteers, Donors, Other NGOs)
- ✅ **Notification sent** to NGO that request was accepted

---

## 4️⃣ Data Sync After Approval

### Single Source of Truth

All roles fetch data from the **same tables** using **status filters**:

- **NGO Requests:** `ngo_help_requests` or `ngoraisehelp`
- **Volunteer Requests:** `volunteer_requests` or `volunteerraisehelp`
- **Donor Campaigns:** `donor_campaigns`

### Visibility Rules

| Status | admin_status | Visible To |
|--------|-------------|------------|
| `pending` | `pending` | ❌ Admin only |
| `rejected` | `rejected` | ❌ Owner only |
| `approved` | `accepted` | ✅ **ALL ROLES** |

---

## 5️⃣ Volunteer Side – View Help Requests

### Screen
- **File:** `VolunteerHelpOthers.kt`
- **Route:** `Routes.VOLUNTEER_HELP_OTHERS`

### API Endpoints
1. `get_all_ngo_requests.php` - Gets approved NGO requests
2. `get_all_volunteer_requests.php` - Gets approved volunteer requests
3. `get_all_donor_campaigns.php` - Gets approved donor campaigns

### Filter Applied
```sql
WHERE admin_status = 'accepted' AND status = 'approved'
```

### What Volunteers See
- ✅ All **approved** NGO help requests
- ✅ All **approved** volunteer requests
- ✅ All **approved** donor campaigns

### Volunteer Actions
- View request details
- Accept task/volunteer opportunity
- Contact requester
- Update help progress

---

## 6️⃣ Donor Side – Browse Causes

### Screen
- **File:** `DonorBrowseCause.kt`
- **Route:** `Routes.DONOR_BROWSE_CAUSES`

### API Endpoints
- Same as Volunteer side: `get_all_ngo_requests.php`, `get_all_volunteer_requests.php`, `get_all_donor_campaigns.php`

### Filter Applied
```sql
WHERE admin_status = 'accepted' AND status = 'approved'
```

### What Donors See
- ✅ All **approved** help requests
- ✅ All **approved** campaigns

### Donor Actions
- Donate money
- Donate items
- Track donation status
- View impact

---

## 7️⃣ Other NGO Side – Help Others

### Screen
- **File:** `NgoHelpOthers.kt`
- **Route:** `Routes.NGO_HELP_OTHERS`

### API Endpoints
- Same endpoints as Volunteer/Donor

### Filter Applied
```sql
WHERE admin_status = 'accepted' AND status = 'approved'
```

### What Other NGOs See
- ✅ All **approved** help requests from **different NGOs**
- ✅ All **approved** volunteer requests
- ✅ All **approved** donor campaigns

### Other NGO Actions
- Provide resources
- Collaborate with other NGOs
- Offer support
- Share expertise

---

## 8️⃣ Unified Visibility Rule

### ✅ APPROVED Requests
**Visible in:**
- `VolunteerHelpOthers.kt`
- `DonorBrowseCause.kt`
- `NgoHelpOthers.kt`

**Filter:**
```sql
WHERE admin_status = 'accepted' AND status = 'approved'
```

### ❌ PENDING Requests
**Visible in:**
- `AdminManageRequests.kt` (Admin only)

**Filter:**
```sql
WHERE admin_status = 'pending' OR admin_status = 'verified'
```

### ❌ REJECTED Requests
**Visible in:**
- `get_my_ngo_requests.php` (Owner NGO only)

**Filter:**
```sql
WHERE ngo_id = [owner_ngo_id] AND admin_status = 'rejected'
```

---

## 📊 Status Flow Summary

```
NGO Submits Request
        ↓
   Status = PENDING
   admin_status = 'pending'
        ↓
Admin Manage Requests
        ↓
  ┌───────────────┐
  │ Admin Rejects │ → Status = REJECTED
  └───────────────┘    admin_status = 'rejected'
        ↓                ↓
   Not visible      Only visible to owner NGO
        ↓
  ┌───────────────┐
  │ Admin Accepts │ → Status = APPROVED
  └───────────────┘    admin_status = 'accepted'
        ↓                ↓
   Visible To:      All roles can see:
   ✔ Volunteers     • VolunteerHelpOthers.kt
   ✔ Donors         • DonorBrowseCause.kt
   ✔ Other NGOs     • NgoHelpOthers.kt
```

---

## 🔧 API Endpoints Summary

### For All Roles (Public View)
| Endpoint | Returns | Filter |
|----------|---------|--------|
| `get_all_ngo_requests.php` | Approved NGO requests | `admin_status='accepted' AND status='approved'` |
| `get_all_volunteer_requests.php` | Approved volunteer requests | `admin_status='accepted' AND status='approved'` |
| `get_all_donor_campaigns.php` | Approved donor campaigns | `admin_status='accepted' AND status='approved'` |

### For Owner (My Requests)
| Endpoint | Returns | Filter |
|----------|---------|--------|
| `get_my_ngo_requests.php` | All user's requests | `ngo_id=[user_id]` (all statuses) |
| `get_my_volunteer_requests.php` | All user's requests | `volunteer_id=[user_id]` (all statuses) |
| `get_my_donor_campaigns.php` | All user's campaigns | `donor_id=[user_id]` (all statuses) |

### For Admin
| Endpoint | Returns | Filter |
|----------|---------|--------|
| `admin_get_pending_requests.php` | Pending requests | `admin_status='pending' OR admin_status='verified'` |
| `admin_accept_request.php` | Updates status | Sets `status='approved'`, `admin_status='accepted'` |
| `admin_reject_request.php` | Updates status | Sets `status='rejected'`, `admin_status='rejected'` |

---

## ✅ Implementation Checklist

- [x] NGO can submit requests with `status='pending'`
- [x] Admin can view pending requests
- [x] Admin can accept requests (sets `status='approved'`)
- [x] Admin can reject requests (sets `status='rejected'`)
- [x] Approved requests visible to all roles
- [x] Rejected requests only visible to owner
- [x] Pending requests only visible to admin
- [x] Notifications sent on accept/reject
- [x] Single source of truth (same tables, different filters)

---

## 🎯 Key Points

1. **Single Source of Truth:** All roles fetch from the same tables using different filters
2. **Status-Based Visibility:** Only `approved` requests are public
3. **Owner Visibility:** Users can always see their own requests regardless of status
4. **Admin Control:** Admin has full control over request visibility
5. **Notifications:** Users are notified when their requests are accepted/rejected

---

## 📝 Notes

- Status values are case-sensitive: `'pending'`, `'approved'`, `'rejected'`
- Both `admin_status` and `status` fields are checked for filtering
- The `admin_status` field tracks admin's decision
- The `status` field tracks the overall request state
- For approved requests: `admin_status='accepted'` AND `status='approved'`

