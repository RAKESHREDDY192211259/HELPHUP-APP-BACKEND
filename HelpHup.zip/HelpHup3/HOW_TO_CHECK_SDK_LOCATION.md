# 📍 How to Check SDK Location in Android Studio

## 🎯 Current Location

You're currently viewing:
- **Appearance & Behavior → System Settings**

## ✅ Where to Find SDK Location

The Android SDK settings are in a **sub-section** under System Settings:

### Steps:

1. **In the left sidebar** (where you see "System Settings" selected)
2. **Look for "Android SDK"** - it should be listed under "System Settings"
3. **Click on "Android SDK"**
4. **The SDK location** will be displayed at the top of the right panel

### What You Should See:

When you click "Android SDK", you'll see:

- **"Android SDK Location"** field at the top
- It should show: `D:\Android\AndroidSdk`
- Below that, you'll see:
  - **SDK Platforms** tab (showing installed Android API levels)
  - **SDK Tools** tab (showing build tools, etc.)

---

## 🔍 Alternative Method

If you can't find "Android SDK" in the sidebar:

1. **Use the search bar** at the top of the left sidebar
2. **Type:** `Android SDK`
3. **Click** on the search result

---

## ✅ Verification

Once you're in the Android SDK settings:

- [ ] SDK Location shows: `D:\Android\AndroidSdk`
- [ ] SDK Platforms tab shows installed platforms (API levels)
- [ ] No error messages displayed

---

## 🐛 If SDK Location is Wrong

If it shows the old C: path:

1. Click **"Edit"** button next to SDK Location
2. Browse to: `D:\Android\AndroidSdk`
3. Click **"Next"** → **"Finish"**
4. Click **"Apply"** and **"OK"**

---

## 📝 Quick Reference

**Path to SDK Settings:**
- Appearance & Behavior → System Settings → **Android SDK**

**Expected SDK Location:**
- `D:\Android\AndroidSdk`

**To verify:**
- Check the "Android SDK Location" field at the top
- Should show D: drive path, not C: drive

