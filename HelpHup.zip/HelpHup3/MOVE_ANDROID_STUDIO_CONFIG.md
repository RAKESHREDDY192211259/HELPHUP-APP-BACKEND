# 📦 Move Android Studio Config Files to D: Drive

## 🎯 Goal
Move Android Studio configuration files from C: drive to `D:\Android\AndroidStudio`

## 📍 Config File Locations

Android Studio config files are typically located in:

1. **`C:\Users\mnand\AppData\Roaming\Google\AndroidStudio*`** (Main config)
2. **`C:\Users\mnand\AppData\Local\Google\AndroidStudio*`** (Local cache)
3. **`C:\Users\mnand\.AndroidStudio*`** (User settings)

---

## ✅ Moving Process

### Step 1: Close Android Studio
**IMPORTANT:** Close Android Studio completely before moving files!

### Step 2: Move Config Files

I'll move the config files and create symlinks for compatibility.

### Step 3: Verify
Check that files are in `D:\Android\AndroidStudio`

---

## 🔍 What Gets Moved

### Main Config (Usually largest):
- **From:** `C:\Users\mnand\AppData\Roaming\Google\AndroidStudio2025.2.2`
- **To:** `D:\Android\AndroidStudio\AndroidStudio2025.2.2`
- **Contains:** Settings, plugins, caches, logs

### Local Cache (Optional):
- **From:** `C:\Users\mnand\AppData\Local\Google\AndroidStudio*`
- **To:** `D:\Android\AndroidStudio\*`
- **Contains:** Local caches, temporary files

---

## ✅ After Moving

### Symlinks Created:
Symlinks will be created so Android Studio still finds files at the original C: locations, but they'll actually be on D: drive.

### Benefits:
- ✅ Frees up C: drive space
- ✅ Android Studio continues to work normally
- ✅ No need to reconfigure Android Studio

---

## 📊 Space Saved

Config files are typically:
- **Main config:** 100-500 MB
- **Local cache:** 200-1000 MB
- **Total:** ~300-1500 MB saved on C: drive

---

## ⚠️ Important Notes

1. **Close Android Studio** before moving
2. **Don't move files while Android Studio is running**
3. **Symlinks require Administrator privileges**
4. **Restart Android Studio** after moving

---

## 🔄 If Something Goes Wrong

### Restore Original Location:
1. Delete the symlink at C: location
2. Move files back from D: to C:
3. Restart Android Studio

---

**Files are being moved now. Check the results above!** 🚀

