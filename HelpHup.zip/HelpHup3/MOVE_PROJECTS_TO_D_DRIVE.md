# 📦 Move Android Studio Projects to D: Drive

## 🎯 Goal
Move Android Studio projects from `C:\Users\mnand\AndroidStudioProjects` to `D:\Android\Projects`

## ✅ What Was Done

### Projects Moved:
- **From:** `C:\Users\mnand\AndroidStudioProjects\HelpHup3`
- **To:** `D:\Android\Projects\HelpHup3`

### Symlink Created:
- **Symlink:** `C:\Users\mnand\AndroidStudioProjects` → `D:\Android\Projects`
- This allows Android Studio to find projects at the original location

---

## 🔧 Update Android Studio Settings

After moving projects, update Android Studio to use the new location:

### Method 1: Update Default Project Directory

1. **Open Android Studio**
2. Go to: **File → Settings** (or `Ctrl + Alt + S`)
3. Navigate to: **Appearance & Behavior → System Settings**
4. Find **"Default project directory:"**
5. Change it to: `D:\Android\Projects`
6. Click **"Apply"** and **"OK"**

### Method 2: Open Project from New Location

1. **Open Android Studio**
2. **File → Open**
3. Navigate to: `D:\Android\Projects\HelpHup3`
4. Click **"OK"**

---

## ✅ Benefits

- ✅ **Frees up C: drive space** (projects can be large)
- ✅ **Projects on D: drive** (more storage available)
- ✅ **Symlink maintains compatibility** (Android Studio finds projects at old location)
- ✅ **Better performance** (if D: drive is faster or has more space)

---

## 📊 Space Saved

Projects can be quite large (especially with build files):
- **HelpHup3 project:** Varies (includes build cache, dependencies, etc.)
- **Total space saved:** Depends on project size

---

## 🔍 Verification

### Check Projects Location:
```powershell
# Check if projects are on D: drive
Get-ChildItem "D:\Android\Projects"

# Check if symlink exists
Get-Item "$env:USERPROFILE\AndroidStudioProjects"
```

### In Android Studio:
1. **File → Open Recent**
2. Projects should still appear (thanks to symlink)
3. Or navigate to `D:\Android\Projects` to open projects

---

## ⚠️ Important Notes

1. **Symlink requires admin privileges** - If symlink creation failed, you may need to:
   - Run PowerShell as Administrator
   - Or manually update Android Studio settings

2. **Build files** - Build cache and generated files will be in the project folder on D: drive

3. **Git repositories** - If using Git, repositories will work normally from new location

---

## 🐛 Troubleshooting

### Issue: Android Studio can't find projects

**Solution:**
1. **File → Open** in Android Studio
2. Navigate to: `D:\Android\Projects\HelpHup3`
3. Open the project
4. Update default project directory in Settings

### Issue: Symlink not working

**Solution:**
1. Run PowerShell as Administrator
2. Create symlink manually:
   ```powershell
   New-Item -ItemType SymbolicLink -Path "$env:USERPROFILE\AndroidStudioProjects" -Target "D:\Android\Projects" -Force
   ```

### Issue: Build errors after move

**Solution:**
1. **File → Invalidate Caches → Invalidate and Restart**
2. **Build → Clean Project**
3. **Build → Rebuild Project**

---

## 📋 Quick Reference

**New Projects Location:** `D:\Android\Projects`

**To open project:**
- Navigate to: `D:\Android\Projects\HelpHup3`
- Or use symlink: `C:\Users\mnand\AndroidStudioProjects\HelpHup3` (redirects to D:)

**To update Android Studio:**
- Settings → Appearance & Behavior → System Settings → Default project directory: `D:\Android\Projects`

---

**Projects are now on D: drive! Update Android Studio settings to use the new location.** 🚀

