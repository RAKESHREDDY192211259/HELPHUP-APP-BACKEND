# 📦 Move Android Studio Project to D: Drive

## 🎯 Current Status

The project folder is currently **in use** (likely by File Explorer or Android Studio).

## ✅ Solution: Manual Move

### Step 1: Close Everything
1. **Close Android Studio** (if open)
2. **Close File Explorer windows** showing the project folder
3. **Wait 10 seconds**

### Step 2: Move the Project

**Option A: Using File Explorer (Easiest)**
1. **Open File Explorer**
2. **Navigate to:** `C:\Users\mnand\AndroidStudioProjects`
3. **Right-click** on `HelpHup3` folder
4. **Select "Cut"** (or press `Ctrl + X`)
5. **Navigate to:** `D:\Android\Projects`
6. **Right-click** in empty space
7. **Select "Paste"** (or press `Ctrl + V`)
8. **Wait for move to complete**

**Option B: Using PowerShell (If File Explorer doesn't work)**
```powershell
# Close processes first
Get-Process | Where-Object {$_.ProcessName -like "*studio*"} | Stop-Process -Force

# Move project
Move-Item -Path "C:\Users\mnand\AndroidStudioProjects\HelpHup3" -Destination "D:\Android\Projects\HelpHup3" -Force
```

### Step 3: Create Symlink (Optional but Recommended)

**This allows Android Studio to find projects at the old location:**

1. **Right-click PowerShell**
2. **Select "Run as Administrator"**
3. **Run this command:**
   ```powershell
   New-Item -ItemType SymbolicLink -Path "C:\Users\mnand\AndroidStudioProjects" -Target "D:\Android\Projects" -Force
   ```

### Step 4: Update Android Studio Settings

1. **Open Android Studio**
2. Go to: **File → Settings** (or `Ctrl + Alt + S`)
3. Navigate to: **Appearance & Behavior → System Settings**
4. Find **"Default project directory:"**
5. Change it to: `D:\Android\Projects`
6. Click **"Apply"** and **"OK"**

### Step 5: Open Project from New Location

1. **File → Open**
2. Navigate to: `D:\Android\Projects\HelpHup3`
3. Click **"OK"**
4. Wait for Gradle sync

---

## ✅ Benefits

- ✅ **Frees up C: drive space**
- ✅ **Projects on D: drive** (more storage)
- ✅ **Better organization**

---

## 📋 Quick Checklist

- [ ] Closed Android Studio
- [ ] Closed File Explorer windows
- [ ] Moved project to `D:\Android\Projects\HelpHup3`
- [ ] Created symlink (optional)
- [ ] Updated Android Studio default project directory
- [ ] Opened project from new location
- [ ] Verified project works

---

## 🐛 If Move Fails

### Error: "Folder is in use"

**Solution:**
1. **Close File Explorer** completely
2. **Close Android Studio** completely
3. **Wait 10 seconds**
4. **Try move again**

### Error: "Permission denied"

**Solution:**
1. **Run File Explorer as Administrator**
2. **Or use PowerShell as Administrator**

---

## 📝 Alternative: Keep Project on C: But Move Build Files

If you can't move the entire project:

1. **Keep project on C: drive**
2. **Move build cache to D: drive** (already done)
3. **Move Gradle cache to D: drive** (already done)

This still saves significant space!

---

**Close File Explorer and Android Studio, then move the project folder manually!** 🚀

