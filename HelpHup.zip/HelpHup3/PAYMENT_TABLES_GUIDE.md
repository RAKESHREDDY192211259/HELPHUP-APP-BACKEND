# 💳 Payment Tables Setup Guide

## ✅ Tables Created

I've created 3 payment tables for your HelpHup app:

### 1. **`donations` Table** 
   - Stores donations FROM donors TO causes/campaigns
   - Links to: `donors`, `donor_campaigns`, `ngos`, `volunteers`
   - Fields: amount, payment_method, transaction_id, payment_status, etc.

### 2. **`ngo_payments` Table**
   - Stores payments FROM NGOs (for community support)
   - Links to: `ngos` table
   - Fields: amount, payment_method, transaction_id, payment_status, etc.

### 3. **`volunteer_payments` Table**
   - Stores payments FROM volunteers (for community support)
   - Links to: `volunteers` table
   - Fields: amount, payment_method, transaction_id, payment_status, etc.

## 📋 How to Create the Tables

### Step 1: Open phpMyAdmin
1. Open browser
2. Go to: `http://localhost/phpmyadmin`
3. Select `helphup` database from left sidebar

### Step 2: Run SQL
1. Click on "SQL" tab at the top
2. Copy the entire content from `payment_tables.sql`
3. Paste it into the SQL text area
4. Click "Go" button

### Step 3: Verify
After running, you should see:
- ✅ `donations` table created
- ✅ `ngo_payments` table created
- ✅ `volunteer_payments` table created

## 📊 Table Structure Overview

### **donations** Table Fields:
- `id` - Primary key
- `donor_id` - Who made the donation
- `campaign_id` - Which campaign (if applicable)
- `ngo_id` - Which NGO cause (if applicable)
- `volunteer_id` - Which volunteer cause (if applicable)
- `amount` - Donation amount
- `payment_method` - CARD, UPI, NET_BANKING, etc.
- `transaction_id` - Payment gateway transaction ID
- `payment_status` - pending, completed, failed, refunded
- `description` - Optional note
- `created_at` - When donation was made
- `updated_at` - Last update time

### **ngo_payments** Table Fields:
- `id` - Primary key
- `ngo_id` - Which NGO made the payment
- `amount` - Payment amount
- `payment_method` - CARD, UPI, NET_BANKING, etc.
- `transaction_id` - Payment gateway transaction ID
- `payment_status` - pending, completed, failed, refunded
- `description` - Optional note
- `created_at` - When payment was made
- `updated_at` - Last update time

### **volunteer_payments** Table Fields:
- `id` - Primary key
- `volunteer_id` - Which volunteer made the payment
- `amount` - Payment amount
- `payment_method` - CARD, UPI, NET_BANKING, etc.
- `transaction_id` - Payment gateway transaction ID
- `payment_status` - pending, completed, failed, refunded
- `description` - Optional note
- `created_at` - When payment was made
- `updated_at` - Last update time

## 🔗 Foreign Key Relationships

**Note:** The SQL doesn't include FOREIGN KEY constraints because:
- Your existing tables use `id` as primary key (not `ngo_id`, `donor_id`, etc.)
- Foreign keys would need to match the exact column names

If you want to add foreign keys later, you can modify the tables:
```sql
ALTER TABLE donations ADD FOREIGN KEY (donor_id) REFERENCES donors(id);
ALTER TABLE donations ADD FOREIGN KEY (ngo_id) REFERENCES ngos(id);
ALTER TABLE donations ADD FOREIGN KEY (volunteer_id) REFERENCES volunteers(id);
```

## 📱 Usage in Your App

These tables will support:
- ✅ Donor donation history (DonorDonationHistory screen)
- ✅ Payment processing (DonorPaymentDetails, NgoPaymentDetails, VolunteerPaymentDetails)
- ✅ Transaction tracking
- ✅ Payment status management
- ✅ Receipt generation (using transaction_id)

## 🚀 Next Steps

After creating the tables:
1. ✅ Create PHP API endpoints to save payments/donations
2. ✅ Create endpoints to retrieve donation/payment history
3. ✅ Update payment confirmation screens to save to database
4. ✅ Update donation history screens to fetch from database

## 📝 Example Queries

### Get all donations for a donor:
```sql
SELECT * FROM donations WHERE donor_id = 1 ORDER BY created_at DESC;
```

### Get total donated amount for a donor:
```sql
SELECT SUM(amount) as total FROM donations 
WHERE donor_id = 1 AND payment_status = 'completed';
```

### Get donations for a campaign:
```sql
SELECT * FROM donations 
WHERE campaign_id = 1 AND payment_status = 'completed'
ORDER BY created_at DESC;
```

### Get NGO payments:
```sql
SELECT * FROM ngo_payments 
WHERE ngo_id = 1 ORDER BY created_at DESC;
```


