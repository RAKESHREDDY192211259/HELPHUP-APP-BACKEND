# 🚀 Quick Email Setup Guide

## ✅ Fastest Method: Gmail SMTP (5 Steps)

### Step 1: Get Gmail App Password
1. Go to: https://myaccount.google.com/security
2. Enable **2-Step Verification** (if not enabled)
3. Go to **App passwords** → Generate new app password
4. Copy the **16-character password**

### Step 2: Download PHPMailer
1. Download: https://github.com/PHPMailer/PHPMailer/archive/refs/heads/master.zip
2. Extract the ZIP file
3. Copy the `PHPMailer` folder to:
   ```
   C:\xampp\htdocs\helphup\api\PHPMailer\
   ```

### Step 3: Update email_config.php
Edit `C:\xampp\htdocs\helphup\api\email_config.php`:

Change line 16:
```php
define('USE_PHP_MAIL', false); // Use SMTP instead of PHP mail()
```

Update lines 10-12:
```php
define('SMTP_USERNAME', 'your-email@gmail.com'); // Your Gmail
define('SMTP_PASSWORD', 'your-16-char-app-password'); // From Step 1
define('SMTP_FROM_EMAIL', 'your-email@gmail.com'); // Same as above
```

### Step 4: Restart Apache
1. Open XAMPP Control Panel
2. Stop Apache
3. Start Apache

### Step 5: Test
1. Open: http://localhost/helphup/api/test_email.php?email=your-email@gmail.com
2. Check your inbox for the test email

---

## 📖 Detailed Instructions

See: `C:\xampp\htdocs\helphup\api\SETUP_EMAIL_SENDING.md`

---

**Time Required:** 10 minutes  
**Difficulty:** Easy ⭐⭐

