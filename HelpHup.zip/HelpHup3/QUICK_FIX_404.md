﻿# ðŸš¨ Quick Fix: HTTP 404 Error on Verify OTP

## Problem
Getting **404 Not Found** when clicking "Verify" on OTP screen.

## âœ… Solution (Choose One)

### Method 1: Run PowerShell Script (Easiest)

1. **Right-click** on `copy_to_server.ps1` in your project
2. Select **"Run with PowerShell"**
3. If prompted, click **"Yes"** to allow script execution
4. Files will be copied automatically!

### Method 2: Manual Copy (5 minutes)

1. **Open File Explorer**
2. **Navigate to:** `C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\`
3. **Select these 6 files:**
   - `ngo_verify_otp.php`
   - `ngo_reset_password.php`
   - `donor_verify_otp.php`
   - `donor_reset_password.php`
   - `volunteer_verify_otp.php`
   - `volunteer_reset_password.php`
4. **Copy** (Ctrl+C)
5. **Navigate to:** `C:\xampp\htdocs\helphup\api\`
6. **Paste** (Ctrl+V)

### Method 3: Command Line (Fast)

Open **Command Prompt** and run:

```cmd
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\ngo_verify_otp.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\ngo_reset_password.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\donor_verify_otp.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\donor_reset_password.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\volunteer_verify_otp.php" "C:\xampp\htdocs\helphup\api\"
copy "C:\Users\mnand\AndroidStudioProjects\HelpHup3\xampp_files\volunteer_reset_password.php" "C:\xampp\htdocs\helphup\api\"
```

---

## âœ… Verify It Works

After copying, test in browser:

```
http://localhost/helphup/api/ngo_verify_otp.php
```

**Expected:** Should show blank page or JSON error (NOT 404)

**Then test in your app** - the 404 error should be gone!

---

## ðŸ” Still Not Working?

1. **Check Apache is running** in XAMPP Control Panel
2. **Check file exists:** `C:\xampp\htdocs\helphup\api\ngo_verify_otp.php`
3. **Restart Apache** in XAMPP Control Panel
4. **Check your IP address** - Make sure `10.22.186.166` is still your PC's IP

---

**That's it! After copying, the 404 error will be fixed.** âœ…

