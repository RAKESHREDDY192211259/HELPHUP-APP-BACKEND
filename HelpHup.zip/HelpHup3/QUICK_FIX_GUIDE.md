# Quick Fix: Requests Not Showing in Admin Portal

## 🚨 Problem
Volunteer requests and donor campaigns are submitted but not appearing in admin portal.

## ✅ Quick Fix (Choose One Method)

### Method 1: Run SQL Script (Recommended - 2 minutes)

1. **Open phpMyAdmin:** `http://localhost/phpmyadmin`
2. **Select database:** `helphup`
3. **Click "SQL" tab**
4. **Copy and paste** the entire content from:
   ```
   xampp_files/add_admin_status_to_tables.sql
   ```
5. **Click "Go"**
6. **Done!** ✅

**What it does:**
- Adds `admin_status` column to `volunteer_requests` table
- Adds `admin_status` column to `donor_campaigns` table
- Adds `admin_id`, `admin_reviewed_at`, `rejection_reason` columns
- Updates existing records to `admin_status='pending'`

---

### Method 2: Run PHP Script (Alternative)

1. **Make sure XAMPP Apache is running**
2. **Open browser:**
   ```
   http://localhost/helphup/api/check_and_fix_admin_status.php
   ```
3. **You'll see JSON response** confirming columns were added
4. **Done!** ✅

---

### Method 3: Manual SQL (If methods 1 & 2 don't work)

Run these SQL commands one by one in phpMyAdmin:

```sql
USE helphup;

-- Add to volunteer_requests
ALTER TABLE volunteer_requests ADD COLUMN admin_status VARCHAR(20) DEFAULT 'pending';
ALTER TABLE volunteer_requests ADD COLUMN admin_id INT(11) DEFAULT NULL;
ALTER TABLE volunteer_requests ADD COLUMN admin_reviewed_at TIMESTAMP NULL DEFAULT NULL;
ALTER TABLE volunteer_requests ADD COLUMN rejection_reason TEXT DEFAULT NULL;

-- Add to donor_campaigns
ALTER TABLE donor_campaigns ADD COLUMN admin_status VARCHAR(20) DEFAULT 'pending';
ALTER TABLE donor_campaigns ADD COLUMN admin_id INT(11) DEFAULT NULL;
ALTER TABLE donor_campaigns ADD COLUMN admin_reviewed_at TIMESTAMP NULL DEFAULT NULL;
ALTER TABLE donor_campaigns ADD COLUMN rejection_reason TEXT DEFAULT NULL;

-- Update existing records
UPDATE volunteer_requests SET admin_status = 'pending' WHERE admin_status IS NULL;
UPDATE donor_campaigns SET admin_status = 'pending' WHERE admin_status IS NULL;
```

---

## ✅ Verify It Works

### 1. Check Columns Exist
```sql
SHOW COLUMNS FROM volunteer_requests LIKE 'admin_status';
SHOW COLUMNS FROM donor_campaigns LIKE 'admin_status';
```
**Expected:** Should show the column details

### 2. Check Pending Requests
```sql
SELECT COUNT(*) FROM volunteer_requests WHERE admin_status = 'pending';
SELECT COUNT(*) FROM donor_campaigns WHERE admin_status = 'pending';
```

### 3. Test Admin Portal
1. **Submit a volunteer request** from the app
2. **Open Admin Manage Requests** → Should see the request
3. **Submit a donor campaign** from the app
4. **Open Admin Manage Campaigns** → Should see the campaign

---

## 📋 What Was Fixed

1. ✅ **SQL Script Created** - Adds missing columns safely
2. ✅ **PHP Fix Script Created** - Alternative fix method
3. ✅ **Submission Endpoints Improved** - Better error handling
4. ✅ **Admin Endpoint Improved** - Handles missing columns gracefully
5. ✅ **Error Logging Added** - Helps debug issues

---

## 🎯 After Fix

Once columns are added:
- ✅ New submissions automatically set `admin_status='pending'`
- ✅ Existing submissions updated to `admin_status='pending'`
- ✅ Admin portal shows all pending requests/campaigns
- ✅ Accept/Reject functionality works correctly

---

## 🔍 Troubleshooting

### Still Not Showing?

1. **Check column exists:**
   ```sql
   SHOW COLUMNS FROM volunteer_requests;
   SHOW COLUMNS FROM donor_campaigns;
   ```

2. **Check records have admin_status:**
   ```sql
   SELECT * FROM volunteer_requests LIMIT 5;
   SELECT * FROM donor_campaigns LIMIT 5;
   ```

3. **Test API directly:**
   - Browser: `http://localhost/helphup/api/admin_get_pending_requests.php?request_type=volunteer`
   - Should return JSON with volunteer requests

4. **Check error logs:**
   - PHP error log: `C:\xampp\apache\logs\error.log`
   - Look for warnings about missing columns

---

**Run the SQL script and requests will start appearing in admin portal!** ✅

