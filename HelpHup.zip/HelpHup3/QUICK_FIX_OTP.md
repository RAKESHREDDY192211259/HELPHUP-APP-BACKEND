# 🚀 Quick Fix: OTP Verification Error

## ⚠️ Problem
Getting "Invalid or expired OTP" error when verifying OTP.

## ✅ Solution Steps

### Step 1: Copy All Updated Files to XAMPP

**Option A: Use PowerShell Script (Recommended)**
1. Open PowerShell as Administrator
2. Navigate to project:
   ```powershell
   cd "D:\Android\Projects\HelpHup3"
   ```
3. Run the script:
   ```powershell
   .\COPY_ALL_FILES.ps1
   ```

**Option B: Manual Copy**
Copy these files from `D:\Android\Projects\HelpHup3\xampp_files\` to `C:\xampp\htdocs\helphup\api\`:

- ✅ `ngo_verify_otp.php` (UPDATED - with better error handling)
- ✅ `donor_verify_otp.php` (UPDATED)
- ✅ `volunteer_verify_otp.php` (UPDATED)
- ✅ `ngo_reset_password.php`
- ✅ `donor_reset_password.php`
- ✅ `volunteer_reset_password.php`
- ✅ `ngoforgot.php` (UPDATED - with table checks)
- ✅ `donor_forgot.php` (UPDATED)
- ✅ `volunteer_forgot.php` (UPDATED)
- ✅ `debug_otp.php` (NEW - for debugging)
- ✅ `setup_password_reset_table.php` (NEW - creates tables)
- ✅ `migrate_to_separate_tables.php` (NEW - migration script)
- ✅ `test_otp_flow.php` (NEW - test script)

### Step 2: Create the Password Reset Tables

**CRITICAL:** The tables must exist before OTP verification will work!

Open in browser:
```
http://localhost/helphup/api/setup_password_reset_table.php
```

This will create:
- `ngo_password_reset_tokens`
- `donor_password_reset_tokens`
- `volunteer_password_reset_tokens`

**Expected Result:** JSON response showing all 3 tables were created.

### Step 3: Test the Setup

**Test 1: Check if tables exist**
```
http://localhost/helphup/api/debug_otp.php?email=your@email.com
```

**Test 2: Test OTP flow**
```
http://localhost/helphup/api/test_otp_flow.php?email=your@email.com
```

### Step 4: Test in Android App

1. **Request OTP:**
   - Go to Forgot Password screen
   - Enter your email
   - Click "Send OTP"
   - **Note the OTP** shown in the response message (if email sending fails)

2. **Verify OTP:**
   - Enter the OTP exactly as shown (including leading zeros like "000937")
   - Click "Verify"
   - Should work now!

## 🔍 Troubleshooting

### Still getting "Invalid or expired OTP"?

1. **Check tables exist:**
   - Open phpMyAdmin: `http://localhost/phpmyadmin`
   - Select `helphup` database
   - Look for these tables:
     - `ngo_password_reset_tokens`
     - `donor_password_reset_tokens`
     - `volunteer_password_reset_tokens`
   - If missing, run: `http://localhost/helphup/api/setup_password_reset_table.php`

2. **Check OTP in database:**
   ```
   http://localhost/helphup/api/debug_otp.php?email=your@email.com
   ```
   This shows all OTPs for that email.

3. **Check PHP error logs:**
   - Location: `C:\xampp\apache\logs\error.log`
   - Look for OTP-related errors

4. **Verify files are copied:**
   - Check: `C:\xampp\htdocs\helphup\api\ngo_verify_otp.php` exists
   - Check file modification date is recent

5. **Test OTP flow:**
   ```
   http://localhost/helphup/api/test_otp_flow.php?email=your@email.com
   ```
   This will show exactly what's happening.

## 📝 Key Fixes Applied

1. ✅ **Case-insensitive email matching** - Emails are normalized to lowercase
2. ✅ **Table existence checks** - Clear error if tables don't exist
3. ✅ **OTP verification after insertion** - Ensures OTP is actually saved
4. ✅ **Better error messages** - Shows exactly what went wrong
5. ✅ **Error logging** - Logs all OTP operations for debugging
6. ✅ **OTP normalization** - Handles leading zeros correctly

## ✅ Success Checklist

- [ ] All files copied to `C:\xampp\htdocs\helphup\api\`
- [ ] Tables created (run setup_password_reset_table.php)
- [ ] Can access debug_otp.php in browser
- [ ] Can request OTP in app
- [ ] OTP verification works in app

---

**After completing these steps, OTP verification should work!** 🎉

