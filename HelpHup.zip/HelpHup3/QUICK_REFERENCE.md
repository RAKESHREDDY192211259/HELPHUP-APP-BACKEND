﻿# Quick Reference - XAMPP Setup

## ðŸ“ Essential File Paths

### XAMPP Installation
```
C:\xampp\
```

### PHP API Files Location
```
C:\xampp\htdocs\helphup\api\
```

### Upload Directory
```
C:\xampp\htdocs\helphup\uploads\registration_proofs\
```

---

## ðŸ”§ Database Connection (Use in all PHP files)

```php
$host = "localhost";
$username = "root";
$password = "";              // Empty by default
$database = "helphup_db";
```

---

## ðŸ“‹ Required PHP Files (10 files)

Create these in: `C:\xampp\htdocs\helphup\api\`

1. `config.php` - Database connection
2. `ngo_login.php`
3. `ngo_register.php`
4. `ngoforgot.php`
5. `volunteer_login.php`
6. `volunteer_register.php`
7. `volunteer_forgot.php`
8. `donor_login.php`
9. `donor_register.php`
10. `donor_forgot.php`
11. `ngo_raise_help.php`
12. `volunteer_raise_help.php`
13. `Donor_raise_help.php`

---

## ðŸ—„ï¸ Database Name
```
helphup_db
```

---

## ðŸ“Š Required Tables (7 tables)

1. `ngo`
2. `volunteer`
3. `donor`
4. `ngo_help_requests`
5. `volunteer_requests`
6. `donor_campaigns`
7. `password_reset_tokens`

---

## ðŸŒ URLs

**phpMyAdmin:** `http://localhost/phpmyadmin`  
**Test API:** `http://localhost/helphup/api/`  
**Base URL (Current):** `http://10.26.77.227/helphup/api/`  
**Base URL (Localhost):** `http://localhost/helphup/api/`

---

## âš¡ Quick Start

1. **Start XAMPP:** Open Control Panel â†’ Start Apache & MySQL
2. **Create DB:** Open phpMyAdmin â†’ Create database `helphup_db`
3. **Create Tables:** Run SQL from XAMPP_SETUP_GUIDE.md
4. **Create Files:** Copy PHP files to `htdocs\helphup\api\`
5. **Test:** Open `http://localhost/helphup/api/config.php`

---

## ðŸ“ Database Credentials

- **Username:** `root`
- **Password:** `` (empty)
- **Host:** `localhost`
- **Port:** `3306` (default)

