# Request Visibility Rules

## Overview
This document explains the visibility rules for help requests across different user roles. When a request is accepted by admin, it becomes visible to other roles, but NOT to users of the same role type.

## Rules

### ✅ NGOs
**Can See:**
- ✅ Volunteer requests (when admin_status = 'accepted')
- ✅ Donor campaigns (when admin_status = 'accepted')

**Cannot See:**
- ❌ NGO requests (from any NGO, including their own)

**Browse Screen:** `NgoHelpOthers.kt`
- Only fetches Volunteer and Donor requests
- Does NOT fetch NGO requests

---

### ✅ Volunteers
**Can See:**
- ✅ NGO requests (when admin_status = 'accepted')
- ✅ Donor campaigns (when admin_status = 'accepted')

**Cannot See:**
- ❌ Volunteer requests (from any volunteer, including their own)

**Browse Screen:** `VolunteerHelpOthers.kt`
- Only fetches NGO and Donor requests
- Does NOT fetch Volunteer requests

---

### ✅ Donors
**Can See:**
- ✅ NGO requests (when admin_status = 'accepted')
- ✅ Volunteer requests (when admin_status = 'accepted')

**Cannot See:**
- ❌ Donor campaigns (from any donor, including their own)

**Browse Screen:** `DonorBrowseCause.kt`
- Only fetches NGO and Volunteer requests
- Does NOT fetch Donor campaigns

---

## Complete Flow

### 1. Request Submission
```
NGO/Volunteer/Donor submits request
    ↓
admin_status = 'pending'
    ↓
Request appears in Admin's "Manage Requests" page
```

### 2. Admin Action
```
Admin views request details
    ↓
Admin clicks Accept/Reject/Verify
    ↓
update_request_status.php updates database
    ↓
If Accepted:
    - admin_status = 'accepted'
    - status = 'approved'
    - Request becomes visible to OTHER roles
```

### 3. Visibility to Other Roles
```
Accepted request visible to:
- NGO request → Volunteers & Donors can see
- Volunteer request → NGOs & Donors can see
- Donor campaign → NGOs & Volunteers can see

NOT visible to:
- Same role type (can't help themselves)
```

### 4. Status Visibility for Requester
```
The requester can see their own request status via:
- get_my_ngo_requests.php (for NGOs)
- get_my_volunteer_requests.php (for Volunteers)
- get_my_donor_campaigns.php (for Donors)

These endpoints show ALL statuses (pending, accepted, rejected)
```

## Implementation Details

### Browse Endpoints Filter
All public browse endpoints filter by:
- `admin_status = 'accepted'` ✅

**Files:**
- `get_all_ngo_requests.php` - Shows NGO requests (but NGOs don't fetch this)
- `get_all_volunteer_requests.php` - Shows Volunteer requests (but Volunteers don't fetch this)
- `get_all_donor_campaigns.php` - Shows Donor campaigns (but Donors don't fetch this)

### Android Implementation

#### NgoHelpOthers.kt
```kotlin
// Only fetches:
val volunteerResponse = HelpOthersRetrofitInstance.api.getVolunteerRequests()
val donorResponse = HelpOthersRetrofitInstance.api.getDonorCampaigns()

// Does NOT fetch NGO requests
```

#### VolunteerHelpOthers.kt
```kotlin
// Only fetches:
val ngoResponse = HelpRequestsRetrofitInstance.api.getNgoRequests()
val donorResponse = HelpRequestsRetrofitInstance.api.getDonorCampaigns()

// Does NOT fetch Volunteer requests
```

#### DonorBrowseCause.kt
```kotlin
// Only fetches:
val ngoResponse = CauseRetrofitInstance.api.getNgoRequests()
val volunteerResponse = CauseRetrofitInstance.api.getVolunteerRequests()

// Does NOT fetch Donor campaigns
```

## Status Flow

| Admin Action | admin_status | status | Visible to Other Roles? |
|--------------|--------------|--------|------------------------|
| Pending (initial) | `pending` | `pending` | ❌ No |
| Verify | `verified` | `pending` | ❌ No |
| Accept | `accepted` | `approved` | ✅ Yes (other roles only) |
| Reject | `rejected` | `rejected` | ❌ No |

## Testing Checklist

- [x] NGO submits request → Appears in Admin Manage Requests
- [x] Admin accepts NGO request → Visible to Volunteers & Donors
- [x] NGO cannot see NGO requests in browse page
- [x] Volunteer submits request → Appears in Admin Manage Requests
- [x] Admin accepts Volunteer request → Visible to NGOs & Donors
- [x] Volunteer cannot see Volunteer requests in browse page
- [x] Donor submits campaign → Appears in Admin Manage Requests
- [x] Admin accepts Donor campaign → Visible to NGOs & Volunteers
- [x] Donor cannot see Donor campaigns in browse page
- [x] Requester can see their own request status via "My Requests" endpoints

## Summary

✅ **Fixed:** Browse screens now exclude same-role requests
✅ **Fixed:** Only accepted requests are visible
✅ **Fixed:** Requesters can see their own request status
✅ **Working:** Admin can verify/accept/reject requests
✅ **Working:** Status updates propagate to database immediately

