# 📍 SDK Location Guide

## Current SDK Location

### ✅ **Primary Location (D: Drive):**
```
D:\Android\AndroidSdk
```

### 📋 **Configuration Files:**

1. **local.properties** (in your project):
   ```
   sdk.dir=D\:\\Android\\AndroidSdk
   ```

2. **Environment Variables:**
   - `ANDROID_HOME` = `D:\Android\AndroidSdk`
   - `ANDROID_SDK_ROOT` = `D:\Android\AndroidSdk`

3. **Symlink (for compatibility):**
   - `C:\Users\mnand\AppData\Local\Android\Sdk` → Points to `D:\Android\AndroidSdk`

---

## 🔧 How to Update SDK Location in Android Studio

### Method 1: Through Settings UI

1. **Open Android Studio**
2. Go to: **File → Settings** (or press `Ctrl + Alt + S`)
3. Navigate to: **Appearance & Behavior → System Settings → Android SDK**
4. Look for **"Android SDK Location"** at the top
5. If it shows the old C: path:
   - Click **"Edit"** button
   - Browse to: `D:\Android\AndroidSdk`
   - Click **"Next"** → **"Finish"**
   - Click **"Apply"** and **"OK"**

### Method 2: Through Project Structure

1. **Open Android Studio**
2. Go to: **File → Project Structure** (or press `Ctrl + Alt + Shift + S`)
3. Click **"SDK Location"** in the left sidebar
4. Set **"Android SDK location"** to: `D:\Android\AndroidSdk`
5. Click **"Apply"** and **"OK"**

---

## ✅ Verification

### Check if SDK is in the right place:

```powershell
# Check if SDK exists on D: drive
Test-Path "D:\Android\AndroidSdk"

# Check SDK size
(Get-ChildItem -Path "D:\Android\AndroidSdk" -Recurse | Measure-Object -Property Length -Sum).Sum / 1GB
```

### Check environment variables:

```powershell
[Environment]::GetEnvironmentVariable("ANDROID_HOME", "User")
[Environment]::GetEnvironmentVariable("ANDROID_SDK_ROOT", "User")
```

### Check local.properties:

```powershell
Get-Content ".\local.properties" | Select-String "sdk.dir"
```

---

## 🐛 Troubleshooting

### Issue: Android Studio shows old C: path

**Solution:**
1. Close Android Studio
2. Verify `local.properties` has: `sdk.dir=D\:\\Android\\AndroidSdk`
3. Reopen Android Studio
4. Go to Settings → Android SDK → Edit → Set to `D:\Android\AndroidSdk`

### Issue: "SDK not found" error

**Solution:**
1. Verify SDK exists: `Test-Path "D:\Android\AndroidSdk"`
2. Check `local.properties` has correct path
3. Restart Android Studio
4. If still not working, restart computer (for environment variables)

### Issue: Gradle can't find SDK

**Solution:**
1. Check `local.properties` in project root
2. Verify path format: `sdk.dir=D\:\\Android\\AndroidSdk` (double backslashes)
3. Sync Gradle: **File → Sync Project with Gradle Files**

---

## 📝 Quick Reference

**SDK Location:** `D:\Android\AndroidSdk`

**To update in Android Studio:**
- Settings → Appearance & Behavior → System Settings → Android SDK → Edit

**To verify:**
- Check `local.properties` file
- Check environment variables
- Check Android Studio Settings

---

**Your SDK is successfully moved to D: drive!** ✅

