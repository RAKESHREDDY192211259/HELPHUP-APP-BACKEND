# 📋 Step-by-Step Guide: Create Payment Tables in Database

## ✅ Step 1: Open phpMyAdmin

1. **Open your web browser** (Chrome, Firefox, Edge, etc.)
2. **Go to:** `http://localhost/phpmyadmin`
3. **Wait for phpMyAdmin to load**

---

## ✅ Step 2: Select Database

1. **Look at the left sidebar** (database list)
2. **Click on `helphup`** database
   - This will select the database
   - You should see the database name highlighted/selected
   - The main area will show the database structure

---

## ✅ Step 3: Open SQL Tab

1. **Look at the top menu bar** in phpMyAdmin
2. **Click on the "SQL" tab**
   - It's usually in the top navigation bar
   - You'll see tabs like: Structure | SQL | Search | etc.
   - Click on **"SQL"**

---

## ✅ Step 4: Open the SQL File

1. **Open File Explorer** (Windows Explorer)
2. **Navigate to:** `C:\xampp\htdocs\helphup\api\`
3. **Find the file:** `payment_tables.sql`
4. **Right-click on the file** → **Open with** → **Notepad** (or any text editor)
5. **Press `Ctrl + A`** to select all text
6. **Press `Ctrl + C`** to copy the entire SQL code

---

## ✅ Step 5: Paste SQL Code

1. **Go back to phpMyAdmin** (in your browser)
2. **Click inside the SQL text area** (the big text box)
3. **Clear any existing text** (if there's any)
4. **Press `Ctrl + V`** to paste the SQL code
5. **You should see the SQL code** with CREATE TABLE statements

---

## ✅ Step 6: Execute the SQL

1. **Look for the "Go" button** at the bottom of the SQL text area
2. **Click the "Go" button**
3. **Wait for execution** (usually takes 1-2 seconds)

---

## ✅ Step 7: Verify Success

After clicking "Go", you should see:

### ✅ Success Message:
```
3 queries executed, 0 errors
- CREATE TABLE `donations` ... (success)
- CREATE TABLE `ngo_payments` ... (success)  
- CREATE TABLE `volunteer_payments` ... (success)
```

### ✅ Check Tables Created:
1. **Look at the left sidebar** under `helphup` database
2. **You should see 3 new tables:**
   - `donations` ✅
   - `ngo_payments` ✅
   - `volunteer_payments` ✅

---

## ✅ Step 8: Verify Table Structure (Optional)

To verify tables are created correctly:

1. **Click on `donations` table** in the left sidebar
2. **Click "Structure" tab** at the top
3. **Check columns:**
   - `id` (Primary key)
   - `donor_id`
   - `campaign_id`
   - `ngo_id`
   - `volunteer_id`
   - `amount`
   - `payment_method`
   - `transaction_id`
   - `payment_status`
   - `description`
   - `created_at`

4. **Repeat for other tables:**
   - Click `ngo_payments` → Structure
   - Click `volunteer_payments` → Structure

---

## ❌ If You Get Errors

### Error: "Table already exists"
**Solution:** The tables are already created. Skip this step.

### Error: "Syntax error"
**Solution:**
1. Make sure you copied the ENTIRE SQL file
2. Check for any missing text
3. Try copying again

### Error: "Access denied"
**Solution:**
1. Make sure MySQL is running in XAMPP
2. Check you're using the correct database (`helphup`)
3. Try refreshing phpMyAdmin page

### Error: "Unknown database"
**Solution:**
1. Make sure you selected `helphup` database
2. If database doesn't exist, create it first:
   - Click "New" in left sidebar
   - Database name: `helphup`
   - Click "Create"

---

## 📸 Quick Visual Guide

```
1. Browser → http://localhost/phpmyadmin
2. Left Sidebar → Click "helphup"
3. Top Menu → Click "SQL" tab
4. File Explorer → Open payment_tables.sql → Copy all text
5. phpMyAdmin → Paste in SQL box → Click "Go"
6. Verify → See 3 new tables in left sidebar
```

---

## ✅ Checklist

Before starting:
- [ ] XAMPP MySQL is running (green in XAMPP Control Panel)
- [ ] Browser is open
- [ ] phpMyAdmin is accessible

After completion:
- [ ] `donations` table exists
- [ ] `ngo_payments` table exists
- [ ] `volunteer_payments` table exists
- [ ] No errors shown

---

## 🎯 Next Steps After Creating Tables

Once tables are created, you can:
1. ✅ Create PHP endpoints to save payments
2. ✅ Create PHP endpoints to fetch payment history
3. ✅ Test payment functionality in your app

---

**That's it! Your payment tables are now ready to use! 🎉**

