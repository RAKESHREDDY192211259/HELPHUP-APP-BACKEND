﻿# ðŸ§ª Test Your Connection - Step by Step

## Test 1: Check XAMPP Apache is Running

1. Open XAMPP Control Panel
2. Look at Apache - is it **GREEN**?
3. âœ… If GREEN â†’ Good!
4. âŒ If RED â†’ Click START button

---

## Test 2: Check PHP Files Exist

1. Open File Explorer
2. Go to: `C:\xampp\htdocs\helphup\api\`
3. Check if these files exist:
   - `config.php`
   - `ngo_login.php`
4. âœ… If files exist â†’ Good!
5. âŒ If folder doesn't exist â†’ Create it and copy files from `xampp_files` folder

---

## Test 3: Test PHP File in Browser (PC)

1. Open any web browser (Chrome, Firefox, etc.)
2. Go to: `http://localhost/helphup/api/ngo_login.php`
3. What do you see?

   **âœ… Good Response:**
   ```
   {"status":false,"message":"Email and password are required"}
   ```
   (This is correct - it's JSON)

   **âŒ Bad Response:**
   - Blank page
   - HTML error page
   - "File not found" error
   - PHP syntax error

---

## Test 4: Test from Phone Browser

1. Make sure phone and PC are on **SAME WiFi**
2. Open browser on phone
3. Go to: `http://10.22.186.166/helphup/api/ngo_login.php`
4. What do you see?

   **âœ… Good Response:**
   - JSON response (same as Test 3)

   **âŒ Bad Response:**
   - "Can't reach this page"
   - Connection timeout
   - "This site can't be reached"

---

## Test 5: Check Database

1. Open browser
2. Go to: `http://localhost/phpmyadmin`
3. Look on left side for database list
4. Do you see `helphup_db`?

   **âœ… If YES:** Good!
   **âŒ If NO:** You need to create it or import SQL file

---

## Test 6: Test Actual Login (with Postman or Browser DevTools)

### Using Browser (Chrome DevTools):

1. Open browser
2. Press F12 (Open Developer Tools)
3. Go to "Network" tab
4. Go to "Console" tab
5. Type this JavaScript:
   ```javascript
   fetch('http://10.22.186.166/helphup/api/ngo_login.php', {
     method: 'POST',
     headers: {'Content-Type': 'application/json'},
     body: JSON.stringify({email: 'test@test.com', password: 'test'})
   })
   .then(r => r.text())
   .then(console.log)
   .catch(console.error)
   ```
6. Check the response

---

## Common Problems & Quick Fixes

### Problem: "File not found" in browser
**Fix:** PHP files are not in correct location
- Copy files to: `C:\xampp\htdocs\helphup\api\`

### Problem: Can't connect from phone
**Fix:** Network/Firewall issue
- Check both on same WiFi
- Check Windows Firewall allows Apache
- Try turning off firewall temporarily (just to test)

### Problem: Blank page when accessing PHP file
**Fix:** PHP errors (check error log)
- Open: `C:\xampp\apache\logs\error.log`
- Look for PHP errors

### Problem: HTML error page instead of JSON
**Fix:** PHP syntax error
- Check `error.log` file
- Fix syntax errors in PHP files

### Problem: Database connection error
**Fix:** MySQL not running or database doesn't exist
- Start MySQL in XAMPP
- Create database in phpMyAdmin

---

## What to Do Next Based on Test Results

### âœ… All Tests Pass:
- Your server is working!
- The issue might be in the Android app code
- Check Android Studio Logcat for specific errors

### âŒ Test 1 Fails (Apache not running):
- Start Apache in XAMPP Control Panel
- Check if port 80 is in use

### âŒ Test 2 Fails (Files not found):
- Copy files from `xampp_files` folder to `C:\xampp\htdocs\helphup\api\`

### âŒ Test 3 Fails (Can't access from PC browser):
- Check XAMPP Apache is running
- Check files are in correct location
- Check PHP error logs

### âŒ Test 4 Fails (Can't access from phone):
- Verify phone and PC on same WiFi
- Check Windows Firewall
- Verify IP address is correct

### âŒ Test 5 Fails (Database not found):
- Create database in phpMyAdmin
- Import database_setup.sql file

---

## Need More Help?

Tell me which test failed and what error message you see, and I can help you fix it!

