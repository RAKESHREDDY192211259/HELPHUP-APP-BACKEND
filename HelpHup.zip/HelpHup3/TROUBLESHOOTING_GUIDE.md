﻿# ðŸ”§ Troubleshooting Guide - Connection Errors

If you're getting connection errors like "End of input at character 2" or "Connection error", follow these steps **IN ORDER**:

---

## âœ… STEP 1: Verify XAMPP is Running

1. **Open XAMPP Control Panel**
2. **Check if Apache is RUNNING (Green)**
   - If RED/STOPPED â†’ Click **Start** button
   - Wait until it shows **Running** in green
3. **Check if MySQL is RUNNING (Green)**
   - If RED/STOPPED â†’ Click **Start** button
   - Wait until it shows **Running** in green

âš ï¸ **If Apache won't start:**
- Check if port 80 is already in use
- Try changing Apache port in XAMPP settings
- Check Windows Firewall

---

## âœ… STEP 2: Verify PHP Files are in Correct Location

**Your PHP files MUST be in:**
```
C:\xampp\htdocs\helphup\api\
```

**Files needed:**
- `config.php`
- `ngo_login.php`
- `ngo_register.php`
- `ngoforgot.php`
- `volunteer_login.php`
- `volunteer_register.php`
- `volunteer_forgot.php`
- `donor_login.php`
- `donor_register.php`
- `donor_forgot.php`

**To copy files:**
1. Copy ALL files from `xampp_files` folder in your project
2. Paste them to `C:\xampp\htdocs\helphup\api\`
3. Make sure folder structure exists: `htdocs\helphup\api\`

---

## âœ… STEP 3: Verify Database Exists

1. Open browser
2. Go to: `http://localhost/phpmyadmin`
3. Check if database `helphup_db` exists
4. If NOT exists:
   - Click "New" â†’ Database name: `helphup_db`
   - Click "Create"
   - Import `database_setup.sql` file

---

## âœ… STEP 4: Check Your Computer's IP Address

**Your app uses IP: `10.73.39.192`**

**To verify your current IP:**
1. Open Command Prompt (CMD)
2. Type: `ipconfig`
3. Look for **IPv4 Address** under your WiFi adapter
4. Example: `192.168.1.100` or `10.73.39.192`

**If IP is DIFFERENT from `10.26.77.227`:**
- Option 1: Change IP in app code (search for `10.73.39.192` in all Kotlin files)
- Option 2: Change your computer's IP to match (not recommended)

---

## âœ… STEP 5: Test PHP Files in Browser

**Test each endpoint:**

1. **Test config.php:**
   - Open: `http://localhost/helphup/api/config.php`
   - Should show blank page (no errors)

2. **Test ngo_login.php:**
   - Open: `http://localhost/helphup/api/ngo_login.php`
   - Should show JSON error (not HTML error page)
   - If you see HTML error â†’ PHP file has errors

3. **Test from your phone's browser:**
   - Open: `http://10.73.39.192/helphup/api/ngo_login.php`
   - Should show JSON response
   - If connection fails â†’ Network/Firewall issue

---

## âœ… STEP 6: Check Windows Firewall

1. Open **Windows Defender Firewall**
2. Click **Allow an app through firewall**
3. Make sure **Apache HTTP Server** is checked (both Private & Public)
4. If not listed â†’ Click "Allow another app" â†’ Browse to `C:\xampp\apache\bin\httpd.exe`

---

## âœ… STEP 7: Verify Phone and PC on Same WiFi

1. **On your PC:**
   - Check WiFi network name (SSID)
   - Example: "HomeWiFi"

2. **On your Android phone:**
   - Check WiFi network name
   - Must be **EXACTLY the same** as PC

3. **If different networks:**
   - Connect both to same WiFi
   - Or use Android Emulator (use `localhost` instead of IP)

---

## âœ… STEP 8: Check PHP Error Logs

1. Open: `C:\xampp\apache\logs\error.log`
2. Look for recent errors
3. Common errors:
   - Database connection failed â†’ Check MySQL is running
   - File not found â†’ Check file paths
   - Syntax error â†’ Check PHP file syntax

---

## âœ… STEP 9: Quick Test Commands

**Test if server responds:**

**In Command Prompt:**
```bash
ping 10.73.39.192
```
- Should get replies (not "Request timed out")

**Test HTTP connection:**
```bash
curl http://10.73.39.192/helphup/api/ngo_login.php
```
- Should return JSON (even if error)

---

## âœ… STEP 10: Common Issues & Solutions

### Issue: "End of input at character 2"
**Cause:** Server returns empty/invalid JSON
**Solution:**
- Check PHP error logs
- Test PHP file in browser
- Verify database connection works

### Issue: "Unable to resolve host"
**Cause:** Cannot find server IP
**Solution:**
- Verify IP address is correct
- Check phone and PC on same WiFi
- Test IP in browser: `http://10.73.39.192`

### Issue: "Connection refused"
**Cause:** Apache not running or port blocked
**Solution:**
- Start Apache in XAMPP
- Check firewall allows Apache
- Try different port if 80 is blocked

### Issue: "Connection timeout"
**Cause:** Network connectivity issue
**Solution:**
- Check WiFi connection
- Verify IP address
- Check firewall settings
- Try ping command

---

## ðŸŽ¯ Quick Checklist

Before testing the app, verify:

- [ ] XAMPP Apache is **RUNNING** (green)
- [ ] XAMPP MySQL is **RUNNING** (green)
- [ ] PHP files are in `C:\xampp\htdocs\helphup\api\`
- [ ] Database `helphup_db` exists in phpMyAdmin
- [ ] IP address `10.73.39.192` matches your PC's IP
- [ ] Phone and PC are on **same WiFi network**
- [ ] Windows Firewall allows Apache
- [ ] Can access `http://10.73.39.192/helphup/api/ngo_login.php` from phone browser
- [ ] No PHP errors in error.log file

---

## ðŸ“ž Still Not Working?

If you've checked everything above and still getting errors:

1. **Check Android Studio Logcat:**
   - Look for actual error messages
   - Copy the full error text

2. **Test with Postman/API Client:**
   - Try calling the API directly
   - See what response you get

3. **Try localhost (if using Emulator):**
   - Change IP to `localhost` or `10.0.2.2` (for Android emulator)
   - Update base URL in app code

4. **Verify JSON Response:**
   - Test endpoint in browser
   - Response should be valid JSON, not HTML

---

## ðŸ” Debug Mode: Enable Detailed Logging

Add this to your PHP files (temporarily) to see errors:
```php
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config.php';
// ... rest of code
```

**Remove this after debugging!**

---

**Last Updated:** Check all steps in order. Most issues are resolved in Steps 1-4.

