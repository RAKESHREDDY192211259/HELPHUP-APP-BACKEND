# 🚀 New Unified Help Request System

## 📋 Overview

A completely new unified help request system that follows the exact help request flow you specified. This system leaves all old tables untouched and creates a clean, unified structure.

## 🎯 Help Request Flow Implementation

### **Step 1: User Raises Help Request**
- **Who:** NGO / Donor / Volunteer
- **What:** New record inserted into `unified_help_requests`
- **Status:** `pending`
- **Admin:** Only admin can see pending requests

### **Step 2: Admin Sees Pending Requests**
- **Endpoint:** `unified_get_admin_requests.php?status=pending`
- **Shows:** ALL pending requests from all 3 roles
- **Details:** Who requested, request details, request type

### **Step 3: Admin Verifies (Approve/Reject)**
- **Endpoint:** `unified_update_request_status.php`
- **Action:** Updates status to `approved` or `rejected`
- **Tracking:** Creates status history entry

### **Step 4: Status Update to Request Owner**
- **Endpoint:** `unified_get_my_requests.php`
- **Shows:** User's own requests with current status
- **Status:** `pending` → `approved` → `rejected`

### **Step 5: Approved Requests Become Public**
- **Endpoint:** `unified_get_public_requests.php`
- **Shows:** Only `approved` requests to all other roles
- **Filtering:** Can exclude requester's own type

---

## 🗄️ Database Structure

### **Main Table: `unified_help_requests`**
```sql
- request_id (PK)
- requester_type (ngo/donor/volunteer)
- requester_id
- requester_name/email/phone
- request_title, category, description, urgency_level
- Type-specific fields (amount, location, dates, etc.)
- status (pending/approved/rejected)
- admin_id, admin_reviewed_at, rejection_reason
- created_at, updated_at
```

### **Supporting Tables:**
- `request_status_history` - Tracks all status changes
- `admin_notifications` - Admin notifications for new requests
- `help_interactions` - Tracks user interest in helping

### **Views for Easy Access:**
- `admin_pending_requests` - Admin dashboard view
- `public_help_requests` - Public help requests view
- `my_requests` - User's own requests view

---

## 🔗 API Endpoints

### **1. Create Help Request**
**POST:** `unified_create_help_request.php`
```json
{
  "requester_type": "ngo",
  "requester_id": 1,
  "requester_name": "Hope Foundation",
  "requester_email": "contact@hope.org",
  "requester_phone": "+91-9876543210",
  "request_title": "Food Distribution Drive",
  "category": "Food Distribution",
  "description": "Need help distributing food",
  "urgency_level": "High",
  "required_amount": 50000,
  "date_needed": "2026-01-25",
  "contact_number": "+91-9876543210"
}
```

### **2. Get Admin Requests**
**GET:** `unified_get_admin_requests.php?status=pending`
```json
{
  "status": true,
  "data": [...],
  "counts": {
    "pending": 5,
    "approved": 12,
    "rejected": 2
  }
}
```

### **3. Update Request Status**
**POST:** `unified_update_request_status.php`
```json
{
  "request_id": 1,
  "status": "approved",
  "admin_id": 1,
  "rejection_reason": null
}
```

### **4. Get Public Requests (Help Others)**
**GET:** `unified_get_public_requests.php?exclude_requester_type=ngo`
```json
{
  "status": true,
  "data": [...],
  "filters": {
    "categories": ["Food", "Education", "Medical"],
    "urgency_levels": ["Low", "Medium", "High", "Critical"]
  }
}
```

### **5. Get My Requests**
**GET:** `unified_get_my_requests.php?requester_type=ngo&requester_id=1`
```json
{
  "status": true,
  "data": [...],
  "counts": {
    "pending": 1,
    "approved": 3,
    "rejected": 0
  }
}
```

---

## 📱 Android App Integration

### **Current Pages → New Endpoints**

| Current Page | Current Endpoint | New Endpoint | Purpose |
|-------------|------------------|---------------|---------|
| NgoRaiseHelp.kt | ngo_raise_help.php | unified_create_help_request.php | Create NGO request |
| VolunteerRaiseHelp.kt | volunteer_raise_help.php | unified_create_help_request.php | Create Volunteer request |
| DonorRaiseDonation.kt | Donor_raise_help.php | unified_create_help_request.php | Create Donor request |
| NgoHelpOthers.kt | get_all_volunteer_requests.php + get_all_donor_campaigns.php | unified_get_public_requests.php?exclude_requester_type=ngo | Show others' requests |
| VolunteerHelpOthers.kt | get_all_ngo_requests.php + get_all_donor_campaigns.php | unified_get_public_requests.php?exclude_requester_type=volunteer | Show others' requests |
| DonorBrowseCause.kt | get_all_ngo_requests.php + get_all_volunteer_requests.php | unified_get_public_requests.php?exclude_requester_type=donor | Show others' requests |

### **New Pages Needed:**
- **My Requests pages** for each role (using `unified_get_my_requests.php`)
- **Admin Dashboard** (using `unified_get_admin_requests.php`)

---

## 🔄 Complete Flow Example

### **NGO Creates Request:**
1. NGO fills form in `NgoRaiseHelp.kt`
2. App calls `unified_create_help_request.php`
3. Status = `pending`
4. Admin gets notification
5. Admin sees request in dashboard

### **Admin Approves:**
1. Admin reviews request in dashboard
2. Admin clicks "Approve"
3. App calls `unified_update_request_status.php`
4. Status = `approved`
5. Request becomes public

### **Others Can Help:**
1. Volunteer opens `VolunteerHelpOthers.kt`
2. App calls `unified_get_public_requests.php?exclude_requester_type=volunteer`
3. Sees NGO request (approved)
4. Can view details and offer help

### **NGO Sees Status:**
1. NGO opens "My Requests" page
2. App calls `unified_get_my_requests.php?requester_type=ngo&requester_id=1`
3. Sees request status = `approved`

---

## 🚀 Implementation Steps

### **1. Database Setup:**
```sql
-- Run this in phpMyAdmin
SOURCE NEW_UNIFIED_HELP_SYSTEM.sql
```

### **2. Deploy API Files:**
Copy all `unified_*.php` files to your `xampp_files/api/` directory

### **3. Update Android App:**
- Update API calls in existing pages
- Create new "My Requests" pages
- Update data models to match new structure

### **4. Test Flow:**
1. Create test requests from each role
2. Verify admin sees pending requests
3. Test approval/rejection workflow
4. Verify approved requests appear in Help Others pages

---

## ✅ Benefits of New System

1. **Clean Architecture:** Single unified table for all requests
2. **Consistent Flow:** Follows your exact help request flow
3. **No Legacy Issues:** Old tables remain untouched
4. **Easy Maintenance:** Centralized logic and data
5. **Scalable:** Easy to add new features
6. **Complete Tracking:** Full history and notifications
7. **Flexible Filtering:** Advanced filtering and search
8. **Role-Based Access:** Proper separation of concerns

---

## 🎯 Key Features

- ✅ **Single Status System:** `pending` → `approved` → `rejected`
- ✅ **Type-Specific Fields:** Handles NGO, Volunteer, Donor differences
- ✅ **Admin Notifications:** Automatic notifications for new requests
- ✅ **Status History:** Complete audit trail of all changes
- ✅ **Public Visibility:** Approved requests visible to all other roles
- ✅ **Search & Filter:** Advanced filtering by category, urgency, etc.
- ✅ **Real-time Updates:** Status changes immediately visible
- ✅ **Help Tracking:** Track user interest in helping requests

This new system provides a clean, unified approach to help requests that perfectly matches your specified flow while leaving all existing code and tables intact.
