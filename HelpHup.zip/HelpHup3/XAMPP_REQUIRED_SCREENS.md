﻿# Screens That Require XAMPP/Database Connection

## âš ï¸ IMPORTANT: These screens will NOT work without XAMPP running!

**Base URL:** `http://10.73.39.192/helphup/api/`  
**Required:** XAMPP must be running with:
- Apache Server (for PHP files)
- MySQL Database (for data storage)
- PHP files in `htdocs/helphup/api/` directory

---

## âœ… SCREENS THAT REQUIRE XAMPP (10 Screens)

### ðŸ” Authentication Screens (7 Screens)

#### 1. **NGO Login Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `NgoLogin.kt`
- **Screen Route:** `Routes.NGO_LOGIN`
- **API Endpoint:** `ngo_login.php`
- **Database Operations:**
  - Validates email and password
  - Checks NGO credentials in database
  - Returns login status
- **What happens if XAMPP is OFF:**
  - âŒ Login button will fail
  - âŒ Shows "Server not reachable" error
  - âŒ Cannot access NGO Dashboard

#### 2. **NGO Registration Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `NgoRegistration.kt`
- **Screen Route:** `Routes.NGO_REGISTER`
- **API Endpoint:** `ngo_register.php`
- **Database Operations:**
  - Creates new NGO account
  - Stores: full_name, phone, email, address, org_name, reg_number, password
  - Uploads registration proof file
  - Inserts data into NGO table
- **What happens if XAMPP is OFF:**
  - âŒ Registration will fail
  - âŒ Shows "Server not reachable" error
  - âŒ Cannot create new NGO account

#### 3. **NGO Forgot Password Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `NgoForgotPassword.kt`
- **Screen Route:** `Routes.NGO_FORGOT_PASSWORD`
- **API Endpoint:** `ngoforgot.php`
- **Database Operations:**
  - Validates email exists
  - Generates and sends OTP
  - Updates password reset token
- **What happens if XAMPP is OFF:**
  - âŒ OTP sending will fail
  - âŒ Shows "Server not reachable" error
  - âŒ Cannot reset password

#### 4. **Volunteer Login Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `VolunteerLogin.kt`
- **Screen Route:** `Routes.VOLUNTEER_LOGIN`
- **API Endpoint:** `volunteer_login.php`
- **Database Operations:**
  - Validates email and password
  - Checks volunteer credentials
  - Returns volunteer data (id, name, email)
- **What happens if XAMPP is OFF:**
  - âŒ Login button will fail
  - âŒ Shows "Network error" message
  - âŒ Cannot access Volunteer Dashboard

#### 5. **Volunteer Registration Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `VolunteerRegistration.kt`
- **Screen Route:** `Routes.VOLUNTEER_REGISTER`
- **API Endpoint:** `volunteer_register.php`
- **Database Operations:**
  - Creates new volunteer account
  - Stores: full_name, email, password, skills, availability
  - Inserts data into volunteer table
- **What happens if XAMPP is OFF:**
  - âŒ Registration will fail
  - âŒ Shows "Network error" message
  - âŒ Cannot create new volunteer account

#### 6. **Donor Login Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `DonorLogin.kt`
- **Screen Route:** `Routes.DONOR_LOGIN`
- **API Endpoint:** `donor_login.php`
- **Database Operations:**
  - Validates email and password
  - Checks donor credentials
  - Returns donor data (donor_id, full_name)
- **What happens if XAMPP is OFF:**
  - âŒ Login button will fail
  - âŒ Shows "Network Error" message
  - âŒ Cannot access Donor Dashboard

#### 7. **Donor Registration Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `DonorRegistration.kt`
- **Screen Route:** `Routes.DONOR_REGISTER`
- **API Endpoint:** `donor_register.php`
- **Database Operations:**
  - Creates new donor account
  - Stores: full_name, phone, email, address, password
  - Inserts data into donor table
- **What happens if XAMPP is OFF:**
  - âŒ Registration will fail
  - âŒ Shows error message
  - âŒ Cannot create new donor account

---

### ðŸ“ Help Request/Campaign Screens (3 Screens)

#### 8. **NGO Raise Help Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `NgoRaiseHelp.kt`
- **Screen Route:** `Routes.NGO_RAISE_HELP`
- **API Endpoint:** `ngo_raise_help.php`
- **Database Operations:**
  - Creates new help request
  - Stores: ngo_id, request_title, category, urgency_level, required_amount, date_needed, contact_number, description
  - Inserts data into help_requests table
- **What happens if XAMPP is OFF:**
  - âŒ Submit button will fail
  - âŒ Shows "Network error" message
  - âŒ Cannot create help request

#### 9. **Volunteer Raise Help Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `VolunteerRaiseHelp.kt`
- **Screen Route:** `Routes.VOLUNTEER_RAISE_HELP`
- **API Endpoint:** `volunteer_raise_help.php`
- **Database Operations:**
  - Creates new volunteer help request
  - Stores: volunteer_id, request_title, category, description, location, help_date, start_time, volunteers_needed
  - Inserts data into volunteer_requests table
- **What happens if XAMPP is OFF:**
  - âŒ Submit button will fail
  - âŒ Shows "Network error" message
  - âŒ Cannot create volunteer request

#### 10. **Donor Raise Donation Campaign Screen** ðŸ”´ REQUIRES XAMPP
- **File:** `DonorRaiseDonation.kt`
- **Screen Route:** `Routes.DONOR_RAISE_DONATION`
- **API Endpoint:** `Donor_raise_help.php`
- **Database Operations:**
  - Creates new donation campaign
  - Stores: donor_id, campaign_title, fundraising_goal, category, cover_image_url, video_url, duration, end_date, beneficiary_name, relationship, contact_email
  - Inserts data into campaigns table
- **What happens if XAMPP is OFF:**
  - âŒ Submit button will fail
  - âŒ Shows error message
  - âŒ Cannot create donation campaign

---

## âœ… SCREENS THAT DO NOT REQUIRE XAMPP (36+ Screens)

These screens work **WITHOUT** XAMPP because they only display static UI or navigate between screens:

### Dashboard Screens (3)
- âœ… `NgoDashboard.kt` - Static UI only
- âœ… `VolunteerDashboard.kt` - Static UI only
- âœ… `DonorDashboard.kt` - Static UI only

### Profile Screens (6)
- âœ… `NgoProfile.kt` - Static UI only
- âœ… `VolunteerProfile.kt` - Static UI only
- âœ… `DonorProfileScreen.kt` - Static UI only
- âœ… `NgoEditProfile.kt` - No API call (just navigation)
- âœ… `VolunteerEditDetails.kt` - No API call (just navigation)
- âœ… `DonorEditDetails.kt` - No API call (just navigation)

### Browse/View Screens (5)
- âœ… `NgoHelpOthers.kt` - Static UI only
- âœ… `VolunteerHelpOthers.kt` - Static UI only
- âœ… `DonorBrowseCause.kt` - Static UI only
- âœ… `DonorBrowseCauseDetailsScreen.kt` - Static UI only
- âœ… `VolunteerViewHelpRequestDetails.kt` - Static UI only

### Support/Donation Screens (3)
- âœ… `NgoCommunitySupport.kt` - Static UI only
- âœ… `VolunteerCommunitySupport.kt` - Static UI only
- âœ… `DonorCommunitySupport.kt` - Static UI only

### Payment Screens (9)
- âœ… `NgoPaymentMethods.kt` - Static UI only
- âœ… `VolunteerPaymentMethods.kt` - Static UI only
- âœ… `DonorPaymentMethods.kt` - Static UI only
- âœ… `NgoPaymentDetails.kt` - Static UI only
- âœ… `VolunteerPaymentDetails.kt` - Static UI only
- âœ… `DonorPaymentDetails.kt` - Static UI only
- âœ… `NgoPaymentConfirmation.kt` - Static UI only
- âœ… `VolunteerSupportConfirmation.kt` - Static UI only
- âœ… `DonorSupportConfirmation.kt` - Static UI only

### History/Records Screens (4)
- âœ… `NgoDonorsHistory.kt` - Static UI only
- âœ… `NgoVolunteersHistory.kt` - Static UI only
- âœ… `VolunteerHistory.kt` - Static UI only
- âœ… `DonorDonationHistory.kt` - Static UI only
- âœ… `VolunteerDonationRecords.kt` - Static UI only

### Other Screens (6+)
- âœ… `NgoNotifications.kt` - Static UI only
- âœ… `VolunteerNotifications.kt` - Static UI only
- âœ… `DonorNotification.kt` - Static UI only
- âœ… `DonorImpact.kt` - Static UI only
- âœ… `VolunteerHelpRequestSubmitted.kt` - Static UI only
- âœ… `RoleSelection.kt` - Static UI only
- âœ… `Welcome.kt` - Static UI only

---

## ðŸ“Š Summary

### Screens Requiring XAMPP: **10 Screens** ðŸ”´
1. NGO Login
2. NGO Registration
3. NGO Forgot Password
4. Volunteer Login
5. Volunteer Registration
6. Donor Login
7. Donor Registration
8. NGO Raise Help
9. Volunteer Raise Help
10. Donor Raise Donation

### Screens NOT Requiring XAMPP: **36+ Screens** âœ…
- All dashboard screens
- All profile screens
- All payment screens
- All history/notification screens
- All browse/view screens

---

## ðŸš¨ Testing Checklist

Before testing, ensure:
1. âœ… XAMPP is installed
2. âœ… Apache is running (green in XAMPP Control Panel)
3. âœ… MySQL is running (green in XAMPP Control Panel)
4. âœ… PHP files are in `C:\xampp\htdocs\helphup\api\` directory
5. âœ… Database is created and tables exist
6. âœ… Android device/emulator can reach `http://10.26.77.227` (same network)

---

## ðŸ’¡ Quick Test

**To test if XAMPP is working:**
1. Open browser and go to: `http://10.73.39.192/helphup/api/ngo_login.php`
2. If you see a response (even an error), XAMPP is working
3. If connection fails, check:
   - Apache is running
   - Firewall is not blocking
   - IP address is correct
   - Device is on same network

