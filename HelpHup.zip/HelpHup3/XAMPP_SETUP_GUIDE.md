﻿# XAMPP Database Setup Guide for HelpHup App

## ðŸ“ File Paths & Directory Structure

### XAMPP Installation Path
**Default Location:** `C:\xampp\`

### Required Directory Structure
```
C:\xampp\
â”œâ”€â”€ htdocs\
â”‚   â””â”€â”€ helphup\
â”‚       â”œâ”€â”€ api\                    â† All PHP files go here
â”‚       â”‚   â”œâ”€â”€ ngo_login.php
â”‚       â”‚   â”œâ”€â”€ ngo_register.php
â”‚       â”‚   â”œâ”€â”€ ngoforgot.php
â”‚       â”‚   â”œâ”€â”€ volunteer_login.php
â”‚       â”‚   â”œâ”€â”€ volunteer_register.php
â”‚       â”‚   â”œâ”€â”€ volunteer_forgot.php
â”‚       â”‚   â”œâ”€â”€ donor_login.php
â”‚       â”‚   â”œâ”€â”€ donor_register.php
â”‚       â”‚   â”œâ”€â”€ donor_forgot.php
â”‚       â”‚   â”œâ”€â”€ ngo_raise_help.php
â”‚       â”‚   â”œâ”€â”€ volunteer_raise_help.php
â”‚       â”‚   â””â”€â”€ Donor_raise_help.php
â”‚       â””â”€â”€ uploads\                 â† For file uploads (registration proofs, images)
â”‚           â””â”€â”€ registration_proofs\
â””â”€â”€ mysql\
    â””â”€â”€ data\
        â””â”€â”€ helphup_db\              â† Database files (auto-created)
```

---

## ðŸ—„ï¸ Database Connection Details

### MySQL Connection Settings
```php
// Database Configuration (use in all PHP files)
$host = "localhost";
$username = "root";           // Default XAMPP MySQL username
$password = "";                // Default XAMPP MySQL password (empty)
$database = "helphup_db";      // Your database name
```

### Create Database
1. Open **phpMyAdmin**: `http://localhost/phpmyadmin`
2. Click **"New"** to create database
3. Database name: `helphup_db`
4. Collation: `utf8mb4_general_ci`
5. Click **"Create"**

---

## ðŸ“Š Database Tables Schema

### 1. **ngo** Table
```sql
CREATE TABLE `ngo` (
  `ngo_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `address` TEXT NOT NULL,
  `org_name` VARCHAR(200) NOT NULL,
  `reg_number` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `reg_proof_file` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ngo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 2. **volunteer** Table
```sql
CREATE TABLE `volunteer` (
  `volunteer_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `skills` TEXT DEFAULT NULL,
  `availability` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`volunteer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 3. **donor** Table
```sql
CREATE TABLE `donor` (
  `donor_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `address` TEXT NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`donor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 4. **ngo_help_requests** Table
```sql
CREATE TABLE `ngo_help_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ngo_id` INT(11) NOT NULL,
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `urgency_level` VARCHAR(20) NOT NULL,
  `required_amount` DECIMAL(10,2) NOT NULL,
  `date_needed` DATE NOT NULL,
  `contact_number` VARCHAR(20) NOT NULL,
  `description` TEXT NOT NULL,
  `status` VARCHAR(20) DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  FOREIGN KEY (`ngo_id`) REFERENCES `ngo`(`ngo_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 5. **volunteer_requests** Table
```sql
CREATE TABLE `volunteer_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `volunteer_id` INT(11) NOT NULL,
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `description` TEXT NOT NULL,
  `location` VARCHAR(200) NOT NULL,
  `help_date` DATE NOT NULL,
  `start_time` TIME NOT NULL,
  `volunteers_needed` INT(11) NOT NULL,
  `status` VARCHAR(20) DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  FOREIGN KEY (`volunteer_id`) REFERENCES `volunteer`(`volunteer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 6. **donor_campaigns** Table
```sql
CREATE TABLE `donor_campaigns` (
  `campaign_id` INT(11) NOT NULL AUTO_INCREMENT,
  `donor_id` INT(11) NOT NULL,
  `campaign_title` VARCHAR(200) NOT NULL,
  `fundraising_goal` DECIMAL(10,2) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `cover_image_url` VARCHAR(255) DEFAULT NULL,
  `video_url` VARCHAR(255) DEFAULT NULL,
  `duration` VARCHAR(50) NOT NULL,
  `end_date` DATE NOT NULL,
  `beneficiary_name` VARCHAR(100) NOT NULL,
  `relationship` VARCHAR(50) NOT NULL,
  `contact_email` VARCHAR(100) NOT NULL,
  `status` VARCHAR(20) DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`campaign_id`),
  FOREIGN KEY (`donor_id`) REFERENCES `donor`(`donor_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 7. **password_reset_tokens** Table (For Forgot Password)
```sql
CREATE TABLE `password_reset_tokens` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL,
  `user_type` VARCHAR(20) NOT NULL,  -- 'ngo', 'volunteer', 'donor'
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_email_type` (`email`, `user_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## ðŸ”§ PHP Database Connection File

### Create: `C:\xampp\htdocs\helphup\api\config.php`

```php
<?php
// Database Configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "helphup_db";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4
$conn->set_charset("utf8mb4");

// Function to send JSON response
function sendResponse($status, $message, $data = null) {
    header('Content-Type: application/json');
    $response = array(
        'status' => $status,
        'message' => $message
    );
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response);
    exit();
}
?>
```

---

## ðŸ“ Example PHP Files

### 1. NGO Login: `ngo_login.php`
```php
<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

if (empty($email) || empty($password)) {
    sendResponse(false, "Email and password are required");
}

// Query database
$stmt = $conn->prepare("SELECT ngo_id, full_name, email, password FROM ngo WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        sendResponse(true, "Login successful", array(
            'ngo_id' => $row['ngo_id'],
            'full_name' => $row['full_name'],
            'email' => $row['email']
        ));
    } else {
        sendResponse(false, "Invalid password");
    }
} else {
    sendResponse(false, "Email not found");
}

$stmt->close();
$conn->close();
?>
```

### 2. NGO Registration: `ngo_register.php`
```php
<?php
require_once 'config.php';

// Handle multipart form data
$full_name = $_POST['full_name'] ?? '';
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';
$address = $_POST['address'] ?? '';
$org_name = $_POST['org_name'] ?? '';
$reg_number = $_POST['reg_number'] ?? '';
$password = $_POST['password'] ?? '';

// Validate required fields
if (empty($full_name) || empty($phone) || empty($email) || 
    empty($address) || empty($org_name) || empty($reg_number) || empty($password)) {
    sendResponse(false, "All fields are required");
}

// Check if email already exists
$check = $conn->prepare("SELECT ngo_id FROM ngo WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    sendResponse(false, "Email already registered");
}
$check->close();

// Handle file upload
$reg_proof_file = null;
if (isset($_FILES['reg_proof']) && $_FILES['reg_proof']['error'] == 0) {
    $upload_dir = '../uploads/registration_proofs/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $file_name = time() . '_' . basename($_FILES['reg_proof']['name']);
    $target_file = $upload_dir . $file_name;
    if (move_uploaded_file($_FILES['reg_proof']['tmp_name'], $target_file)) {
        $reg_proof_file = 'uploads/registration_proofs/' . $file_name;
    }
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert into database
$stmt = $conn->prepare("INSERT INTO ngo (full_name, phone, email, address, org_name, reg_number, password, reg_proof_file) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $full_name, $phone, $email, $address, $org_name, $reg_number, $hashed_password, $reg_proof_file);

if ($stmt->execute()) {
    sendResponse(true, "Registration successful");
} else {
    sendResponse(false, "Registration failed: " . $conn->error);
}

$stmt->close();
$conn->close();
?>
```

### 3. Volunteer Forgot Password: `volunteer_forgot.php`
```php
<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$email = $data['email'] ?? '';

if (empty($email)) {
    sendResponse(false, "Email is required");
}

// Check if email exists
$stmt = $conn->prepare("SELECT volunteer_id FROM volunteer WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    sendResponse(false, "Email not found");
}

// Generate 6-digit OTP
$otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));

// Delete old tokens for this email
$delete = $conn->prepare("DELETE FROM password_reset_tokens WHERE email = ? AND user_type = 'volunteer'");
$delete->bind_param("s", $email);
$delete->execute();
$delete->close();

// Insert new token
$insert = $conn->prepare("INSERT INTO password_reset_tokens (email, user_type, otp, expires_at) VALUES (?, 'volunteer', ?, ?)");
$insert->bind_param("sss", $email, $otp, $expires_at);
$insert->execute();
$insert->close();

// TODO: Send OTP via email/SMS
// For now, just return success (in production, send OTP via email)

sendResponse(true, "OTP sent to your email. OTP: " . $otp); // Remove OTP from message in production!

$stmt->close();
$conn->close();
?>
```

---

## ðŸŒ Network Configuration

### Current Base URL in App
```
http://10.26.77.227/helphup/api/
```

### For Localhost Testing
If testing on same machine, change to:
```
http://localhost/helphup/api/
```

### For Network Access (Android Device)
1. Find your PC's IP address:
   - Open Command Prompt
   - Type: `ipconfig`
   - Look for **IPv4 Address** (e.g., `192.168.1.100`)

2. Update base URL in Android app:
   - Change `10.26.77.227` to your PC's IP address
   - Or use `localhost` if using Android emulator

3. Ensure firewall allows Apache:
   - Windows Firewall â†’ Allow Apache HTTP Server

---

## ðŸ“‹ Step-by-Step Setup Instructions

### Step 1: Install XAMPP
1. Download from: https://www.apachefriends.org/
2. Install to: `C:\xampp\`
3. Start **XAMPP Control Panel**

### Step 2: Start Services
1. Click **Start** for **Apache**
2. Click **Start** for **MySQL**
3. Both should show green "Running" status

### Step 3: Create Database
1. Open browser: `http://localhost/phpmyadmin`
2. Click **"New"** in left sidebar
3. Database name: `helphup_db`
4. Collation: `utf8mb4_general_ci`
5. Click **"Create"**

### Step 4: Create Tables
1. Select `helphup_db` database
2. Click **"SQL"** tab
3. Copy and paste all SQL CREATE TABLE statements above
4. Click **"Go"**

### Step 5: Create Directory Structure
```
C:\xampp\htdocs\helphup\api\
C:\xampp\htdocs\helphup\uploads\registration_proofs\
```

### Step 6: Create PHP Files
1. Create `config.php` in `api\` folder
2. Create all PHP endpoint files (see examples above)
3. Save all files with `.php` extension

### Step 7: Test Connection
1. Open browser: `http://localhost/helphup/api/config.php`
2. Should show connection status (or blank if working)

### Step 8: Update Android App Base URL
- If using localhost: Change to `http://localhost/helphup/api/`
- If using network: Change to `http://YOUR_IP/helphup/api/`

---

## ðŸ” Security Notes

### Password Hashing
Always use `password_hash()` and `password_verify()`:
```php
// Registration
$hashed = password_hash($password, PASSWORD_DEFAULT);

// Login
if (password_verify($input_password, $stored_hash)) {
    // Login successful
}
```

### SQL Injection Prevention
Always use prepared statements:
```php
$stmt = $conn->prepare("SELECT * FROM table WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
```

### File Upload Security
```php
// Check file type
$allowed = ['pdf', 'jpg', 'png'];
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allowed)) {
    sendResponse(false, "Invalid file type");
}
```

---

## ðŸ“± Testing Checklist

- [ ] XAMPP Apache is running
- [ ] XAMPP MySQL is running
- [ ] Database `helphup_db` created
- [ ] All 7 tables created
- [ ] `config.php` file created
- [ ] All PHP endpoint files created
- [ ] Upload directory created with write permissions
- [ ] Base URL updated in Android app
- [ ] Test NGO registration
- [ ] Test NGO login
- [ ] Test Volunteer registration
- [ ] Test Volunteer login
- [ ] Test Donor registration
- [ ] Test Donor login
- [ ] Test Forgot Password (all 3 roles)
- [ ] Test Raise Help requests

---

## ðŸ› Troubleshooting

### Issue: "Connection failed"
- Check MySQL is running in XAMPP
- Verify database name is correct
- Check username/password in config.php

### Issue: "Access denied"
- Check MySQL user permissions
- Default XAMPP: username=`root`, password=`` (empty)

### Issue: "File upload failed"
- Check upload directory exists
- Check directory permissions (should be writable)
- Check PHP upload_max_filesize in php.ini

### Issue: "Cannot connect from Android"
- Check PC and Android on same WiFi network
- Check firewall allows Apache
- Verify IP address is correct
- Try `localhost` if using emulator

---

## ðŸ“ž Quick Reference

**XAMPP Path:** `C:\xampp\`  
**PHP Files:** `C:\xampp\htdocs\helphup\api\`  
**Database:** `helphup_db`  
**phpMyAdmin:** `http://localhost/phpmyadmin`  
**Test API:** `http://localhost/helphup/api/`  
**MySQL User:** `root`  
**MySQL Password:** `` (empty by default)

