# Your XAMPP File Structure

## ✅ Confirmed File Path
```
C:\xampp\htdocs\helphup\api\
```

---

## 📁 Complete Directory Structure You Need

```
C:\xampp\
└── htdocs\
    └── helphup\
        ├── api\                          ← YOUR PATH (✅ Correct!)
        │   ├── config.php                ← Database connection file
        │   ├── ngo_login.php
        │   ├── ngo_register.php
        │   ├── ngoforgot.php
        │   ├── volunteer_login.php
        │   ├── volunteer_register.php
        │   ├── volunteer_forgot.php      ← NEW (needs to be created)
        │   ├── donor_login.php
        │   ├── donor_register.php
        │   ├── donor_forgot.php          ← NEW (needs to be created)
        │   ├── ngo_raise_help.php
        │   ├── volunteer_raise_help.php
        │   └── Donor_raise_help.php
        └── uploads\                      ← Create this folder too!
            └── registration_proofs\      ← For NGO registration file uploads
```

---

## 📝 Files You Need to Create

### In: `C:\xampp\htdocs\helphup\api\`

**Total: 13 PHP files**

1. ✅ `config.php` - Database connection (create this first!)
2. ✅ `ngo_login.php` - NGO login endpoint
3. ✅ `ngo_register.php` - NGO registration endpoint
4. ✅ `ngoforgot.php` - NGO forgot password
5. ✅ `volunteer_login.php` - Volunteer login endpoint
6. ✅ `volunteer_register.php` - Volunteer registration endpoint
7. ⭐ `volunteer_forgot.php` - **NEW - Volunteer forgot password**
8. ✅ `donor_login.php` - Donor login endpoint
9. ✅ `donor_register.php` - Donor registration endpoint
10. ⭐ `donor_forgot.php` - **NEW - Donor forgot password**
11. ✅ `ngo_raise_help.php` - NGO create help request
12. ✅ `volunteer_raise_help.php` - Volunteer create help request
13. ✅ `Donor_raise_help.php` - Donor create campaign

---

## 🗂️ Additional Folder to Create

### Upload Directory
```
C:\xampp\htdocs\helphup\uploads\registration_proofs\
```

**Purpose:** Store NGO registration proof files

**How to create:**
1. Navigate to: `C:\xampp\htdocs\helphup\`
2. Create folder: `uploads`
3. Inside `uploads`, create folder: `registration_proofs`

---

## ✅ Quick Checklist

- [x] Path confirmed: `C:\xampp\htdocs\helphup\api\`
- [ ] Create `config.php` in api folder
- [ ] Create all 13 PHP endpoint files
- [ ] Create `uploads\registration_proofs\` folder
- [ ] Set folder permissions (if needed)

---

## 🔍 Verify Your Setup

1. **Check if folder exists:**
   - Open File Explorer
   - Navigate to: `C:\xampp\htdocs\helphup\api\`
   - If it doesn't exist, create it

2. **Check XAMPP is running:**
   - Open XAMPP Control Panel
   - Apache should be "Running" (green)
   - MySQL should be "Running" (green)

3. **Test your path:**
   - Open browser
   - Go to: `http://localhost/helphup/api/`
   - Should show directory listing or 404 (if no files yet)

---

## 📌 Important Notes

1. **File names are case-sensitive** on some servers
   - `Donor_raise_help.php` (capital D) - matches your app code
   - Keep exact names as shown

2. **All PHP files must be in the `api\` folder**
   - Not in `helphup\` root
   - Not in `htdocs\` root
   - Must be: `C:\xampp\htdocs\helphup\api\`

3. **Database connection file:**
   - Create `config.php` first
   - All other PHP files will include it
   - Contains database credentials

---

## 🚀 Next Steps

1. ✅ Your path is correct!
2. Create `config.php` (see XAMPP_SETUP_GUIDE.md)
3. Create all PHP endpoint files
4. Create uploads folder
5. Test each endpoint

Your file path structure is perfect! 🎯

