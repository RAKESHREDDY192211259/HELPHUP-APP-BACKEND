package com.example.helphup

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Color
import com.example.helphup.ui.navigation.AppNavigation
import com.example.helphup.ui.theme.HelpHupTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ✅ Enables proper status bar & navigation bar handling
        enableEdgeToEdge()

        setContent {
            HelpHupTheme {

                // ✅ Prevents background issues with edge-to-edge
                Surface(color = Color.Transparent) {
                    AppNavigation()
                }
            }
        }
    }
}
