package com.example.helphup.ui.data

import com.google.gson.annotations.SerializedName

/* ===================== COMMON API MODELS ===================== */

/**
 * Unified API Response for all help request operations
 */
data class UnifiedApiResponse(
    val status: Boolean,
    val message: String,
    val data: Map<String, Any>? = null
)

/**
 * Generic API Response for operations that return Any data
 */
data class ApiResponse(
    val status: Boolean,
    val message: String,
    val data: Any? = null
)
