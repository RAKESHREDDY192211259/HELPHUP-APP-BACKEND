package com.example.helphup.ui.data

data class HelpRequest(
    val id: String,
    val title: String,
    val category: String,
    val location: String,
    val requestType: String,
    val amount: String = "0",
    val ngoName: String? = null,
    val volunteerName: String? = null,
    val donorName: String? = null,
    val description: String? = null
)
