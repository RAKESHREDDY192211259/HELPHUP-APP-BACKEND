package com.example.helphup.ui.data

import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.State

/**
 * Global data store for managing help request updates across the app
 * This ensures that when an NGO submits a new help request,
 * all relevant screens (DonorBrowseCauseDetails, VolunteerHelpOthers, NgoHelpOthers)
 * are automatically updated with the latest data
 */
object HelpRequestDataStore {
    // Counter to trigger data refresh across screens
    private val _refreshTrigger = mutableStateOf(0)
    val refreshTrigger: State<Int> = _refreshTrigger

    // Flag to indicate if new help request was added
    private val _newHelpRequestAdded = mutableStateOf(false)
    val newHelpRequestAdded: State<Boolean> = _newHelpRequestAdded

    /**
     * Call this method when a new help request is submitted
     * This will trigger refresh in all screens observing the data store
     */
    fun notifyHelpRequestUpdated() {
        Log.d("HelpRequestDataStore", "notifyHelpRequestUpdated called - triggering refresh")
        _newHelpRequestAdded.value = true
        _refreshTrigger.value += 1
        Log.d("HelpRequestDataStore", "New help request flag: ${_newHelpRequestAdded.value}, Refresh trigger: ${_refreshTrigger.value}")
    }

    /**
     * Call this method after screens have refreshed their data
     * Resets the new help request flag
     */
    fun resetUpdateFlag() {
        Log.d("HelpRequestDataStore", "resetUpdateFlag called - resetting flag")
        _newHelpRequestAdded.value = false
    }

    /**
     * Get current refresh trigger value
     * Screens can observe this to know when to refresh their data
     */
    fun getRefreshTrigger(): Int {
        return _refreshTrigger.value
    }
}
