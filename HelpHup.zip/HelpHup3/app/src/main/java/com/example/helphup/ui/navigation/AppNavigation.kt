package com.example.helphup.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

/* -------- Common -------- */
import com.example.helphup.ui.role.RoleSelectionScreen
import com.example.helphup.ui.welcome.WelcomeScreen

/* -------- NGO Screens -------- */
import com.example.helphup.ui.theme.NgoChangePasswordScreen
import com.example.helphup.ui.theme.NgoCommunitySupport
import com.example.helphup.ui.theme.NgoDashboard
import com.example.helphup.ui.theme.NgoDonorsHistory
import com.example.helphup.ui.theme.NgoEditProfileScreen
import com.example.helphup.ui.theme.NgoForgotPassword
import com.example.helphup.ui.theme.NgoHelpOthers
import com.example.helphup.ui.theme.NgoHelpOthersDetailsScreen
import com.example.helphup.ui.theme.NgoHelpRequestSubmitted
import com.example.helphup.ui.theme.NgoLoginScreen
import com.example.helphup.ui.theme.NgoNotifications
import com.example.helphup.ui.theme.NgoPaymentConfirmation
import com.example.helphup.ui.theme.NgoPaymentDetails
import com.example.helphup.ui.theme.NgoPaymentMethods
import com.example.helphup.ui.theme.NgoProfileScreen
import com.example.helphup.ui.theme.NgoRaiseHelp
import com.example.helphup.ui.theme.NgoRegistrationScreen
import com.example.helphup.ui.theme.NgoResetPassword
import com.example.helphup.ui.theme.NgoVerifyOtpScreen
import com.example.helphup.ui.theme.NgoVolunteersHistory
import com.example.helphup.ui.theme.PaymentSelectionScreen
import com.example.helphup.ui.theme.AmountSelectionScreen
import com.example.helphup.ui.theme.RequestDetailsScreen
import com.example.helphup.ui.theme.PaymentDetailsScreen
import com.example.helphup.ui.theme.PaymentProcessingScreen
import com.example.helphup.ui.theme.PaymentSuccessScreen

/* -------- Volunteer Screens -------- */
import com.example.helphup.ui.theme.VolunteerChangePassword
import com.example.helphup.ui.theme.VolunteerCommunitySupport
import com.example.helphup.ui.theme.VolunteerDashboard
import com.example.helphup.ui.theme.VolunteerEditDetails
import com.example.helphup.ui.theme.VolunteerForgotPasswordScreen
import com.example.helphup.ui.theme.VolunteerHelpOthers
import com.example.helphup.ui.theme.VolunteerHistory
import com.example.helphup.ui.theme.VolunteerLoginScreen
import com.example.helphup.ui.theme.VolunteerNotifications
import com.example.helphup.ui.theme.VolunteerPaymentDetails
import com.example.helphup.ui.theme.VolunteerPaymentMethods
import com.example.helphup.ui.theme.VolunteerProfile
import com.example.helphup.ui.theme.VolunteerRaiseHelp
import com.example.helphup.ui.theme.VolunteerRegistration
import com.example.helphup.ui.theme.VolunteerResetPasswordScreen
import com.example.helphup.ui.theme.VolunteerDonationRecords
import com.example.helphup.ui.theme.VolunteerHelpRequestSubmitted
import com.example.helphup.ui.theme.VolunteerSupportConfirmation
import com.example.helphup.ui.theme.VolunteerViewHelpRequestDetails
import com.example.helphup.ui.theme.VolunteerRequestDetailsScreen
import com.example.helphup.ui.volunteer.VolunteerVerifyOtpScreen

/* -------- Donor Screens -------- */
import com.example.helphup.ui.theme.DonorBrowseCauseDetailsScreen
import com.example.helphup.ui.theme.DonorBrowseCauseScreen
import com.example.helphup.ui.theme.DonorChangePassword
import com.example.helphup.ui.theme.DonorCommunitySupport
import com.example.helphup.ui.theme.DonorEditDetails
import com.example.helphup.ui.theme.DonorImpactScreen
import com.example.helphup.ui.theme.DonorRaiseDonationScreen
import com.example.helphup.ui.theme.DonorDashboard
import com.example.helphup.ui.theme.DonorDonationHistoryScreen
import com.example.helphup.ui.theme.DonorForgotPasswordScreen
import com.example.helphup.ui.theme.DonorLoginScreen
import com.example.helphup.ui.theme.DonorNotificationScreen
import com.example.helphup.ui.theme.DonorPaymentDetails
import com.example.helphup.ui.theme.DonorPaymentMethods
import com.example.helphup.ui.theme.DonorProfileScreen
import com.example.helphup.ui.theme.DonorRegistration
import com.example.helphup.ui.theme.DonorResetPasswordScreen
import com.example.helphup.ui.theme.DonorSupportConfirmation
import com.example.helphup.ui.theme.DonorVerifyOtpScreen

/* -------- Admin Screens -------- */
import com.example.helphup.ui.theme.AdminLoginScreen
import com.example.helphup.ui.theme.AdminDashboard
import com.example.helphup.ui.theme.AdminRegistrationScreen
import com.example.helphup.ui.theme.AdminForgotPasswordScreen
import com.example.helphup.ui.theme.AdminVerifyOtpScreen
import com.example.helphup.ui.theme.AdminResetPasswordScreen
import com.example.helphup.ui.theme.AdminManageRequests
import com.example.helphup.ui.theme.AdminManageCampaigns
import com.example.helphup.ui.theme.AdminRequestDetails
import com.example.helphup.ui.theme.AdminManageUsers
import com.example.helphup.ui.theme.AdminNGODetailsScreen
import com.example.helphup.ui.theme.AdminVolunteerDetailsScreen
import com.example.helphup.ui.theme.AdminDonorDetailsScreen

@Composable
fun AppNavigation() {

    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Routes.WELCOME
    ) {

        /* ================= COMMON ================= */

        composable(Routes.WELCOME) {
            WelcomeScreen {
                navController.navigate(Routes.ROLE_SELECTION)
            }
        }

        composable(Routes.ROLE_SELECTION) {
            RoleSelectionScreen(
                onNgoClick = { navController.navigate(Routes.NGO_LOGIN) },
                onVolunteerClick = { navController.navigate(Routes.VOLUNTEER_LOGIN) },
                onDonorClick = { navController.navigate(Routes.DONOR_LOGIN) },
                onAdminClick = { navController.navigate(Routes.ADMIN_LOGIN) }
            )
        }

        /* ================= NGO ================= */

        composable(Routes.NGO_LOGIN) { NgoLoginScreen(navController) }
        composable(Routes.NGO_REGISTER) { NgoRegistrationScreen(navController) }

        composable(Routes.NGO_FORGOT_PASSWORD) {
            NgoForgotPassword(
                onBackClick = { navController.popBackStack() },
                onOtpSent = { email ->
                    navController.navigate("ngo_verify_otp/${email}")
                }
            )
        }

        composable(
            route = Routes.NGO_VERIFY_OTP,
            arguments = listOf(navArgument("email") { type = NavType.StringType })
        ) {
            val email = it.arguments?.getString("email") ?: ""
            NgoVerifyOtpScreen(
                email = email,
                onBackClick = { navController.popBackStack() },
                onVerifySuccess = { otp ->
                    navController.navigate("ngo_reset_password/${email}/${otp}")
                },
                onResendClick = {
                    navController.navigate(Routes.NGO_FORGOT_PASSWORD)
                }
            )
        }

        composable(
            route = Routes.NGO_RESET_PASSWORD,
            arguments = listOf(
                navArgument("email") { type = NavType.StringType },
                navArgument("otp") { type = NavType.StringType }
            )
        ) {
            val email = it.arguments?.getString("email") ?: ""
            val otp = it.arguments?.getString("otp") ?: ""
            NgoResetPassword(
                email = email,
                otp = otp,
                onBackClick = { navController.popBackStack() },
                onPasswordResetSuccess = {
                    navController.navigate(Routes.NGO_LOGIN) {
                        popUpTo(Routes.NGO_FORGOT_PASSWORD) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.NGO_DASHBOARD) { NgoDashboard(navController) }
        composable(Routes.NGO_PROFILE) { NgoProfileScreen(navController) }
        composable(Routes.NGO_EDIT_PROFILE) { NgoEditProfileScreen(navController) }
        composable(Routes.NGO_CHANGE_PASSWORD) { NgoChangePasswordScreen(navController) }
        composable(Routes.NGO_NOTIFICATIONS) { NgoNotifications(navController) }
        composable(Routes.NGO_RAISE_HELP) { NgoRaiseHelp(navController) }
        composable(Routes.NGO_HELP_OTHERS) { NgoHelpOthers(navController) }
        composable(
            route = Routes.NGO_HELP_OTHERS_DETAILS + "/{request_type}/{request_id}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            NgoHelpOthersDetailsScreen(navController, requestType, requestId)
        }

        /* ---------- NGO PAYMENT FLOW ---------- */

        composable(
            route = Routes.NGO_COMMUNITY_SUPPORT + "/{request_type}/{request_id}/{amount}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "100"
            NgoCommunitySupport(navController, requestType, requestId, amount)
        }

        composable(
            route = Routes.NGO_PAYMENT_METHODS + "/{request_type}/{request_id}/{amount}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            NgoPaymentMethods(navController, requestType, requestId, amount)
        }

        composable(
            route = Routes.NGO_PAYMENT_DETAILS + "/{request_type}/{request_id}/{amount}/{method}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType },
                navArgument("method") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            val method = it.arguments?.getString("method") ?: ""
            NgoPaymentDetails(navController, requestType, requestId, amount, method)
        }

        composable(
            route = Routes.NGO_SUPPORT_CONFIRMATION + "/{request_type}/{request_id}/{amount}/{method}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType },
                navArgument("method") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            val method = it.arguments?.getString("method") ?: ""
            NgoPaymentConfirmation(navController, requestType, requestId, amount, method)
        }

        composable(Routes.NGO_DONORS_HISTORY) { NgoDonorsHistory(navController) }
        composable(Routes.NGO_VOLUNTEER_HISTORY) { NgoVolunteersHistory(navController) }
        composable(Routes.NGO_HELP_REQUEST_SUBMITTED) { NgoHelpRequestSubmitted(navController) }

        /* ================= VOLUNTEER ================= */

        composable(Routes.VOLUNTEER_LOGIN) {
            VolunteerLoginScreen(
                onBackClick = { navController.popBackStack() },
                onForgotPasswordClick = { navController.navigate(Routes.VOLUNTEER_FORGOT_PASSWORD) },
                onLoginSuccess = {
                    navController.navigate(Routes.VOLUNTEER_DASHBOARD) {
                        popUpTo(Routes.VOLUNTEER_LOGIN) { inclusive = true }
                    }
                },
                onRegisterClick = { navController.navigate(Routes.VOLUNTEER_REGISTER) }
            )
        }

        composable(Routes.VOLUNTEER_REGISTER) { VolunteerRegistration(navController) }

        composable(Routes.VOLUNTEER_FORGOT_PASSWORD) {
            VolunteerForgotPasswordScreen(
                onBackClick = { navController.popBackStack() },
                onOtpSent = { email ->
                    navController.navigate("volunteer_verify_otp/${email}")
                }
            )
        }

        composable(
            route = Routes.VOLUNTEER_VERIFY_OTP,
            arguments = listOf(navArgument("email") { type = NavType.StringType })
        ) {
            val email = it.arguments?.getString("email") ?: ""
            VolunteerVerifyOtpScreen(
                email = email,
                onBackClick = { navController.popBackStack() },
                onVerifySuccess = { otp ->
                    navController.navigate("volunteer_reset_password/${email}/${otp}")
                },
                onResendClick = {
                    navController.navigate(Routes.VOLUNTEER_FORGOT_PASSWORD)
                }
            )
        }

        composable(
            route = Routes.VOLUNTEER_RESET_PASSWORD,
            arguments = listOf(
                navArgument("email") { type = NavType.StringType },
                navArgument("otp") { type = NavType.StringType }
            )
        ) {
            val email = it.arguments?.getString("email") ?: ""
            val otp = it.arguments?.getString("otp") ?: ""
            VolunteerResetPasswordScreen(
                onBackClick = { navController.popBackStack() },
                onUpdatePasswordClick = { _, _ ->
                    navController.navigate(Routes.VOLUNTEER_LOGIN) {
                        popUpTo(Routes.VOLUNTEER_FORGOT_PASSWORD) { inclusive = true }
                    }
                },
                email = email,
                otp = otp
            )
        }

        composable(Routes.VOLUNTEER_DASHBOARD) { VolunteerDashboard(navController) }
        composable(Routes.VOLUNTEER_PROFILE) { VolunteerProfile(navController) }
        composable(Routes.VOLUNTEER_EDIT_DETAILS) { VolunteerEditDetails(navController) }
        composable(Routes.VOLUNTEER_CHANGE_PASSWORD) { VolunteerChangePassword(navController) }
        composable(Routes.VOLUNTEER_NOTIFICATIONS) { VolunteerNotifications(navController) }
        composable(Routes.VOLUNTEER_HELP_OTHERS) { VolunteerHelpOthers(navController) }
        composable(Routes.VOLUNTEER_RAISE_HELP) { VolunteerRaiseHelp(navController) }
        composable(Routes.VOLUNTEER_HISTORY) { VolunteerHistory(navController) }
        composable(Routes.VOLUNTEER_DONATION_RECORDS) { VolunteerDonationRecords(navController) }
        composable(Routes.VOLUNTEER_HELP_REQUEST_SUBMITTED) { VolunteerHelpRequestSubmitted(navController) }
        composable(Routes.VOLUNTEER_VIEW_HELP_REQUEST_DETAILS) { VolunteerViewHelpRequestDetails(navController) }
        composable(
            route = Routes.VOLUNTEER_REQUEST_DETAILS + "/{request_type}/{request_id}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            VolunteerRequestDetailsScreen(navController, requestType, requestId)
        }
        composable(
            route = Routes.VOLUNTEER_COMMUNITY_SUPPORT + "/{request_type}/{request_id}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            VolunteerCommunitySupport(navController, requestType, requestId)
        }
        
        composable(
            route = Routes.VOLUNTEER_PAYMENT_METHODS + "/{request_type}/{request_id}/{amount}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            VolunteerPaymentMethods(navController, requestType, requestId, amount)
        }
        
        composable(
            route = Routes.VOLUNTEER_PAYMENT_DETAILS + "/{request_type}/{request_id}/{amount}/{method}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType },
                navArgument("method") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            val method = it.arguments?.getString("method") ?: ""
            VolunteerPaymentDetails(navController, requestType, requestId, amount, method)
        }
        
        composable(
            route = Routes.VOLUNTEER_SUPPORT_CONFIRMATION + "/{request_type}/{request_id}/{amount}/{method}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType },
                navArgument("method") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            val method = it.arguments?.getString("method") ?: ""
            VolunteerSupportConfirmation(navController, requestType, requestId, amount, method)
        }

        /* ================= DONOR ================= */

        composable(Routes.DONOR_LOGIN) {
            DonorLoginScreen(
                onBackClick = { navController.popBackStack() },
                onLoginSuccess = {
                    navController.navigate(Routes.DONOR_DASHBOARD) {
                        popUpTo(Routes.DONOR_LOGIN) { inclusive = true }
                    }
                },
                onForgotPasswordClick = { navController.navigate(Routes.DONOR_FORGOT_PASSWORD) },
                onCreateAccountClick = { navController.navigate(Routes.DONOR_REGISTER) }
            )
        }

        composable(Routes.DONOR_REGISTER) { DonorRegistration(navController) }

        composable(Routes.DONOR_FORGOT_PASSWORD) {
            DonorForgotPasswordScreen(
                onBackClick = { navController.popBackStack() },
                onOtpSent = { email ->
                    navController.navigate("donor_verify_otp/${email}")
                }
            )
        }

        composable(
            route = Routes.DONOR_VERIFY_OTP,
            arguments = listOf(navArgument("email") { type = NavType.StringType })
        ) {
            val email = it.arguments?.getString("email") ?: ""
            DonorVerifyOtpScreen(
                email = email,
                onBackClick = { navController.popBackStack() },
                onVerifySuccess = { otp ->
                    navController.navigate("donor_reset_password/${email}/${otp}")
                },
                onResendClick = {
                    navController.navigate(Routes.DONOR_FORGOT_PASSWORD)
                }
            )
        }

        composable(
            route = Routes.DONOR_RESET_PASSWORD,
            arguments = listOf(
                navArgument("email") { type = NavType.StringType },
                navArgument("otp") { type = NavType.StringType }
            )
        ) {
            val email = it.arguments?.getString("email") ?: ""
            val otp = it.arguments?.getString("otp") ?: ""
            DonorResetPasswordScreen(
                onBackClick = { navController.popBackStack() },
                onUpdatePasswordClick = { _, _ ->
                    navController.navigate(Routes.DONOR_LOGIN) {
                        popUpTo(Routes.DONOR_FORGOT_PASSWORD) { inclusive = true }
                    }
                },
                email = email,
                otp = otp
            )
        }
        composable(
            route = Routes.PAYMENT_SELECTION,
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { 
                    type = NavType.StringType
                    defaultValue = "1000.0"
                }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "1000.0"
            PaymentSelectionScreen(
                navController = navController,
                requestType = requestType,
                requestId = requestId
            )
        }

        // Amount Selection Route
        composable(
            route = Routes.AMOUNT_SELECTION,
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            AmountSelectionScreen(
                navController = navController,
                requestType = requestType,
                requestId = requestId
            )
        }

        // Request Details Route
        composable(
            route = Routes.REQUEST_DETAILS,
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            RequestDetailsScreen(
                navController = navController,
                requestType = requestType,
                requestId = requestId
            )
        }

        // Payment Details Route
        composable(
            route = Routes.PAYMENT_DETAILS,
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("payment_method") { type = NavType.StringType },
                navArgument("amount") { 
                    type = NavType.StringType
                    defaultValue = "0.0"
                }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val paymentMethod = it.arguments?.getString("payment_method") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0.0"
            
            android.util.Log.d("AppNavigation", "PAYMENT_DETAILS route matched")
            android.util.Log.d("AppNavigation", "RequestType: $requestType, RequestId: $requestId, PaymentMethod: $paymentMethod, Amount: $amount")
            
            PaymentDetailsScreen(
                navController = navController,
                requestType = requestType,
                requestId = requestId,
                paymentMethod = paymentMethod
            )
        }

        // Payment Processing Route
        composable(
            route = Routes.PAYMENT_PROCESSING,
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { 
                    type = NavType.StringType
                    defaultValue = "0.0"
                }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0.0"
            PaymentProcessingScreen(
                navController = navController,
                requestType = requestType,
                requestId = requestId
            )
        }

        // Payment Success Route
        composable(
            route = Routes.PAYMENT_SUCCESS,
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { 
                    type = NavType.StringType
                    defaultValue = "0.0"
                }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0.0"
            PaymentSuccessScreen(
                navController = navController,
                requestType = requestType,
                requestId = requestId
            )
        }

        composable(Routes.DONOR_DASHBOARD) { DonorDashboard(navController) }
        composable(Routes.DONOR_PROFILE) { DonorProfileScreen(navController) }
        composable(Routes.DONOR_EDIT_DETAILS) { DonorEditDetails(navController) }
        composable(Routes.DONOR_CHANGE_PASSWORD) { DonorChangePassword(navController) }
        composable(Routes.DONOR_DONATION_HISTORY) { DonorDonationHistoryScreen(navController) }
        composable(Routes.DONOR_NOTIFICATIONS) { DonorNotificationScreen(navController) }
        composable(Routes.DONOR_BROWSE_CAUSES) { DonorBrowseCauseScreen(navController) }
        composable(
            route = Routes.DONOR_BROWSE_CAUSE_DETAILS + "/{request_type}/{request_id}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            DonorBrowseCauseDetailsScreen(navController, requestType, requestId)
        }
        composable(Routes.DONOR_RAISE_DONATION) { DonorRaiseDonationScreen(navController) }
        composable(Routes.DONOR_IMPACT) { DonorImpactScreen(navController) }
        
        /* ---------- DONOR PAYMENT FLOW ---------- */
        
        composable(
            route = Routes.DONOR_COMMUNITY_SUPPORT + "/{request_type}/{request_id}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            DonorCommunitySupport(navController, requestType, requestId)
        }
        
        composable(
            route = Routes.DONOR_PAYMENT_METHODS + "/{request_type}/{request_id}/{amount}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            DonorPaymentMethods(navController, requestType, requestId, amount)
        }
        
        composable(
            route = Routes.DONOR_PAYMENT_DETAILS + "/{request_type}/{request_id}/{amount}/{method}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType },
                navArgument("method") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            val method = it.arguments?.getString("method") ?: ""
            DonorPaymentDetails(navController, requestType, requestId, amount, method)
        }
        
        composable(
            route = Routes.DONOR_SUPPORT_CONFIRMATION + "/{request_type}/{request_id}/{amount}/{method}",
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.StringType },
                navArgument("amount") { type = NavType.StringType },
                navArgument("method") { type = NavType.StringType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getString("request_id") ?: ""
            val amount = it.arguments?.getString("amount") ?: "0"
            val method = it.arguments?.getString("method") ?: ""
            DonorSupportConfirmation(navController, requestType, requestId, amount, method)
        }

        /* ================= ADMIN ================= */

        composable(Routes.ADMIN_LOGIN) { 
            AdminLoginScreen(navController) 
        }

        composable(Routes.ADMIN_REGISTER) { 
            AdminRegistrationScreen(navController) 
        }

        composable(Routes.ADMIN_FORGOT_PASSWORD) {
            AdminForgotPasswordScreen(
                onBackClick = { navController.popBackStack() },
                onOtpSent = { email ->
                    navController.navigate("admin_verify_otp/${email}")
                }
            )
        }

        composable(
            route = Routes.ADMIN_VERIFY_OTP,
            arguments = listOf(navArgument("email") { type = NavType.StringType })
        ) {
            val email = it.arguments?.getString("email") ?: ""
            AdminVerifyOtpScreen(
                email = email,
                onBackClick = { navController.popBackStack() },
                onVerifySuccess = { otp ->
                    navController.navigate("admin_reset_password/${email}/${otp}")
                },
                onResendClick = {
                    navController.navigate(Routes.ADMIN_FORGOT_PASSWORD)
                }
            )
        }

        composable(
            route = Routes.ADMIN_RESET_PASSWORD,
            arguments = listOf(
                navArgument("email") { type = NavType.StringType },
                navArgument("otp") { type = NavType.StringType }
            )
        ) {
            val email = it.arguments?.getString("email") ?: ""
            val otp = it.arguments?.getString("otp") ?: ""
            AdminResetPasswordScreen(
                email = email,
                otp = otp,
                onBackClick = { navController.popBackStack() },
                onPasswordResetSuccess = {
                    navController.navigate(Routes.ADMIN_LOGIN) {
                        popUpTo(Routes.ADMIN_FORGOT_PASSWORD) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.ADMIN_DASHBOARD) { 
            AdminDashboard(navController) 
        }

        composable(Routes.ADMIN_MANAGE_REQUESTS) {
            AdminManageRequests(navController)
        }

        composable(Routes.ADMIN_MANAGE_CAMPAIGNS) {
            AdminManageCampaigns(navController)
        }

        composable(Routes.ADMIN_MANAGE_USERS) {
            AdminManageUsers(navController)
        }

        composable(
            route = Routes.ADMIN_NGO_DETAILS,
            arguments = listOf(navArgument("ngo_id") { type = NavType.StringType })
        ) {
            val ngoId = it.arguments?.getString("ngo_id") ?: "1"
            AdminNGODetailsScreen(navController, ngoId)
        }

        composable(
            route = Routes.ADMIN_VOLUNTEER_DETAILS,
            arguments = listOf(navArgument("volunteer_id") { type = NavType.StringType })
        ) {
            val volunteerId = it.arguments?.getString("volunteer_id") ?: "1"
            AdminVolunteerDetailsScreen(navController, volunteerId)
        }

        composable(
            route = Routes.ADMIN_DONOR_DETAILS,
            arguments = listOf(navArgument("donor_id") { type = NavType.StringType })
        ) {
            val donorId = it.arguments?.getString("donor_id") ?: "1"
            AdminDonorDetailsScreen(navController, donorId)
        }

        composable(
            route = Routes.ADMIN_REQUEST_DETAILS,
            arguments = listOf(
                navArgument("request_type") { type = NavType.StringType },
                navArgument("request_id") { type = NavType.IntType }
            )
        ) {
            val requestType = it.arguments?.getString("request_type") ?: ""
            val requestId = it.arguments?.getInt("request_id") ?: 0
            AdminRequestDetails(
                navController = navController,
                requestType = requestType,
                requestId = requestId
            )
        }
    }
}
