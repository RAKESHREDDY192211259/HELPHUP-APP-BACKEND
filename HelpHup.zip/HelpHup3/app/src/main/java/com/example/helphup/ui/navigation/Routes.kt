package com.example.helphup.ui.navigation

object Routes {

    /* ================= App Start ================= */
    const val WELCOME = "welcome"
    const val ROLE_SELECTION = "role_selection"

    /* ================= NGO ================= */

    // ---- Auth ----
    const val NGO_LOGIN = "ngo_login"
    const val NGO_REGISTER = "ngo_register"
    const val NGO_FORGOT_PASSWORD = "ngo_forgot_password"
    const val NGO_VERIFY_OTP = "ngo_verify_otp/{email}"
    const val NGO_RESET_PASSWORD = "ngo_reset_password/{email}/{otp}"
    const val NGO_CHANGE_PASSWORD = "ngo_change_password"

    // ---- Main ----
    const val NGO_DASHBOARD = "ngo_dashboard"
    const val NGO_PROFILE = "ngo_profile"
    const val NGO_EDIT_PROFILE = "ngo_edit_profile"
    const val NGO_NOTIFICATIONS = "ngo_notifications"

    const val NGO_RAISE_HELP = "ngo_raise_help"
    const val NGO_HELP_OTHERS = "ngo_help_others"
    const val NGO_HELP_OTHERS_DETAILS = "ngo_help_others_details"

    const val NGO_DONORS_HISTORY = "ngo_donors_history"
    const val NGO_VOLUNTEER_HISTORY = "ngo_volunteer_history"
    const val NGO_HELP_REQUEST_SUBMITTED = "ngo_help_request_submitted"

    // ---- NGO Support Flow ----
    const val NGO_COMMUNITY_SUPPORT = "ngo_community_support"
    const val NGO_PAYMENT_METHODS = "ngo_payment_methods"
    const val NGO_PAYMENT_DETAILS = "ngo_payment_details"
    const val NGO_SUPPORT_CONFIRMATION = "ngo_support_confirmation"

    /* ================= Volunteer ================= */

    // ---- Auth ----
    const val VOLUNTEER_LOGIN = "volunteer_login"
    const val VOLUNTEER_REGISTER = "volunteer_register"
    const val VOLUNTEER_FORGOT_PASSWORD = "volunteer_forgot_password"
    const val VOLUNTEER_VERIFY_OTP = "volunteer_verify_otp/{email}"
    const val VOLUNTEER_RESET_PASSWORD = "volunteer_reset_password/{email}/{otp}"

    // ---- Main ----
    const val VOLUNTEER_DASHBOARD = "volunteer_dashboard"
    const val VOLUNTEER_PROFILE = "volunteer_profile"
    const val VOLUNTEER_EDIT_DETAILS = "volunteer_edit_details"
    const val VOLUNTEER_CHANGE_PASSWORD = "volunteer_change_password"
    const val VOLUNTEER_NOTIFICATIONS = "volunteer_notifications"

    const val VOLUNTEER_HELP_OTHERS = "volunteer_help_others"
    const val VOLUNTEER_RAISE_HELP = "volunteer_raise_help"
    const val VOLUNTEER_HISTORY = "volunteer_history"
    const val VOLUNTEER_DONATION_RECORDS = "volunteer_donation_records"
    const val VOLUNTEER_HELP_REQUEST_SUBMITTED = "volunteer_help_request_submitted"

    // ---- Volunteer Details ----
    const val VOLUNTEER_REQUEST_DETAILS = "volunteer_request_details"
    const val VOLUNTEER_VIEW_HELP_REQUEST_DETAILS = "volunteer_view_help_request_details"

    // ---- Volunteer Support Flow ----
    const val VOLUNTEER_COMMUNITY_SUPPORT = "volunteer_community_support"
    const val VOLUNTEER_PAYMENT_METHODS = "volunteer_payment_methods"
    const val VOLUNTEER_PAYMENT_DETAILS = "volunteer_payment_details"
    const val VOLUNTEER_SUPPORT_CONFIRMATION = "volunteer_support_confirmation"

    /* ================= Donor ================= */

    // ---- Auth ----
    const val DONOR_LOGIN = "donor_login"
    const val DONOR_REGISTER = "donor_register"
    const val DONOR_FORGOT_PASSWORD = "donor_forgot_password"
    const val DONOR_VERIFY_OTP = "donor_verify_otp/{email}"
    const val DONOR_RESET_PASSWORD = "donor_reset_password/{email}/{otp}"

    // ---- Main ----
    const val DONOR_DASHBOARD = "donor_dashboard"
    const val DONOR_PROFILE = "donor_profile"
    const val DONOR_EDIT_DETAILS = "donor_edit_details"
    const val DONOR_CHANGE_PASSWORD = "donor_change_password"
    const val DONOR_NOTIFICATIONS = "donor_notifications"

    const val DONOR_BROWSE_CAUSES = "donor_browse_causes"
    const val DONOR_BROWSE_CAUSE_DETAILS = "donor_browse_cause_details"

    const val DONOR_RAISE_DONATION = "donor_raise_donation"
    const val DONOR_DONATION_HISTORY = "donor_donation_history"
    const val DONOR_IMPACT = "donor_impact"
    const val DONOR_BROWSE_HISTORY = "donor_browse_history"

    // ---- Donor Support Flow ----
    const val DONOR_COMMUNITY_SUPPORT = "donor_community_support"
    const val DONOR_PAYMENT_METHODS = "donor_payment_methods"
    const val DONOR_PAYMENT_DETAILS = "donor_payment_details"
    const val DONOR_SUPPORT_CONFIRMATION = "donor_support_confirmation"

    /* ================= Admin ================= */

    // ---- Auth ----
    const val ADMIN_LOGIN = "admin_login"
    const val ADMIN_REGISTER = "admin_register"
    const val ADMIN_FORGOT_PASSWORD = "admin_forgot_password"
    const val ADMIN_VERIFY_OTP = "admin_verify_otp/{email}"
    const val ADMIN_RESET_PASSWORD = "admin_reset_password/{email}/{otp}"

    // ---- Main ----
    const val ADMIN_DASHBOARD = "admin_dashboard"
    const val ADMIN_MANAGE_REQUESTS = "admin_manage_requests"
    const val ADMIN_MANAGE_CAMPAIGNS = "admin_manage_campaigns"
    const val ADMIN_REQUEST_DETAILS = "admin_request_details/{request_type}/{request_id}"
    const val ADMIN_CAMPAIGN_DETAILS = "admin_campaign_details/{campaign_id}"
    const val ADMIN_MANAGE_USERS = "admin_manage_users"
    const val ADMIN_NGO_DETAILS = "admin_ngo_details/{ngo_id}"
    const val ADMIN_VOLUNTEER_DETAILS = "admin_volunteer_details/{volunteer_id}"
    const val ADMIN_DONOR_DETAILS = "admin_donor_details/{donor_id}"

    /* ================= Payment ================= */
    const val AMOUNT_SELECTION = "amount_selection/{request_type}/{request_id}"
    const val PAYMENT_SELECTION = "payment_selection/{request_type}/{request_id}"
    const val PAYMENT_DETAILS = "payment_details/{request_type}/{request_id}/{payment_method}"
    const val PAYMENT_PROCESSING = "payment_processing/{request_type}/{request_id}"
    const val PAYMENT_SUCCESS = "payment_success/{request_type}/{request_id}"
    const val PAYMENT_FAILED = "payment_failed/{request_type}/{request_id}"

    /* ================= Request Details ================= */
    const val REQUEST_DETAILS = "request_details/{request_type}/{request_id}"
}
