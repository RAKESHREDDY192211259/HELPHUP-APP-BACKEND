package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import androidx.compose.runtime.remember

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboard(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    
    fun handleLogout() {
        sessionManager.clearSession()
        navController.navigate(Routes.ADMIN_LOGIN) {
            popUpTo(Routes.ADMIN_DASHBOARD) { inclusive = true }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0F4F8),
        topBar = {
            TopAppBar(
                title = { Text("Admin Dashboard") },
                navigationIcon = {
                    IconButton(onClick = { 
                        navController.navigate(Routes.ROLE_SELECTION) {
                            popUpTo(Routes.ADMIN_DASHBOARD) { inclusive = true }
                        }
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { handleLogout() }) {
                        Icon(
                            Icons.Default.ExitToApp,
                            contentDescription = "Logout",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF3B82F6),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F4F8))
                .padding(paddingValues)
                .padding(16.dp)
        ) {

            /* ---------- Header ---------- */
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Row(verticalAlignment = Alignment.CenterVertically) {

                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0xFF3B82F6), RoundedCornerShape(12.dp))
                            .padding(8.dp)
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Admin Panel",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1F2937)
                        )
                        Text(
                            text = "Manage the platform",
                            fontSize = 14.sp,
                            color = Color(0xFF3B82F6)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            /* ---------- Welcome Card ---------- */
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFDBEAFE), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "Welcome, Administrator!",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E40AF)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Manage users, requests, and platform settings",
                        fontSize = 14.sp,
                        color = Color(0xFF3B82F6)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            /* ---------- Dashboard Cards ---------- */

            AdminDashboardCard(
                icon = Icons.Default.People,
                title = "Manage Users",
                subtitle = "View and manage all users",
                color = Color(0xFF3B82F6)
            ) {
                navController.navigate(Routes.ADMIN_MANAGE_USERS)
            }

            AdminDashboardCard(
                icon = Icons.Default.RequestPage,
                title = "Manage Requests",
                subtitle = "View and manage help requests",
                color = Color(0xFF10B981)
            ) {
                navController.navigate(Routes.ADMIN_MANAGE_REQUESTS)
            }

            AdminDashboardCard(
                icon = Icons.Default.Campaign,
                title = "Manage Campaigns",
                subtitle = "View and manage donor campaigns",
                color = Color(0xFFF59E0B)
            ) {
                navController.navigate(Routes.ADMIN_MANAGE_CAMPAIGNS)
            }

            AdminDashboardCard(
                icon = Icons.Default.Settings,
                title = "Platform Settings",
                subtitle = "Configure platform settings",
                color = Color(0xFF8B5CF6)
            ) {
                // TODO: Navigate to settings screen
            }

            AdminDashboardCard(
                icon = Icons.Default.BarChart,
                title = "Analytics & Reports",
                subtitle = "View platform statistics",
                color = Color(0xFFEF4444)
            ) {
                // TODO: Navigate to analytics screen
            }
        }
    }
}

/* ---------- Admin Dashboard Card ---------- */
@Composable
fun AdminDashboardCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier
                    .size(48.dp)
                    .background(color, RoundedCornerShape(12.dp))
                    .padding(10.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(text = subtitle, fontSize = 13.sp, color = color)
            }
        }
    }
}

