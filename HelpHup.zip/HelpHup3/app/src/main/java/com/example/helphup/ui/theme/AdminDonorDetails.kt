package com.example.helphup.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.R
import com.example.helphup.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDonorDetailsScreen(
    navController: NavController,
    donorId: String = "1"
) {
    Scaffold(
        containerColor = Color(0xFFF8FAFC),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Donor Details", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "View complete donor information",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF16A34A),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {

            // Donor Profile Header
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Profile Image
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(80.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                                contentDescription = "Donor Profile",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(Modifier.width(16.dp))

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Priya Sharma",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1F2937)
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Premium Donor",
                                fontSize = 14.sp,
                                color = Color(0xFF16A34A),
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Member since 2021",
                                fontSize = 12.sp,
                                color = Color(0xFF6B7280)
                            )
                        }

                        // Status Badge
                        Surface(
                            color = Color(0xFF16A34A),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                text = "ACTIVE",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Personal Information
            InfoSectionCard(
                title = "Personal Information",
                icon = Icons.Default.Person
            ) {
                IconInfoRow(Icons.Default.Phone, "+91-9876543210")
                IconInfoRow(Icons.Default.Email, "priya.sharma@email.com")
                IconInfoRow(Icons.Default.Cake, "Age: 35 years")
                IconInfoRow(Icons.Default.LocationOn, "Mumbai, Maharashtra")
            }

            Spacer(Modifier.height(16.dp))

            // Donation Preferences
            InfoSectionCard(
                title = "Donation Preferences",
                icon = Icons.Default.Favorite
            ) {
                IconInfoRow(Icons.Default.Category, "Preferred Causes: Education, Healthcare")
                IconInfoRow(Icons.Default.Payment, "Payment Method: Credit Card, UPI")
                IconInfoRow(Icons.Default.Schedule, "Frequency: Monthly")
                IconInfoRow(Icons.Default.AttachMoney, "Average Donation: ₹5,000/month")
            }

            Spacer(Modifier.height(16.dp))

            // Statistics
            InfoSectionCard(
                title = "Donation Statistics",
                icon = Icons.Default.BarChart
            ) {
                IconInfoRow(Icons.Default.TrendingUp, "Total Donations: ₹2,50,000")
                IconInfoRow(Icons.Default.Campaign, "Campaigns Supported: 25")
                IconInfoRow(Icons.Default.People, "NGOs Helped: 12")
                IconInfoRow(Icons.Default.Star, "Impact Score: 9.2/10")
            }

            Spacer(Modifier.height(16.dp))

            // Recent Activity
            InfoSectionCard(
                title = "Recent Activity",
                icon = Icons.Default.History
            ) {
                IconInfoRow(Icons.Default.Event, "Last Donation: 5 days ago")
                IconInfoRow(Icons.Default.Campaign, "Active Campaigns: 3")
                IconInfoRow(Icons.Default.Pending, "Pending Pledges: 2")
                IconInfoRow(Icons.Default.LocalActivity, "Events Attended: 8")
            }

            Spacer(Modifier.height(16.dp))

            // Campaign History
            InfoSectionCard(
                title = "Recent Campaigns",
                icon = Icons.Default.Assignment
            ) {
                IconInfoRow(Icons.Default.CheckCircle, "Emergency Medical Fund - ₹10,000")
                IconInfoRow(Icons.Default.CheckCircle, "Education for All - ₹5,000")
                IconInfoRow(Icons.Default.CheckCircle, "Clean Water Initiative - ₹7,500")
                IconInfoRow(Icons.Default.CheckCircle, "Food Distribution Drive - ₹15,000")
            }

            Spacer(Modifier.height(16.dp))

            // Verification
            InfoSectionCard(
                title = "Verification Status",
                icon = Icons.Default.Verified
            ) {
                IconInfoRow(Icons.Default.Verified, "KYC Verified: Yes")
                IconInfoRow(Icons.Default.Verified, "Bank Account: Verified")
                IconInfoRow(Icons.Default.Verified, "Email Verified: Yes")
                IconInfoRow(Icons.Default.Verified, "Phone Verified: Yes")
            }

            Spacer(Modifier.height(16.dp))

            // Action Buttons
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Actions",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ActionButton(
                            text = "View Campaigns",
                            icon = Icons.Default.Campaign,
                            color = Color(0xFF16A34A),
                            onClick = {
                                navController.navigate(Routes.ADMIN_MANAGE_CAMPAIGNS)
                            }
                        )
                        ActionButton(
                            text = "Suspend",
                            icon = Icons.Default.Block,
                            color = Color(0xFFEF4444),
                            onClick = {
                                // Handle suspend action
                            }
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ActionButton(
                            text = "Send Message",
                            icon = Icons.Default.Message,
                            color = Color(0xFF3B82F6),
                            onClick = {
                                // Handle message action
                            }
                        )
                        ActionButton(
                            text = "Export Report",
                            icon = Icons.Default.Download,
                            color = Color(0xFF6B7280),
                            onClick = {
                                // Handle export action
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun InfoSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = Color(0xFF16A34A),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )
            }
            content()
        }
    }
}

@Composable
private fun IconInfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = Color(0xFF6B7280),
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = text,
            fontSize = 14.sp,
            color = Color(0xFF4B5563)
        )
    }
}

@Composable
private fun ActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
