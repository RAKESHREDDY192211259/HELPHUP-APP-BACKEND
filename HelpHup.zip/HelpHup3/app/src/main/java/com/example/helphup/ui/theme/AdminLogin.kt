﻿package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* -------------------- DATA MODELS -------------------- */

data class AdminLoginRequest(
    val email: String,
    val password: String
)

data class AdminLoginResponse(
    val status: Boolean,
    val message: String,
    val data: AdminData? = null
)

data class AdminData(
    val admin_id: Int? = null,
    val full_name: String? = null,
    val email: String? = null
)

/* -------------------- API SERVICE -------------------- */

interface AdminLoginApiService {
    @POST("admin_login.php")
    suspend fun loginAdmin(@Body request: AdminLoginRequest): AdminLoginResponse
}

object AdminApiClient {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: AdminLoginApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AdminLoginApiService::class.java)
    }
}

/* -------------------- VIEWMODEL -------------------- */

class AdminLoginViewModel : ViewModel() {

    var isLoading by mutableStateOf(false)
    var errorMessage by mutableStateOf("")
    var loginSuccess by mutableStateOf(false)
    var loginData: AdminData? by mutableStateOf(null)
        private set

    fun login(email: String, password: String) {
        viewModelScope.launch {
            isLoading = true
            errorMessage = ""

            try {
                val response = AdminApiClient.api.loginAdmin(
                    AdminLoginRequest(email, password)
                )

                if (response.status && response.data != null) {
                    loginData = response.data
                    loginSuccess = true
                } else {
                    errorMessage = response.message
                }

            } catch (e: Exception) {
                val errorMsg = e.message ?: "Unknown error"
                errorMessage = when {
                    errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Unable to resolve host") -> "Connection error: Cannot find server\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Connection refused") -> "Connection error: Connection refused\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Connection reset") || errorMsg.contains("connection reset") -> "Connection error: Connection reset\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("timeout") -> "Connection error: Connection timeout\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Network is unreachable") -> "Connection error: Network unreachable\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    else -> "Connection error: $errorMsg\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                }
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
}

/* -------------------- UI -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminLoginScreen(
    navController: NavController,
    viewModel: AdminLoginViewModel = viewModel()
) {

    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    // Save session when login succeeds
    if (viewModel.loginSuccess && viewModel.loginData != null) {
        LaunchedEffect(viewModel.loginData) {
            val sessionManager = UserSessionManager(context)
            val data = viewModel.loginData!!
            if (data.admin_id != null && data.full_name != null && data.email != null) {
                sessionManager.saveAdminSession(
                    data.admin_id,
                    data.full_name,
                    data.email
                )
            }
            navController.navigate(Routes.ADMIN_DASHBOARD) {
                popUpTo(Routes.ADMIN_LOGIN) { inclusive = true }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Login") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(Color(0xFFF0F4F8)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {

                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text(
                        "Admin Access",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        "Administrator Login",
                        fontSize = 14.sp,
                        color = Color(0xFF6B7280)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                    contentDescription = "Toggle password visibility"
                                )
                            }
                        }
                    )

                    if (viewModel.errorMessage.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(viewModel.errorMessage, color = Color.Red, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            if (email.isBlank() || password.isBlank()) {
                                viewModel.errorMessage = "Email and password are required"
                            } else {
                                viewModel.login(email, password)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !viewModel.isLoading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF3B82F6)
                        )
                    ) {
                        if (viewModel.isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text("Sign In", color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TextButton(
                        onClick = { navController.navigate(Routes.ADMIN_FORGOT_PASSWORD) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "Forgot Password?",
                            color = Color(0xFF3B82F6),
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Don't have an account? ",
                            fontSize = 14.sp,
                            color = Color(0xFF6B7280)
                        )
                        Text(
                            "Sign Up",
                            fontSize = 14.sp,
                            color = Color(0xFF3B82F6),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                navController.navigate(Routes.ADMIN_REGISTER)
                            }
                        )
                    }
                }
            }
        }
    }
}





