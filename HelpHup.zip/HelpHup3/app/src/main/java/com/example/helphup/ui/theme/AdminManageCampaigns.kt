package com.example.helphup.ui.theme

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

/* -------------------- API MODELS -------------------- */

// Reuse PendingRequest from AdminManageRequests.kt

/* -------------------- API SERVICE -------------------- */

interface AdminManageCampaignsApi {
    @GET("unified_get_admin_requests.php?status=pending")
    suspend fun getPendingCampaigns(): PendingRequestsResponse // Reuse same response type
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object AdminManageCampaignsRetrofit {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: AdminManageCampaignsApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AdminManageCampaignsApi::class.java)
    }
}

/* -------------------- UI SCREEN -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminManageCampaigns(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val adminId = remember { sessionManager.getAdminId() }

    var campaigns by remember { mutableStateOf<List<PendingRequest>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        isLoading = true
        errorMessage = ""
        try {
            val response = AdminManageCampaignsRetrofit.api.getPendingCampaigns()
            if (response.status && response.data != null) {
                // Convert UnifiedAdminRequestItem to PendingRequest display format
                val convertedData = response.data.map { unifiedItem ->
                    PendingRequest(
                        request_id = unifiedItem.requestId,
                        request_type = unifiedItem.requesterType,
                        ngo_id = if (unifiedItem.requesterType == "ngo") unifiedItem.requesterId else null,
                        volunteer_id = if (unifiedItem.requesterType == "volunteer") unifiedItem.requesterId else null,
                        donor_id = if (unifiedItem.requesterType == "donor") unifiedItem.requesterId else null,
                        request_title = unifiedItem.requestTitle,
                        category = unifiedItem.category,
                        description = unifiedItem.description,
                        admin_status = unifiedItem.status,
                        created_at = unifiedItem.createdAt,
                        submitter_name = unifiedItem.requesterName,
                        submitter_email = unifiedItem.requesterEmail,
                        submitter_org = if (unifiedItem.requesterType == "ngo") unifiedItem.requesterName else null,
                        // NGO specific
                        urgency_level = unifiedItem.urgencyLevel,
                        required_amount = unifiedItem.requiredAmount?.toString(),
                        date_needed = unifiedItem.dateNeeded,
                        contact_number = unifiedItem.requesterPhone,
                        // Volunteer specific
                        location = unifiedItem.location,
                        help_date = unifiedItem.helpDate,
                        start_time = null, // Not in unified model
                        volunteers_needed = unifiedItem.volunteersNeeded,
                        // Donor specific
                        fundraising_goal = unifiedItem.fundraisingGoal?.toString(),
                        beneficiary_name = null, // Not in unified model
                        relationship = null, // Not in unified model
                        contact_email = unifiedItem.requesterEmail,
                        cover_image_url = null, // Not in unified model
                        video_url = null, // Not in unified model
                        duration = null, // Not in unified model
                        end_date = null // Not in unified model
                    )
                }
                // Only show donor campaigns (request_type = 'donor')
                campaigns = convertedData.filter { it.request_type == "donor" }
            } else {
                errorMessage = response.message
            }
        } catch (e: Exception) {
            errorMessage = "Failed to load campaigns: ${e.message}"
        } finally {
            isLoading = false
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0F4F8),
        topBar = {
            TopAppBar(
                title = { Text("Manage Campaigns") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFF59E0B),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F4F8))
                .padding(paddingValues)
        ) {
            // Info Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Review and approve donor campaigns. Accepted campaigns will be visible to NGOs and Volunteers.",
                        fontSize = 13.sp,
                        color = Color(0xFF92400E)
                    )
                }
            }

            if (errorMessage.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                ) {
                    Text(
                        text = errorMessage,
                        color = Color(0xFFC62828),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (campaigns.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Campaign,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color(0xFF9CA3AF)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No pending campaigns",
                            fontSize = 18.sp,
                            color = Color(0xFF9CA3AF)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(campaigns) { campaign ->
                        CampaignCard(
                            campaign = campaign,
                            onClick = {
                                navController.navigate("admin_request_details/donor/${campaign.request_id}")
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CampaignCard(campaign: PendingRequest, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Color(0xFFF59E0B).copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Donor Campaign",
                        color = Color(0xFFF59E0B),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Text(
                    text = campaign.created_at.substring(0, 10),
                    fontSize = 12.sp,
                    color = Color(0xFF9CA3AF)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = campaign.request_title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = campaign.description.take(100) + if (campaign.description.length > 100) "..." else "",
                fontSize = 14.sp,
                color = Color(0xFF6B7280)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "By: ${campaign.submitter_name}",
                    fontSize = 12.sp,
                    color = Color(0xFF9CA3AF)
                )
                Surface(
                    color = when (campaign.admin_status) {
                        "pending" -> Color(0xFFF59E0B).copy(alpha = 0.1f)
                        "accepted" -> Color(0xFF10B981).copy(alpha = 0.1f)
                        "rejected" -> Color(0xFFEF4444).copy(alpha = 0.1f)
                        else -> Color(0xFF6B7280).copy(alpha = 0.1f)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = campaign.admin_status.uppercase(),
                        color = when (campaign.admin_status) {
                            "pending" -> Color(0xFFF59E0B)
                            "accepted" -> Color(0xFF10B981)
                            "rejected" -> Color(0xFFEF4444)
                            else -> Color(0xFF6B7280)
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Icon(
                    Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = Color(0xFF9CA3AF),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

