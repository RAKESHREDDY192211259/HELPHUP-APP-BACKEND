﻿package com.example.helphup.ui.theme

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Body

/* -------------------- API MODELS -------------------- */

data class PendingRequest(
    val request_id: Int,
    val request_type: String, // 'ngo','volunteer', 'donor'
    val ngo_id: Int? = null,
    val volunteer_id: Int? = null,
    val donor_id: Int? = null,
    val request_title: String,
    val category: String,
    val description: String,
    val admin_status: String,
    val created_at: String,
    val submitter_name: String,
    val submitter_email: String,
    val submitter_org: String? = null,
    // NGO specific
    val urgency_level: String? = null,
    val required_amount: String? = null,
    val date_needed: String? = null,
    val contact_number: String? = null,
    // Volunteer specific
    val location: String? = null,
    val help_date: String? = null,
    val start_time: String? = null,
    val volunteers_needed: Int? = null,
    // Donor specific
    val fundraising_goal: String? = null,
    val beneficiary_name: String? = null,
    val relationship: String? = null,
    val contact_email: String? = null,
    val cover_image_url: String? = null,
    val video_url: String? = null,
    val duration: String? = null,
    val end_date: String? = null
)

data class PendingRequestsResponse(
    val status: Boolean,
    val message: String,
    val data: List<UnifiedAdminRequestItem>? = null
)

/* -------------------- SHARED DATA MODELS IMPORT -------------------- */

// These will be imported from AdminRequestDetails.kt to avoid duplication

/* -------------------- API SERVICE -------------------- */

interface AdminManageRequestsApi {
    @GET("unified_get_admin_requests.php?status=pending")
    suspend fun getPendingRequests(): PendingRequestsResponse
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object AdminManageRequestsRetrofit {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: AdminManageRequestsApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AdminManageRequestsApi::class.java)
    }
}

/* -------------------- UI SCREEN -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminManageRequests(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val adminId = remember { sessionManager.getAdminId() }

    var requests by remember { mutableStateOf<List<PendingRequest>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    // Admin Manage Requests shows only NGO and Volunteer requests (not donor campaigns)
    var selectedFilter by remember { mutableStateOf("all") } // 'all', 'ngo', 'volunteer'

    val scope = rememberCoroutineScope()

    LaunchedEffect(selectedFilter) {
        isLoading = true
        errorMessage = ""
        try {
            val response = AdminManageRequestsRetrofit.api.getPendingRequests()
            if (response.status && response.data != null) {
                // Convert UnifiedAdminRequestItem to PendingRequest display format
                val convertedData = response.data.map { unifiedItem ->
                    PendingRequest(
                        request_id = unifiedItem.requestId,
                        request_type = unifiedItem.requesterType,
                        ngo_id = if (unifiedItem.requesterType == "ngo") unifiedItem.requesterId else null,
                        volunteer_id = if (unifiedItem.requesterType == "volunteer") unifiedItem.requesterId else null,
                        donor_id = if (unifiedItem.requesterType == "donor") unifiedItem.requesterId else null,
                        request_title = unifiedItem.requestTitle,
                        category = unifiedItem.category,
                        description = unifiedItem.description,
                        admin_status = unifiedItem.status,
                        created_at = unifiedItem.createdAt,
                        submitter_name = unifiedItem.requesterName,
                        submitter_email = unifiedItem.requesterEmail,
                        submitter_org = if (unifiedItem.requesterType == "ngo") unifiedItem.requesterName else null,
                        // NGO specific
                        urgency_level = unifiedItem.urgencyLevel,
                        required_amount = unifiedItem.requiredAmount?.toString(),
                        date_needed = unifiedItem.dateNeeded,
                        contact_number = unifiedItem.requesterPhone,
                        // Volunteer specific
                        location = unifiedItem.location,
                        help_date = unifiedItem.helpDate,
                        start_time = null, // Not in unified model
                        volunteers_needed = unifiedItem.volunteersNeeded,
                        // Donor specific
                        fundraising_goal = unifiedItem.fundraisingGoal?.toString(),
                        beneficiary_name = null, // Not in unified model
                        relationship = null, // Not in unified model
                        contact_email = unifiedItem.requesterEmail,
                        cover_image_url = null, // Not in unified model
                        video_url = null, // Not in unified model
                        duration = null, // Not in unified model
                        end_date = null // Not in unified model
                    )
                }
                // Filter out donor campaigns - they go to Manage Campaigns page
                requests = if (selectedFilter == "all") {
                    convertedData.filter { it.request_type != "donor" }
                } else {
                    convertedData.filter { it.request_type == selectedFilter }
                }
            } else {
                errorMessage = response.message
            }
        } catch (e: Exception) {
            errorMessage = "Failed to load requests: ${e.message}"
        } finally {
            isLoading = false
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0F4F8),
        topBar = {
            TopAppBar(
                title = { Text("Manage Requests") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF10B981),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F4F8))
                .padding(paddingValues)
        ) {
            // Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == "all",
                    onClick = { selectedFilter = "all" },
                    label = { Text("All") }
                )
                FilterChip(
                    selected = selectedFilter == "ngo",
                    onClick = { selectedFilter = "ngo" },
                    label = { Text("NGO") }
                )
                FilterChip(
                    selected = selectedFilter == "volunteer",
                    onClick = { selectedFilter = "volunteer" },
                    label = { Text("Volunteer") }
                )
                // Donor campaigns are managed in separate "Manage Campaigns" page
            }

            if (errorMessage.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                ) {
                    Text(
                        text = errorMessage,
                        color = Color(0xFFC62828),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (requests.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Inbox,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color(0xFF9CA3AF)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No pending requests",
                            fontSize = 18.sp,
                            color = Color(0xFF9CA3AF)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(requests) { request ->
                        RequestCard(
                            request = request,
                            onClick = {
                                navController.navigate("admin_request_details/${request.request_type}/${request.request_id}")
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RequestCard(request: PendingRequest, onClick: () -> Unit) {
    val typeColor = when (request.request_type) {
        "ngo" -> Color(0xFF3B82F6)
        "volunteer" -> Color(0xFF10B981)
        "donor" -> Color(0xFFF59E0B)
        else -> Color(0xFF6B7280)
    }

    val typeLabel = when (request.request_type) {
        "ngo" -> "NGO Request"
        "volunteer" -> "Volunteer Request"
        "donor" -> "Donor Campaign"
        else -> "Request"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = typeColor.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = typeLabel,
                        color = typeColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Text(
                    text = request.created_at.substring(0, 10),
                    fontSize = 12.sp,
                    color = Color(0xFF9CA3AF)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = request.request_title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = request.description.take(100) + if (request.description.length > 100) "..." else "",
                fontSize = 14.sp,
                color = Color(0xFF6B7280)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "By: ${request.submitter_name}",
                    fontSize = 12.sp,
                    color = Color(0xFF9CA3AF)
                )
                Icon(
                    Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = Color(0xFF9CA3AF),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

