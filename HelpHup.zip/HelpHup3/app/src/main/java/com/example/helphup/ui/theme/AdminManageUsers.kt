package com.example.helphup.ui.theme

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/* -------------------- API MODELS -------------------- */

data class User(
    @SerializedName("user_id") val userId: Int,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("phone") val phone: String,
    @SerializedName("email") val email: String,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("user_type") val userType: String,
    // NGO specific
    @SerializedName("org_name") val orgName: String? = null,
    @SerializedName("reg_number") val regNumber: String? = null,
    @SerializedName("address") val address: String? = null,
    // Volunteer specific
    @SerializedName("skills") val skills: String? = null,
    @SerializedName("availability") val availability: String? = null,
    // Donor specific
    @SerializedName("total_donated") val totalDonated: String? = null,
    @SerializedName("last_donation") val lastDonation: String? = null,
    @SerializedName("preferred_causes") val preferredCauses: String? = null,
    @SerializedName("rejection_reason") val rejectionReason: String? = null
)

data class UsersResponse(
    val status: Boolean,
    val message: String,
    val data: List<User>? = null
)

data class RejectUserRequest(
    val user_type: String,
    val user_id: Int,
    val admin_id: Int,
    val rejection_reason: String
)

data class RejectUserResponse(
    val status: Boolean,
    val message: String
)

data class ApproveUserRequest(
    val user_type: String,
    val user_id: Int,
    val admin_id: Int
)

data class ApproveUserResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- API SERVICE -------------------- */

interface AdminManageUsersApi {
    @GET("xampp_files/admin_get_all_users.php")
    suspend fun getUsers(@retrofit2.http.Query("user_type") userType: String): UsersResponse
    
    @POST("xampp_files/admin_reject_user.php")
    suspend fun rejectUser(@Body request: RejectUserRequest): RejectUserResponse
    
    @POST("xampp_files/admin_approve_user.php")
    suspend fun approveUser(@Body request: ApproveUserRequest): ApproveUserResponse
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object AdminManageUsersRetrofit {
    private const val BASE_URL = "http://10.126.222.192/helphup/"
    
    val api: AdminManageUsersApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AdminManageUsersApi::class.java)
    }
}

/* -------------------- UI SCREEN -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminManageUsers(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val adminId = remember { sessionManager.getAdminId() }
    
    var users by remember { mutableStateOf<List<User>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) } // null = show categories, 'ngo'/'volunteer'/'donor' = show users
    
    val scope = rememberCoroutineScope()
    
    // Show rejection dialog
    var showRejectDialog by remember { mutableStateOf(false) }
    var selectedUser by remember { mutableStateOf<User?>(null) }
    var rejectionReason by remember { mutableStateOf("") }
    
    fun loadUsers(category: String) {
        scope.launch {
            isLoading = true
            errorMessage = ""
            successMessage = ""
            
            // Load sample data directly like other flows
            Log.d("AdminManageUsers", "Loading sample data for category: $category")
            users = getSampleUsers(category)
            
            isLoading = false
        }
    }
    
    fun approveUser(user: User) {
        scope.launch {
            isLoading = true
            errorMessage = ""
            successMessage = ""
            try {
                if (adminId == null || adminId == 0) {
                    errorMessage = "Admin ID not found. Please login again."
                    isLoading = false
                    return@launch
                }
                
                val response = AdminManageUsersRetrofit.api.approveUser(
                    ApproveUserRequest(
                        user_type = user.userType,
                        user_id = user.userId,
                        admin_id = adminId
                    )
                )
                if (response.status) {
                    successMessage = "User approved successfully"
                    // Reload users to show updated status
                    loadUsers(user.userType)
                } else {
                    errorMessage = response.message
                }
            } catch (e: Exception) {
                errorMessage = "Failed to approve user: ${e.message}"
                Log.e("AdminManageUsers", "Error approving user", e)
            } finally {
                isLoading = false
            }
        }
    }
    
    fun rejectUser(user: User, reason: String) {
        scope.launch {
            isLoading = true
            errorMessage = ""
            successMessage = ""
            try {
                if (adminId == null || adminId == 0) {
                    errorMessage = "Admin ID not found. Please login again."
                    isLoading = false
                    return@launch
                }
                
                val response = AdminManageUsersRetrofit.api.rejectUser(
                    RejectUserRequest(
                        user_type = user.userType,
                        user_id = user.userId,
                        admin_id = adminId,
                        rejection_reason = reason
                    )
                )
                if (response.status) {
                    successMessage = "User rejected successfully"
                    // Reload users to show updated status
                    loadUsers(user.userType)
                    showRejectDialog = false
                    rejectionReason = ""
                    selectedUser = null
                } else {
                    errorMessage = response.message
                }
            } catch (e: Exception) {
                errorMessage = "Failed to reject user: ${e.message}"
                Log.e("AdminManageUsers", "Error rejecting user", e)
            } finally {
                isLoading = false
            }
        }
    }
    
    Scaffold(
        containerColor = Color(0xFFF0F4F8),
        topBar = {
            TopAppBar(
                title = { Text(if (selectedCategory == null) "Manage Users" else "Users - ${selectedCategory?.uppercase()}") },
                navigationIcon = {
                    IconButton(onClick = { 
                        if (selectedCategory != null) {
                            selectedCategory = null
                            users = emptyList()
                        } else {
                            navController.popBackStack()
                        }
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF3B82F6),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F4F8))
                .padding(paddingValues)
        ) {
            if (selectedCategory == null) {
                // Show category selection
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Select User Category",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
                    CategoryCard(
                        title = "NGOs",
                        subtitle = "Manage NGO accounts",
                        icon = Icons.Default.Business,
                        color = Color(0xFF3B82F6),
                        onClick = {
                            selectedCategory = "ngo"
                            loadUsers("ngo")
                        }
                    )
                    
                    CategoryCard(
                        title = "Volunteers",
                        subtitle = "Manage Volunteer accounts",
                        icon = Icons.Default.People,
                        color = Color(0xFF10B981),
                        onClick = {
                            selectedCategory = "volunteer"
                            loadUsers("volunteer")
                        }
                    )
                    
                    CategoryCard(
                        title = "Donors",
                        subtitle = "Manage Donor accounts",
                        icon = Icons.Default.Favorite,
                        color = Color(0xFFF59E0B),
                        onClick = {
                            selectedCategory = "donor"
                            loadUsers("donor")
                        }
                    )
                }
            } else {
                // Show users list
                if (errorMessage.isNotEmpty()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                    ) {
                        Text(
                            text = errorMessage,
                            color = Color(0xFFC62828),
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                
                if (successMessage.isNotEmpty()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
                    ) {
                        Text(
                            text = successMessage,
                            color = Color(0xFF2E7D32),
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                
                if (isLoading) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                } else if (users.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.People,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = Color(0xFF9CA3AF)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "No users found",
                                fontSize = 18.sp,
                                color = Color(0xFF9CA3AF)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "Total Users: ${users.size}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1F2937),
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }
                        items(users) { user ->
                            UserCard(
                                user = user,
                                onApproveClick = { approveUser(user) },
                                onRejectClick = {
                                    selectedUser = user
                                    showRejectDialog = true
                                },
                                onCardClick = {
                                    // Navigate to appropriate detail page based on user type
                                    when (user.userType.lowercase()) {
                                        "ngo" -> navController.navigate(Routes.ADMIN_NGO_DETAILS.replace("{ngo_id}", user.userId.toString()))
                                        "volunteer" -> navController.navigate(Routes.ADMIN_VOLUNTEER_DETAILS.replace("{volunteer_id}", user.userId.toString()))
                                        "donor" -> navController.navigate(Routes.ADMIN_DONOR_DETAILS.replace("{donor_id}", user.userId.toString()))
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
    
    // Rejection Dialog
    if (showRejectDialog && selectedUser != null) {
        AlertDialog(
            onDismissRequest = {
                showRejectDialog = false
                rejectionReason = ""
            },
            title = { Text("Reject User") },
            text = {
                Column {
                    Text("Are you sure you want to reject this user?")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectionReason,
                        onValueChange = { rejectionReason = it },
                        label = { Text("Rejection Reason") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (rejectionReason.isNotEmpty() && selectedUser != null) {
                            rejectUser(selectedUser!!, rejectionReason)
                        }
                    },
                    enabled = rejectionReason.isNotEmpty()
                ) {
                    Text("Reject", color = Color(0xFFEF4444))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showRejectDialog = false
                        rejectionReason = ""
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun CategoryCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier
                    .size(56.dp)
                    .background(color, RoundedCornerShape(12.dp))
                    .padding(14.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )
                Text(
                    text = subtitle,
                    fontSize = 14.sp,
                    color = color
                )
            }
            
            Spacer(modifier = Modifier.fillMaxWidth())
            
            Icon(
                Icons.Default.ChevronRight,
                contentDescription = null,
                tint = Color(0xFF9CA3AF)
            )
        }
    }
}

@Composable
fun UserCard(
    user: User,
    onApproveClick: () -> Unit = {},
    onRejectClick: () -> Unit,
    onCardClick: () -> Unit = {}
) {
    val statusColor = when (user.status.lowercase()) {
        "active" -> Color(0xFF10B981)
        "rejected" -> Color(0xFFEF4444)
        "inactive" -> Color(0xFF9CA3AF)
        else -> Color(0xFF6B7280)
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() },
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = user.fullName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = user.email,
                        fontSize = 14.sp,
                        color = Color(0xFF6B7280)
                    )
                    if (user.orgName != null) {
                        Text(
                            text = "Org: ${user.orgName}",
                            fontSize = 12.sp,
                            color = Color(0xFF9CA3AF)
                        )
                    }
                }
                
                Surface(
                    color = statusColor.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = user.status.uppercase(),
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Phone: ${user.phone}",
                    fontSize = 12.sp,
                    color = Color(0xFF9CA3AF)
                )
                Text(
                    text = "Joined: ${user.createdAt.substring(0, 10)}",
                    fontSize = 12.sp,
                    color = Color(0xFF9CA3AF)
                )
            }
            
            if (user.status.lowercase() != "rejected" && user.status.lowercase() != "active") {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onApproveClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Approve")
                    }
                    Button(
                        onClick = onRejectClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Default.Block,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reject")
                    }
                }
            } else if (user.status.lowercase() != "rejected") {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onRejectClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        Icons.Default.Block,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Reject User")
                }
            }
        }
    }
}

/* ---------- Sample Data ---------- */

private fun getSampleUsers(category: String): List<User> {
    return when (category.lowercase()) {
        "ngo" -> listOf(
            User(
                userId = 1,
                fullName = "HelpCare Foundation",
                phone = "+91-9876543210",
                email = "contact@helpcare.org",
                status = "pending",
                createdAt = "2024-01-15",
                userType = "NGO",
                orgName = "HelpCare Foundation",
                regNumber = "NGO-2021-HYD-0456",
                address = "Hyderabad, Telangana"
            ),
            User(
                userId = 2,
                fullName = "Education First Initiative",
                phone = "+91-8765432109",
                email = "info@educationfirst.org",
                status = "active",
                createdAt = "2021-06-20",
                userType = "NGO",
                orgName = "Education First Initiative",
                regNumber = "NGO-2021-HYD-0489",
                address = "Bangalore, Karnataka"
            ),
            User(
                userId = 3,
                fullName = "Green Earth Foundation",
                phone = "+91-7654321098",
                email = "green@earthfoundation.org",
                status = "pending",
                createdAt = "2024-01-10",
                userType = "NGO",
                orgName = "Green Earth Foundation",
                regNumber = "NGO-2022-HYD-0523",
                address = "Chennai, Tamil Nadu"
            )
        )
        "volunteer" -> listOf(
            User(
                userId = 4,
                fullName = "Rahul Kumar",
                phone = "+91-8765432109",
                email = "rahul.kumar@email.com",
                status = "pending",
                createdAt = "2024-01-15",
                userType = "Volunteer",
                skills = "Teaching, Healthcare Support, Event Management",
                availability = "Weekends, Weekday Evenings"
            ),
            User(
                userId = 5,
                fullName = "Priya Singh",
                phone = "+91-9876543211",
                email = "priya.singh@email.com",
                status = "active",
                createdAt = "2022-05-20",
                userType = "Volunteer",
                skills = "Community Outreach, Counseling, First Aid",
                availability = "Flexible, Emergency Available"
            ),
            User(
                userId = 6,
                fullName = "Amit Patel",
                phone = "+91-7654321099",
                email = "amit.patel@email.com",
                status = "pending",
                createdAt = "2024-01-08",
                userType = "Volunteer",
                skills = "Teaching, Sports Coaching, Mentoring",
                availability = "Weekends Only"
            )
        )
        "donor" -> listOf(
            User(
                userId = 7,
                fullName = "Priya Sharma",
                phone = "+91-9876543210",
                email = "priya.sharma@email.com",
                status = "pending",
                createdAt = "2024-01-12",
                userType = "Donor",
                totalDonated = "0",
                lastDonation = null,
                preferredCauses = "Education, Healthcare"
            ),
            User(
                userId = 8,
                fullName = "Rajesh Kumar",
                phone = "+91-8765432110",
                email = "rajesh.kumar@email.com",
                status = "active",
                createdAt = "2021-07-20",
                userType = "Donor",
                totalDonated = "180000",
                lastDonation = "2024-01-02",
                preferredCauses = "Environment, Animal Welfare"
            ),
            User(
                userId = 9,
                fullName = "Anita Desai",
                phone = "+91-7654321110",
                email = "anita.desai@email.com",
                status = "pending",
                createdAt = "2024-01-05",
                userType = "Donor",
                totalDonated = "0",
                lastDonation = null,
                preferredCauses = "Women Empowerment, Child Education"
            )
        )
        else -> emptyList()
    }
}

