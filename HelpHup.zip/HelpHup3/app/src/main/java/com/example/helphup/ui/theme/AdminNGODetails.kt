package com.example.helphup.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.R
import com.example.helphup.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminNGODetailsScreen(
    navController: NavController,
    ngoId: String = "1"
) {
    Scaffold(
        containerColor = Color(0xFFF8FAFC),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("NGO Details", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "View complete NGO information",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF3B82F6),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {

            // NGO Profile Header
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Profile Image
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(80.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                                contentDescription = "NGO Profile",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(Modifier.width(16.dp))

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "HelpCare Foundation",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1F2937)
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Verified NGO • Active",
                                fontSize = 14.sp,
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Member since 2021",
                                fontSize = 12.sp,
                                color = Color(0xFF6B7280)
                            )
                        }

                        // Status Badge
                        Surface(
                            color = Color(0xFF10B981),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                text = "ACTIVE",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Contact Information
            InfoSectionCard(
                title = "Contact Information",
                icon = Icons.Default.ContactPhone
            ) {
                IconInfoRow(Icons.Default.Phone, "+91-9876543210")
                IconInfoRow(Icons.Default.Email, "contact@helpcare.org")
                IconInfoRow(Icons.Default.LocationOn, "Hyderabad, Telangana, India")
                IconInfoRow(Icons.Default.Language, "www.helpcare.org")
            }

            Spacer(Modifier.height(16.dp))

            // Organization Details
            InfoSectionCard(
                title = "Organization Details",
                icon = Icons.Default.Business
            ) {
                IconInfoRow(Icons.Default.Numbers, "Reg Number: NGO-2021-HYD-0456")
                IconInfoRow(Icons.Default.Category, "Category: Healthcare & Education")
                IconInfoRow(Icons.Default.People, "Team Size: 25+ members")
                IconInfoRow(Icons.Default.CalendarToday, "Founded: 2021")
            }

            Spacer(Modifier.height(16.dp))

            // Statistics
            InfoSectionCard(
                title = "Impact Statistics",
                icon = Icons.Default.BarChart
            ) {
                IconInfoRow(Icons.Default.TrendingUp, "Help Requests Raised: 45")
                IconInfoRow(Icons.Default.People, "Volunteers Mobilized: 200+")
                IconInfoRow(Icons.Default.AttachMoney, "Funds Raised: ₹25,00,000")
                IconInfoRow(Icons.Default.Star, "Success Rate: 92%")
            }

            Spacer(Modifier.height(16.dp))

            // Recent Activity
            InfoSectionCard(
                title = "Recent Activity",
                icon = Icons.Default.History
            ) {
                IconInfoRow(Icons.Default.Event, "Last Request: 2 days ago")
                IconInfoRow(Icons.Default.CheckCircle, "Active Campaigns: 3")
                IconInfoRow(Icons.Default.Pending, "Pending Approvals: 2")
                IconInfoRow(Icons.Default.LocalActivity, "Events This Month: 5")
            }

            Spacer(Modifier.height(16.dp))

            // Documents
            InfoSectionCard(
                title = "Documents & Verification",
                icon = Icons.Default.Description
            ) {
                IconInfoRow(Icons.Default.Verified, "NGO Registration: Verified")
                IconInfoRow(Icons.Default.Verified, "PAN Card: Verified")
                IconInfoRow(Icons.Default.Verified, "Address Proof: Verified")
                IconInfoRow(Icons.Default.Verified, "Bank Account: Verified")
            }

            Spacer(Modifier.height(16.dp))

            // Action Buttons
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Actions",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ActionButton(
                            text = "View Requests",
                            icon = Icons.Default.List,
                            color = Color(0xFF3B82F6),
                            onClick = {
                                navController.navigate(Routes.ADMIN_MANAGE_REQUESTS)
                            }
                        )
                        ActionButton(
                            text = "Suspend",
                            icon = Icons.Default.Block,
                            color = Color(0xFFEF4444),
                            onClick = {
                                // Handle suspend action
                            }
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ActionButton(
                            text = "Send Message",
                            icon = Icons.Default.Message,
                            color = Color(0xFF10B981),
                            onClick = {
                                // Handle message action
                            }
                        )
                        ActionButton(
                            text = "Export Data",
                            icon = Icons.Default.Download,
                            color = Color(0xFF6B7280),
                            onClick = {
                                // Handle export action
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun InfoSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = Color(0xFF3B82F6),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )
            }
            content()
        }
    }
}

@Composable
private fun IconInfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = Color(0xFF6B7280),
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = text,
            fontSize = 14.sp,
            color = Color(0xFF4B5563)
        )
    }
}

@Composable
private fun ActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
