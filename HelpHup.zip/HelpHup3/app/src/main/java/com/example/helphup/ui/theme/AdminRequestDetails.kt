package com.example.helphup.ui.theme

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.data.HelpRequestDataStore
import com.example.helphup.utils.UserSessionManager
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.GET
import retrofit2.Response

/* -------------------- API MODELS -------------------- */

data class AdminActionRequest(
    val request_id: Int,
    val status: String,
    val admin_id: Int,
    val rejection_reason: String? = null
)

data class AdminActionResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- UNIFIED DATA MODELS -------------------- */

data class UnifiedAdminRequestsResponse(
    val status: Boolean,
    val message: String,
    val data: List<UnifiedAdminRequestItem>?,
    val counts: Map<String, Int>? = null
)

data class UnifiedAdminRequestItem(
    @SerializedName("request_id") val requestId: Int,
    @SerializedName("requester_type") val requesterType: String,
    @SerializedName("requester_id") val requesterId: Int,
    @SerializedName("requester_name") val requesterName: String,
    @SerializedName("requester_email") val requesterEmail: String,
    @SerializedName("requester_phone") val requesterPhone: String,
    @SerializedName("request_title") val requestTitle: String,
    @SerializedName("category") val category: String,
    @SerializedName("description") val description: String,
    @SerializedName("urgency_level") val urgencyLevel: String,
    @SerializedName("required_amount") val requiredAmount: Double?,
    @SerializedName("date_needed") val dateNeeded: String?,
    @SerializedName("contact_number") val contactNumber: String?,
    @SerializedName("location") val location: String?,
    @SerializedName("help_date") val helpDate: String?,
    @SerializedName("start_time") val startTime: String?,
    @SerializedName("volunteers_needed") val volunteersNeeded: Int?,
    @SerializedName("fundraising_goal") val fundraisingGoal: Double?,
    @SerializedName("duration") val duration: String?,
    @SerializedName("end_date") val endDate: String?,
    @SerializedName("beneficiary_name") val beneficiaryName: String?,
    @SerializedName("relationship") val relationship: String?,
    @SerializedName("contact_email") val contactEmail: String?,
    @SerializedName("cover_image_url") val coverImageUrl: String?,
    @SerializedName("video_url") val videoUrl: String?,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("created_at_formatted") val createdAtFormatted: String? = null
)

data class SingleRequestResponse(
    val status: Boolean,
    val message: String,
    val data: UnifiedAdminRequestItem?
)

/* -------------------- DISPLAY DATA MODEL -------------------- */

data class AdminRequestDisplay(
    val request_id: Int,
    val request_type: String,
    val ngo_id: Int? = null,
    val volunteer_id: Int? = null,
    val donor_id: Int? = null,
    val request_title: String,
    val category: String,
    val description: String,
    val admin_status: String,
    val created_at: String,
    val submitter_name: String,
    val submitter_email: String,
    val submitter_org: String? = null,
    val urgency_level: String? = null,
    val required_amount: String? = null,
    val date_needed: String? = null,
    val contact_number: String? = null,
    val location: String? = null,
    val help_date: String? = null,
    val start_time: String? = null,
    val volunteers_needed: Int? = null,
    val fundraising_goal: String? = null,
    val beneficiary_name: String? = null,
    val relationship: String? = null,
    val contact_email: String? = null,
    val cover_image_url: String? = null,
    val video_url: String? = null,
    val duration: String? = null,
    val end_date: String? = null
)

/* -------------------- API SERVICE -------------------- */

interface AdminRequestActionApi {
    @POST("unified_update_request_status.php")
    suspend fun updateRequestStatus(@Body request: AdminActionRequest): Response<AdminActionResponse>
}

interface AdminSingleRequestApi {
    @GET("unified_get_admin_requests.php?status=pending")
    suspend fun getPendingRequests(): UnifiedAdminRequestsResponse
    
    @GET("get_request_details.php")
    suspend fun getRequestDetails(@retrofit2.http.Query("request_id") requestId: Int): SingleRequestResponse
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object AdminRequestActionRetrofit {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: AdminRequestActionApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AdminRequestActionApi::class.java)
    }
}

object AdminSingleRequestRetrofit {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: AdminSingleRequestApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AdminSingleRequestApi::class.java)
    }
}

/* -------------------- UI SCREEN -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminRequestDetails(
    navController: NavController,
    requestType: String,
    requestId: Int
) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val adminId = remember { sessionManager.getAdminId() }

    var request by remember { mutableStateOf<AdminRequestDisplay?>(null) }
    var showRejectDialog by remember { mutableStateOf(false) }
    var rejectionReason by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var isLoadingRequest by remember { mutableStateOf(true) }
    var successMessage by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    // Fetch request details
    LaunchedEffect(requestType, requestId) {
        isLoadingRequest = true
        try {
            val response = AdminSingleRequestRetrofit.api.getRequestDetails(requestId)
            if (response.status && response.data != null) {
                val foundRequest = response.data
                // Verify request type matches
                if (foundRequest.requesterType == requestType) {
                    request = AdminRequestDisplay(
                        request_id = foundRequest.requestId,
                        request_type = foundRequest.requesterType,
                        ngo_id = if (foundRequest.requesterType == "ngo") foundRequest.requesterId else null,
                        volunteer_id = if (foundRequest.requesterType == "volunteer") foundRequest.requesterId else null,
                        donor_id = if (foundRequest.requesterType == "donor") foundRequest.requesterId else null,
                        request_title = foundRequest.requestTitle,
                        category = foundRequest.category,
                        description = foundRequest.description,
                        admin_status = foundRequest.status,
                        created_at = foundRequest.createdAtFormatted ?: foundRequest.createdAt,
                        submitter_name = foundRequest.requesterName,
                        submitter_email = foundRequest.requesterEmail,
                        submitter_org = if (foundRequest.requesterType == "ngo") foundRequest.requesterName else null,
                        urgency_level = foundRequest.urgencyLevel,
                        required_amount = foundRequest.requiredAmount?.toString(),
                        date_needed = foundRequest.dateNeeded,
                        contact_number = foundRequest.contactNumber ?: foundRequest.requesterPhone,
                        location = foundRequest.location,
                        help_date = foundRequest.helpDate,
                        start_time = foundRequest.startTime,
                        volunteers_needed = foundRequest.volunteersNeeded,
                        fundraising_goal = foundRequest.fundraisingGoal?.toString(),
                        beneficiary_name = foundRequest.beneficiaryName,
                        relationship = foundRequest.relationship,
                        contact_email = foundRequest.contactEmail ?: foundRequest.requesterEmail,
                        cover_image_url = foundRequest.coverImageUrl,
                        video_url = foundRequest.videoUrl,
                        duration = foundRequest.duration,
                        end_date = foundRequest.endDate
                    )
                } else {
                    errorMessage = "Request type mismatch"
                }
            } else {
                errorMessage = response.message
            }
        } catch (e: Exception) {
            errorMessage = "Failed to load request: ${e.message}"
        } finally {
            isLoadingRequest = false
        }
    }

    fun performAction(action: String) {
        val currentRequest = request ?: return
        val adminId = adminId ?: return

        isLoading = true
        successMessage = ""
        errorMessage = ""

        scope.launch {
            try {
                val actionRequest = AdminActionRequest(
                    request_id = currentRequest.request_id,
                    status = if (action == "approve") "approved" else "rejected",
                    admin_id = adminId,
                    rejection_reason = if (action == "reject") rejectionReason else null
                )

                val response = AdminRequestActionRetrofit.api.updateRequestStatus(actionRequest)
                
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody?.status == true) {
                        successMessage = if (action == "approve") 
                            "Request approved successfully!" 
                        else 
                            "Request rejected successfully!"
                        
                        // Refresh data store to trigger UI updates
                        HelpRequestDataStore.notifyHelpRequestUpdated()
                        
                        kotlinx.coroutines.delay(1000)
                        navController.popBackStack()
                    } else {
                        val msg = responseBody?.message ?: "Failed to update request status"
                        errorMessage = msg
                    }
                } else {
                    errorMessage = "Server error: ${response.code()} - ${response.message()}"
                }
            } catch (e: Exception) {
                errorMessage = "Failed to update request: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    // UI Components (keep existing UI code)
    @Composable
    fun AdminInfoRow(label: String, value: String) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                modifier = Modifier.weight(1f),
                fontSize = 14.sp,
                color = Color(0xFF6B7280)
            )
            Text(
                text = value,
                modifier = Modifier.weight(1.5f),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color.Black
            )
        }
    }

    when (isLoadingRequest) {
        true -> {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        }
        false -> {
            request?.let { currentRequest ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .padding(20.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { navController.popBackStack() }
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                        
                        Text(
                            text = "Request Details",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1F2937)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Request Details Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Text(
                                text = currentRequest.request_title,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1F2937)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = currentRequest.description,
                                fontSize = 14.sp,
                                color = Color(0xFF6B7280)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            AdminInfoRow("Submitted by", currentRequest.submitter_name)
                            AdminInfoRow("Email", currentRequest.submitter_email)
                            currentRequest.submitter_org?.let { org ->
                                AdminInfoRow("Organization", org)
                            }

                            // Request-specific fields
                            when (requestType) {
                                "ngo" -> {
                                    AdminInfoRow("Category", currentRequest.category)
                                    AdminInfoRow("Urgency", currentRequest.urgency_level ?: "N/A")
                                    AdminInfoRow("Amount Required", "₹${currentRequest.required_amount ?: "0"}")
                                    AdminInfoRow("Date Needed", currentRequest.date_needed ?: "N/A")
                                    AdminInfoRow("Contact", currentRequest.contact_number ?: "N/A")
                                }
                                "volunteer" -> {
                                    AdminInfoRow("Category", currentRequest.category)
                                    AdminInfoRow("Location", currentRequest.location ?: "N/A")
                                    AdminInfoRow("Help Date", currentRequest.help_date ?: "N/A")
                                    AdminInfoRow("Start Time", currentRequest.start_time ?: "N/A")
                                    AdminInfoRow("Volunteers Needed", "${currentRequest.volunteers_needed ?: 0}")
                                }
                                "donor" -> {
                                    AdminInfoRow("Category", currentRequest.category)
                                    AdminInfoRow("Fundraising Goal", "₹${currentRequest.fundraising_goal ?: "0"}")
                                    AdminInfoRow("End Date", currentRequest.end_date ?: "N/A")
                                    AdminInfoRow("Beneficiary", currentRequest.beneficiary_name ?: "N/A")
                                    AdminInfoRow("Relationship", currentRequest.relationship ?: "N/A")
                                    AdminInfoRow("Contact Email", currentRequest.contact_email ?: "N/A")
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            AdminInfoRow("Status", currentRequest.admin_status)
                            AdminInfoRow("Created", currentRequest.created_at.substring(0, 10))
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // View All Data Button (for approved/rejected requests)
                    if (currentRequest.admin_status == "approved" || currentRequest.admin_status == "rejected") {
                        Button(
                            onClick = { /* Already showing all data */ },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2196F3),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Viewing All Submitted Data")
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Action Buttons
                    if (currentRequest.admin_status == "pending" || currentRequest.admin_status == "verified") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color(0xFFE8F5E8),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(16.dp)
                        ) {
                            // Verify button (only show if pending)
                            if (currentRequest.admin_status == "pending") {
                                Button(
                                    onClick = { performAction("verify") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF4CAF50),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Text("Verify Request")
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Approve button
                                Button(
                                    onClick = { performAction("approve") },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF4CAF50),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Text("Approve")
                                }

                                // Reject button
                                Button(
                                    onClick = { showRejectDialog = true },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFF44336),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Text("Reject")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Success/Error Messages
    if (successMessage.isNotEmpty()) {
        LaunchedEffect(successMessage) {
            kotlinx.coroutines.delay(3000)
            successMessage = ""
        }
        
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF4CAF50)),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = successMessage,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }

    if (errorMessage.isNotEmpty()) {
        LaunchedEffect(errorMessage) {
            kotlinx.coroutines.delay(3000)
            errorMessage = ""
        }
        
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF44336)),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Error,
                        contentDescription = "Error",
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = errorMessage,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }

    // Reject Dialog
    if (showRejectDialog) {
        AlertDialog(
            onDismissRequest = { showRejectDialog = false },
            title = { Text("Reject Request") },
            text = {
                Column {
                    Text(
                        text = "Please provide a reason for rejecting this request:",
                        fontSize = 14.sp,
                        color = Color(0xFF6B7280)
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    OutlinedTextField(
                        value = rejectionReason,
                        onValueChange = { rejectionReason = it },
                        label = { Text("Rejection Reason") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = false
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (rejectionReason.isNotBlank()) {
                            performAction("reject")
                            showRejectDialog = false
                        }
                    },
                    enabled = rejectionReason.isNotBlank()
                ) {
                    Text("Reject")
                }
            },
            dismissButton = {
                Button(
                    onClick = { showRejectDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}
