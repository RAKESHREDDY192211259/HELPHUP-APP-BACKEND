package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

/* -------------------- API MODELS -------------------- */

data class AdminVerifyOtpRequest(
    val email: String,
    val otp: String
)

data class AdminVerifyOtpResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- API SERVICE -------------------- */

interface AdminVerifyOtpApiService {
    @POST("admin_verify_otp.php")
    suspend fun verifyOtp(@Body request: AdminVerifyOtpRequest): AdminVerifyOtpResponse
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object AdminVerifyOtpRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val api: AdminVerifyOtpApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AdminVerifyOtpApiService::class.java)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminVerifyOtpScreen(
    email: String,
    onBackClick: () -> Unit,
    onVerifySuccess: (String) -> Unit, // Passes OTP to reset password screen
    onResendClick: () -> Unit
) {
    var otp by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = Color(0xFFF0F4F8),
        topBar = {
            TopAppBar(
                title = { Text("Verify OTP") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF3B82F6),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .background(Color(0xFFF0F4F8)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(40.dp))

            Card(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .background(Color(0xFFDBEAFE), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Lock,
                            contentDescription = "OTP",
                            tint = Color(0xFF3B82F6),
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Verify OTP",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Enter the 6-digit code sent to your email",
                        fontSize = 13.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    OutlinedTextField(
                        value = otp,
                        onValueChange = {
                            if (it.length <= 6) otp = it
                        },
                        label = { Text("OTP Code") },
                        placeholder = { Text("123456") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            if (otp.length != 6) {
                                isError = true
                                message = "Please enter 6-digit OTP"
                                return@Button
                            }
                            
                            isLoading = true
                            message = ""
                            
                            scope.launch {
                                try {
                                    val response = AdminVerifyOtpRetrofitInstance.api.verifyOtp(
                                        AdminVerifyOtpRequest(email, otp)
                                    )
                                    
                                    if (response.status) {
                                        onVerifySuccess(otp)
                                    } else {
                                        isError = true
                                        message = response.message
                                    }
                                } catch (e: Exception) {
                                    isError = true
                                    val errorMsg = e.message ?: "Unknown error"
                                    message = when {
                                        errorMsg.contains("actively refused") || errorMsg.contains("target machine") -> "Connection refused: Server not running"
                                        errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response"
                                        errorMsg.contains("Unable to resolve host") -> "Connection error: Cannot find server"
                                        else -> "Error: $errorMsg"
                                    }
                                } finally {
                                    isLoading = false
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !isLoading && otp.length == 6,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF3B82F6)
                        )
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(
                            text = "Verify",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (message.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = message,
                            color = if (isError) Color.Red else Color(0xFF3B82F6),
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Resend Code",
                        fontSize = 14.sp,
                        color = Color(0xFF3B82F6),
                        modifier = Modifier.clickable { onResendClick() }
                    )
                }
            }
        }
    }
}

