package com.example.helphup.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.R
import com.example.helphup.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminVolunteerDetailsScreen(
    navController: NavController,
    volunteerId: String = "1"
) {
    Scaffold(
        containerColor = Color(0xFFF8FAFC),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Volunteer Details", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "View complete volunteer information",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF10B981),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {

            // Volunteer Profile Header
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Profile Image
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(80.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                                contentDescription = "Volunteer Profile",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(Modifier.width(16.dp))

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Rahul Kumar",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1F2937)
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Active Volunteer",
                                fontSize = 14.sp,
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Member since 2022",
                                fontSize = 12.sp,
                                color = Color(0xFF6B7280)
                            )
                        }

                        // Status Badge
                        Surface(
                            color = Color(0xFF10B981),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                text = "ACTIVE",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Personal Information
            InfoSectionCard(
                title = "Personal Information",
                icon = Icons.Default.Person
            ) {
                IconInfoRow(Icons.Default.Phone, "+91-8765432109")
                IconInfoRow(Icons.Default.Email, "rahul.kumar@email.com")
                IconInfoRow(Icons.Default.Cake, "Age: 28 years")
                IconInfoRow(Icons.Default.LocationOn, "Hyderabad, Telangana")
            }

            Spacer(Modifier.height(16.dp))

            // Skills & Expertise
            InfoSectionCard(
                title = "Skills & Expertise",
                icon = Icons.Default.Build
            ) {
                IconInfoRow(Icons.Default.Star, "Teaching & Education")
                IconInfoRow(Icons.Default.Star, "Healthcare Support")
                IconInfoRow(Icons.Default.Star, "Event Management")
                IconInfoRow(Icons.Default.Star, "Community Outreach")
            }

            Spacer(Modifier.height(16.dp))

            // Availability
            InfoSectionCard(
                title = "Availability",
                icon = Icons.Default.Schedule
            ) {
                IconInfoRow(Icons.Default.EventAvailable, "Weekends: Available")
                IconInfoRow(Icons.Default.EventAvailable, "Weekdays: Evenings (6-9 PM)")
                IconInfoRow(Icons.Default.EventAvailable, "Emergency: Available 24/7")
                IconInfoRow(Icons.Default.EventAvailable, "Flexible Schedule")
            }

            Spacer(Modifier.height(16.dp))

            // Statistics
            InfoSectionCard(
                title = "Contribution Statistics",
                icon = Icons.Default.BarChart
            ) {
                IconInfoRow(Icons.Default.TrendingUp, "Help Requests Completed: 15")
                IconInfoRow(Icons.Default.Timer, "Total Hours: 250+")
                IconInfoRow(Icons.Default.Group, "NGOs Helped: 8")
                IconInfoRow(Icons.Default.EmojiEvents, "Rating: 4.8/5.0")
            }

            Spacer(Modifier.height(16.dp))

            // Recent Activity
            InfoSectionCard(
                title = "Recent Activity",
                icon = Icons.Default.History
            ) {
                IconInfoRow(Icons.Default.Event, "Last Activity: 3 days ago")
                IconInfoRow(Icons.Default.CheckCircle, "Active Requests: 2")
                IconInfoRow(Icons.Default.Pending, "Pending Tasks: 1")
                IconInfoRow(Icons.Default.LocalActivity, "Events Attended: 12")
            }

            Spacer(Modifier.height(16.dp))

            // Verification
            InfoSectionCard(
                title = "Verification Status",
                icon = Icons.Default.Verified
            ) {
                IconInfoRow(Icons.Default.Verified, "ID Proof: Verified")
                IconInfoRow(Icons.Default.Verified, "Background Check: Clear")
                IconInfoRow(Icons.Default.Verified, "Skills Assessment: Completed")
                IconInfoRow(Icons.Default.Verified, "Training: Basic First Aid")
            }

            Spacer(Modifier.height(16.dp))

            // Action Buttons
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Actions",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ActionButton(
                            text = "View Requests",
                            icon = Icons.Default.List,
                            color = Color(0xFF10B981),
                            onClick = {
                                navController.navigate(Routes.ADMIN_MANAGE_REQUESTS)
                            }
                        )
                        ActionButton(
                            text = "Suspend",
                            icon = Icons.Default.Block,
                            color = Color(0xFFEF4444),
                            onClick = {
                                // Handle suspend action
                            }
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ActionButton(
                            text = "Send Message",
                            icon = Icons.Default.Message,
                            color = Color(0xFF3B82F6),
                            onClick = {
                                // Handle message action
                            }
                        )
                        ActionButton(
                            text = "Assign Task",
                            icon = Icons.Default.Assignment,
                            color = Color(0xFF6B7280),
                            onClick = {
                                // Handle assign task action
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun InfoSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )
            }
            content()
        }
    }
}

@Composable
private fun IconInfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = Color(0xFF6B7280),
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = text,
            fontSize = 14.sp,
            color = Color(0xFF4B5563)
        )
    }
}

@Composable
private fun ActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
