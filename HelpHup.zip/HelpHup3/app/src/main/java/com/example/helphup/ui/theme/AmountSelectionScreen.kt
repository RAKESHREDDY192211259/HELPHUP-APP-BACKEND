package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import kotlinx.coroutines.launch
import android.util.Log

data class AmountOption(
    val amount: Double,
    val label: String,
    val description: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmountSelectionScreen(
    navController: NavController,
    requestType: String,
    requestId: String
) {
    var selectedAmount by remember { mutableStateOf("") }
    var customAmount by remember { mutableStateOf("") }
    var isCustomAmount by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    // Predefined amount options based on request type
    val amountOptions = when (requestType) {
        "ngo" -> listOf(
            AmountOption(500.0, "₹500", "Small contribution"),
            AmountOption(1000.0, "₹1,000", "Popular choice"),
            AmountOption(2500.0, "₹2,500", "Generous support"),
            AmountOption(5000.0, "₹5,000", "Major contribution")
        )
        "volunteer" -> listOf(
            AmountOption(200.0, "₹200", "Basic support"),
            AmountOption(500.0, "₹500", "Standard support"),
            AmountOption(1000.0, "₹1,000", "Enhanced support"),
            AmountOption(2000.0, "₹2,000", "Premium support")
        )
        "donor" -> listOf(
            AmountOption(1000.0, "₹1,000", "Starting contribution"),
            AmountOption(2500.0, "₹2,500", "Good support"),
            AmountOption(5000.0, "₹5,000", "Great support"),
            AmountOption(10000.0, "₹10,000", "Outstanding support")
        )
        else -> listOf(
            AmountOption(500.0, "₹500", "Basic support"),
            AmountOption(1000.0, "₹1,000", "Standard support"),
            AmountOption(2500.0, "₹2,500", "Generous support"),
            AmountOption(5000.0, "₹5,000", "Major support")
        )
    }

    Scaffold(
        containerColor = Color(0xFFF8FAFC),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Select Amount",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Support ${requestType.uppercase()} Request #$requestId",
                            fontSize = 12.sp,
                            color = Color(0xFFE3F2FD)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2)
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Request Information Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = when (requestType) {
                            "ngo" -> Icons.Default.AttachMoney
                            "volunteer" -> Icons.Default.VolunteerActivism
                            "donor" -> Icons.Default.Handshake
                            else -> Icons.Default.Help
                        },
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = Color(0xFF1976D2)
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Text(
                        text = when (requestType) {
                            "ngo" -> "Support NGO Campaign"
                            "volunteer" -> "Help Volunteer Initiative"
                            "donor" -> "Support Donor Campaign"
                            else -> "Support This Cause"
                        },
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1976D2)
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Choose how much you'd like to contribute",
                        fontSize = 14.sp,
                        color = Color.Gray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            // Predefined Amount Options
            Text(
                text = "Quick Select Amount",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937),
                modifier = Modifier.align(Alignment.Start)
            )

            // Amount Selection Grid
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                amountOptions.chunked(2).forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        row.forEach { option ->
                            AmountOptionCard(
                                amount = option,
                                isSelected = selectedAmount == option.amount.toString() && !isCustomAmount,
                                onClick = {
                                    selectedAmount = option.amount.toString()
                                    isCustomAmount = false
                                    customAmount = ""
                                    errorMessage = ""
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Custom Amount Option
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Or Enter Custom Amount",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937),
                modifier = Modifier.align(Alignment.Start)
            )

            OutlinedTextField(
                value = customAmount,
                onValueChange = { 
                    customAmount = it.filter { char -> char.isDigit() }
                    if (customAmount.isNotEmpty()) {
                        isCustomAmount = true
                        selectedAmount = ""
                        errorMessage = ""
                    }
                },
                label = { Text("Custom Amount (₹)") },
                placeholder = { Text("Enter amount") },
                leadingIcon = {
                    Icon(Icons.Default.AttachMoney, contentDescription = null)
                },
                isError = errorMessage.isNotEmpty(),
                supportingText = if (errorMessage.isNotEmpty()) {
                    { Text(errorMessage, color = Color(0xFFEF4444)) }
                } else {
                    { Text("Minimum amount: ₹100", color = Color(0xFF6B7280)) }
                },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = KeyboardType.Number
                ),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Selected Amount Display
            if (selectedAmount.isNotEmpty() || customAmount.isNotEmpty()) {
                val displayAmount = if (isCustomAmount) customAmount else selectedAmount
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Selected Amount:",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1976D2)
                        )
                        Text(
                            text = "₹${String.format("%,.2f", displayAmount.toDoubleOrNull() ?: 0.0)}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1976D2)
                        )
                    }
                }
            }

            // Continue Button
            Button(
                onClick = {
                    val amount = if (isCustomAmount) {
                        customAmount.toDoubleOrNull()
                    } else {
                        selectedAmount.toDoubleOrNull()
                    }

                    when {
                        amount == null || amount <= 0 -> {
                            errorMessage = "Please enter a valid amount"
                        }
                        amount < 100 -> {
                            errorMessage = "Minimum amount is ₹100"
                        }
                        else -> {
                            errorMessage = ""
                            scope.launch {
                                isLoading = true
                                try {
                                    // Navigate to payment selection with amount
                                    val navigationRoute = "${Routes.PAYMENT_SELECTION}/$requestType/$requestId?amount=$amount"
                                    Log.d("AmountSelection", "Attempting to navigate to: $navigationRoute")
                                    Log.d("AmountSelection", "RequestType: $requestType, RequestId: $requestId, Amount: $amount")
                                    navController.navigate(navigationRoute)
                                    Log.d("AmountSelection", "Navigation call completed successfully")
                                } catch (e: Exception) {
                                    Log.e("AmountSelection", "Error navigating to payment selection", e)
                                    errorMessage = "Failed to proceed. Please try again."
                                } finally {
                                    isLoading = false
                                }
                            }
                        }
                    }
                },
                enabled = !isLoading && (selectedAmount.isNotEmpty() || customAmount.isNotEmpty()),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1976D2)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = if (isLoading) "Processing..." else "Continue to Payment",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun AmountOptionCard(
    amount: AmountOption,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF1976D2) else Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) 8.dp else 2.dp
        ),
        border = if (isSelected) {
            androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF1976D2))
        } else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = amount.label,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color(0xFF1976D2)
            )
            
            if (amount.description.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = amount.description,
                    fontSize = 12.sp,
                    color = if (isSelected) Color(0xFFE3F2FD) else Color(0xFF6B7280)
                )
            }
        }
    }
}
