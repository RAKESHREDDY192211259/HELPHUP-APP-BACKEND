package com.example.helphup.ui.theme

import androidx.compose.ui.graphics.Color

/* ---------------- App-Wide Color Palette ---------------- */

/* Primary Colors - Green Theme (Hope & Growth) */
val PrimaryGreen = Color(0xFF10B981)
val PrimaryGreenLight = Color(0xFF34D399)
val PrimaryGreenDark = Color(0xFF059669)
val PrimaryGreenPale = Color(0xFFD1FAE5)

/* Secondary Colors - Blue (Trust & Professional) */
val SecondaryBlue = Color(0xFF3B82F6)
val SecondaryBlueLight = Color(0xFF60A5FA)
val SecondaryBlueDark = Color(0xFF2563EB)
val SecondaryBluePale = Color(0xFFDBEAFE)

/* Accent Colors */
val AccentOrange = Color(0xFFF97316) // Warmth & Energy
val AccentPurple = Color(0xFF8B5CF6) // Creativity & Impact
val AccentPink = Color(0xFFEC4899) // Compassion & Care
val AccentTeal = Color(0xFF14B8A6) // Freshness & Renewal

/* Neutral Colors - Professional & Clean */
val NeutralWhite = Color(0xFFFFFFFF)
val NeutralGray50 = Color(0xFFF9FAFB)
val NeutralGray100 = Color(0xFFF3F4F6)
val NeutralGray200 = Color(0xFFE5E7EB)
val NeutralGray300 = Color(0xFFD1D5DB)
val NeutralGray400 = Color(0xFF9CA3AF)
val NeutralGray500 = Color(0xFF6B7280)
val NeutralGray600 = Color(0xFF4B5563)
val NeutralGray700 = Color(0xFF374151)
val NeutralGray800 = Color(0xFF1F2937)
val NeutralGray900 = Color(0xFF111827)

/* Semantic Colors - Status & Feedback */
val SuccessGreen = Color(0xFF22C55E)
val SuccessGreenLight = Color(0xFF86EFAC)
val SuccessGreenPale = Color(0xFFF0FDF4)

val WarningOrange = Color(0xFFF59E0B)
val WarningOrangeLight = Color(0xFFFCD34D)
val WarningOrangePale = Color(0xFFFFFEF7)

val ErrorRed = Color(0xFFEF4444)
val ErrorRedLight = Color(0xFFF87171)
val ErrorRedPale = Color(0xFFFEF2F2)

val InfoBlue = Color(0xFF0EA5E9)
val InfoBlueLight = Color(0xFF38BDF8)
val InfoBluePale = Color(0xFFF0F9FF)

/* ---------------- Screen-Specific Color Schemes ---------------- */

/* NGO Dashboard - Professional & Trustworthy */
object NgoColors {
    val Primary = PrimaryGreen
    val Secondary = SecondaryBlue
    val Background = NeutralGray50
    val Surface = NeutralWhite
    val Accent = AccentPurple
    val Success = SuccessGreen
    val Warning = WarningOrange
    val Error = ErrorRed
}

/* Volunteer Dashboard - Energetic & Warm */
object VolunteerColors {
    val Primary = AccentOrange
    val Secondary = PrimaryGreen
    val Background = Color(0xFFFFFAF5) // Warm off-white
    val Surface = NeutralWhite
    val Accent = AccentTeal
    val Success = SuccessGreen
    val Warning = WarningOrange
    val Error = ErrorRed
}

/* Donor Dashboard - Compassionate & Hopeful */
object DonorColors {
    val Primary = PrimaryGreen
    val Secondary = AccentPink
    val Background = Color(0xFFF0FDF4) // Very pale green
    val Surface = NeutralWhite
    val Accent = AccentPurple
    val Success = SuccessGreen
    val Warning = WarningOrange
    val Error = ErrorRed
}

/* Authentication Screens - Clean & Modern */
object AuthColors {
    val Primary = PrimaryGreen
    val Secondary = SecondaryBlue
    val Background = Color(0xFFFAFAFA)
    val Surface = NeutralWhite
    val TextPrimary = NeutralGray800
    val TextSecondary = NeutralGray500
    val Border = NeutralGray200
    val InputBackground = NeutralGray50
}

/* ---------------- Component Color Extensions ---------------- */

/* Button Colors */
object ButtonColors {
    val Primary = PrimaryGreen
    val PrimaryHover = PrimaryGreenDark
    val Secondary = SecondaryBlue
    val SecondaryHover = SecondaryBlueDark
    val Success = SuccessGreen
    val SuccessHover = Color(0xFF16A34A)
    val Warning = WarningOrange
    val WarningHover = Color(0xFFD97706)
    val Error = ErrorRed
    val ErrorHover = Color(0xFFDC2626)
    val Outline = NeutralGray300
    val OutlineHover = NeutralGray400
    val Ghost = Color.Transparent
    val GhostHover = NeutralGray100
}

/* Card Colors */
object CardColors {
    val Default = NeutralWhite
    val Elevated = NeutralWhite
    val Filled = NeutralGray50
    val Outlined = NeutralWhite
    val PrimaryPale = PrimaryGreenPale
    val SecondaryPale = SecondaryBluePale
    val SuccessPale = SuccessGreenPale
    val WarningPale = WarningOrangePale
    val ErrorPale = ErrorRedPale
    val InfoPale = InfoBluePale
}

/* Text Colors */
object TextColors {
    val Primary = NeutralGray900
    val Secondary = NeutralGray600
    val Tertiary = NeutralGray500
    val Disabled = NeutralGray400
    val Inverse = NeutralWhite
    val OnPrimary = NeutralWhite
    val OnSecondary = NeutralWhite
    val OnSuccess = NeutralWhite
    val OnWarning = NeutralWhite
    val OnError = NeutralWhite
    val OnInfo = NeutralWhite
}

/* Icon Colors */
object IconColors {
    val Primary = NeutralGray600
    val Secondary = NeutralGray400
    val Tertiary = NeutralGray300
    val Disabled = NeutralGray200
    val Inverse = NeutralWhite
    val OnPrimary = NeutralWhite
    val OnSecondary = NeutralWhite
    val OnSuccess = NeutralWhite
    val OnWarning = NeutralWhite
    val OnError = NeutralWhite
    val OnInfo = NeutralWhite
    val Accent = AccentOrange
    val Success = SuccessGreen
    val Warning = WarningOrange
    val Error = ErrorRed
    val Info = InfoBlue
}

/* ---------------- Gradient Colors ---------------- */

object GradientColors {
    val PrimaryGradient = listOf(
        PrimaryGreen,
        PrimaryGreenLight
    )
    
    val SecondaryGradient = listOf(
        SecondaryBlue,
        SecondaryBlueLight
    )
    
    val AccentGradient = listOf(
        AccentOrange,
        AccentPink
    )
    
    val SuccessGradient = listOf(
        SuccessGreen,
        SuccessGreenLight
    )
    
    val WarmGradient = listOf(
        Color(0xFFFF6B6B),
        Color(0xFFFFA500)
    )
    
    val CoolGradient = listOf(
        SecondaryBlue,
        AccentTeal
    )
    
    val NatureGradient = listOf(
        PrimaryGreen,
        AccentTeal
    )
    
    val SunsetGradient = listOf(
        AccentOrange,
        AccentPink
    )
}

/* ---------------- Shadow Colors ---------------- */

object ShadowColors {
    val Light = Color(0x00000000)
    val Medium = Color(0x1A000000)
    val Dark = Color(0x33000000)
    val Colored = Color(0x3310B981) // Primary green with transparency
}

/* ---------------- Theme Extensions ---------------- */

/* Material 3 Color Schemes */
val LightColorScheme = androidx.compose.material3.lightColorScheme(
    primary = PrimaryGreen,
    onPrimary = NeutralWhite,
    primaryContainer = PrimaryGreenPale,
    onPrimaryContainer = PrimaryGreenDark,
    
    secondary = SecondaryBlue,
    onSecondary = NeutralWhite,
    secondaryContainer = SecondaryBluePale,
    onSecondaryContainer = SecondaryBlueDark,
    
    tertiary = AccentOrange,
    onTertiary = NeutralWhite,
    tertiaryContainer = Color(0xFFFFEDD5),
    onTertiaryContainer = Color(0xFF7C2D12),
    
    background = NeutralGray50,
    onBackground = NeutralGray900,
    
    surface = NeutralWhite,
    onSurface = NeutralGray800,
    surfaceVariant = NeutralGray100,
    onSurfaceVariant = NeutralGray600,
    
    error = ErrorRed,
    onError = NeutralWhite,
    errorContainer = ErrorRedPale,
    onErrorContainer = Color(0xFF991B1B),
    
    outline = NeutralGray300,
    outlineVariant = NeutralGray200,
    
    scrim = Color(0x00000000),
    
    surfaceTint = PrimaryGreen
)

val DarkColorScheme = androidx.compose.material3.darkColorScheme(
    primary = PrimaryGreenLight,
    onPrimary = NeutralGray900,
    primaryContainer = PrimaryGreenDark,
    onPrimaryContainer = PrimaryGreenPale,
    
    secondary = SecondaryBlueLight,
    onSecondary = NeutralGray900,
    secondaryContainer = SecondaryBlueDark,
    onSecondaryContainer = SecondaryBluePale,
    
    tertiary = AccentOrange,
    onTertiary = NeutralWhite,
    tertiaryContainer = Color(0xFF7C2D12),
    onTertiaryContainer = Color(0xFFFFEDD5),
    
    background = NeutralGray900,
    onBackground = NeutralGray100,
    
    surface = NeutralGray800,
    onSurface = NeutralGray200,
    surfaceVariant = NeutralGray700,
    onSurfaceVariant = NeutralGray300,
    
    error = ErrorRedLight,
    onError = NeutralGray900,
    errorContainer = Color(0xFF991B1B),
    onErrorContainer = ErrorRedPale,
    
    outline = NeutralGray600,
    outlineVariant = NeutralGray500,
    
    scrim = Color(0x00000000),
    
    surfaceTint = PrimaryGreenLight
)
