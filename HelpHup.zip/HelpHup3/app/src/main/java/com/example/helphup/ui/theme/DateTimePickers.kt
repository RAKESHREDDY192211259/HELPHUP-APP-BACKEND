package com.example.helphup.ui.theme

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

private const val TAG = "DateTimePickers"

/**
 * Date Picker Component
 * Opens a calendar dialog to select a date
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerField(
    label: String,
    selectedDate: String,
    onDateSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    errorMessage: String = "",
    allowPastDates: Boolean = false // Default: no past dates
) {
    var showDatePicker by remember { mutableStateOf(false) }
    val dateFormatter = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val interactionSource = remember { MutableInteractionSource() }
    
    // Calculate initial date in milliseconds based on selectedDate
    val initialDateMillis = remember(selectedDate) {
        if (selectedDate.isNotEmpty()) {
            try {
                dateFormatter.parse(selectedDate)?.time
            } catch (e: Exception) {
                System.currentTimeMillis()
            }
        } else {
            System.currentTimeMillis()
        }
    }
    
    // Calculate minimum date - no past dates allowed unless explicitly allowed
    val minDateMillis = remember {
        if (allowPastDates) {
            null
        } else {
            // Set to start of today (midnight) to allow today's date
            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, 0)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)
            calendar.timeInMillis
        }
    }
    
    // Create SelectableDates object when past dates are not allowed
    val selectableDates: SelectableDates? = remember(allowPastDates, minDateMillis) {
        if (allowPastDates) {
            null
        } else {
            val minDate = minDateMillis
            object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean {
                    // Only allow today and future dates
                    return minDate != null && utcTimeMillis >= minDate
                }
            }
        }
    }
    
    // Create state - call rememberDatePickerState at composable level
    val datePickerState = if (selectableDates != null) {
        rememberDatePickerState(
            initialSelectedDateMillis = initialDateMillis,
            selectableDates = selectableDates
        )
    } else {
        rememberDatePickerState(
            initialSelectedDateMillis = initialDateMillis
        )
    }
    
    // Single clickable Surface that looks like a TextField
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .border(
                width = if (errorMessage.isNotEmpty()) 2.dp else 1.dp,
                color = if (errorMessage.isNotEmpty()) 
                    MaterialTheme.colorScheme.error 
                else 
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                shape = RoundedCornerShape(4.dp)
            )
            .clip(RoundedCornerShape(4.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                Log.d(TAG, "Date field clicked - opening picker")
                showDatePicker = true
            },
        shape = RoundedCornerShape(4.dp),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
            ) {
                // Label
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
                
                // Value
                Text(
                    text = selectedDate.ifEmpty { "Select date" },
                    style = TextStyle(
                        fontSize = 16.sp,
                        color = if (selectedDate.isEmpty()) 
                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        else 
                            MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(top = 4.dp)
                )
                
                // Error message
                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            
            Icon(
                Icons.Outlined.CalendarToday,
                contentDescription = "Select date",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
        }
    }
    
    // Show dialog when state changes
    if (showDatePicker) {
        Log.d(TAG, "Showing date picker dialog")
        DatePickerDialog(
            onDismissRequest = { 
                Log.d(TAG, "Date picker dismissed")
                showDatePicker = false 
            },
            onDateSelected = { selectedDateMillis ->
                Log.d(TAG, "Date selected: $selectedDateMillis")
                selectedDateMillis?.let {
                    val formattedDate = dateFormatter.format(Date(it))
                    Log.d(TAG, "Formatted date: $formattedDate")
                    onDateSelected(formattedDate)
                }
                showDatePicker = false
            },
            datePickerState = datePickerState
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerDialog(
    onDismissRequest: () -> Unit,
    onDateSelected: (Long?) -> Unit,
    datePickerState: DatePickerState
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = { Text("Select Date", fontSize = 20.sp, fontWeight = FontWeight.Bold) },
        text = {
            DatePicker(state = datePickerState)
        },
        confirmButton = {
            TextButton(
                onClick = { 
                    Log.d(TAG, "OK button clicked in date picker")
                    onDateSelected(datePickerState.selectedDateMillis) 
                }
            ) {
                Text("OK", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Cancel")
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp)
    )
}

/**
 * Time Picker Component
 * Opens a time picker dialog with hour/minute scrolling and AM/PM selection
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerField(
    label: String,
    selectedTime: String,
    onTimeSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    errorMessage: String = "",
    selectedDate: String = "", // Date to check if time should be future
    allowPastTime: Boolean = false // Default: no past times if date is today
) {
    var showTimePicker by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    
    // Parse selected time (expects HH:mm format from database) and convert to hour/minute
    val initialTime = remember(selectedTime) {
        if (selectedTime.isNotEmpty()) {
            try {
                val parts = selectedTime.split(":")
                if (parts.size == 2) {
                    val hour = parts[0].toIntOrNull() ?: Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                    val minute = parts[1].toIntOrNull() ?: Calendar.getInstance().get(Calendar.MINUTE)
                    Pair(hour, minute)
                } else {
                    val now = Calendar.getInstance()
                    Pair(now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE))
                }
            } catch (e: Exception) {
                val now = Calendar.getInstance()
                Pair(now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE))
            }
        } else {
            val now = Calendar.getInstance()
            Pair(now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE))
        }
    }
    
    // Create state directly - composable functions must be called in composable context
    val timePickerState = rememberTimePickerState(
        initialHour = initialTime.first,
        initialMinute = initialTime.second,
        is24Hour = false // 12-hour format with AM/PM
    )
    
    // Format time for display (convert HH:mm to 12-hour format with AM/PM)
    val displayTime = remember(selectedTime) {
        if (selectedTime.isNotEmpty()) {
            try {
                val parts = selectedTime.split(":")
                if (parts.size == 2) {
                    val hour = parts[0].toIntOrNull() ?: 0
                    val minute = parts[1].toIntOrNull() ?: 0
                    val amPm = if (hour < 12) "AM" else "PM"
                    val displayHour = when {
                        hour == 0 -> 12
                        hour > 12 -> hour - 12
                        else -> hour
                    }
                    String.format("%d:%02d %s", displayHour, minute, amPm)
                } else {
                    selectedTime
                }
            } catch (e: Exception) {
                selectedTime
            }
        } else {
            "Select time"
        }
    }
    
    // Single clickable Surface that looks like a TextField
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .border(
                width = if (errorMessage.isNotEmpty()) 2.dp else 1.dp,
                color = if (errorMessage.isNotEmpty()) 
                    MaterialTheme.colorScheme.error 
                else 
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                shape = RoundedCornerShape(4.dp)
            )
            .clip(RoundedCornerShape(4.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                Log.d(TAG, "Time field clicked - opening picker")
                showTimePicker = true
            },
        shape = RoundedCornerShape(4.dp),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
            ) {
                // Label
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
                
                // Value
                Text(
                    text = displayTime,
                    style = TextStyle(
                        fontSize = 16.sp,
                        color = if (selectedTime.isEmpty()) 
                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        else 
                            MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(top = 4.dp)
                )
                
                // Error message
                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            
            Icon(
                Icons.Outlined.Schedule,
                contentDescription = "Select time",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
        }
    }
    
    // Show dialog when state changes
    if (showTimePicker) {
        Log.d(TAG, "Showing time picker dialog")
        TimePickerDialog(
            onDismissRequest = { 
                Log.d(TAG, "Time picker dismissed")
                showTimePicker = false 
            },
            onTimeSelected = { hour, minute ->
                Log.d(TAG, "Time selected: $hour:$minute")
                
                // Validate time if date is today and past times not allowed
                var isValidTime = true
                if (!allowPastTime && selectedDate.isNotEmpty()) {
                    val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                    val today = Calendar.getInstance()
                    val selectedDateObj = try {
                        dateFormatter.parse(selectedDate)
                    } catch (e: Exception) {
                        null
                    }
                    
                    if (selectedDateObj != null) {
                        val selectedCal = Calendar.getInstance()
                        selectedCal.time = selectedDateObj
                        
                        // Check if selected date is today
                        val isToday = selectedCal.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                                     selectedCal.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)
                        
                        if (isToday) {
                            // Check if time is in the past
                            val selectedTimeMinutes = hour * 60 + minute
                            val currentTimeMinutes = today.get(Calendar.HOUR_OF_DAY) * 60 + today.get(Calendar.MINUTE)
                            
                            if (selectedTimeMinutes <= currentTimeMinutes) {
                                // Time is in the past, don't allow
                                Log.d(TAG, "Time is in the past, not allowing")
                                isValidTime = false
                            }
                        }
                    }
                }
                
                if (isValidTime) {
                    // When is24Hour = false, hour is still 0-23 in Material3
                    // Format as HH:mm for database (24-hour format)
                    val formattedTime = String.format("%02d:%02d", hour, minute)
                    Log.d(TAG, "Formatted time: $formattedTime")
                    onTimeSelected(formattedTime)
                } else {
                    // Show error - time is in the past
                    // You could show a snackbar or toast here
                    Log.d(TAG, "Cannot select past time")
                }
                showTimePicker = false
            },
            timePickerState = timePickerState,
            selectedDate = selectedDate,
            allowPastTime = allowPastTime
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerDialog(
    onDismissRequest: () -> Unit,
    onTimeSelected: (Int, Int) -> Unit,
    timePickerState: TimePickerState,
    selectedDate: String = "",
    allowPastTime: Boolean = false
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = { Text("Select Time", fontSize = 20.sp, fontWeight = FontWeight.Bold) },
        text = {
            TimePicker(state = timePickerState)
        },
        confirmButton = {
            TextButton(
                onClick = {
                    Log.d(TAG, "OK button clicked in time picker")
                    // timePickerState.hour is 0-23 even when is24Hour = false
                    // The AM/PM is just for display in Material3
                    onTimeSelected(timePickerState.hour, timePickerState.minute)
                }
            ) {
                Text("OK", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Cancel")
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp)
    )
}
