package com.example.helphup.ui.theme

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Pets
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.WaterDrop
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.data.HelpRequestDataStore
import com.example.helphup.ui.theme.DonorBottomBar
import com.example.helphup.ui.navigation.Routes
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

/* ---------------- API MODELS ---------------- */

data class DonorCampaignItem(
    @SerializedName("campaign_id") val campaignId: Int,
    @SerializedName("donor_id") val donorId: Int,
    @SerializedName("donor_name") val donorName: String,
    @SerializedName("campaign_title") val campaignTitle: String,
    @SerializedName("fundraising_goal") val fundraisingGoal: String,
    @SerializedName("category") val category: String,
    @SerializedName("cover_image_url") val coverImageUrl: String?,
    @SerializedName("video_url") val videoUrl: String?,
    @SerializedName("duration") val duration: String,
    @SerializedName("end_date") val endDate: String,
    @SerializedName("beneficiary_name") val beneficiaryName: String,
    @SerializedName("relationship") val relationship: String,
    @SerializedName("contact_email") val contactEmail: String,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("request_type") val requestType: String
)

data class CauseResponse(
    val status: Boolean,
    val message: String,
    val data: List<Map<String, Any>>?
)

/* ---------------- API SERVICE ---------------- */

interface CauseApiService {
    @GET("get_all_ngo_requests.php")
    suspend fun getNgoRequests(): CauseResponse
    
    @GET("get_all_volunteer_requests.php")
    suspend fun getVolunteerRequests(): CauseResponse
    
    @GET("get_all_donor_campaigns.php")
    suspend fun getDonorCampaigns(): CauseResponse
}

object CauseRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"
    
    val api: CauseApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CauseApiService::class.java)
    }
}

/* ---------------- DATA MODEL ---------------- */

data class CauseItem(
    val id: String,
    val title: String,
    val description: String,
    val amount: String,
    val requestType: String,
    val category: String,
    val location: String? = null,
    val ngoName: String? = null,
    val volunteerName: String? = null,
    val donorName: String? = null
)

/* ---------------- DATA FETCHING FUNCTION ---------------- */

fun fetchCausesData(
    scope: CoroutineScope,
    onLoading: (Boolean) -> Unit,
    onError: (String) -> Unit,
    onSuccess: (List<CauseItem>) -> Unit
) {
    scope.launch {
        onLoading(true)
        onError("")
        try {
            // Donors should NOT see Donor campaigns - only NGO and Volunteer requests
            val ngoResponse = CauseRetrofitInstance.api.getNgoRequests()
            val volunteerResponse = CauseRetrofitInstance.api.getVolunteerRequests()
            // Skip fetching Donor campaigns - Donors should not see their own type
            
            val allCauses = mutableListOf<CauseItem>()
            
            // Process NGO requests
            if (ngoResponse.status && ngoResponse.data != null) {
                ngoResponse.data.forEach { item ->
                    try {
                        val ngoRequest = item as? Map<String, Any> ?: return@forEach
                        val urgencyLevel = ngoRequest["urgency_level"]?.toString() ?: ""
                        val requiredAmount = ngoRequest["required_amount"]?.toString() ?: ""
                        val dateNeeded = ngoRequest["date_needed"]?.toString() ?: ""
                        val description = ngoRequest["description"]?.toString() ?: "NGO help request"
                        val fullDescription = buildString {
                            append(description)
                            if (urgencyLevel.isNotEmpty()) {
                                append(" | Urgency: $urgencyLevel")
                            }
                            if (dateNeeded.isNotEmpty()) {
                                append(" | Needed by: $dateNeeded")
                            }
                        }
                        allCauses.add(CauseItem(
                            id = "ngo_${ngoRequest["request_id"]}",
                            title = ngoRequest["request_title"]?.toString() ?: "",
                            description = fullDescription,
                            amount = if (requiredAmount.isNotEmpty()) "₹$requiredAmount" else "Amount not specified",
                            requestType = "NGO",
                            category = ngoRequest["category"]?.toString() ?: "",
                            ngoName = ngoRequest["org_name"]?.toString()
                        ))
                    } catch (e: Exception) {
                        Log.e("DonorBrowseCause", "Error processing NGO request: ${e.message}", e)
                    }
                }
            } else {
                Log.e("DonorBrowseCause", "NGO response failed: status=${ngoResponse.status}, data=${ngoResponse.data}")
            }
            
            // Process Volunteer requests
            if (volunteerResponse.status && volunteerResponse.data != null) {
                volunteerResponse.data.forEach { volRequest ->
                    allCauses.add(CauseItem(
                        id = "vol_${volRequest["request_id"]}",
                        title = volRequest["request_title"]?.toString() ?: "",
                        description = volRequest["description"]?.toString() ?: "Volunteer help request",
                        amount = "Volunteers Needed: ${volRequest["volunteers_needed"]}",
                        requestType = "Volunteer",
                        category = volRequest["category"]?.toString() ?: "",
                        volunteerName = volRequest["volunteer_name"]?.toString()
                    ))
                }
            }
            
            // Donors should NOT see Donor campaigns - skip processing
            
            onSuccess(allCauses)
        } catch (e: Exception) {
            Log.e("DonorBrowseCause", "Exception in fetch: ${e.message}", e)
            val errorMsg = e.message ?: "Unknown error"
            onError(when {
                errorMsg.contains("404") || errorMsg.contains("Not Found") -> "API endpoint not found. Please ensure PHP files are in C:\\xampp\\htdocs\\helphup\\api\\ directory"
                errorMsg.contains("HTTP") && errorMsg.contains("404") -> "Server error 404: API files not found. Check if files exist in web server directory."
                errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                errorMsg.contains("Connection refused") -> "Connection error: Connection refused\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                errorMsg.contains("timeout") -> "Connection error: Connection timeout\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                else -> "Failed to load causes: $errorMsg"
            })
            
            // ✅ Add sample data as fallback when API fails
            Log.d("DonorBrowseCause", "API failed, loading sample data")
            onSuccess(getSampleCauses())
        } finally {
            onLoading(false)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorBrowseCauseScreen(navController: NavController) {

    // Observe data store for help request updates
    val refreshTrigger by remember { HelpRequestDataStore.refreshTrigger }
    val newHelpRequestAdded by remember { HelpRequestDataStore.newHelpRequestAdded }

    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var causes by remember { mutableStateOf<List<CauseItem>>(emptyList()) }

    val scope = rememberCoroutineScope()
    
    // Reset update flag when component recomposes
    LaunchedEffect(newHelpRequestAdded) {
        if (newHelpRequestAdded) {
            Log.d("DonorBrowseCause", "Help request update detected, triggering refresh")
            HelpRequestDataStore.resetUpdateFlag()
            // Trigger data refresh
            fetchCausesData(scope, { isLoading = it }, { errorMessage = it }, { causes = it })
        }
    }

    // Fetch causes on composable initialization and when screen comes into focus
    LaunchedEffect(Unit) {
        fetchCausesData(scope, { isLoading = it }, { errorMessage = it }, { causes = it })
    }

    // Filter causes based on search
    val filteredCauses = causes.filter { cause ->
        searchQuery.isBlank() || 
            cause.title.contains(searchQuery, ignoreCase = true) ||
            cause.description.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Browse Causes", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Find campaigns that align with your values",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Outlined.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        bottomBar = { DonorBottomBar(navController, Routes.DONOR_BROWSE_CAUSES) }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(16.dp)
        ) {

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search causes or organizations") },
                leadingIcon = {
                    Icon(Icons.Outlined.Search, contentDescription = null)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryChip("Hunger Relief")
                CategoryChip("Education")
                CategoryChip("Animal Welfare")
            }

            Spacer(Modifier.height(16.dp))

            Text("Trending Causes", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)

            Spacer(Modifier.height(12.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color.Red,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (filteredCauses.isEmpty()) {
                        item {
                            Text(
                                text = "No causes found",
                                modifier = Modifier.padding(16.dp),
                                color = Color.Gray
                            )
                        }
                    } else {
                        items(filteredCauses) { cause ->
                            CauseCard(
                                icon = when (cause.category) {
                                    "Medical", "Healthcare" -> Icons.Outlined.Favorite
                                    "Education" -> Icons.Outlined.School
                                    "Animal Welfare" -> Icons.Outlined.Pets
                                    else -> Icons.Outlined.WaterDrop
                                },
                                priority = when (cause.requestType) {
                                    "NGO" -> "High Priority"
                                    "Volunteer" -> "Medium Priority"
                                    "Donor Campaign" -> "Medium Priority"
                                    else -> "Low Priority"
                                },
                                priorityColor = when (cause.requestType) {
                                    "NGO" -> Color(0xFFE53935)
                                    "Volunteer" -> Color(0xFF9C27B0)
                                    "Donor Campaign" -> Color(0xFF2E7D32)
                                    else -> Color(0xFF757575)
                                },
                                title = cause.title,
                                description = cause.description,
                                location = cause.location ?: "Various Locations",
                                time = when (cause.requestType) {
                                    "NGO" -> "Urgent"
                                    "Volunteer" -> "Weekend"
                                    "Donor Campaign" -> "Ongoing"
                                    else -> "Flexible"
                                },
                                amount = cause.amount,
                                requestType = cause.requestType,
                                onClick = {
                                    // Navigate to Donor browse cause details
                                    val requestId = cause.id.split("_").getOrNull(1) ?: "0"
                                    if (requestId.isNotEmpty() && requestId != "0") {
                                        Log.d("DonorBrowseCause", "Viewing Donor browse cause details for ${cause.requestType} request #$requestId")
                                        try {
                                            navController.navigate("${Routes.DONOR_BROWSE_CAUSE_DETAILS}/${cause.requestType}/$requestId")
                                        } catch (e: Exception) {
                                            Log.e("DonorBrowseCause", "Error navigating to Donor browse cause details", e)
                                        }
                                    } else {
                                        Log.w("DonorBrowseCause", "Invalid request ID: $requestId")
                                    }
                                },
                                onDonateClick = {
                                    // Navigate to Donor community support first, then payment flow
                                    val requestId = cause.id.split("_").getOrNull(1) ?: "0"
                                    if (requestId.isNotEmpty() && requestId != "0") {
                                        Log.d("DonorBrowseCause", "Navigating to Donor community support for ${cause.requestType} request #$requestId")
                                        try {
                                            navController.navigate("${Routes.DONOR_COMMUNITY_SUPPORT}/${cause.requestType}/$requestId")
                                        } catch (e: Exception) {
                                            Log.e("DonorBrowseCause", "Error navigating to Donor community support", e)
                                        }
                                    } else {
                                        Log.w("DonorBrowseCause", "Invalid request ID: $requestId")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/* ---------- Components ---------- */

@Composable
private fun CategoryChip(text: String) {
    Surface(
        color = Color(0xFFE8F5E9),
        shape = RoundedCornerShape(20.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            fontSize = 13.sp,
            color = Color(0xFF16A34A)
        )
    }
}

@Composable
private fun CauseCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    priority: String,
    priorityColor: Color,
    title: String,
    description: String,
    location: String,
    time: String,
    amount: String,
    requestType: String,
    onClick: () -> Unit = {},
    onDonateClick: () -> Unit = {}
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {

            // Request Type Badge
            Surface(
                color = when (requestType) {
                    "NGO" -> Color(0xFFE3F2FD)
                    "Volunteer" -> Color(0xFFF3E5F5)
                    "Donor Campaign" -> Color(0xFFE8F5E9)
                    else -> Color(0xFFF3E5F5)
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Text(
                    text = requestType,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 12.sp,
                    color = when (requestType) {
                        "NGO" -> Color(0xFF1976D2)
                        "Volunteer" -> Color(0xFF7B1FA2)
                        "Donor Campaign" -> Color(0xFF16A34A)
                        else -> Color(0xFF7B1FA2)
                    },
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = priority,
                color = priorityColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(6.dp))

            Text(description, fontSize = 13.sp, color = Color.DarkGray)

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onDonateClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFE8F5E9),
                    contentColor = Color(0xFF16A34A)
                )
            ) {
                Text("Donate Now →", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.LocationOn,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "$location • $time",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

/* ---------- Sample Data ---------- */

private fun getSampleCauses(): List<CauseItem> {
    return listOf(
        CauseItem(
            id = "ngo_1",
            title = "Emergency Medical Fund for Children",
            description = "Help provide critical medical care for underprivileged children needing urgent surgeries and treatments. Your support can save young lives.",
            amount = "₹50,000",
            requestType = "NGO",
            category = "Medical",
            location = "City General Hospital",
            ngoName = "Children's Hope Foundation"
        ),
        CauseItem(
            id = "ngo_2", 
            title = "Clean Water Initiative",
            description = "Provide clean drinking water to rural communities. Help install water purification systems in villages lacking access to safe water.",
            amount = "₹25,000",
            requestType = "NGO", 
            category = "Water",
            location = "Rural Village Areas",
            ngoName = "Water for Life NGO"
        ),
        CauseItem(
            id = "vol_1",
            title = "Teaching Support Needed",
            description = "Volunteers needed to teach basic education to children in underserved communities. Help shape young minds and build a better future.",
            amount = "Volunteers Needed: 15",
            requestType = "Volunteer",
            category = "Education", 
            location = "Community Learning Center",
            volunteerName = "Education First Initiative"
        ),
        CauseItem(
            id = "vol_2",
            title = "Community Garden Project",
            description = "Join us in creating sustainable community gardens to provide fresh vegetables for local families. No experience needed!",
            amount = "Volunteers Needed: 8",
            requestType = "Volunteer",
            category = "Environment",
            location = "City Park Area",
            volunteerName = "Green Earth Volunteers"
        ),
        CauseItem(
            id = "ngo_3",
            title = "Animal Shelter Rescue",
            description = "Support our animal shelter in rescuing and caring for abandoned pets. Help provide food, medical care, and shelter.",
            amount = "₹15,000",
            requestType = "NGO",
            category = "Animal Welfare",
            location = "Downtown Animal Center",
            ngoName = "Paws & Love Shelter"
        ),
        CauseItem(
            id = "ngo_4",
            title = "Senior Care Support",
            description = "Help provide essential care and companionship for elderly residents in our community center. Your donation supports meals and healthcare.",
            amount = "₹30,000",
            requestType = "NGO",
            category = "Elderly Care",
            location = "Golden Years Community Center",
            ngoName = "Golden Years Foundation"
        )
    )
}
