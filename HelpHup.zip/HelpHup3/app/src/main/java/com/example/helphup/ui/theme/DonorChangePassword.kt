package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.theme.ValidationUtils
import com.example.helphup.utils.UserSessionManager
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.util.Log
import com.example.helphup.ui.theme.DonorProfileApiClient
import com.example.helphup.ui.theme.UpdateDonorPasswordRequest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorChangePassword(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val scope = rememberCoroutineScope()
    
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var currentPasswordVisible by remember { mutableStateOf(false) }
    var newPasswordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    var newPasswordError by remember { mutableStateOf("") }
    var confirmPasswordError by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Change Password", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Lock Icon
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(Color(0xFFF3F4F6), RoundedCornerShape(40.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Lock",
                    modifier = Modifier.size(40.dp),
                    tint = Color(0xFF6B7280)
                )
            }

            Text(
                text = "Change Your Password",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Enter your current password and choose a new one",
                fontSize = 14.sp,
                color = Color.Gray
            )

            // Current Password
            OutlinedTextField(
                value = currentPassword,
                onValueChange = { currentPassword = it },
                label = { Text("Current Password") },
                visualTransformation = if (currentPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { currentPasswordVisible = !currentPasswordVisible }) {
                        Icon(
                            if (currentPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // New Password
            OutlinedTextField(
                value = newPassword,
                onValueChange = { 
                    newPassword = it
                    newPasswordError = ""
                },
                label = { Text("New Password") },
                visualTransformation = if (newPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                isError = newPasswordError.isNotEmpty(),
                supportingText = if (newPasswordError.isNotEmpty()) {
                    { Text(newPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                trailingIcon = {
                    IconButton(onClick = { newPasswordVisible = !newPasswordVisible }) {
                        Icon(
                            if (newPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Confirm Password
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { 
                    confirmPassword = it
                    confirmPasswordError = ""
                },
                label = { Text("Confirm New Password") },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                isError = confirmPasswordError.isNotEmpty(),
                supportingText = if (confirmPasswordError.isNotEmpty()) {
                    { Text(confirmPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                trailingIcon = {
                    IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                        Icon(
                            if (confirmPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Error Message
            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color.Red,
                    fontSize = 14.sp
                )
            }
            
            // Success Message
            if (successMessage.isNotEmpty()) {
                Text(
                    text = successMessage,
                    color = Color(0xFF22C55E),
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Update Password Button
            Button(
                enabled = !isLoading,
                onClick = {
                    // Clear previous errors
                    newPasswordError = ""
                    confirmPasswordError = ""
                    errorMessage = ""
                    
                    // Check if current password is filled
                    if (currentPassword.isEmpty()) {
                        errorMessage = "Please enter your current password"
                    }
                    
                    // Validate new password
                    val newPasswordValidation = ValidationUtils.validatePassword(newPassword)
                    if (!newPasswordValidation.isValid) {
                        newPasswordError = newPasswordValidation.errorMessage
                    }
                    
                    // Validate confirm password
                    val confirmPasswordValidation = ValidationUtils.validateConfirmPassword(newPassword, confirmPassword)
                    if (!confirmPasswordValidation.isValid) {
                        confirmPasswordError = confirmPasswordValidation.errorMessage
                    }
                    
                    // Check if new password is different from current password
                    if (currentPassword.isNotEmpty() && newPassword == currentPassword) {
                        errorMessage = "New password must be different from current password"
                    }
                    
                    // If all validations pass, update password
                    if (currentPassword.isNotEmpty() &&
                        newPasswordValidation.isValid &&
                        confirmPasswordValidation.isValid &&
                        newPassword != currentPassword) {
                        errorMessage = ""
                        successMessage = ""
                        
                        scope.launch {
                            isLoading = true
                            try {
                                val donorId = sessionManager.getDonorId()
                                if (donorId <= 0) {
                                    errorMessage = "Invalid session. Please login again."
                                    return@launch
                                }
                                
                                val response = DonorProfileApiClient.api.updatePassword(
                                    UpdateDonorPasswordRequest(
                                        donorId = donorId,
                                        currentPassword = currentPassword,
                                        newPassword = newPassword
                                    )
                                )
                                
                                if (response.status) {
                                    successMessage = "Password updated successfully!"
                                    // Navigate back after delay
                                    kotlinx.coroutines.delay(2000)
                                    navController.popBackStack()
                                } else {
                                    errorMessage = response.message
                                }
                            } catch (e: Exception) {
                                Log.e("DonorChangePassword", "Error changing password: ${e.message}", e)
                                errorMessage = "Failed to update password. Please try again."
                            } finally {
                                isLoading = false
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3B82F6)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = if (isLoading) "Updating..." else "Update Password",
                    fontSize = 16.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Cancel Button
            OutlinedButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Cancel", fontSize = 16.sp, color = Color(0xFF3B82F6))
            }
        }
    }
}
