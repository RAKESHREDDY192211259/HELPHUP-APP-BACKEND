package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes

// ==================== Constants ====================

private object DonorCommunitySupportConstants {
    // Colors
    val BackgroundColor = Color(0xFFF0FDF4)
    val CardBackgroundColor = Color.White
    val PrimaryColor = Color(0xFF22C55E)
    val IconBackgroundColor = Color(0xFFDFF6EA)
    val ImpactBackgroundColor = Color(0xFFDFF6EA)
    val TextPrimary = Color(0xFF1F2937)
    val TextSecondary = Color(0xFF6B7280)
    val BorderColor = Color(0xFFE5E7EB)
    val CustomRadioColor = Color(0xFFEC4899)
    
    // Spacing
    val PaddingSmall = 8.dp
    val PaddingMedium = 16.dp
    val PaddingLarge = 20.dp
    val PaddingExtraLarge = 24.dp
    
    // Sizes
    val IconSize = 64.dp
    val IconInnerSize = 32.dp
    val RadioButtonSize = 20.dp
    val RadioButtonInnerSize = 10.dp
    val ButtonHeight = 48.dp
    val PrimaryButtonHeight = 52.dp
    
    // Amounts (in INR)
    val PredefinedAmounts = listOf(500, 1000, 2000, 5000, 10000) // INR amounts
    val DefaultAmount = 1000
    val MealsPerRupee = 5 // ₹5 per family meal (in INR)
    
    // Text Sizes
    val TitleSize = 24.sp
    val SubtitleSize = 14.sp
    val SectionTitleSize = 18.sp
    val BodySize = 14.sp
    val ButtonTextSize = 16.sp
    val AmountTextSize = 15.sp
}

// ==================== Main Screen ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorCommunitySupport(
    navController: NavController,
    requestType: String = "",
    requestId: String = ""
) {
    // State Management
    var selectedAmount by remember { mutableStateOf(DonorCommunitySupportConstants.DefaultAmount) }
    var isCustomSelected by remember { mutableStateOf(false) }
    var customAmount by remember { mutableStateOf("") }
    
    val currentAmount = if (isCustomSelected) selectedAmount else selectedAmount
    val familiesHelped = if (currentAmount > 0) (currentAmount / DonorCommunitySupportConstants.MealsPerRupee) else 0

    Scaffold(
        containerColor = DonorCommunitySupportConstants.BackgroundColor
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(DonorCommunitySupportConstants.BackgroundColor)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Section
            BackButtonSection(
                onBackClick = { navController.popBackStack() }
            )
            
            Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingMedium))
            
            // Hero Section
            HeroSection()
            
            Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingExtraLarge))
            
            // Donation Card Section
            DonationCardSection(
                selectedAmount = selectedAmount,
                isCustomSelected = isCustomSelected,
                customAmount = customAmount,
                onAmountSelected = { amount ->
                    selectedAmount = amount
                    isCustomSelected = false
                },
                onCustomSelected = {
                    isCustomSelected = true
                    selectedAmount = 0
                },
                onCustomAmountChanged = { amount ->
                    customAmount = amount
                    selectedAmount = amount.toIntOrNull() ?: 0
                },
                currentAmount = currentAmount,
                familiesHelped = familiesHelped,
                onContinueClick = {
                    navController.navigate(
                        Routes.DONOR_PAYMENT_METHODS + "/$requestType/$requestId/$currentAmount"
                    )
                }
            )
            
            Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingLarge))
        }
    }
}

// ==================== Header Components ====================

@Composable
private fun BackButtonSection(
    onBackClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(DonorCommunitySupportConstants.PaddingMedium),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onBackClick,
            colors = ButtonDefaults.textButtonColors(
                contentColor = DonorCommunitySupportConstants.PrimaryColor
            )
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "BACK",
                fontSize = DonorCommunitySupportConstants.SubtitleSize,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==================== Hero Section ====================

@Composable
private fun HeroSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DonorCommunitySupportConstants.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Heart Icon
        SupportIcon()
        
        Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingMedium))
        
        // Title
        Text(
            text = "Community Support",
            fontSize = DonorCommunitySupportConstants.TitleSize,
            fontWeight = FontWeight.Bold,
            color = DonorCommunitySupportConstants.TextPrimary
        )
        
        Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingSmall))
        
        // Subtitle
        Text(
            text = "Make a difference with your donation",
            fontSize = DonorCommunitySupportConstants.SubtitleSize,
            color = DonorCommunitySupportConstants.TextSecondary
        )
    }
}

@Composable
private fun SupportIcon() {
    Box(
        modifier = Modifier
            .size(DonorCommunitySupportConstants.IconSize)
            .background(
                DonorCommunitySupportConstants.IconBackgroundColor,
                CircleShape
            )
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.FavoriteBorder,
            contentDescription = "Support Icon",
            tint = DonorCommunitySupportConstants.PrimaryColor,
            modifier = Modifier.size(DonorCommunitySupportConstants.IconInnerSize)
        )
    }
}

// ==================== Donation Card Section ====================

@Composable
private fun DonationCardSection(
    selectedAmount: Int,
    isCustomSelected: Boolean,
    customAmount: String,
    onAmountSelected: (Int) -> Unit,
    onCustomSelected: () -> Unit,
    onCustomAmountChanged: (String) -> Unit,
    currentAmount: Int,
    familiesHelped: Int,
    onContinueClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DonorCommunitySupportConstants.PaddingLarge),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = DonorCommunitySupportConstants.CardBackgroundColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(DonorCommunitySupportConstants.PaddingLarge)
        ) {
            // Section Title
            Text(
                text = "Select Amount",
                fontSize = DonorCommunitySupportConstants.SectionTitleSize,
                fontWeight = FontWeight.Bold,
                color = DonorCommunitySupportConstants.TextPrimary
            )
            
            Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingMedium))
            
            // Predefined Amount Buttons
            PredefinedAmountsRow(
                amounts = DonorCommunitySupportConstants.PredefinedAmounts,
                selectedAmount = selectedAmount,
                isCustomSelected = isCustomSelected,
                onAmountClick = onAmountSelected
            )
            
            Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingMedium))
            
            // Custom Amount Option
            CustomAmountSection(
                isSelected = isCustomSelected,
                customAmount = customAmount,
                onCustomSelected = onCustomSelected,
                onCustomAmountChanged = onCustomAmountChanged
            )
            
            Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingLarge))
            
            // Impact Statement
            ImpactStatement(
                amount = currentAmount,
                familiesHelped = familiesHelped
            )
            
            Spacer(modifier = Modifier.height(DonorCommunitySupportConstants.PaddingExtraLarge))
            
            // Continue Button
            ContinueButton(
                enabled = currentAmount > 0,
                onClick = onContinueClick
            )
        }
    }
}

// ==================== Amount Selection Components ====================

@Composable
private fun PredefinedAmountsRow(
    amounts: List<Int>,
    selectedAmount: Int,
    isCustomSelected: Boolean,
    onAmountClick: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        amounts.forEach { amount ->
            AmountButton(
                amount = amount,
                isSelected = selectedAmount == amount && !isCustomSelected,
                onClick = { onAmountClick(amount) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun AmountButton(
    amount: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(DonorCommunitySupportConstants.ButtonHeight)
            .padding(horizontal = 4.dp)
            .background(
                if (isSelected) DonorCommunitySupportConstants.PrimaryColor else Color.Transparent,
                RoundedCornerShape(10.dp)
            )
            .border(
                1.dp,
                if (isSelected) Color.Transparent else DonorCommunitySupportConstants.BorderColor,
                RoundedCornerShape(10.dp)
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "₹${amount}",
            color = if (isSelected) Color.White else DonorCommunitySupportConstants.TextPrimary,
            fontWeight = FontWeight.Medium,
            fontSize = DonorCommunitySupportConstants.AmountTextSize
        )
    }
}

@Composable
private fun CustomAmountSection(
    isSelected: Boolean,
    customAmount: String,
    onCustomSelected: () -> Unit,
    onCustomAmountChanged: (String) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Radio Button Indicator
            CustomRadioButton(isSelected = isSelected)
            
            Spacer(modifier = Modifier.width(DonorCommunitySupportConstants.PaddingSmall))
            
            // Custom Button
            OutlinedButton(
                onClick = onCustomSelected,
                modifier = Modifier
                    .weight(1f)
                    .height(DonorCommunitySupportConstants.ButtonHeight),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (isSelected) 
                        DonorCommunitySupportConstants.PrimaryColor 
                    else 
                        DonorCommunitySupportConstants.TextSecondary
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) 
                        DonorCommunitySupportConstants.PrimaryColor 
                    else 
                        DonorCommunitySupportConstants.BorderColor
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = "Custom",
                    fontWeight = FontWeight.Medium
                )
            }
        }
        
        // Custom Amount Input
        if (isSelected) {
            Spacer(modifier = Modifier.height(12.dp))
            CustomAmountInput(
                value = customAmount,
                onValueChange = onCustomAmountChanged
            )
        }
    }
}

@Composable
private fun CustomRadioButton(isSelected: Boolean) {
    Box(
        modifier = Modifier
            .size(DonorCommunitySupportConstants.RadioButtonSize)
            .background(
                if (isSelected) 
                    DonorCommunitySupportConstants.CustomRadioColor 
                else 
                    Color.Transparent,
                CircleShape
            )
            .border(
                2.dp,
                DonorCommunitySupportConstants.CustomRadioColor,
                CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(DonorCommunitySupportConstants.RadioButtonInnerSize)
                    .background(Color.White, CircleShape)
            )
        }
    }
}

@Composable
private fun CustomAmountInput(
    value: String,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = { 
            // Only allow digits
            onValueChange(it.filter { char -> char.isDigit() })
        },
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Enter amount in INR") },
        prefix = { 
            Text("₹", color = DonorCommunitySupportConstants.TextSecondary) 
        },
        singleLine = true,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
        shape = RoundedCornerShape(10.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = DonorCommunitySupportConstants.PrimaryColor,
            unfocusedBorderColor = DonorCommunitySupportConstants.BorderColor
        )
    )
}

// ==================== Impact Statement ====================

@Composable
private fun ImpactStatement(
    amount: Int,
    familiesHelped: Int
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                DonorCommunitySupportConstants.ImpactBackgroundColor,
                RoundedCornerShape(12.dp)
            )
            .padding(DonorCommunitySupportConstants.PaddingMedium)
    ) {
        Text(
            text = buildAnnotatedString {
                append("₹${amount} can provide meals for ")
                withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                    append("$familiesHelped")
                }
                append(" families.")
            },
            fontSize = DonorCommunitySupportConstants.BodySize,
            color = DonorCommunitySupportConstants.TextPrimary,
            lineHeight = 20.sp
        )
    }
}

// ==================== Action Button ====================

@Composable
private fun ContinueButton(
    enabled: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(DonorCommunitySupportConstants.PrimaryButtonHeight),
        colors = ButtonDefaults.buttonColors(
            containerColor = DonorCommunitySupportConstants.PrimaryColor,
            contentColor = Color.White,
            disabledContainerColor = DonorCommunitySupportConstants.BorderColor,
            disabledContentColor = DonorCommunitySupportConstants.TextSecondary
        ),
        shape = RoundedCornerShape(12.dp),
        enabled = enabled
    ) {
        Text(
            text = "Continue to Payment",
            fontSize = DonorCommunitySupportConstants.ButtonTextSize,
            fontWeight = FontWeight.SemiBold
        )
    }
}
