package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import androidx.compose.runtime.remember

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorDashboard(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    
    fun handleLogout() {
        sessionManager.clearSession()
        navController.navigate(Routes.DONOR_LOGIN) {
            popUpTo(Routes.DONOR_DASHBOARD) { inclusive = true }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        bottomBar = { DonorBottomBar(navController) }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(16.dp)
        ) {

            /* ---------- HEADER ---------- */
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Row(verticalAlignment = Alignment.CenterVertically) {

                    Icon(
                        Icons.Outlined.VolunteerActivism,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0xFF22C55E), RoundedCornerShape(12.dp))
                            .padding(8.dp)
                    )

                    Spacer(Modifier.width(12.dp))

                    Column {
                        Text(
                            "Donor Dashboard",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1F2937)
                        )
                        Text(
                            "Your generosity changes lives",
                            fontSize = 14.sp,
                            color = Color(0xFF22C55E)
                        )
                    }
                }

                Row {
                    IconButton(
                        onClick = {
                            navController.navigate(Routes.DONOR_NOTIFICATIONS)
                        }
                    ) {
                        Icon(
                            Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = Color(0xFF22C55E)
                        )
                    }
                    
                    IconButton(
                        onClick = { handleLogout() }
                    ) {
                        Icon(
                            Icons.Outlined.ExitToApp,
                            contentDescription = "Logout",
                            tint = Color(0xFFEF4444)
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            DashboardMenuCard(
                icon = Icons.Outlined.Search,
                title = "Browse Causes",
                subtitle = "Explore causes needing help"
            ) {
                navController.navigate(Routes.DONOR_BROWSE_CAUSES)
            }

            DashboardMenuCard(
                icon = Icons.Outlined.AddCircleOutline,
                title = "Raise Help Request",
                subtitle = "Request help for a cause"
            ) {
                navController.navigate(Routes.DONOR_RAISE_DONATION)
            }

            DashboardMenuCard(
                icon = Icons.Outlined.History,
                title = "Donation History",
                subtitle = "Track your donations"
            ) {
                navController.navigate(Routes.DONOR_DONATION_HISTORY)
            }

            DashboardMenuCard(
                icon = Icons.Outlined.Favorite,
                title = "My Impact",
                subtitle = "See your contribution impact"
            ) {
                navController.navigate(Routes.DONOR_IMPACT)
            }
        }
    }
}

/* ---------- COMPONENTS ---------- */

@Composable
fun DashboardMenuCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = Color(0xFF22C55E), modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

/* ---------- BOTTOM BAR ---------- */

@Composable
fun DonorBottomBar(navController: NavController, currentRoute: String = "") {
    NavigationBar {
        NavigationBarItem(
            selected = currentRoute == Routes.DONOR_DASHBOARD,
            onClick = { navController.navigate(Routes.DONOR_DASHBOARD) },
            icon = { Icon(Icons.Outlined.Home, null) },
            label = { Text("Home") }
        )
        NavigationBarItem(
            selected = currentRoute == Routes.DONOR_BROWSE_CAUSES,
            onClick = { navController.navigate(Routes.DONOR_BROWSE_CAUSES) },
            icon = { Icon(Icons.Outlined.Search, null) },
            label = { Text("Browse") }
        )
        NavigationBarItem(
            selected = currentRoute == Routes.DONOR_DONATION_HISTORY,
            onClick = { navController.navigate(Routes.DONOR_DONATION_HISTORY) },
            icon = { Icon(Icons.Outlined.History, null) },
            label = { Text("History") }
        )
        NavigationBarItem(
            selected = currentRoute == Routes.DONOR_PROFILE,
            onClick = { navController.navigate(Routes.DONOR_PROFILE) },
            icon = { Icon(Icons.Outlined.Person, null) },
            label = { Text("Profile") }
        )
    }
}
