package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.theme.DonorBottomBar
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import com.google.gson.annotations.SerializedName

/* -------------------- API MODELS -------------------- */

data class DonationReceivedItem(
    @SerializedName("payment_id") val payment_id: Int,
    @SerializedName("transaction_id") val transaction_id: String,
    @SerializedName("request_id") val request_id: Int,
    @SerializedName("request_title") val request_title: String,
    @SerializedName("payer_name") val payer_name: String,
    @SerializedName("payer_email") val payer_email: String,
    @SerializedName("payer_type") val payer_type: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("payment_method") val payment_method: String,
    @SerializedName("payment_status") val payment_status: String,
    @SerializedName("created_at") val created_at: String,
    @SerializedName("completed_at") val completed_at: String?
)

data class DonationsReceivedResponse(
    val status: Boolean,
    val message: String,
    val data: DonationsReceivedData?
)

data class DonationsReceivedData(
    val donations: List<DonationReceivedItem>,
    @SerializedName("total_received") val total_received: Double,
    @SerializedName("total_donations") val total_donations: Int
)

interface DonationsReceivedApi {
    @GET("get_donations_received.php")
    suspend fun getDonationsReceived(@Query("donor_id") donorId: Int): DonationsReceivedResponse
}

object DonationsReceivedRetrofit {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"
    
    val api: DonationsReceivedApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DonationsReceivedApi::class.java)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorDonationHistoryScreen(
    navController: NavController,
    onExportClick: () -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var donations by remember { mutableStateOf<List<com.example.helphup.ui.theme.DonationItem>>(emptyList()) }
    var totalAmount by remember { mutableStateOf(0.0) }
    var totalDonations by remember { mutableStateOf(0) }
    
    val context = LocalContext.current
    val sessionManager = remember { com.example.helphup.utils.UserSessionManager(context) }
    val donorId = remember { sessionManager.getDonorId() }
    
    // Fetch donations RECEIVED (not donations made) when screen loads
    LaunchedEffect(donorId) {
        if (donorId > 0) {
            scope.launch {
                isLoading = true
                errorMessage = null
                try {
                    val response = DonationsReceivedRetrofit.api.getDonationsReceived(donorId)
                    if (response.status && response.data != null) {
                        donations = response.data.donations.map { 
                            com.example.helphup.ui.theme.DonationItem(
                                id = it.payment_id,
                                campaignId = it.request_id,
                                ngoId = null,
                                volunteerId = null,
                                amount = it.amount,
                                paymentMethod = it.payment_method,
                                transactionId = it.transaction_id,
                                paymentStatus = it.payment_status,
                                description = "Donation received for: ${it.request_title}",
                                createdAt = it.created_at,
                                campaignTitle = it.request_title,
                                orgName = "${it.payer_name} (${it.payer_type})"
                            )
                        }
                        totalAmount = response.data.total_received
                        totalDonations = response.data.total_donations
                    } else {
                        errorMessage = response.message ?: "Failed to load donation history"
                    }
                } catch (e: Exception) {
                    errorMessage = "Error: ${e.message}"
                    e.printStackTrace()
                } finally {
                    isLoading = false
                }
            }
        }
    }
    
    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Donation History",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "View your contributions and download tax receipts",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.Outlined.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    TextButton(onClick = onExportClick) {
                        Icon(
                            Icons.Outlined.Download,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = Color.White
                        )
                        Spacer(Modifier.width(6.dp))
                        Text("Export (CSV)", color = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        bottomBar = { DonorBottomBar(navController, Routes.DONOR_DONATION_HISTORY) }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (errorMessage != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFFFEBEE)
                    )
                ) {
                    Text(
                        text = errorMessage ?: "",
                        modifier = Modifier.padding(16.dp),
                        color = Color(0xFFC62828)
                    )
                }
            } else {
                SummaryCard(title = "Total Donated", value = "₹${String.format("%.2f", totalAmount)}")
                Spacer(Modifier.height(8.dp))
                SummaryCard(title = "Causes Supported", value = "$totalDonations")
                Spacer(Modifier.height(8.dp))
                SummaryCard(title = "Tax Deductible", value = "₹${String.format("%.2f", totalAmount)}", valueColor = Color(0xFF22C55E))

                Spacer(Modifier.height(16.dp))

                if (donations.isNotEmpty()) {
                    DonationHeader()

                    donations.forEach { donation ->
                        val dateFormatted = formatDate(donation.createdAt)
                        val causeName = donation.campaignTitle ?: donation.orgName ?: "Community Support"
                        val orgName = donation.orgName ?: ""
                        val amountFormatted = "₹${String.format("%.2f", donation.amount)}"
                        
                        DonationItem(
                            date = dateFormatted,
                            cause = causeName,
                            org = orgName,
                            amount = amountFormatted
                        )
                    }
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {
                        Text(
                            text = "No donations yet",
                            modifier = Modifier.padding(16.dp),
                            color = Color.Gray
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                TaxInformationCard(totalAmount = totalAmount)
            }
        }
    }
}

private fun formatDate(dateString: String): String {
    return try {
        val inputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val outputFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        val date = inputFormat.parse(dateString)
        if (date != null) {
            outputFormat.format(date)
        } else {
            dateString
        }
    } catch (e: Exception) {
        dateString
    }
}

/* ---------- Components ---------- */

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    valueColor: Color = Color.Black
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontSize = 12.sp, color = Color.Gray)
            Spacer(Modifier.height(6.dp))
            Text(
                value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        }
    }
}

@Composable
private fun DonationHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Date", fontSize = 12.sp, color = Color.Gray)
        Text("Cause", fontSize = 12.sp, color = Color.Gray)
        Text("Amount", fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable
private fun DonationItem(
    date: String,
    cause: String,
    org: String,
    amount: String
) {
    Divider()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {

        Text(date, fontSize = 13.sp)

        Column(
            modifier = Modifier.weight(1f).padding(start = 12.dp)
        ) {
            Text(cause, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (org.isNotEmpty()) {
                Text(org, fontSize = 12.sp, color = Color.Gray)
            }
        }

        Text(amount, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TaxInformationCard(totalAmount: Double = 0.0) {
    Card(
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFEFF6FF)
        )
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                "Tax Information",
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1E3A8A)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "All donations are tax-deductible. Download your receipts above "
                        + "for tax filing purposes. Your total tax-deductible donations: ₹${String.format("%.2f", totalAmount)}",
                fontSize = 13.sp,
                color = Color(0xFF1E40AF)
            )
        }
    }
}
