package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.theme.ValidationUtils
import com.example.helphup.utils.UserSessionManager
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.util.Log
import com.example.helphup.ui.theme.DonorProfileApiClient
import com.example.helphup.ui.theme.GetDonorProfileRequest
import com.example.helphup.ui.theme.UpdateDonorProfileRequest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorEditDetails(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val scope = rememberCoroutineScope()
    
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    
    // Load user data from session initially
    val loadedFullName = sessionManager.getDonorFullName()
    val loadedEmail = sessionManager.getDonorEmail()
    val loadedPhone = sessionManager.getDonorPhone()
    val loadedAddress = sessionManager.getDonorAddress()
    
    // Initialize state variables with session data
    var fullName by remember { mutableStateOf(loadedFullName) }
    var email by remember { mutableStateOf(loadedEmail) }
    var countryCode by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var address by remember { mutableStateOf(loadedAddress) }
    
    // Validation error messages
    var fullNameError by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf("") }
    var countryCodeError by remember { mutableStateOf("") }
    var phoneNumberError by remember { mutableStateOf("") }
    
    // Fetch profile data from API when screen loads
    LaunchedEffect(Unit) {
        val donorId = sessionManager.getDonorId()
        if (donorId > 0) {
            isLoading = true
            try {
                val response = DonorProfileApiClient.api.getProfile(
                    GetDonorProfileRequest(donorId)
                )
                if (response.status && response.data != null) {
                    val data = response.data
                    fullName = data.fullName
                    email = data.email
                    address = data.address
                    
                    // Parse phone number
                    val phoneParts = if (data.phone.isNotEmpty() && data.phone.startsWith("+")) {
                        val match = Regex("^(\\+\\d{1,4})(\\d+)$").find(data.phone)
                        if (match != null) {
                            match.groupValues[1] to match.groupValues[2]
                        } else {
                            when {
                                data.phone.startsWith("+91") && data.phone.length > 3 -> "+91" to data.phone.substring(3)
                                data.phone.startsWith("+1") && data.phone.length > 2 -> "+1" to data.phone.substring(2)
                                data.phone.startsWith("+44") && data.phone.length > 3 -> "+44" to data.phone.substring(3)
                                else -> "" to data.phone
                            }
                        }
                    } else {
                        "" to data.phone
                    }
                    countryCode = phoneParts.first
                    phoneNumber = phoneParts.second
                    
                    // Update session
                    sessionManager.saveDonorSession(donorId, data.fullName, data.email)
                    sessionManager.saveDonorProfileData(data.phone, data.address)
                } else {
                    errorMessage = "Failed to load profile: ${response.message}"
                }
            } catch (e: Exception) {
                Log.e("DonorEditDetails", "Error loading profile: ${e.message}", e)
                errorMessage = "Failed to load profile: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Edit Profile", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            Spacer(modifier = Modifier.height(16.dp))

            // Profile Picture Section
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(Color(0xFFDFF6EA), RoundedCornerShape(50.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Profile",
                    modifier = Modifier.size(50.dp),
                    tint = Color(0xFF22C55E)
                )
            }

            // Full Name with validation
            OutlinedTextField(
                value = fullName,
                onValueChange = { 
                    fullName = it
                    fullNameError = ""
                },
                label = { Text("Full Name") },
                leadingIcon = { Icon(Icons.Default.Person, null) },
                isError = fullNameError.isNotEmpty(),
                supportingText = if (fullNameError.isNotEmpty()) {
                    { Text(fullNameError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Email with validation
            OutlinedTextField(
                value = email,
                onValueChange = { 
                    email = it
                    emailError = ""
                },
                label = { Text("Email") },
                leadingIcon = { Icon(Icons.Default.Email, null) },
                isError = emailError.isNotEmpty(),
                supportingText = if (emailError.isNotEmpty()) {
                    { Text(emailError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Phone Number with Country Code
            PhoneNumberField(
                countryCode = countryCode,
                phoneNumber = phoneNumber,
                onCountryCodeChange = { 
                    countryCode = it
                    countryCodeError = ""
                },
                onPhoneNumberChange = { 
                    phoneNumber = it
                    phoneNumberError = ""
                },
                errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneNumberError,
                modifier = Modifier.fillMaxWidth()
            )

            // Address
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            
            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color(0xFFEF4444),
                    fontSize = 14.sp
                )
            }
            
            if (successMessage.isNotEmpty()) {
                Text(
                    text = successMessage,
                    color = Color(0xFF22C55E),
                    fontSize = 14.sp
                )
            }

            // Save Button
            Button(
                enabled = !isLoading,
                onClick = { 
                    // Clear previous errors
                    fullNameError = ""
                    emailError = ""
                    countryCodeError = ""
                    phoneNumberError = ""
                    
                    // Validate all fields
                    val fullNameValidation = ValidationUtils.validateFullName(fullName)
                    val emailValidation = ValidationUtils.validateEmail(email)
                    val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
                    val phoneNumberValidation = ValidationUtils.validatePhoneNumber(phoneNumber)
                    
                    // Set error messages
                    if (!fullNameValidation.isValid) fullNameError = fullNameValidation.errorMessage
                    if (!emailValidation.isValid) emailError = emailValidation.errorMessage
                    if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
                    if (!phoneNumberValidation.isValid) phoneNumberError = phoneNumberValidation.errorMessage
                    
                    // If all validations pass, save changes
                    if (fullNameValidation.isValid &&
                        emailValidation.isValid &&
                        countryCodeValidation.isValid &&
                        phoneNumberValidation.isValid) {
                        
                        scope.launch {
                            isLoading = true
                            try {
                                val donorId = sessionManager.getDonorId()
                                val fullPhone = "$countryCode$phoneNumber"
                                
                                val response = DonorProfileApiClient.api.updateProfile(
                                    UpdateDonorProfileRequest(
                                        donorId = donorId,
                                        fullName = fullName,
                                        phone = fullPhone,
                                        email = email,
                                        address = address
                                    )
                                )
                                
                                if (response.status) {
                                    // Save updated data to session
                                    sessionManager.saveDonorProfileData(fullPhone, address)
                                    sessionManager.saveDonorSession(donorId, fullName, email)
                                    successMessage = "Profile updated successfully"
                                    
                                    // Navigate back after short delay
                                    kotlinx.coroutines.delay(1500)
                                    navController.popBackStack()
                                } else {
                                    errorMessage = response.message
                                }
                            } catch (e: Exception) {
                                Log.e("DonorEditDetails", "Error updating profile: ${e.message}", e)
                                errorMessage = "Failed to update profile: ${e.message}"
                            } finally {
                                isLoading = false
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3B82F6)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save Changes", fontSize = 16.sp, color = Color.White)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Cancel Button
            OutlinedButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Cancel", fontSize = 16.sp, color = Color(0xFF3B82F6))
            }
        }
    }
}
