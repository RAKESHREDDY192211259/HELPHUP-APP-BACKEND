package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.Pets
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.VolunteerActivism
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.theme.DonorBottomBar
import com.example.helphup.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorImpactScreen(navController: NavController) {

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Your Impact", fontWeight = FontWeight.Bold)
                        Text(
                            "See the difference your generosity makes",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Outlined.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            DonorBottomBar(navController, Routes.DONOR_IMPACT)
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {

            ImpactStatsGrid()

            Spacer(Modifier.height(20.dp))

            Text(
                text = "Impact Stories",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(Modifier.height(12.dp))

            ImpactStoryCard(
                icon = Icons.Outlined.Favorite,
                title = "Food Security",
                description = "Provided nutritious meals to families in need."
            )

            ImpactStoryCard(
                icon = Icons.Outlined.School,
                title = "Education Support",
                description = "Helped students continue their education."
            )

            ImpactStoryCard(
                icon = Icons.Outlined.Pets,
                title = "Animal Welfare",
                description = "Rescued and treated abandoned animals."
            )

            Spacer(Modifier.height(24.dp))

            ThankYouCard()
        }
    }
}

/* ---------------- Stats Grid ---------------- */

@Composable
private fun ImpactStatsGrid() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ImpactStatCard("Donations", "342", Modifier.weight(1f))
            ImpactStatCard("Projects", "89", Modifier.weight(1f))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ImpactStatCard("Funds Raised", "₹52,425", Modifier.weight(1f))
            ImpactStatCard("NGOs Supported", "15", Modifier.weight(1f))
        }
    }
}

@Composable
private fun ImpactStatCard(
    title: String,
    value: String,
    modifier: Modifier
) {
    Card(
        modifier = modifier.height(90.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(title, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

/* ---------------- Impact Story ---------------- */

@Composable
private fun ImpactStoryCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF16A34A),
                modifier = Modifier.size(40.dp)
            )

            Spacer(Modifier.width(12.dp))

            Column {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(description, fontSize = 13.sp, color = Color.Gray)
            }
        }
    }
}

/* ---------------- Thank You ---------------- */

@Composable
private fun ThankYouCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF16A34A))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Outlined.VolunteerActivism,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(36.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text("Thank You!", color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                "Your generosity creates real impact.",
                color = Color.White,
                fontSize = 13.sp
            )
        }
    }
}
