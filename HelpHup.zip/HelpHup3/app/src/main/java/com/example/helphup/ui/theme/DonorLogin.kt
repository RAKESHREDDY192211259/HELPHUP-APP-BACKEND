package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.gson.annotations.SerializedName
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch
import com.example.helphup.ui.theme.DonorProfileApiClient
import com.example.helphup.ui.theme.GetDonorProfileRequest
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* -------------------- API MODELS -------------------- */

// For Login
data class DonorLoginRequest(
    val email: String,
    val password: String
)

data class DonorLoginResponse(
    val status: Boolean,
    val message: String,
    val donor_id: Int?,
    val full_name: String?
)

data class DonorLoginData(
    val donor_id: Int,
    val full_name: String,
    val email: String
)

/* -------------------- API SERVICE -------------------- */

interface DonorLoginApi {
    @POST("donor_login.php")
    suspend fun login(@Body request: DonorLoginRequest): DonorLoginResponse
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object DonorLoginRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: DonorLoginApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DonorLoginApi::class.java)
    }
}

/* -------------------- VIEWMODEL -------------------- */

class DonorLoginViewModel : ViewModel() {

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var isLoading by mutableStateOf(false)
        private set
    
    var loginData by mutableStateOf<DonorLoginData?>(null)
        private set

    fun login(email: String, password: String, onLoginSuccess: () -> Unit) {
        viewModelScope.launch {
            isLoading = true
            errorMessage = null
            try {
                val response = DonorLoginRetrofitInstance.api.login(
                    DonorLoginRequest(email, password)
                )
                if (response.status && response.donor_id != null && response.full_name != null) {
                    loginData = DonorLoginData(
                        donor_id = response.donor_id,
                        full_name = response.full_name,
                        email = email
                    )
                    onLoginSuccess()
                } else {
                    errorMessage = response.message
                }
            } catch (e: Exception) {
                val errorMsg = e.message ?: e.localizedMessage ?: "Unknown error"
                errorMessage = when {
                    errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Unable to resolve host") -> "Connection error: Cannot find server\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Connection refused") || errorMsg.contains("actively refused") || errorMsg.contains("target machine") -> "Connection error: Connection refused\nXAMPP Apache may not be running\n\nFix:\n1. Open XAMPP Control Panel\n2. Start Apache\n3. Check IP: 10.126.222.192\n4. Ensure phone and PC on same WiFi"
                    errorMsg.contains("Connection reset") || errorMsg.contains("connection reset") -> "Connection error: Connection reset\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Network is unreachable") -> "Connection error: Network unreachable\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    else -> "Connection failed: $errorMsg\n\nQuick Fix:\n1. ✅ Start XAMPP Apache\n2. ✅ Check IP: 10.126.222.192\n3. ✅ Same WiFi network\n4. ✅ Test: http://10.126.222.192/helphup/api/donor_login.php"
                }
                android.util.Log.e("DonorLogin", "Login error: $errorMsg", e)
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
}

/* -------------------- UI SCREEN -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorLoginScreen(
    onBackClick: () -> Unit,
    onForgotPasswordClick: () -> Unit,
    onCreateAccountClick: () -> Unit,
    onLoginSuccess: () -> Unit
) {
    val viewModel: DonorLoginViewModel = viewModel()
    val context = LocalContext.current

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Donor Login", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, null)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {

            Card(
                modifier = Modifier.fillMaxWidth(0.9f),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {

                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(Color(0xFFDFF6EA), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Outlined.FavoriteBorder,
                            contentDescription = null,
                            tint = Color(0xFF22C55E),
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "Donor Login",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            val image = if (passwordVisible)
                                Icons.Outlined.Visibility
                            else Icons.Outlined.VisibilityOff
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(image, "Toggle password visibility")
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Forgot Password?",
                        modifier = Modifier
                            .align(Alignment.End)
                            .clickable { onForgotPasswordClick() },
                        color = Color(0xFFE91E63),
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                    
                    viewModel.errorMessage?.let {
                        Text(
                            text = it,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.login(email, password) {
                                // Save session data and fetch full profile
                                val sessionManager = UserSessionManager(context)
                                if (viewModel.loginData != null) {
                                    val data = viewModel.loginData!!
                                    sessionManager.saveDonorSession(
                                        data.donor_id,
                                        data.full_name,
                                        data.email
                                    )
                                    
                                    // Fetch full profile data after login
                                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                                        try {
                                            val profileResponse = DonorProfileApiClient.api.getProfile(
                                                GetDonorProfileRequest(data.donor_id)
                                            )
                                            if (profileResponse.status && profileResponse.data != null) {
                                                val profileData = profileResponse.data
                                                sessionManager.saveDonorProfileData(
                                                    profileData.phone,
                                                    profileData.address
                                                )
                                            }
                                        } catch (e: Exception) {
                                            // If profile fetch fails, continue with basic login data
                                            e.printStackTrace()
                                        }
                                    }
                                }
                                onLoginSuccess()
                            }
                        },
                        enabled = !viewModel.isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
                    ) {
                        if (viewModel.isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White)
                        } else {
                            Text("Login", color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row {
                        Text("Don't have an account? ")
                        Text(
                            text = "Create one",
                            modifier = Modifier.clickable { onCreateAccountClick() },
                            color = Color(0xFFE91E63),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}