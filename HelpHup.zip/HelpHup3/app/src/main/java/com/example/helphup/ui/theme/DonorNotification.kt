package com.example.helphup.ui.theme

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorNotificationScreen(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val donorId = remember { sessionManager.getDonorId() }
    
    var notifications by remember { mutableStateOf<List<NotificationData>>(emptyList()) }
    var helpReceived by remember { mutableStateOf<List<HelpReceivedItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var unreadCount by remember { mutableStateOf(0) }
    var showHelpReceived by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()
    
    // Fetch notifications and help received
    LaunchedEffect(donorId) {
        if (donorId > 0) {
            isLoading = true
            errorMessage = null
            try {
                // Fetch notifications
                val notifResponse = NotificationsRetrofitInstance.api.getNotifications("donor", donorId)
                if (notifResponse.status && notifResponse.data != null) {
                    notifications = notifResponse.data.notifications
                    unreadCount = notifResponse.data.unread_count
                }
                
                // Fetch help received
                val helpResponse = NotificationsRetrofitInstance.api.getHelpReceived("donor", donorId)
                if (helpResponse.status && helpResponse.data != null) {
                    helpReceived = helpResponse.data.help_received
                }
            } catch (e: Exception) {
                errorMessage = "Failed to load data: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }
    
    fun markAsRead(notificationId: Int) {
        scope.launch {
            try {
                NotificationsRetrofitInstance.api.markAsRead(
                    MarkReadRequest(notificationId, "donor", donorId)
                )
                // Refresh notifications
                val response = NotificationsRetrofitInstance.api.getNotifications("donor", donorId)
                if (response.status && response.data != null) {
                    notifications = response.data.notifications
                    unreadCount = response.data.unread_count
                }
            } catch (e: Exception) {
                // Handle error silently
            }
        }
    }
    
    fun markAllAsRead() {
        scope.launch {
            try {
                NotificationsRetrofitInstance.api.markAllAsRead(
                    MarkAllReadRequest("donor", donorId)
                )
                // Refresh notifications
                val response = NotificationsRetrofitInstance.api.getNotifications("donor", donorId)
                if (response.status && response.data != null) {
                    notifications = response.data.notifications
                    unreadCount = response.data.unread_count
                }
            } catch (e: Exception) {
                // Handle error silently
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        bottomBar = { DonorBottomBar(navController, Routes.DONOR_NOTIFICATIONS) }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
        ) {

            /* ---------- Header ---------- */
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFF16A34A)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "Notifications",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    Text(
                        text = if (unreadCount > 0) "$unreadCount unread" else "All caught up",
                        fontSize = 14.sp,
                        color = Color(0xFF16A34A)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            /* ---------- Toggle Buttons ---------- */
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Toggle between notifications and help received
                Row {
                    TextButton(
                        onClick = { showHelpReceived = false },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = if (!showHelpReceived) Color(0xFF16A34A) else Color.Gray
                        )
                    ) {
                        Text("Requests Status (${notifications.size})")
                    }
                    TextButton(
                        onClick = { showHelpReceived = true },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = if (showHelpReceived) Color(0xFF16A34A) else Color.Gray
                        )
                    ) {
                        Text("Help Received (${helpReceived.size})")
                    }
                }
                
                if (!showHelpReceived && unreadCount > 0) {
                    Text(
                        text = "✓ Mark all as read",
                        modifier = Modifier.clickable { markAllAsRead() },
                        fontSize = 14.sp,
                        color = Color(0xFF16A34A),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            /* ---------- Notifications ---------- */
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Color(0xFF16A34A))
                    }
                }
                errorMessage != null -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = errorMessage ?: "Error loading notifications",
                            color = Color.Red
                        )
                    }
                }
                showHelpReceived -> {
                    if (helpReceived.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Favorite,
                                    contentDescription = null,
                                    modifier = Modifier.size(64.dp),
                                    tint = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "No help received yet",
                                    color = Color.Gray,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    } else {
                        LazyColumn {
                            items(helpReceived) { help ->
                                HelpReceivedItem(
                                    help = help,
                                    onClick = { /* Navigate to details if needed */ }
                                )
                            }
                        }
                    }
                }
                notifications.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.Notifications,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "No notifications",
                                color = Color.Gray,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
                else -> {
                    LazyColumn {
                        items(notifications) { notification ->
                            NotificationItem(
                                icon = getNotificationIcon(notification.title),
                                title = notification.title,
                                message = notification.message,
                                rejectionReason = notification.rejection_reason,
                                time = formatTimeAgo(notification.created_at),
                                iconColor = getNotificationColor(notification.title),
                                isRead = notification.is_read,
                                onClick = {
                                    if (!notification.is_read) {
                                        markAsRead(notification.notification_id)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
