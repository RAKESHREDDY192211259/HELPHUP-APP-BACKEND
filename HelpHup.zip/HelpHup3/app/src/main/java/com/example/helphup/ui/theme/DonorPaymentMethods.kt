package com.example.helphup.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes

// ==================== Constants ====================

private object DonorPaymentMethodsConstants {
    // Colors
    val BackgroundColor = Color(0xFFF0FDF4)
    val CardBackgroundColor = Color.White
    val SelectedCardColor = Color(0xFFE6F9EF)
    val PrimaryColor = Color(0xFF22C55E)
    val TextPrimary = Color(0xFF1F2937)
    val TextSecondary = Color(0xFF6B7280)
    val BorderColor = Color(0xFFE5E7EB)
    
    // Spacing
    val PaddingSmall = 8.dp
    val PaddingMedium = 16.dp
    val PaddingLarge = 20.dp
    val PaddingExtraLarge = 24.dp
    
    // Sizes
    val IconSize = 48.dp
    val ButtonHeight = 52.dp
    
    // Text Sizes
    val TitleSize = 24.sp
    val SubtitleSize = 14.sp
    val MethodTitleSize = 16.sp
    val ButtonTextSize = 16.sp
}

// ==================== Main Screen ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorPaymentMethods(
    navController: NavController,
    requestType: String = "",
    requestId: String = "",
    amount: String = "100"
) {
    val paymentMethods = listOf(
        Triple("CARD", "Credit / Debit Card", Icons.Default.CreditCard),
        Triple("UPI", "UPI", Icons.Default.PhoneAndroid),
        Triple("NETBANKING", "Net Banking", Icons.Default.AccountBalance),
        Triple("WALLET", "Wallets", Icons.Default.Wallet),
        Triple("EMI", "EMI", Icons.Default.CalendarToday)
    )

    var selectedMethod by remember { mutableStateOf("CARD") }

    Scaffold(
        containerColor = DonorPaymentMethodsConstants.BackgroundColor
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(DonorPaymentMethodsConstants.BackgroundColor)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Section
            BackButtonSection(
                onBackClick = { navController.popBackStack() }
            )
            
            Spacer(modifier = Modifier.height(DonorPaymentMethodsConstants.PaddingMedium))
            
            // Hero Section
            HeroSection(amount = amount.toIntOrNull() ?: 100)
            
            Spacer(modifier = Modifier.height(DonorPaymentMethodsConstants.PaddingExtraLarge))
            
            // Payment Methods List
            PaymentMethodsList(
                methods = paymentMethods,
                selectedMethod = selectedMethod,
                onMethodSelected = { selectedMethod = it }
            )
            
            Spacer(modifier = Modifier.height(DonorPaymentMethodsConstants.PaddingExtraLarge))
            
            // Continue Button
            ContinueButton(
                enabled = selectedMethod.isNotEmpty(),
                onClick = {
                    navController.navigate(
                        Routes.DONOR_PAYMENT_DETAILS + "/$requestType/$requestId/$amount/$selectedMethod"
                    )
                }
            )
            
            Spacer(modifier = Modifier.height(DonorPaymentMethodsConstants.PaddingLarge))
        }
    }
}

// ==================== Header Components ====================

@Composable
private fun BackButtonSection(
    onBackClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(DonorPaymentMethodsConstants.PaddingMedium),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onBackClick,
            colors = ButtonDefaults.textButtonColors(
                contentColor = DonorPaymentMethodsConstants.PrimaryColor
            )
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "BACK",
                fontSize = DonorPaymentMethodsConstants.SubtitleSize,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==================== Hero Section ====================

@Composable
private fun HeroSection(amount: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DonorPaymentMethodsConstants.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Payment Icon
        Box(
            modifier = Modifier
                .size(80.dp)
                .background(
                    DonorPaymentMethodsConstants.SelectedCardColor,
                    RoundedCornerShape(40.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CreditCard,
                contentDescription = "Payment",
                tint = DonorPaymentMethodsConstants.PrimaryColor,
                modifier = Modifier.size(40.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(DonorPaymentMethodsConstants.PaddingMedium))
        
        // Title
        Text(
            text = "Select Payment Method",
            fontSize = DonorPaymentMethodsConstants.TitleSize,
            fontWeight = FontWeight.Bold,
            color = DonorPaymentMethodsConstants.TextPrimary
        )
        
        Spacer(modifier = Modifier.height(DonorPaymentMethodsConstants.PaddingSmall))
        
        // Subtitle
        Text(
            text = "Choose how you'd like to donate ₹${amount}",
            fontSize = DonorPaymentMethodsConstants.SubtitleSize,
            color = DonorPaymentMethodsConstants.TextSecondary
        )
    }
}

// ==================== Payment Methods List ====================

@Composable
private fun PaymentMethodsList(
    methods: List<Triple<String, String, ImageVector>>,
    selectedMethod: String,
    onMethodSelected: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DonorPaymentMethodsConstants.PaddingLarge)
    ) {
        methods.forEach { (key, title, icon) ->
            PaymentMethodCard(
                key = key,
                title = title,
                icon = icon,
                isSelected = selectedMethod == key,
                onClick = { onMethodSelected(key) }
            )
            Spacer(modifier = Modifier.height(DonorPaymentMethodsConstants.PaddingSmall))
        }
    }
}

@Composable
private fun PaymentMethodCard(
    key: String,
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        border = if (isSelected) 
            BorderStroke(2.dp, DonorPaymentMethodsConstants.PrimaryColor) 
        else 
            BorderStroke(1.dp, DonorPaymentMethodsConstants.BorderColor),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) 
                DonorPaymentMethodsConstants.SelectedCardColor 
            else 
                DonorPaymentMethodsConstants.CardBackgroundColor
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) 4.dp else 2.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(DonorPaymentMethodsConstants.PaddingMedium),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(DonorPaymentMethodsConstants.IconSize)
                    .background(
                        if (isSelected) 
                            DonorPaymentMethodsConstants.PrimaryColor 
                        else 
                            DonorPaymentMethodsConstants.BorderColor,
                        RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) Color.White else DonorPaymentMethodsConstants.TextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(DonorPaymentMethodsConstants.PaddingMedium))
            
            // Title
            Text(
                text = title,
                fontSize = DonorPaymentMethodsConstants.MethodTitleSize,
                fontWeight = FontWeight.SemiBold,
                color = DonorPaymentMethodsConstants.TextPrimary,
                modifier = Modifier.weight(1f)
            )
            
            // Check Icon
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = DonorPaymentMethodsConstants.PrimaryColor,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

// ==================== Action Button ====================

@Composable
private fun ContinueButton(
    enabled: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DonorPaymentMethodsConstants.PaddingLarge)
    ) {
        Button(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(DonorPaymentMethodsConstants.ButtonHeight),
            colors = ButtonDefaults.buttonColors(
                containerColor = DonorPaymentMethodsConstants.PrimaryColor,
                contentColor = Color.White,
                disabledContainerColor = DonorPaymentMethodsConstants.BorderColor,
                disabledContentColor = DonorPaymentMethodsConstants.TextSecondary
            ),
            shape = RoundedCornerShape(12.dp),
            enabled = enabled
        ) {
            Text(
                text = "Continue",
                fontSize = DonorPaymentMethodsConstants.ButtonTextSize,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
