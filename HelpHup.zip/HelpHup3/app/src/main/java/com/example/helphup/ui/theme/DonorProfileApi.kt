package com.example.helphup.ui.theme

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* -------------------- API MODELS -------------------- */

data class GetDonorProfileRequest(
    @SerializedName("donor_id") val donorId: Int
)

data class GetDonorProfileResponse(
    val status: Boolean,
    val message: String,
    val data: DonorProfileData? = null
)

data class DonorProfileData(
    @SerializedName("donor_id") val donorId: Int,
    @SerializedName("full_name") val fullName: String,
    val phone: String,
    val email: String,
    val address: String
)

data class UpdateDonorProfileRequest(
    @SerializedName("donor_id") val donorId: Int,
    @SerializedName("full_name") val fullName: String,
    val phone: String,
    val email: String,
    val address: String
)

data class UpdateDonorProfileResponse(
    val status: Boolean,
    val message: String
)

data class UpdateDonorPasswordRequest(
    @SerializedName("donor_id") val donorId: Int,
    @SerializedName("current_password") val currentPassword: String,
    @SerializedName("new_password") val newPassword: String
)

data class UpdateDonorPasswordResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- API SERVICE -------------------- */

interface DonorProfileApiService {
    @POST("get_donor_profile.php")
    suspend fun getProfile(@Body request: GetDonorProfileRequest): GetDonorProfileResponse

    @POST("update_donor_profile.php")
    suspend fun updateProfile(@Body request: UpdateDonorProfileRequest): UpdateDonorProfileResponse

    @POST("update_donor_password.php")
    suspend fun updatePassword(@Body request: UpdateDonorPasswordRequest): UpdateDonorPasswordResponse
}

object DonorProfileApiClient {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: DonorProfileApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DonorProfileApiService::class.java)
    }
}

