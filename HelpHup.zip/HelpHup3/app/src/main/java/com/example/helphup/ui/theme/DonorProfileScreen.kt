package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.util.Log

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorProfileScreen(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val scope = rememberCoroutineScope()
    
    // Load user data from session initially
    var fullName by remember { mutableStateOf(sessionManager.getDonorFullName()) }
    var email by remember { mutableStateOf(sessionManager.getDonorEmail()) }
    var phone by remember { mutableStateOf(sessionManager.getDonorPhone()) }
    var address by remember { mutableStateOf(sessionManager.getDonorAddress()) }
    
    var isLoading by remember { mutableStateOf(false) }
    
    // Function to load profile data from API
    fun loadProfileData() {
        scope.launch {
            // First, load from session
            fullName = sessionManager.getDonorFullName()
            email = sessionManager.getDonorEmail()
            phone = sessionManager.getDonorPhone()
            address = sessionManager.getDonorAddress()
            
            // Then try to fetch from API to get latest data
            val donorId = sessionManager.getDonorId()
            if (donorId > 0) {
                isLoading = true
                try {
                    val response = DonorProfileApiClient.api.getProfile(
                        GetDonorProfileRequest(donorId)
                    )
                    if (response.status && response.data != null) {
                        val data = response.data
                        fullName = data.fullName
                        email = data.email
                        phone = data.phone
                        address = data.address
                        
                        // Update session with full data from API
                        sessionManager.saveDonorSession(data.donorId, data.fullName, data.email)
                        sessionManager.saveDonorProfileData(data.phone, data.address)
                    }
                } catch (e: Exception) {
                    Log.e("DonorProfile", "API call failed: ${e.message}", e)
                } finally {
                    isLoading = false
                }
            }
        }
    }
    
    // Load profile data when screen opens
    LaunchedEffect(Unit) {
        loadProfileData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Donor Profile", fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F9FF))
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            // Profile Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Profile",
                        tint = Color(0xFF22C55E),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = fullName,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    Text(
                        text = "Active Donor",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Personal Information - Read-only display of registration data
            Text(
                text = "Personal Information",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Full Name - Read-only
                    Column {
                        Text(
                            text = "Full Name",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (fullName.isNotBlank()) fullName else "Not set",
                            fontSize = 16.sp,
                            color = if (fullName.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Email - Read-only
                    Column {
                        Text(
                            text = "Email Address",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (email.isNotBlank()) email else "Not set",
                            fontSize = 16.sp,
                            color = if (email.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Phone - Read-only
                    Column {
                        Text(
                            text = "Phone Number",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (phone.isNotBlank()) phone else "Not set",
                            fontSize = 16.sp,
                            color = if (phone.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Address - Read-only
                    Column {
                        Text(
                            text = "Address",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (address.isNotBlank()) address else "Not set",
                            fontSize = 16.sp,
                            color = if (address.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Account Actions
            Text(
                text = "Account Actions",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E40AF)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { /* Handle change password */ }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Change Password",
                            tint = Color(0xFF3B82F6),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "Change Password",
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowRight,
                            contentDescription = "Arrow",
                            tint = Color.Gray
                        )
                    }

                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { navController.navigate(Routes.DONOR_EDIT_DETAILS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Edit Details", color = Color(0xFF3B82F6))
                }
                
                OutlinedButton(
                    onClick = { navController.navigate(Routes.DONOR_CHANGE_PASSWORD) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Change Password", color = Color(0xFF3B82F6))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    sessionManager.clearSession()
                    navController.navigate(Routes.DONOR_LOGIN) {
                        popUpTo(Routes.DONOR_PROFILE) { inclusive = true }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Logout",
                    color = Color.White
                )
            }
        }
    }
}
