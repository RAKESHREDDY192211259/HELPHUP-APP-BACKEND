package com.example.helphup.ui.theme

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.platform.LocalContext
import com.example.helphup.utils.UserSessionManager
import com.example.helphup.ui.theme.ValidationUtils
import com.example.helphup.ui.data.UnifiedApiResponse
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* ===================== API MODELS ===================== */

data class UnifiedDonorHelpRequest(
    @SerializedName("requester_type") val requesterType: String = "donor",
    @SerializedName("requester_id") val requesterId: Int,
    @SerializedName("requester_name") val requesterName: String,
    @SerializedName("requester_email") val requesterEmail: String,
    @SerializedName("requester_phone") val requesterPhone: String,
    @SerializedName("request_title") val requestTitle: String,
    @SerializedName("category") val category: String,
    @SerializedName("description") val description: String,
    @SerializedName("urgency_level") val urgencyLevel: String,
    // Donor specific fields
    @SerializedName("fundraising_goal") val fundraisingGoal: String?,
    @SerializedName("duration") val duration: String?,
    @SerializedName("end_date") val endDate: String?,
    @SerializedName("beneficiary_name") val beneficiaryName: String?,
    @SerializedName("relationship") val relationship: String?,
    @SerializedName("contact_email") val contactEmail: String?,
    @SerializedName("cover_image_url") val coverImageUrl: String?,
    @SerializedName("video_url") val videoUrl: String?
)

/* ===================== RETROFIT ===================== */

interface DonorUnifiedApi {
    @POST("unified_create_help_request.php")
    suspend fun raiseHelp(
        @Body request: UnifiedDonorHelpRequest
    ): UnifiedApiResponse
}

object DonorRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"
    val api: DonorUnifiedApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DonorUnifiedApi::class.java)
    }
}

/* ===================== SCREEN ===================== */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorRaiseDonationScreen(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }

    var campaignTitle by remember { mutableStateOf("") }
    var fundraisingGoal by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Medical") }
    var description by remember { mutableStateOf("") }
    var urgencyLevel by remember { mutableStateOf("Medium") }
    var videoUrl by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("30 days") }
    var endDate by remember { mutableStateOf("") }
    var beneficiaryName by remember { mutableStateOf("") }
    var relationship by remember { mutableStateOf("Self") }
    var contactEmail by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    
    // Validation error messages
    var beneficiaryNameError by remember { mutableStateOf("") }
    var contactEmailError by remember { mutableStateOf("") }
    var countryCodeError by remember { mutableStateOf("") }
    var phoneNumberError by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> selectedImageUri = uri }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Create Campaign", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Section("Campaign Details", Icons.Outlined.Info) {
                OutlinedTextField(campaignTitle, { campaignTitle = it }, label = { Text("Campaign Title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = fundraisingGoal,
                    onValueChange = { 
                        // Only allow digits
                        fundraisingGoal = it.filter { char -> char.isDigit() }
                    },
                    label = { Text("Fundraising Goal (INR)") },
                    prefix = { Text("₹", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    placeholder = { Text("Enter amount in INR") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Dropdown("Category", listOf("Medical", "Education", "Disaster", "Food Distribution", "Clothing & Essentials", "Shelter", "Other"), category) { category = it }
                Spacer(Modifier.height(12.dp))
                Text("Urgency Level", fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Low", "Medium", "High", "Critical").forEach { level ->
                        FilterChip(
                            selected = urgencyLevel == level,
                            onClick = { urgencyLevel = level },
                            label = { Text(level) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    maxLines = 5
                )
            }

            Section("Campaign Media", Icons.Outlined.Photo) {
                ImageBox(selectedImageUri) { imagePicker.launch("image/*") }
                OutlinedTextField(videoUrl, { videoUrl = it }, label = { Text("Video URL (Optional)") }, modifier = Modifier.fillMaxWidth())
            }

            Section("Timeline", Icons.Outlined.DateRange) {
                Dropdown("Duration", listOf("15 days", "30 days", "45 days"), duration) { duration = it }
                DatePickerField(
                    label = "End Date",
                    selectedDate = endDate,
                    onDateSelected = { endDate = it },
                    modifier = Modifier.fillMaxWidth(),
                    allowPastDates = false
                )
            }

            Section("Beneficiary Details", Icons.Outlined.Person) {
                OutlinedTextField(
                    value = beneficiaryName,
                    onValueChange = { 
                        beneficiaryName = it
                        beneficiaryNameError = ""
                    },
                    label = { Text("Beneficiary Full Name") },
                    isError = beneficiaryNameError.isNotEmpty(),
                    supportingText = if (beneficiaryNameError.isNotEmpty()) {
                        { Text(beneficiaryNameError, color = Color(0xFFEF4444)) }
                    } else null,
                    modifier = Modifier.fillMaxWidth()
                )
                Dropdown("Relationship", listOf("Self", "Family", "Other"), relationship) { relationship = it }
                OutlinedTextField(
                    value = contactEmail,
                    onValueChange = { 
                        contactEmail = it
                        contactEmailError = ""
                    },
                    label = { Text("Contact Email") },
                    isError = contactEmailError.isNotEmpty(),
                    supportingText = if (contactEmailError.isNotEmpty()) {
                        { Text(contactEmailError, color = Color(0xFFEF4444)) }
                    } else null,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(Modifier.height(12.dp))
                
                // Phone Number Field with Country Code
                PhoneNumberField(
                    countryCode = countryCode,
                    phoneNumber = phoneNumber,
                    onCountryCodeChange = { 
                        countryCode = it
                        countryCodeError = ""
                    },
                    onPhoneNumberChange = { 
                        phoneNumber = it
                        phoneNumberError = ""
                    },
                    errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneNumberError,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (errorMessage.isNotEmpty()) {
                Text(errorMessage, color = Color.Red)
            }

            Button(
                onClick = {
                    // Clear previous errors
                    errorMessage = ""
                    beneficiaryNameError = ""
                    contactEmailError = ""
                    countryCodeError = ""
                    phoneNumberError = ""
                    
                    // Validate beneficiary name and email
                    val beneficiaryNameValidation = ValidationUtils.validateFullName(beneficiaryName)
                    val contactEmailValidation = ValidationUtils.validateEmail(contactEmail)
                    
                    // Validate phone number
                    val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
                    val phoneNumberValidation = ValidationUtils.validatePhoneNumber(phoneNumber)
                    
                    if (!beneficiaryNameValidation.isValid) beneficiaryNameError = beneficiaryNameValidation.errorMessage
                    if (!contactEmailValidation.isValid) contactEmailError = contactEmailValidation.errorMessage
                    if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
                    if (!phoneNumberValidation.isValid) phoneNumberError = phoneNumberValidation.errorMessage
                    
                    if (campaignTitle.isBlank() || fundraisingGoal.isBlank() || endDate.isBlank() ||
                        description.isBlank() || !beneficiaryNameValidation.isValid || 
                        !contactEmailValidation.isValid || !countryCodeValidation.isValid || 
                        !phoneNumberValidation.isValid) {
                        errorMessage = "Please fill all required fields correctly"
                        return@Button
                    }

                    scope.launch {
                        isLoading = true
                        try {
                            val donorId = sessionManager.getDonorId()
                            val donorName = sessionManager.getDonorFullName()
                            val donorEmail = sessionManager.getDonorEmail()
                            val donorPhone = sessionManager.getDonorPhone()
                            
                            val response = DonorRetrofitInstance.api.raiseHelp(
                                UnifiedDonorHelpRequest(
                                    requesterType = "donor",
                                    requesterId = donorId,
                                    requesterName = donorName.ifBlank { "Donor $donorId" },
                                    requesterEmail = donorEmail.ifBlank { "donor$donorId@example.com" },
                                    requesterPhone = donorPhone.ifBlank { "$countryCode$phoneNumber" },
                                    requestTitle = campaignTitle,
                                    category = category,
                                    description = description,
                                    urgencyLevel = urgencyLevel,
                                    fundraisingGoal = fundraisingGoal.ifBlank { null },
                                    duration = duration.ifBlank { null },
                                    endDate = endDate.ifBlank { null },
                                    beneficiaryName = beneficiaryName.ifBlank { null },
                                    relationship = relationship.ifBlank { null },
                                    contactEmail = contactEmail.ifBlank { null },
                                    coverImageUrl = selectedImageUri?.toString(),
                                    videoUrl = videoUrl.ifBlank { null }
                                )
                            )
                            if (response.status) {
                                navController.popBackStack()
                            } else {
                                errorMessage = response.message
                            }
                        } catch (e: Exception) {
                            errorMessage = e.message ?: "Network error"
                        } finally {
                            isLoading = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                if (isLoading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                else Text("Create Campaign")
            }
        }
    }
}

/* ===================== UI HELPERS ===================== */

@Composable
fun Section(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
        colors = CardDefaults.cardColors(Color.White)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Color(0xFF10B981))
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Dropdown(label: String, options: List<String>, value: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text(label) }, trailingIcon = {
            ExposedDropdownMenuDefaults.TrailingIcon(expanded)
        }, modifier = Modifier.fillMaxWidth().menuAnchor())
        ExposedDropdownMenu(expanded, { expanded = false }) {
            options.forEach {
                DropdownMenuItem(text = { Text(it) }, onClick = { onSelect(it); expanded = false })
            }
        }
    }
}

@Composable
fun ImageBox(uri: Uri?, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Color.LightGray)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (uri == null) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.CloudUpload, null, tint = Color(0xFF10B981))
                Text("Upload Image")
            }
        } else {
            Text("Image Selected", color = Color.Gray)
        }
    }
}
