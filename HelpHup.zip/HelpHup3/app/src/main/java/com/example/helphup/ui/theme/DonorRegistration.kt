package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* -------------------- API MODELS -------------------- */

data class DonorRegisterRequest(
    val full_name: String,
    val phone: String,
    val email: String,
    val address: String,
    val password: String
)

data class DonorRegisterResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- API SERVICE -------------------- */

interface DonorRegisterApi {
    @POST("donor_register.php")
    suspend fun register(@Body request: DonorRegisterRequest): DonorRegisterResponse
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object DonorRegisterRetrofit {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: DonorRegisterApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DonorRegisterApi::class.java)
    }
}

/* -------------------- UI SCREEN -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorRegistration(navController: NavController) {

    var fullName by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }

    // Validation error messages
    var fullNameError by remember { mutableStateOf("") }
    var countryCodeError by remember { mutableStateOf("") }
    var phoneNumberError by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf("") }
    var confirmPasswordError by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Register as Donor", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate("donor_login") }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(16.dp))

            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = null,
                tint = Color(0xFF22C55E),
                modifier = Modifier.size(48.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Register as Donor",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Text(
                text = "Your generosity can change lives",
                fontSize = 14.sp,
                color = Color(0xFF6B7280)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Full Name Field
            OutlinedTextField(
                value = fullName,
                onValueChange = { 
                    fullName = it
                    fullNameError = ""
                },
                label = { Text("Full Name") },
                isError = fullNameError.isNotEmpty(),
                supportingText = if (fullNameError.isNotEmpty()) {
                    { Text(fullNameError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Phone Number Field with Country Code
            PhoneNumberField(
                countryCode = countryCode,
                phoneNumber = phoneNumber,
                onCountryCodeChange = { 
                    countryCode = it
                    countryCodeError = ""
                },
                onPhoneNumberChange = { 
                    phoneNumber = it
                    phoneNumberError = ""
                },
                errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneNumberError,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Email Field
            OutlinedTextField(
                value = email,
                onValueChange = { 
                    email = it
                    emailError = ""
                },
                label = { Text("Email Address") },
                isError = emailError.isNotEmpty(),
                supportingText = if (emailError.isNotEmpty()) {
                    { Text(emailError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Address Field
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Password Field
            OutlinedTextField(
                value = password,
                onValueChange = { 
                    password = it
                    passwordError = ""
                },
                label = { Text("Password") },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                isError = passwordError.isNotEmpty(),
                supportingText = if (passwordError.isNotEmpty()) {
                    { Text(passwordError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Confirm Password Field
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { 
                    confirmPassword = it
                    confirmPasswordError = ""
                },
                label = { Text("Confirm Password") },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                        Icon(
                            if (confirmPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                isError = confirmPasswordError.isNotEmpty(),
                supportingText = if (confirmPasswordError.isNotEmpty()) {
                    { Text(confirmPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (errorMessage.isNotEmpty()) {
                Text(errorMessage, color = Color.Red)
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (successMessage.isNotEmpty()) {
                Text(successMessage, color = Color(0xFF16A34A))
                Spacer(modifier = Modifier.height(8.dp))
            }

            Button(
                onClick = {
                    // Clear previous errors
                    fullNameError = ""
                    countryCodeError = ""
                    phoneNumberError = ""
                    emailError = ""
                    passwordError = ""
                    confirmPasswordError = ""
                    errorMessage = ""

                    // Validate all fields
                    val fullNameValidation = ValidationUtils.validateFullName(fullName)
                    val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
                    val phoneNumberValidation = ValidationUtils.validatePhoneNumber(phoneNumber)
                    val emailValidation = ValidationUtils.validateEmail(email)
                    val passwordValidation = ValidationUtils.validatePassword(password)
                    val confirmPasswordValidation = ValidationUtils.validateConfirmPassword(password, confirmPassword)

                    // Set error messages
                    if (!fullNameValidation.isValid) fullNameError = fullNameValidation.errorMessage
                    if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
                    if (!phoneNumberValidation.isValid) phoneNumberError = phoneNumberValidation.errorMessage
                    if (!emailValidation.isValid) emailError = emailValidation.errorMessage
                    if (!passwordValidation.isValid) passwordError = passwordValidation.errorMessage
                    if (!confirmPasswordValidation.isValid) confirmPasswordError = confirmPasswordValidation.errorMessage

                    // Check if address is blank
                    if (address.isBlank()) {
                        errorMessage = "Please fill all fields"
                    }

                    // If all validations pass, submit form
                    if (fullNameValidation.isValid &&
                        countryCodeValidation.isValid &&
                        phoneNumberValidation.isValid &&
                        emailValidation.isValid &&
                        passwordValidation.isValid &&
                        confirmPasswordValidation.isValid &&
                        address.isNotBlank()
                    ) {
                        errorMessage = ""
                        isLoading = true

                        scope.launch {
                            try {
                                // Combine country code with phone number
                                val fullPhoneNumber = "$countryCode$phoneNumber"
                                
                                val response =
                                    DonorRegisterRetrofit.api.register(
                                        DonorRegisterRequest(
                                            full_name = fullName,
                                            phone = fullPhoneNumber,
                                            email = email,
                                            address = address,
                                            password = password
                                        )
                                    )

                                if (response.status) {
                                    successMessage = response.message
                                    navController.navigate("donor_login") {
                                        popUpTo("donor_login") { inclusive = true }
                                    }
                                } else {
                                    errorMessage = response.message
                                }
                            } catch (e: Exception) {
                                val errorMsg = e.message ?: "Unknown error"
                                errorMessage = when {
                                    errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                                    errorMsg.contains("Unable to resolve host") -> "Connection error: Cannot find server\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                                    errorMsg.contains("Connection reset") || errorMsg.contains("connection reset") -> "Connection error: Connection reset\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                                    errorMsg.contains("timeout") -> "Connection error: Connection timeout\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                                    errorMsg.contains("Network is unreachable") -> "Connection error: Network unreachable\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                                    else -> "Connection error: $errorMsg\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                                }
                                e.printStackTrace()
                            } finally {
                                isLoading = false
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3B82F6)
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = Color.White,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Creating Account...", color = Color.White)
                } else {
                    Text("Create Account", color = Color.White)
                }
            }
        }
    }
}
