package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import kotlinx.coroutines.launch

// ==================== Constants ====================

private object DonorConfirmationConstants {
    // Colors
    val BackgroundColor = Color(0xFFF0FDF4)
    val CardBackgroundColor = Color.White
    val PrimaryColor = Color(0xFF22C55E)
    val SuccessBackgroundColor = Color(0xFFD1FAE5)
    val TextPrimary = Color(0xFF1F2937)
    val TextSecondary = Color(0xFF6B7280)
    val DarkGreen = Color(0xFF14532D)
    
    // Spacing
    val PaddingSmall = 8.dp
    val PaddingMedium = 16.dp
    val PaddingLarge = 20.dp
    val PaddingExtraLarge = 24.dp
    
    // Sizes
    val SuccessIconSize = 80.dp
    val IconSize = 24.dp
    val ButtonHeight = 52.dp
    
    // Text Sizes
    val TitleSize = 28.sp
    val SubtitleSize = 14.sp
    val BodySize = 16.sp
    val SectionTitleSize = 18.sp
    val ButtonTextSize = 16.sp
}

// ==================== Main Screen ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorSupportConfirmation(
    navController: NavController,
    requestType: String = "",
    requestId: String = "",
    amount: String = "100",
    method: String = "CARD"
) {
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    // Save donation to backend when screen loads
    LaunchedEffect(Unit) {
        scope.launch {
            isLoading = true
            errorMessage = null
            try {
                // TODO: Get actual donor_id from session/preferences
                // For now, using default value 1
                val donorId = 1
                
                val request = SaveDonationRequest(
                    donorId = donorId,
                    ngoId = null, // Community support donations go to NGO cause
                    amount = amount.toDouble(),
                    paymentMethod = method,
                    paymentStatus = "completed",
                    description = "Community support donation"
                )
                
                val response = PaymentRetrofitInstance.api.saveDonation(request)
                if (!response.status) {
                    errorMessage = response.message
                }
            } catch (e: Exception) {
                errorMessage = "Failed to save donation: ${e.message}"
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
    
    Scaffold(
        containerColor = DonorConfirmationConstants.BackgroundColor
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(DonorConfirmationConstants.BackgroundColor)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Section
            BackButtonSection(
                onBackClick = { navController.popBackStack() }
            )
            
            Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingLarge))
            
            // Show loading or error state
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
                Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingLarge))
            }
            
            if (errorMessage != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = DonorConfirmationConstants.PaddingLarge),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFFFEBEE)
                    )
                ) {
                    Text(
                        text = errorMessage ?: "",
                        modifier = Modifier.padding(DonorConfirmationConstants.PaddingMedium),
                        color = Color(0xFFC62828)
                    )
                }
                Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingMedium))
            }
            
            // Success Content
            SuccessContent()
            
            Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingExtraLarge))
            
            // What's Next Card
            WhatsNextCard()
            
            Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingExtraLarge))
            
            // Action Buttons
            ActionButtons(
                onBackToDashboard = { navController.navigate(Routes.DONOR_DASHBOARD) }
            )
            
            Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingLarge))
        }
    }
}

// ==================== Header Components ====================

@Composable
private fun BackButtonSection(onBackClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(DonorConfirmationConstants.PaddingMedium),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onBackClick,
            colors = ButtonDefaults.textButtonColors(
                contentColor = DonorConfirmationConstants.PrimaryColor
            )
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "BACK",
                fontSize = DonorConfirmationConstants.SubtitleSize,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==================== Success Content ====================

@Composable
private fun SuccessContent() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DonorConfirmationConstants.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Success Icon
        Box(
            modifier = Modifier
                .size(DonorConfirmationConstants.SuccessIconSize)
                .background(
                    DonorConfirmationConstants.SuccessBackgroundColor,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = DonorConfirmationConstants.PrimaryColor,
                modifier = Modifier.size(48.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingExtraLarge))
        
        // Title
        Text(
            text = "Thank You!",
            fontSize = DonorConfirmationConstants.TitleSize,
            fontWeight = FontWeight.Bold,
            color = DonorConfirmationConstants.DarkGreen,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingMedium))
        
        // Subtitle
        Text(
            text = "Your donation has been successfully processed",
            fontSize = DonorConfirmationConstants.BodySize,
            color = Color.DarkGray,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingSmall))
        
        // Additional Info
        Text(
            text = "You'll receive a receipt via email shortly",
            fontSize = DonorConfirmationConstants.SubtitleSize,
            color = DonorConfirmationConstants.TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

// ==================== What's Next Card ====================

@Composable
private fun WhatsNextCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DonorConfirmationConstants.PaddingLarge),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = DonorConfirmationConstants.CardBackgroundColor
        ),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(
            modifier = Modifier.padding(DonorConfirmationConstants.PaddingLarge)
        ) {
            // Title
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = null,
                    tint = DonorConfirmationConstants.PrimaryColor,
                    modifier = Modifier.size(DonorConfirmationConstants.IconSize)
                )
                Spacer(modifier = Modifier.width(DonorConfirmationConstants.PaddingSmall))
                Text(
                    text = "What's Next?",
                    fontSize = DonorConfirmationConstants.SectionTitleSize,
                    fontWeight = FontWeight.Bold,
                    color = DonorConfirmationConstants.DarkGreen
                )
            }
            
            Spacer(modifier = Modifier.height(DonorConfirmationConstants.PaddingMedium))
            
            // Steps
            NextStepItem(
                icon = Icons.Default.Email,
                text = "Receipt sent to your email"
            )
            NextStepItem(
                icon = Icons.Default.Verified,
                text = "Your donation is being processed"
            )
            NextStepItem(
                icon = Icons.Default.Schedule,
                text = "Impact report available in 2-3 days"
            )
            NextStepItem(
                icon = Icons.Default.Phone,
                text = "Thank you for making a difference!"
            )
        }
    }
}

@Composable
private fun NextStepItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = DonorConfirmationConstants.PaddingSmall),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = DonorConfirmationConstants.PrimaryColor,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(DonorConfirmationConstants.PaddingMedium))
        Text(
            text = text,
            fontSize = DonorConfirmationConstants.SubtitleSize,
            color = DonorConfirmationConstants.TextSecondary,
            lineHeight = 20.sp
        )
    }
}

// ==================== Action Buttons ====================

@Composable
private fun ActionButtons(onBackToDashboard: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = DonorConfirmationConstants.PaddingLarge)
    ) {
        Button(
            onClick = onBackToDashboard,
            modifier = Modifier
                .fillMaxWidth()
                .height(DonorConfirmationConstants.ButtonHeight),
            colors = ButtonDefaults.buttonColors(
                containerColor = DonorConfirmationConstants.PrimaryColor
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = "Back to Dashboard",
                fontSize = DonorConfirmationConstants.ButtonTextSize,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
