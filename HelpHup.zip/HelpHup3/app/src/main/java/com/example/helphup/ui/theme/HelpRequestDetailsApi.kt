package com.example.helphup.ui.theme

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

/* -------------------- DATA MODELS -------------------- */

data class HelpRequestDetailsItem(
    @SerializedName("request_id") val requestId: Int,
    @SerializedName("requester_type") val requesterType: String,
    @SerializedName("requester_id") val requesterId: Int,
    @SerializedName("requester_name") val requesterName: String,
    @SerializedName("requester_email") val requesterEmail: String,
    @SerializedName("requester_phone") val requesterPhone: String,
    @SerializedName("request_title") val requestTitle: String,
    @SerializedName("category") val category: String,
    @SerializedName("description") val description: String,
    @SerializedName("urgency_level") val urgencyLevel: String,
    @SerializedName("required_amount") val requiredAmount: Double?,
    @SerializedName("date_needed") val dateNeeded: String?,
    @SerializedName("contact_number") val contactNumber: String?,
    @SerializedName("location") val location: String?,
    @SerializedName("help_date") val helpDate: String?,
    @SerializedName("start_time") val startTime: String?,
    @SerializedName("volunteers_needed") val volunteersNeeded: Int?,
    @SerializedName("fundraising_goal") val fundraisingGoal: Double?,
    @SerializedName("duration") val duration: String?,
    @SerializedName("end_date") val endDate: String?,
    @SerializedName("beneficiary_name") val beneficiaryName: String?,
    @SerializedName("relationship") val relationship: String?,
    @SerializedName("contact_email") val contactEmail: String?,
    @SerializedName("cover_image_url") val coverImageUrl: String?,
    @SerializedName("video_url") val videoUrl: String?,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("created_at_formatted") val createdAtFormatted: String? = null
)

data class HelpRequestDetailsResponse(
    val status: Boolean,
    val message: String,
    val data: HelpRequestDetailsItem?
)

/* -------------------- API SERVICE -------------------- */

interface HelpRequestDetailsApi {
    @GET("get_request_details.php")
    suspend fun getRequestDetails(@Query("request_id") requestId: Int): HelpRequestDetailsResponse
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object HelpRequestDetailsRetrofit {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: HelpRequestDetailsApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(HelpRequestDetailsApi::class.java)
    }
}
