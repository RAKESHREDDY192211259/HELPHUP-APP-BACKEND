package com.example.helphup.ui.theme

import android.content.Context
import android.net.Uri
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

fun uploadMultipart(
    context: Context,
    urlStr: String,
    params: Map<String, String>,
    fileUri: Uri
): String {

    val boundary = UUID.randomUUID().toString()
    val lineEnd = "\r\n"
    val twoHyphens = "--"

    val url = URL(urlStr)
    val connection = url.openConnection() as HttpURLConnection
    
    // Set connection timeout
    connection.connectTimeout = 10000 // 10 seconds
    connection.readTimeout = 10000 // 10 seconds

    connection.requestMethod = "POST"
    connection.doInput = true
    connection.doOutput = true
    connection.useCaches = false
    connection.setRequestProperty(
        "Content-Type",
        "multipart/form-data; boundary=$boundary"
    )

    val outputStream = DataOutputStream(connection.outputStream)

    // ---- Text fields ----
    for ((key, value) in params) {
        outputStream.writeBytes(twoHyphens + boundary + lineEnd)
        outputStream.writeBytes(
            "Content-Disposition: form-data; name=\"$key\"$lineEnd$lineEnd"
        )
        outputStream.writeBytes(value + lineEnd)
    }

    // ---- File field ----
    outputStream.writeBytes(twoHyphens + boundary + lineEnd)
    outputStream.writeBytes(
        "Content-Disposition: form-data; name=\"reg_proof\"; filename=\"proof\"$lineEnd"
    )
    outputStream.writeBytes("Content-Type: application/octet-stream$lineEnd$lineEnd")

    val inputStream = context.contentResolver.openInputStream(fileUri)
        ?: throw Exception("Unable to read file")

    inputStream.use { input ->
        val buffer = ByteArray(4096)
        var bytesRead: Int
        while (input.read(buffer).also { bytesRead = it } != -1) {
            outputStream.write(buffer, 0, bytesRead)
        }
    }

    outputStream.writeBytes(lineEnd)
    outputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd)

    outputStream.flush()
    outputStream.close()

    val responseCode = connection.responseCode
    val responseStream =
        if (responseCode in 200..299)
            connection.inputStream
        else
            connection.errorStream

    val response = responseStream.bufferedReader().use { it.readText() }
    
    if (responseCode !in 200..299) {
        throw Exception("HTTP $responseCode: $response")
    }
    
    return response
}
