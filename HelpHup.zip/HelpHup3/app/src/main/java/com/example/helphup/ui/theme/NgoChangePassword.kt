package com.example.helphup.ui.theme

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.helphup.ui.theme.ValidationUtils
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoChangePasswordScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val scope = rememberCoroutineScope()
    
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    
    // Password visibility states
    var currentPasswordVisible by remember { mutableStateOf(false) }
    var newPasswordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    
    // Validation error messages
    var newPasswordError by remember { mutableStateOf("") }
    var confirmPasswordError by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Change Password") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            OutlinedTextField(
                value = currentPassword,
                onValueChange = { currentPassword = it },
                label = { Text("Current Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                visualTransformation = if (currentPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { currentPasswordVisible = !currentPasswordVisible }) {
                        Icon(
                            if (currentPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = newPassword,
                onValueChange = { 
                    newPassword = it
                    newPasswordError = ""
                },
                label = { Text("New Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                visualTransformation = if (newPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { newPasswordVisible = !newPasswordVisible }) {
                        Icon(
                            if (newPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                isError = newPasswordError.isNotEmpty(),
                supportingText = if (newPasswordError.isNotEmpty()) {
                    { Text(newPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { 
                    confirmPassword = it
                    confirmPasswordError = ""
                },
                label = { Text("Confirm New Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                        Icon(
                            if (confirmPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                isError = confirmPasswordError.isNotEmpty(),
                supportingText = if (confirmPasswordError.isNotEmpty()) {
                    { Text(confirmPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )
            
            if (isLoading) {
                CircularProgressIndicator()
            }
            
            if (errorMessage.isNotEmpty()) {
                Text(errorMessage, color = Color(0xFFEF4444))
            }
            
            if (successMessage.isNotEmpty()) {
                Text(successMessage, color = Color(0xFF22C55E))
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    // Clear previous errors
                    newPasswordError = ""
                    confirmPasswordError = ""
                    errorMessage = ""
                    successMessage = ""
                    
                    // Validate all fields
                    val newPasswordValidation = ValidationUtils.validatePassword(newPassword)
                    val confirmPasswordValidation = ValidationUtils.validateConfirmPassword(newPassword, confirmPassword)
                    
                    // Set error messages
                    if (!newPasswordValidation.isValid) newPasswordError = newPasswordValidation.errorMessage
                    if (!confirmPasswordValidation.isValid) confirmPasswordError = confirmPasswordValidation.errorMessage
                    
                    // Check if current password is filled
                    if (currentPassword.isBlank()) {
                        errorMessage = "Please enter your current password"
                    }
                    
                    // Check if new password is different from current password
                    if (currentPassword.isNotBlank() && newPassword == currentPassword) {
                        errorMessage = "New password must be different from current password"
                    }
                    
                    // If all validations pass, update password
                    if (currentPassword.isNotBlank() &&
                        newPasswordValidation.isValid &&
                        confirmPasswordValidation.isValid &&
                        newPassword != currentPassword) {
                        
                        scope.launch {
                            isLoading = true
                            try {
                                val ngoId = sessionManager.getNgoId()
                                val response = NgoProfileApiClient.api.updatePassword(
                                    UpdateNgoPasswordRequest(
                                        ngoId = ngoId,
                                        currentPassword = currentPassword,
                                        newPassword = newPassword
                                    )
                                )
                                
                                if (response.status) {
                                    successMessage = "Password updated successfully"
                                    // Navigate back after short delay
                                    kotlinx.coroutines.delay(1000)
                                    navController.popBackStack()
                                } else {
                                    errorMessage = response.message
                                }
                            } catch (e: Exception) {
                                errorMessage = "Failed to update password: ${e.message}"
                            } finally {
                                isLoading = false
                            }
                        }
                    }
                },
                enabled = !isLoading,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22C55E)
                )
            ) {
                Text("Update Password")
            }
        }
    }
}
