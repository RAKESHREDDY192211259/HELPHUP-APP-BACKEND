package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import android.util.Log
import com.example.helphup.ui.navigation.Routes

// ==================== Constants ====================

private object CommunitySupportConstants {
    // Colors
    val BackgroundColor = Color(0xFFF0FDF4)
    val CardBackgroundColor = Color.White
    val PrimaryColor = Color(0xFF22C55E)
    val IconBackgroundColor = Color(0xFFDFF6EA)
    val ImpactBackgroundColor = Color(0xFFDFF6EA)
    val TextPrimary = Color(0xFF1F2937)
    val TextSecondary = Color(0xFF6B7280)
    val BorderColor = Color(0xFFE5E7EB)
    val CustomRadioColor = Color(0xFFEC4899)
    
    // Spacing
    val PaddingSmall = 8.dp
    val PaddingMedium = 16.dp
    val PaddingLarge = 20.dp
    val PaddingExtraLarge = 24.dp
    
    // Sizes
    val IconSize = 64.dp
    val IconInnerSize = 32.dp
    val RadioButtonSize = 20.dp
    val RadioButtonInnerSize = 10.dp
    val ButtonHeight = 48.dp
    val PrimaryButtonHeight = 52.dp
    
    // Amounts
    val PredefinedAmounts = listOf(5, 10, 20, 50, 100)
    val DefaultAmount = 100
    val MealsPerRupee = 5 // ₹5 per family meal (in INR)
    
    // Text Sizes
    val TitleSize = 24.sp
    val SubtitleSize = 14.sp
    val SectionTitleSize = 18.sp
    val BodySize = 14.sp
    val ButtonTextSize = 16.sp
    val AmountTextSize = 15.sp
}

// ==================== Main Screen ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoCommunitySupport(
    navController: NavController,
    requestType: String = "",
    requestId: String = "",
    requestedAmount: String = "100"
) {
    var selectedAmount by remember { mutableStateOf(requestedAmount.toIntOrNull() ?: 100) }
    var isCustomSelected by remember { mutableStateOf(false) }
    var customAmount by remember { mutableStateOf("") }
    
    val currentAmount = if (isCustomSelected) selectedAmount else selectedAmount
    val familiesHelped = if (currentAmount > 0) (currentAmount / CommunitySupportConstants.MealsPerRupee) else 0

    Scaffold(
        containerColor = CommunitySupportConstants.BackgroundColor
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(CommunitySupportConstants.BackgroundColor)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Section
            BackButtonSection(
                onBackClick = { navController.popBackStack() }
            )
            
            Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingMedium))
            
            // Hero Section
            HeroSection()
            
            Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingExtraLarge))
            
            // Donation Card Section
            DonationCardSection(
                selectedAmount = selectedAmount,
                isCustomSelected = isCustomSelected,
                customAmount = customAmount,
                onAmountSelected = { amount ->
                    selectedAmount = amount
                    isCustomSelected = false
                },
                onCustomSelected = {
                    isCustomSelected = true
                    selectedAmount = 0
                },
                onCustomAmountChanged = { amount ->
                    customAmount = amount
                    selectedAmount = amount.toIntOrNull() ?: 0
                },
                currentAmount = currentAmount,
                familiesHelped = familiesHelped,
                onContinueClick = {
                    navController.navigate(
                        Routes.NGO_PAYMENT_METHODS + "/$requestType/$requestId/$currentAmount"
                    )
                }
            )
            
            Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingLarge))
        }
    }
}

// ==================== Header Components ====================

@Composable
private fun BackButtonSection(
    onBackClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(CommunitySupportConstants.PaddingMedium),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onBackClick,
            colors = ButtonDefaults.textButtonColors(
                contentColor = CommunitySupportConstants.PrimaryColor
            )
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "BACK",
                fontSize = CommunitySupportConstants.SubtitleSize,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==================== Hero Section ====================

@Composable
private fun HeroSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = CommunitySupportConstants.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Heart Icon
        SupportIcon()
        
        Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingMedium))
        
        // Title
        Text(
            text = "Community Support",
            fontSize = CommunitySupportConstants.TitleSize,
            fontWeight = FontWeight.Bold,
            color = CommunitySupportConstants.TextPrimary
        )
        
        Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingSmall))
        
        // Subtitle
        Text(
            text = "Support those in need",
            fontSize = CommunitySupportConstants.SubtitleSize,
            color = CommunitySupportConstants.TextSecondary
        )
    }
}

@Composable
private fun SupportIcon() {
    Box(
        modifier = Modifier
            .size(CommunitySupportConstants.IconSize)
            .background(
                CommunitySupportConstants.IconBackgroundColor,
                CircleShape
            )
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.FavoriteBorder,
            contentDescription = "Support Icon",
            tint = CommunitySupportConstants.PrimaryColor,
            modifier = Modifier.size(CommunitySupportConstants.IconInnerSize)
        )
    }
}

// ==================== Donation Card Section ====================

@Composable
private fun DonationCardSection(
    selectedAmount: Int,
    isCustomSelected: Boolean,
    customAmount: String,
    onAmountSelected: (Int) -> Unit,
    onCustomSelected: () -> Unit,
    onCustomAmountChanged: (String) -> Unit,
    currentAmount: Int,
    familiesHelped: Int,
    onContinueClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = CommunitySupportConstants.PaddingLarge),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = CommunitySupportConstants.CardBackgroundColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(CommunitySupportConstants.PaddingLarge)
        ) {
            // Section Title
            Text(
                text = "Select Amount",
                fontSize = CommunitySupportConstants.SectionTitleSize,
                fontWeight = FontWeight.Bold,
                color = CommunitySupportConstants.TextPrimary
            )
            
            Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingMedium))
            
            // Predefined Amount Buttons
            PredefinedAmountsRow(
                amounts = CommunitySupportConstants.PredefinedAmounts,
                selectedAmount = selectedAmount,
                isCustomSelected = isCustomSelected,
                onAmountClick = onAmountSelected
            )
            
            Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingMedium))
            
            // Custom Amount Option
            CustomAmountSection(
                isSelected = isCustomSelected,
                customAmount = customAmount,
                onCustomSelected = onCustomSelected,
                onCustomAmountChanged = onCustomAmountChanged
            )
            
            Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingLarge))
            
            // Impact Statement
            ImpactStatement(
                amount = currentAmount,
                familiesHelped = familiesHelped
            )
            
            Spacer(modifier = Modifier.height(CommunitySupportConstants.PaddingExtraLarge))
            
            // Continue Button
            ContinueButton(
                enabled = currentAmount > 0,
                onClick = onContinueClick
            )
        }
    }
}

// ==================== Amount Selection Components ====================

@Composable
private fun PredefinedAmountsRow(
    amounts: List<Int>,
    selectedAmount: Int,
    isCustomSelected: Boolean,
    onAmountClick: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        amounts.forEach { amount ->
            AmountButton(
                amount = amount,
                isSelected = selectedAmount == amount && !isCustomSelected,
                onClick = { onAmountClick(amount) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun AmountButton(
    amount: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(CommunitySupportConstants.ButtonHeight)
            .padding(horizontal = 4.dp)
            .background(
                if (isSelected) CommunitySupportConstants.PrimaryColor else Color.Transparent,
                RoundedCornerShape(10.dp)
            )
            .border(
                1.dp,
                if (isSelected) Color.Transparent else CommunitySupportConstants.BorderColor,
                RoundedCornerShape(10.dp)
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "₹${amount}",
            color = if (isSelected) Color.White else CommunitySupportConstants.TextPrimary,
            fontWeight = FontWeight.Medium,
            fontSize = CommunitySupportConstants.AmountTextSize
        )
    }
}

@Composable
private fun CustomAmountSection(
    isSelected: Boolean,
    customAmount: String,
    onCustomSelected: () -> Unit,
    onCustomAmountChanged: (String) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Radio Button Indicator
            CustomRadioButton(isSelected = isSelected)
            
            Spacer(modifier = Modifier.width(CommunitySupportConstants.PaddingSmall))
            
            // Custom Button
            OutlinedButton(
                onClick = onCustomSelected,
                modifier = Modifier
                    .weight(1f)
                    .height(CommunitySupportConstants.ButtonHeight),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (isSelected) 
                        CommunitySupportConstants.PrimaryColor 
                    else 
                        CommunitySupportConstants.TextSecondary
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) 
                        CommunitySupportConstants.PrimaryColor 
                    else 
                        CommunitySupportConstants.BorderColor
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = "Custom",
                    fontWeight = FontWeight.Medium
                )
            }
        }
        
        // Custom Amount Input
        if (isSelected) {
            Spacer(modifier = Modifier.height(12.dp))
            CustomAmountInput(
                value = customAmount,
                onValueChange = onCustomAmountChanged
            )
        }
    }
}

@Composable
private fun CustomRadioButton(isSelected: Boolean) {
    Box(
        modifier = Modifier
            .size(CommunitySupportConstants.RadioButtonSize)
            .background(
                if (isSelected) 
                    CommunitySupportConstants.CustomRadioColor 
                else 
                    Color.Transparent,
                CircleShape
            )
            .border(
                2.dp,
                CommunitySupportConstants.CustomRadioColor,
                CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(CommunitySupportConstants.RadioButtonInnerSize)
                    .background(Color.White, CircleShape)
            )
        }
    }
}

@Composable
private fun CustomAmountInput(
    value: String,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = { 
            // Only allow digits
            onValueChange(it.filter { char -> char.isDigit() })
        },
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Enter amount") },
        prefix = { 
            Text("₹", color = CommunitySupportConstants.TextSecondary) 
        },
        singleLine = true,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
        shape = RoundedCornerShape(10.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CommunitySupportConstants.PrimaryColor,
            unfocusedBorderColor = CommunitySupportConstants.BorderColor
        )
    )
}

// ==================== Impact Statement ====================

@Composable
private fun ImpactStatement(
    amount: Int,
    familiesHelped: Int
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                CommunitySupportConstants.ImpactBackgroundColor,
                RoundedCornerShape(12.dp)
            )
            .padding(CommunitySupportConstants.PaddingMedium)
    ) {
        Text(
            text = buildAnnotatedString {
                append("₹${amount} can provide meals for ")
                withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                    append("$familiesHelped")
                }
                append(" families.")
            },
            fontSize = CommunitySupportConstants.BodySize,
            color = CommunitySupportConstants.TextPrimary,
            lineHeight = 20.sp
        )
    }
}

// ==================== Action Button ====================

@Composable
private fun ContinueButton(
    enabled: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(CommunitySupportConstants.PrimaryButtonHeight),
        colors = ButtonDefaults.buttonColors(
            containerColor = CommunitySupportConstants.PrimaryColor,
            contentColor = Color.White,
            disabledContainerColor = CommunitySupportConstants.BorderColor,
            disabledContentColor = CommunitySupportConstants.TextSecondary
        ),
        shape = RoundedCornerShape(12.dp),
        enabled = enabled
    ) {
        Text(
            text = "Continue to Payment",
            fontSize = CommunitySupportConstants.ButtonTextSize,
            fontWeight = FontWeight.SemiBold
        )
    }
}
