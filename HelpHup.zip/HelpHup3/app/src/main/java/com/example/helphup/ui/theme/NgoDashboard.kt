package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoDashboard(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    
    fun handleLogout() {
        sessionManager.clearSession()
        navController.navigate(Routes.NGO_LOGIN) {
            popUpTo(Routes.NGO_DASHBOARD) { inclusive = true }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        bottomBar = { NgoBottomBar(navController) }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
        ) {

            /* ---------- Header ---------- */
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Row(verticalAlignment = Alignment.CenterVertically) {

                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0xFF22C55E), RoundedCornerShape(12.dp))
                            .padding(8.dp)
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "NGO Dashboard",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1F2937)
                        )
                        Text(
                            text = "Manage your organization",
                            fontSize = 14.sp,
                            color = Color(0xFF22C55E)
                        )
                    }
                }

                Row {
                    /* 🔔 Notifications */
                    IconButton(
                        onClick = {
                            navController.navigate(Routes.NGO_NOTIFICATIONS)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = Color(0xFF22C55E)
                        )
                    }
                    
                    /* 🚪 Logout */
                    IconButton(
                        onClick = { handleLogout() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Logout",
                            tint = Color(0xFFEF4444)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            /* ---------- Welcome Card ---------- */
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFE0F4E3), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "Welcome Back!",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = "What would you like to do today?")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            /* ---------- Dashboard Cards ---------- */

            DashboardCard(
                icon = Icons.Default.Add,
                title = "Raise Help Request",
                subtitle = "Create a new help request"
            ) {
                navController.navigate(Routes.NGO_RAISE_HELP)
            }

            DashboardCard(
                icon = Icons.Default.FavoriteBorder,
                title = "Help Others",
                subtitle = "Browse and support requests"
            ) {
                navController.navigate(Routes.NGO_HELP_OTHERS)
            }

            DashboardCard(
                icon = Icons.Default.AccountCircle,
                title = "Past Donors History",
                subtitle = "View donation records"
            ) {
                navController.navigate(Routes.NGO_DONORS_HISTORY)
            }

            DashboardCard(
                icon = Icons.Default.Person,
                title = "Past Volunteers History",
                subtitle = "View volunteer records"
            ) {
                navController.navigate(Routes.NGO_VOLUNTEER_HISTORY)
            }
        }
    }
}

/* ---------- Dashboard Card ---------- */
@Composable
fun DashboardCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(0xFF22C55E), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(text = subtitle, fontSize = 13.sp, color = Color(0xFF22C55E))
            }
        }
    }
}

/* ---------- Bottom Navigation ---------- */
@Composable
fun NgoBottomBar(navController: NavController) {

    NavigationBar {

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Routes.NGO_DASHBOARD) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Routes.NGO_RAISE_HELP) },
            icon = { Icon(Icons.Default.Add, contentDescription = "Raise Help") },
            label = { Text("Raise Help") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Routes.NGO_HELP_OTHERS) },
            icon = { Icon(Icons.Default.FavoriteBorder, contentDescription = "Help Others") },
            label = { Text("Help Others") }
        )

        NavigationBarItem(
            selected = false,
            onClick = {
                navController.navigate(Routes.NGO_PROFILE)
            },
            icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Profile") },
            label = { Text("Profile") }
        )
    }
}
