package com.example.helphup.ui.theme

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.theme.ValidationUtils
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoEditProfileScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val scope = rememberCoroutineScope()
    
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    
    // Load user data from session initially
    val loadedFullName = sessionManager.getNgoFullName()
    val loadedEmail = sessionManager.getNgoEmail()
    val loadedPhone = sessionManager.getNgoPhone()
    val loadedAddress = sessionManager.getNgoAddress()
    val loadedOrgName = sessionManager.getNgoOrgName()
    val loadedRegNumber = sessionManager.getNgoRegNumber()
    
    // Parse phone number from session data initially
    val initialPhoneParts = if (loadedPhone.isNotEmpty()) {
        when {
            loadedPhone.startsWith("+91") && loadedPhone.length > 3 -> {
                "+91" to loadedPhone.substring(3)
            }
            loadedPhone.startsWith("+1") && loadedPhone.length > 2 -> {
                "+1" to loadedPhone.substring(2)
            }
            loadedPhone.startsWith("+44") && loadedPhone.length > 3 -> {
                "+44" to loadedPhone.substring(3)
            }
            loadedPhone.startsWith("+") -> {
                val match = Regex("^(\\+\\d{1,4})(.+)$").find(loadedPhone)
                if (match != null) {
                    match.groupValues[1] to match.groupValues[2]
                } else {
                    "" to loadedPhone
                }
            }
            else -> {
                "" to loadedPhone
            }
        }
    } else {
        "" to ""
    }
    
    // Initialize state variables with session data
    var fullName by remember { mutableStateOf(loadedFullName) }
    var email by remember { mutableStateOf(loadedEmail) }
    var countryCode by remember { mutableStateOf(initialPhoneParts.first) }
    var phoneNumber by remember { mutableStateOf(initialPhoneParts.second) }
    var address by remember { mutableStateOf(loadedAddress) }
    var orgName by remember { mutableStateOf(loadedOrgName) }
    var regNumber by remember { mutableStateOf(loadedRegNumber) }
    
    Log.d("NgoEditProfile", "Initialized from session - Name: $loadedFullName, Email: $loadedEmail, Phone: $loadedPhone -> Code: ${initialPhoneParts.first}, Number: ${initialPhoneParts.second}, Address: $loadedAddress, Org: $loadedOrgName, Reg: $loadedRegNumber")
    
    // Fetch profile data from API when screen loads
    LaunchedEffect(Unit) {
        val ngoId = sessionManager.getNgoId()
        Log.d("NgoEditProfile", "Loading profile for NGO ID: $ngoId")
        if (ngoId > 0) {
            isLoading = true
            try {
                Log.d("NgoEditProfile", "Making API call to get profile data")
                val response = NgoProfileApiClient.api.getProfile(
                    GetNgoProfileRequest(ngoId)
                )
                Log.d("NgoEditProfile", "API response status: ${response.status}, message: ${response.message}")
                if (response.status && response.data != null) {
                    val data = response.data
                    Log.d("NgoEditProfile", "Profile data loaded: ${data.fullName}, ${data.email}")
                    // Update session with fetched data
                    sessionManager.saveNgoSession(data.ngoId, data.fullName, data.email)
                    sessionManager.saveNgoProfileData(data.phone, data.address, data.orgName, data.regNumber)
                    
                    // Update the state variables with loaded data
                    fullName = data.fullName
                    email = data.email
                    address = data.address
                    orgName = data.orgName
                    regNumber = data.regNumber
                    
                    // Parse phone number - handle +918296358137 format
                    val phoneParts = if (data.phone.isNotEmpty()) {
                        when {
                            data.phone.startsWith("+91") && data.phone.length > 3 -> {
                                "+91" to data.phone.substring(3)
                            }
                            data.phone.startsWith("+1") && data.phone.length > 2 -> {
                                "+1" to data.phone.substring(2)
                            }
                            data.phone.startsWith("+44") && data.phone.length > 3 -> {
                                "+44" to data.phone.substring(3)
                            }
                            data.phone.startsWith("+") -> {
                                // Try to extract country code (1-4 digits after +)
                                val match = Regex("^(\\+\\d{1,4})(.+)$").find(data.phone)
                                if (match != null) {
                                    match.groupValues[1] to match.groupValues[2]
                                } else {
                                    "" to data.phone
                                }
                            }
                            else -> {
                                "" to data.phone
                            }
                        }
                    } else {
                        "" to ""
                    }
                    countryCode = phoneParts.first
                    phoneNumber = phoneParts.second
                    
                    Log.d("NgoEditProfile", "Parsed phone - countryCode: $countryCode, phoneNumber: $phoneNumber")
                    
                } else {
                    Log.w("NgoEditProfile", "API returned error: ${response.message}")
                    // Don't show error if we have session data - just use session data
                    if (loadedFullName.isEmpty() && loadedEmail.isEmpty()) {
                        errorMessage = "Failed to load profile: ${response.message}"
                    }
                }
            } catch (e: Exception) {
                Log.e("NgoEditProfile", "Error loading profile: ${e.message}", e)
                // If API fails but we have session data, use session data
                // Only show error if we have no session data
                if (loadedFullName.isEmpty() && loadedEmail.isEmpty()) {
                    errorMessage = "Failed to load profile: ${e.message}"
                } else {
                    // Parse phone from session data
                    val phoneParts = if (loadedPhone.isNotEmpty()) {
                        when {
                            loadedPhone.startsWith("+91") && loadedPhone.length > 3 -> {
                                "+91" to loadedPhone.substring(3)
                            }
                            loadedPhone.startsWith("+1") && loadedPhone.length > 2 -> {
                                "+1" to loadedPhone.substring(2)
                            }
                            loadedPhone.startsWith("+44") && loadedPhone.length > 3 -> {
                                "+44" to loadedPhone.substring(3)
                            }
                            loadedPhone.startsWith("+") -> {
                                val match = Regex("^(\\+\\d{1,4})(.+)$").find(loadedPhone)
                                if (match != null) {
                                    match.groupValues[1] to match.groupValues[2]
                                } else {
                                    "" to loadedPhone
                                }
                            }
                            else -> {
                                "" to loadedPhone
                            }
                        }
                    } else {
                        "" to ""
                    }
                    countryCode = phoneParts.first
                    phoneNumber = phoneParts.second
                }
            } finally {
                isLoading = false
            }
        } else {
            Log.w("NgoEditProfile", "Invalid NGO ID: $ngoId")
            // If no valid ID, try to parse phone from session
            val phoneParts = if (loadedPhone.isNotEmpty()) {
                when {
                    loadedPhone.startsWith("+91") && loadedPhone.length > 3 -> {
                        "+91" to loadedPhone.substring(3)
                    }
                    loadedPhone.startsWith("+1") && loadedPhone.length > 2 -> {
                        "+1" to loadedPhone.substring(2)
                    }
                    loadedPhone.startsWith("+44") && loadedPhone.length > 3 -> {
                        "+44" to loadedPhone.substring(3)
                    }
                    loadedPhone.startsWith("+") -> {
                        val match = Regex("^(\\+\\d{1,4})(.+)$").find(loadedPhone)
                        if (match != null) {
                            match.groupValues[1] to match.groupValues[2]
                        } else {
                            "" to loadedPhone
                        }
                    }
                    else -> {
                        "" to loadedPhone
                    }
                }
            } else {
                "" to ""
            }
            countryCode = phoneParts.first
            phoneNumber = phoneParts.second
        }
    }
    
    // Validation error messages
    var fullNameError by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf("") }
    var countryCodeError by remember { mutableStateOf("") }
    var phoneNumberError by remember { mutableStateOf("") }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Edit Profile", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Show loading indicator only if we have no data
            if (isLoading && fullName.isEmpty() && email.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 4.dp,
                            color = Color(0xFF22C55E)
                        )
                        Text(
                            text = "Loading Profile Data...",
                            fontSize = 16.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                return@Column
            }

            // Only show error if we have no data at all
            if (errorMessage.isNotEmpty() && fullName.isEmpty() && email.isEmpty() && !isLoading) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            Icons.Default.Error,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = errorMessage,
                            color = Color(0xFFDC2626),
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Account Information Header
            Text(
                text = "Edit Account Details",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937),
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(16.dp))

            // Full Name with validation
            ProfileFieldWithError(
                icon = Icons.Default.Person,
                label = "Full Name",
                value = fullName,
                onValueChange = { 
                    fullName = it
                    fullNameError = ""
                },
                errorMessage = fullNameError
            )
            
            // Email with validation
            ProfileFieldWithError(
                icon = Icons.Default.Email,
                label = "Email",
                value = email,
                onValueChange = { 
                    email = it
                    emailError = ""
                },
                errorMessage = emailError
            )
            
            // Phone Number with Country Code
            PhoneNumberField(
                countryCode = countryCode,
                phoneNumber = phoneNumber,
                onCountryCodeChange = { 
                    countryCode = it
                    countryCodeError = ""
                },
                onPhoneNumberChange = { 
                    phoneNumber = it
                    phoneNumberError = ""
                },
                errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneNumberError,
                modifier = Modifier.fillMaxWidth()
            )
            
            // Address Field (matching registration)
            ProfileField(Icons.Default.LocationOn, "Address", address) { address = it }
            
            // Organization Name Field (matching registration)
            ProfileField(Icons.Default.Info, "Organization Name", orgName) { orgName = it }
            
            // Registration Number Field (matching registration)
            ProfileField(Icons.Default.Info, "Registration Number", regNumber) { regNumber = it }

            if (isLoading) {
                CircularProgressIndicator()
            }
            
            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color(0xFFEF4444),
                    fontSize = 14.sp
                )
            }
            
            if (successMessage.isNotEmpty()) {
                Text(
                    text = successMessage,
                    color = Color(0xFF22C55E),
                    fontSize = 14.sp
                )
            }
            
            Spacer(modifier = Modifier.height(20.dp))

            // Save Button - Prominent and clear
            // Add extra bottom padding to ensure button is always accessible
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    // Clear previous errors
                    fullNameError = ""
                    emailError = ""
                    countryCodeError = ""
                    phoneNumberError = ""
                    errorMessage = ""
                    successMessage = ""
                    
                    // Validate all fields
                    val fullNameValidation = ValidationUtils.validateFullName(fullName)
                    val emailValidation = ValidationUtils.validateEmail(email)
                    val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
                    val phoneNumberValidation = ValidationUtils.validatePhoneNumber(phoneNumber)
                    
                    // Set error messages
                    if (!fullNameValidation.isValid) fullNameError = fullNameValidation.errorMessage
                    if (!emailValidation.isValid) emailError = emailValidation.errorMessage
                    if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
                    if (!phoneNumberValidation.isValid) phoneNumberError = phoneNumberValidation.errorMessage
                    
                    // Check if other required fields are filled
                    if (address.isBlank() || orgName.isBlank() || regNumber.isBlank()) {
                        errorMessage = "Please fill all fields"
                    }
                    
                    // If all validations pass, save changes
                    if (fullNameValidation.isValid &&
                        emailValidation.isValid &&
                        countryCodeValidation.isValid &&
                        phoneNumberValidation.isValid &&
                        address.isNotBlank() &&
                        orgName.isNotBlank() &&
                        regNumber.isNotBlank()) {
                        
                        scope.launch {
                            isLoading = true
                            try {
                                val ngoId = sessionManager.getNgoId()
                                val fullPhone = "$countryCode$phoneNumber"
                                Log.d("NgoEditProfile", "Updating profile for NGO ID: $ngoId")
                                Log.d("NgoEditProfile", "Data: fullName=$fullName, email=$email, phone=$fullPhone")
                                
                                val response = NgoProfileApiClient.api.updateProfile(
                                    UpdateNgoProfileRequest(
                                        ngoId = ngoId,
                                        fullName = fullName,
                                        phone = fullPhone,
                                        email = email,
                                        address = address,
                                        orgName = orgName,
                                        regNumber = regNumber
                                    )
                                )
                                
                                Log.d("NgoEditProfile", "Update API response: status=${response.status}, message=${response.message}")
                                if (response.status) {
                                    // Save updated data to session
                                    sessionManager.saveNgoProfileData(fullPhone, address, orgName, regNumber)
                                    sessionManager.saveNgoSession(ngoId, fullName, email)
                                    successMessage = "Profile updated successfully"
                                    Log.d("NgoEditProfile", "Profile updated successfully")
                                    
                                    // Navigate back after short delay to allow user to see success message
                                    kotlinx.coroutines.delay(1500)
                                    navController.popBackStack()
                                } else {
                                    errorMessage = response.message
                                    Log.e("NgoEditProfile", "Update failed: ${response.message}")
                                }
                            } catch (e: Exception) {
                                Log.e("NgoEditProfile", "Error updating profile: ${e.message}", e)
                                errorMessage = "Failed to update profile: ${e.message}"
                            } finally {
                                isLoading = false
                            }
                        }
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22C55E)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = if (isLoading) "Saving..." else "Save Changes",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            // Add bottom padding to ensure Save button is always accessible when scrolling
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ProfileField(
    icon: ImageVector,
    label: String,
    value: String,
    singleLine: Boolean = true,
    onValueChange: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = Color(0xFF22C55E))
                Spacer(modifier = Modifier.width(8.dp))
                Text(label, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = singleLine,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ProfileFieldWithError(
    icon: ImageVector,
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    errorMessage: String,
    singleLine: Boolean = true
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = Color(0xFF22C55E))
                Spacer(modifier = Modifier.width(8.dp))
                Text(label, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = singleLine,
                isError = errorMessage.isNotEmpty(),
                supportingText = if (errorMessage.isNotEmpty()) {
                    { Text(errorMessage, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
