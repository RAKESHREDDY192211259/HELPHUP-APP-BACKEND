﻿package com.example.helphup.ui.theme

import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Help
import androidx.compose.material.icons.automirrored.outlined.TrendingUp
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.outlined.AttachMoney
import androidx.compose.material.icons.outlined.VolunteerActivism
import androidx.compose.material.icons.outlined.Handshake
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.data.HelpRequest
import com.example.helphup.ui.data.HelpRequestDataStore
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import androidx.compose.runtime.rememberCoroutineScope
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Body
import retrofit2.Response

/* ---------------- API MODELS ---------------- */

data class HelpOthersResponse(
    val status: Boolean,
    val message: String,
    val data: List<Map<String, Any>>?
)

/* ---------------- API SERVICE ---------------- */

interface HelpOthersApiService {
    @GET("get_all_ngo_requests.php")
    suspend fun getNgoRequests(): HelpOthersResponse
    
    @GET("get_all_volunteer_requests.php")
    suspend fun getVolunteerRequests(): HelpOthersResponse
    
    @GET("get_all_donor_campaigns.php")
    suspend fun getDonorCampaigns(): HelpOthersResponse
}

object HelpOthersRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"
    
    val api: HelpOthersApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(HelpOthersApiService::class.java)
    }
}

/* ---------------- DATA MODEL ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoHelpOthers(
    navController: NavController
) {
    // Observe data store for help request updates
    val refreshTrigger by remember { HelpRequestDataStore.refreshTrigger }
    val newHelpRequestAdded by remember { HelpRequestDataStore.newHelpRequestAdded }
    
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var helpRequests by remember { mutableStateOf<List<HelpRequest>>(emptyList()) }
    
    // TODO: Get current logged-in NGO ID from session/preferences
    // Get current NGO ID from session manager
    val context: Context = LocalContext.current
    val sessionManager: UserSessionManager = remember { UserSessionManager(context) }
    val currentNgoId: Int = remember { sessionManager.getNgoId() ?: 1 } // Use session, fallback to 1
    
    val scope = rememberCoroutineScope()
    
    // Load sample data directly like DonorBrowseCause flow
    LaunchedEffect(Unit) {
        isLoading = true
        errorMessage = ""
        
        // ❌ Remove sample data - use unified API
        Log.d("NgoHelpOthers", "Loading data from unified API")
        fetchNgoHelpRequestsData(scope, { isLoading = it }, { errorMessage = it }, { helpRequests = it })
    }
    
    // Reset the update flag when component recomposes and refresh data
    LaunchedEffect(newHelpRequestAdded) {
        if (newHelpRequestAdded) {
            HelpRequestDataStore.resetUpdateFlag()
            // Reload data from unified API
            Log.d("NgoHelpOthers", "Help request update detected, reloading from API")
            fetchNgoHelpRequestsData(scope, { isLoading = it }, { errorMessage = it }, { helpRequests = it })
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Browse Approved Requests", fontWeight = FontWeight.Bold)
                        Text(
                            text = "Only approved help requests are visible",
                            fontSize = 12.sp,
                            color = Color(0xFF22C55E)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color.Red,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (helpRequests.isEmpty()) {
                        item {
                            Text(
                                text = "No help requests found",
                                modifier = Modifier.padding(16.dp),
                                color = Color.Gray
                            )
                        }
                    } else {
                        items(helpRequests) { request ->
                            val requestId = request.id.split("_").getOrNull(1) ?: "0"
                            HelpRequestCard(
                                priority = when (request.requestType) {
                                    "NGO" -> "High Priority"
                                    "Volunteer" -> "Medium Priority"
                                    "Donor" -> "Medium Priority"
                                    else -> "Low Priority"
                                },
                                priorityColor = when (request.requestType) {
                                    "NGO" -> Color(0xFFE53935)
                                    "Volunteer" -> Color(0xFF9C27B0)
                                    "Donor" -> Color(0xFF2E7D32)
                                    else -> Color(0xFF757575)
                                },
                                title = request.title,
                                description = request.description ?: "",
                                location = request.location,
                                time = when (request.requestType) {
                                    "NGO" -> "Urgent"
                                    "Volunteer" -> "Weekend"
                                    "Donor" -> "Ongoing"
                                    else -> "Flexible"
                                },
                                requestType = request.requestType,
                                requestId = requestId,
                                amount = request.amount,
                                onOfferHelpClick = {
                                    // Navigate to NGO community support first, then payment flow
                                    if (requestId.isNotEmpty() && requestId != "0") {
                                        Log.d("NgoHelpOthers", "Navigating to NGO community support for ${request.requestType} request #$requestId with amount ${request.amount}")
                                        try {
                                            navController.navigate("${Routes.NGO_COMMUNITY_SUPPORT}/${request.requestType}/$requestId/${request.amount}")
                                        } catch (e: Exception) {
                                            Log.e("NgoHelpOthers", "Error navigating to NGO community support", e)
                                        }
                                    } else {
                                        Log.w("NgoHelpOthers", "Invalid request ID: $requestId")
                                    }
                                },
                                onViewDetailsClick = {
                                    // Navigate to NGO help others details
                                    if (requestId.isNotEmpty() && requestId != "0") {
                                        Log.d("NgoHelpOthers", "Viewing NGO help others details for ${request.requestType} request #$requestId")
                                        try {
                                            navController.navigate("${Routes.NGO_HELP_OTHERS_DETAILS}/${request.requestType}/$requestId")
                                        } catch (e: Exception) {
                                            Log.e("NgoHelpOthers", "Error navigating to NGO help others details", e)
                                        }
                                    } else {
                                        Log.w("NgoHelpOthers", "Invalid request ID: $requestId")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HelpRequestCard(
    priority: String,
    priorityColor: Color,
    title: String,
    description: String,
    location: String,
    time: String,
    requestType: String,
    requestId: String,
    amount: String = "0",
    onOfferHelpClick: () -> Unit,
    onViewDetailsClick: () -> Unit,
    content: @Composable () -> Unit = {}
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Request Type Badge
            Surface(
                color = when (requestType) {
                    "NGO" -> Color(0xFFE3F2FD)
                    "Volunteer" -> Color(0xFFF3E5F5)
                    "Donor Campaign" -> Color(0xFFE8F5E9)
                    else -> Color(0xFFF3E5F5)
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Text(
                    text = requestType,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 12.sp,
                    color = when (requestType) {
                        "NGO" -> Color(0xFF1976D2)
                        "Volunteer" -> Color(0xFF7B1FA2)
                        "Donor Campaign" -> Color(0xFF16A34A)
                        else -> Color(0xFF7B1FA2)
                    },
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = priority,
                color = priorityColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(6.dp))

            Text(description, fontSize = 13.sp, color = Color.DarkGray)

            Spacer(modifier = Modifier.height(12.dp))

            // 📋 Show more details from user submission
            when (requestType) {
                "NGO" -> {
                    Row {
                        Icon(Icons.Outlined.AttachMoney, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Amount Required: ₹$amount", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                        TextButton(
                            onClick = onViewDetailsClick,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("View Details", fontSize = 12.sp, color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
                        }
                    }
                }
                "Volunteer" -> {
                    Row {
                        Icon(Icons.Outlined.Group, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Volunteers Needed", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                        TextButton(
                            onClick = onViewDetailsClick,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("View Details", fontSize = 12.sp, color = Color(0xFF7B1FA2), fontWeight = FontWeight.Bold)
                        }
                    }
                }
                "Donor" -> {
                    Row {
                        Icon(Icons.AutoMirrored.Outlined.TrendingUp, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Fundraising Goal: ₹$amount", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                        TextButton(
                            onClick = onViewDetailsClick,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("View Details", fontSize = 12.sp, color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 💳 Payment/Action Button
            Button(
                onClick = onOfferHelpClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (requestType) {
                        "NGO" -> Color(0xFFE3F2FD)
                        "Volunteer" -> Color(0xFFF3E5F5)
                        "Donor" -> Color(0xFFE8F5E9)
                        else -> Color(0xFFF3E5F5)
                    },
                    contentColor = when (requestType) {
                        "NGO" -> Color(0xFF1976D2)
                        "Volunteer" -> Color(0xFF7B1FA2)
                        "Donor" -> Color(0xFF16A34A)
                        else -> Color(0xFF7B1FA2)
                    }
                )
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (requestType) {
                        "NGO" -> {
                            Icon(Icons.Outlined.AttachMoney, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Donate Now", fontWeight = FontWeight.Bold)
                        }
                        "Volunteer" -> {
                            Icon(Icons.Outlined.VolunteerActivism, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Offer Help", fontWeight = FontWeight.Bold)
                        }
                        "Donor" -> {
                            Icon(Icons.Outlined.Handshake, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Support Campaign", fontWeight = FontWeight.Bold)
                        }
                        else -> {
                            Icon(Icons.AutoMirrored.Outlined.Help, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Offer Help →", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.LocationOn,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = location,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

/* -------------------- NGO DATA FETCHING -------------------- */

private fun fetchNgoHelpRequestsData(
    scope: CoroutineScope,
    onLoading: (Boolean) -> Unit,
    onError: (String) -> Unit,
    onSuccess: (List<HelpRequest>) -> Unit
) {
    scope.launch {
        onLoading(true)
        onError("")
        Log.d("NgoHelpOthers", "Starting to fetch help requests data")
        try {
            // Use unified endpoint - NGOs should NOT see NGO requests
            val response = HelpRequestsRetrofitInstance.api.getPublicRequests()
            
            Log.d("NgoHelpOthers", "API response status: ${response.status}")
            
            val allRequests = mutableListOf<HelpRequest>()
            
            // Process unified requests
            if (response.status && response.data != null) {
                response.data.forEach { item ->
                    try {
                        // Convert to display format
                        allRequests.add(
                            HelpRequest(
                                id = "${item.requesterType}_${item.requestId}",
                                title = item.requestTitle,
                                category = item.category,
                                location = item.location ?: item.dateNeeded ?: "",
                                description = item.description,
                                ngoName = if (item.requesterType == "ngo") item.requesterName else null,
                                volunteerName = if (item.requesterType == "volunteer") item.requesterName else null,
                                donorName = if (item.requesterType == "donor") item.requesterName else null,
                                requestType = item.requesterType.uppercase(),
                                amount = item.requiredAmount?.toString() ?: "0"
                            )
                        )
                    } catch (e: Exception) {
                        Log.e("NgoHelpOthers", "Error processing request: ${e.message}")
                    }
                }
            }
            
            Log.d("NgoHelpOthers", "Total requests processed: ${allRequests.size}")
            onSuccess(allRequests)
            
        } catch (e: Exception) {
            Log.e("NgoHelpOthers", "Error fetching help requests: ${e.message}")
            val errorMsg = e.message ?: "Unknown error"
            
            // Provide detailed error messages
            onError(when {
                errorMsg.contains("404") || errorMsg.contains("Not Found") -> "API endpoint not found. Please ensure the PHP files are in C:\\xampp\\htdocs\\helphup\\api\\ directory"
                errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                errorMsg.contains("Connection refused") -> "Connection error: Connection refused\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                else -> "Connection error: $errorMsg\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
            })
            
            // ❌ Remove sample data - show error message instead
            Log.d("NgoHelpOthers", "API failed, showing error message")
            onError("Failed to load help requests. Please check your internet connection.")
            onSuccess(emptyList())
        } finally {
            onLoading(false)
        }
    }
}
