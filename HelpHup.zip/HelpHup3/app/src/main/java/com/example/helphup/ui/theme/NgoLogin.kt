package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.helphup.ui.theme.NgoProfileApiClient
import com.example.helphup.ui.theme.GetNgoProfileRequest
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* -------------------- DATA MODELS -------------------- */

data class NgoLoginRequest(
    val email: String,
    val password: String
)

data class NgoLoginResponse(
    val status: Boolean,
    val message: String,
    val data: NgoLoginData? = null
)

data class NgoLoginData(
    val ngo_id: Int,
    val full_name: String,
    val email: String
)

/* -------------------- API SERVICE -------------------- */

interface NgoLoginApiService {
    @POST("ngo_login.php")
    suspend fun loginNgo(@Body request: NgoLoginRequest): NgoLoginResponse
}

object NgoApiClient {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: NgoLoginApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(NgoLoginApiService::class.java)
    }
}

/* -------------------- VIEWMODEL -------------------- */

class NgoLoginViewModel : ViewModel() {

    var isLoading by mutableStateOf(false)
    var errorMessage by mutableStateOf("")
    var loginSuccess by mutableStateOf(false)
    var loginData by mutableStateOf<NgoLoginData?>(null)

    fun login(email: String, password: String) {
        viewModelScope.launch {
            isLoading = true
            errorMessage = ""

            try {
                val response = NgoApiClient.api.loginNgo(
                    NgoLoginRequest(email, password)
                )

                if (response.status && response.data != null) {
                    loginData = response.data
                    loginSuccess = true
                } else {
                    errorMessage = response.message
                }

            } catch (e: Exception) {
                val errorMsg = e.message ?: "Unknown error"
                errorMessage = when {
                    errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Unable to resolve host") -> "Connection error: Cannot find server\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Connection refused") -> "Connection error: Connection refused\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Connection reset") || errorMsg.contains("connection reset") -> "Connection error: Connection reset\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("timeout") -> "Connection error: Connection timeout\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Network is unreachable") -> "Connection error: Network unreachable\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    else -> "Connection error: $errorMsg\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                }
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
}

/* -------------------- UI -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoLoginScreen(
    navController: NavController,
    viewModel: NgoLoginViewModel = viewModel()
) {

    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    // Save session when login succeeds and fetch full profile
    if (viewModel.loginSuccess && viewModel.loginData != null) {
        LaunchedEffect(viewModel.loginData) {
            val sessionManager = UserSessionManager(context)
            val data = viewModel.loginData!!
            sessionManager.saveNgoSession(
                data.ngo_id,
                data.full_name,
                data.email
            )
            
            // Try to fetch full profile data after login
            try {
                val profileResponse = NgoProfileApiClient.api.getProfile(
                    GetNgoProfileRequest(data.ngo_id)
                )
                if (profileResponse.status && profileResponse.data != null) {
                    val profileData = profileResponse.data
                    // Save full profile to session
                    sessionManager.saveNgoProfileData(
                        profileData.phone,
                        profileData.address,
                        profileData.orgName,
                        profileData.regNumber
                    )
                }
            } catch (e: Exception) {
                // If profile fetch fails, continue with basic login data
                // Profile screen will try again later
                e.printStackTrace()
            }
            
            navController.navigate(Routes.NGO_DASHBOARD) {
                popUpTo(Routes.NGO_LOGIN) { inclusive = true }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NGO Login") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(Color(0xFFF0FDF4)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {

                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text(
                        "Welcome Back",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                    contentDescription = "Toggle password visibility"
                                )
                            }
                        }
                    )

                    if (viewModel.errorMessage.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(viewModel.errorMessage, color = Color.Red, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            if (email.isBlank() || password.isBlank()) {
                                viewModel.errorMessage = "Email and password are required"
                            } else {
                                viewModel.login(email, password)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !viewModel.isLoading
                    ) {
                        if (viewModel.isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text("Sign In", color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "Forgot Password?",
                        color = Color(0xFF22C55E),
                        modifier = Modifier.clickable {
                            navController.navigate(Routes.NGO_FORGOT_PASSWORD)
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row {
                        Text("Don’t have an account? ")
                        Text(
                            "Create New Account",
                            color = Color(0xFF22C55E),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                navController.navigate(Routes.NGO_REGISTER)
                            }
                        )
                    }
                }
            }
        }
    }
}
