package com.example.helphup.ui.theme

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

/* ---------------- API MODELS ---------------- */

data class MyRequestsResponse(
    val status: Boolean,
    val message: String,
    val data: List<MyRequestItem>?,
    val counts: Map<String, Int>?
)

data class MyRequestItem(
    @SerializedName("request_id") val requestId: Int,
    @SerializedName("requester_type") val requesterType: String,
    @SerializedName("requester_name") val requesterName: String,
    @SerializedName("request_title") val requestTitle: String,
    @SerializedName("category") val category: String,
    @SerializedName("description") val description: String,
    @SerializedName("urgency_level") val urgencyLevel: String,
    @SerializedName("required_amount") val requiredAmount: Double?,
    @SerializedName("date_needed") val dateNeeded: String?,
    @SerializedName("location") val location: String?,
    @SerializedName("help_date") val helpDate: String?,
    @SerializedName("volunteers_needed") val volunteersNeeded: Int?,
    @SerializedName("fundraising_goal") val fundraisingGoal: Double?,
    @SerializedName("status") val status: String,
    @SerializedName("status_display") val statusDisplay: String,
    @SerializedName("next_action") val nextAction: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("created_at_formatted") val createdAtFormatted: String,
    @SerializedName("admin_reviewed_at") val adminReviewedAt: String?,
    @SerializedName("admin_reviewed_at_formatted") val adminReviewedAtFormatted: String?,
    @SerializedName("rejection_reason") val rejectionReason: String?
)

/* ---------------- API SERVICE ---------------- */

interface MyRequestsApiService {
    @GET("unified_get_my_requests.php")
    suspend fun getMyRequests(
        @Query("requester_type") requesterType: String,
        @Query("requester_id") requesterId: Int
    ): MyRequestsResponse
}

object MyRequestsRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"
    
    val api: MyRequestsApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(MyRequestsApiService::class.java)
    }
}

/* ---------------- UI COMPOSABLE ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoMyRequests(navController: NavController) {
    
    var requests by remember { mutableStateOf<List<MyRequestItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var selectedStatus by remember { mutableStateOf("all") }
    
    val scope = rememberCoroutineScope()
    
    // Function to fetch requests
    fun fetchRequests() {
        scope.launch {
            try {
                isLoading = true
                errorMessage = ""
                
                val response = MyRequestsRetrofitInstance.api.getMyRequests(
                    requesterType = "ngo",
                    requesterId = 1 // Replace with logged-in NGO ID
                )
                
                if (response.status) {
                    requests = response.data ?: emptyList()
                    Log.d("NgoMyRequests", "Fetched ${requests.size} requests")
                } else {
                    errorMessage = response.message
                }
                
            } catch (e: Exception) {
                errorMessage = e.localizedMessage ?: "Network error"
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
    
    // Initial fetch
    LaunchedEffect(Unit) {
        fetchRequests()
    }
    
    // Filter requests based on selected status
    val filteredRequests = if (selectedStatus == "all") {
        requests
    } else {
        requests.filter { it.status == selectedStatus }
    }
    
    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("My Requests", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { fetchRequests() }) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(16.dp)
        ) {
            
            // Status Filter Chips
            Text("Filter by Status", fontWeight = FontWeight.Medium, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedStatus == "all",
                    onClick = { selectedStatus = "all" },
                    label = { Text("All") }
                )
                FilterChip(
                    selected = selectedStatus == "pending",
                    onClick = { selectedStatus = "pending" },
                    label = { Text("Pending") }
                )
                FilterChip(
                    selected = selectedStatus == "approved",
                    onClick = { selectedStatus = "approved" },
                    label = { Text("Approved") }
                )
                FilterChip(
                    selected = selectedStatus == "rejected",
                    onClick = { selectedStatus = "rejected" },
                    label = { Text("Rejected") }
                )
            }
            
            Spacer(Modifier.height(16.dp))
            
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(40.dp),
                                color = Color(0xFF22C55E)
                            )
                            Spacer(Modifier.height(16.dp))
                            Text(
                                "Loading your requests...",
                                color = Color.Gray
                            )
                        }
                    }
                }
                
                errorMessage.isNotEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                errorMessage,
                                color = Color.Red,
                                modifier = Modifier.padding(16.dp)
                            )
                            Button(
                                onClick = { fetchRequests() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF22C55E)
                                )
                            ) {
                                Text("Retry")
                            }
                        }
                    }
                }
                
                filteredRequests.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "No requests found",
                                color = Color.Gray,
                                fontSize = 16.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                            Text(
                                if (selectedStatus == "all") "You haven't created any help requests yet" 
                                else "No $selectedStatus requests found",
                                color = Color.Gray,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
                
                else -> {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filteredRequests) { request ->
                            RequestCard(request = request)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RequestCard(request: MyRequestItem) {
    val statusColor = when (request.status) {
        "pending" -> Color(0xFFF59E0B)
        "approved" -> Color(0xFF22C55E)
        "rejected" -> Color(0xFFEF4444)
        else -> Color.Gray
    }
    
    val statusIcon = when (request.status) {
        "pending" -> "⏳"
        "approved" -> "✅"
        "rejected" -> "❌"
        else -> "📋"
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* Navigate to details if needed */ },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header with title and status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                ExpandedText(
                    text = request.requestTitle,
                    maxLines = 2,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.weight(1f)
                )
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = statusIcon,
                        fontSize = 16.sp
                    )
                    Text(
                        text = request.statusDisplay,
                        color = statusColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            
            Spacer(Modifier.height(8.dp))
            
            // Category and Urgency
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = request.category,
                    color = Color(0xFF6B7280),
                    fontSize = 14.sp
                )
                Text(
                    text = "•",
                    color = Color(0xFF6B7280),
                    fontSize = 14.sp
                )
                Text(
                    text = request.urgencyLevel,
                    color = when (request.urgencyLevel) {
                        "Critical" -> Color(0xFFDC2626)
                        "High" -> Color(0xFFF59E0B)
                        "Medium" -> Color(0xFF3B82F6)
                        "Low" -> Color(0xFF10B981)
                        else -> Color.Gray
                    },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            
            Spacer(Modifier.height(8.dp))
            
            // Description
            ExpandedText(
                text = request.description,
                maxLines = 3,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color(0xFF4B5563)
                )
            )
            
            // Type-specific details
            if (request.requiredAmount != null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Required: ₹${String.format("%.0f", request.requiredAmount)}",
                    color = Color(0xFF22C55E),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            
            if (request.volunteersNeeded != null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Volunteers needed: ${request.volunteersNeeded}",
                    color = Color(0xFF3B82F6),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            
            if (request.fundraisingGoal != null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Goal: ₹${String.format("%.0f", request.fundraisingGoal)}",
                    color = Color(0xFF8B5CF6),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            
            Spacer(Modifier.height(8.dp))
            
            // Footer with dates and next action
            Column {
                Text(
                    text = "Created: ${request.createdAtFormatted}",
                    color = Color(0xFF6B7280),
                    fontSize = 12.sp
                )
                
                if (request.adminReviewedAtFormatted != null) {
                    Text(
                        text = "Reviewed: ${request.adminReviewedAtFormatted}",
                        color = Color(0xFF6B7280),
                        fontSize = 12.sp
                    )
                }
                
                if (request.rejectionReason != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Reason: ${request.rejectionReason}",
                        color = Color(0xFFEF4444),
                        fontSize = 12.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                }
                
                Spacer(Modifier.height(4.dp))
                Text(
                    text = request.nextAction,
                    color = Color(0xFF6B7280),
                    fontSize = 12.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        }
    }
}

@Composable
fun ExpandedText(
    text: String,
    maxLines: Int,
    style: androidx.compose.ui.text.TextStyle,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }
    
    Text(
        text = text,
        style = style,
        maxLines = if (isExpanded) Int.MAX_VALUE else maxLines,
        modifier = modifier.clickable { isExpanded = !isExpanded }
    )
}
