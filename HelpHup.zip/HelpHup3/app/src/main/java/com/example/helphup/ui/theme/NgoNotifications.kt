package com.example.helphup.ui.theme

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Body
import retrofit2.http.Query
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*

/* -------------------- API MODELS -------------------- */

data class NotificationData(
    val notification_id: Int,
    val title: String,
    val message: String,
    val rejection_reason: String?,
    val is_read: Boolean,
    val created_at: String,
    val request_type: String,
    val request_id: Int
)

data class NotificationsResponse(
    val status: Boolean,
    val message: String,
    val data: NotificationsData?
)

data class NotificationsData(
    val notifications: List<NotificationData>,
    val unread_count: Int
)

data class MarkReadRequest(
    val notification_id: Int,
    val user_type: String,
    val user_id: Int
)

data class MarkAllReadRequest(
    val user_type: String,
    val user_id: Int
)

data class HelpReceivedItem(
    val interaction_id: Int,
    val request_id: Int,
    val request_title: String,
    val helper_name: String,
    val helper_email: String?,
    val payment_amount: Double?,
    val payment_method: String?,
    val payment_status: String?,
    val interaction_status: String,
    val interaction_date: String,
    val transaction_id: String?
)

data class HelpReceivedResponse(
    val status: Boolean,
    val message: String,
    val data: HelpReceivedData?
)

data class HelpReceivedData(
    val help_received: List<HelpReceivedItem>,
    val total_received: Double,
    val total_help_count: Int
)

/* -------------------- API SERVICE -------------------- */

interface NotificationsApi {
    @GET("get_notifications.php")
    suspend fun getNotifications(
        @Query("user_type") userType: String,
        @Query("user_id") userId: Int
    ): NotificationsResponse

    @GET("get_help_received.php")
    suspend fun getHelpReceived(
        @Query("user_type") userType: String,
        @Query("user_id") userId: Int
    ): HelpReceivedResponse

    @POST("mark_notification_read.php")
    suspend fun markAsRead(@Body request: MarkReadRequest): ApiResponse

    @POST("mark_all_notifications_read.php")
    suspend fun markAllAsRead(@Body request: MarkAllReadRequest): ApiResponse
}

object NotificationsRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"
    
    val api: NotificationsApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(NotificationsApi::class.java)
    }
}

/* -------------------- HELPER FUNCTIONS -------------------- */

fun formatTimeAgo(dateString: String): String {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val date = sdf.parse(dateString)
        val now = Date()
        val diff = now.time - (date?.time ?: 0)
        
        val seconds = diff / 1000
        val minutes = seconds / 60
        val hours = minutes / 60
        val days = hours / 24
        
        when {
            days > 0 -> "$days day${if (days > 1) "s" else ""} ago"
            hours > 0 -> "$hours hour${if (hours > 1) "s" else ""} ago"
            minutes > 0 -> "$minutes min${if (minutes > 1) "s" else ""} ago"
            else -> "Just now"
        }
    } catch (e: Exception) {
        dateString
    }
}

fun getNotificationIcon(title: String): androidx.compose.ui.graphics.vector.ImageVector {
    return when {
        title.contains("Rejected", ignoreCase = true) -> Icons.Default.Cancel
        title.contains("Approved", ignoreCase = true) || title.contains("Accepted", ignoreCase = true) -> Icons.Default.CheckCircle
        else -> Icons.Default.Notifications
    }
}

fun getNotificationColor(title: String): Color {
    return when {
        title.contains("Rejected", ignoreCase = true) -> Color(0xFFEF4444)
        title.contains("Approved", ignoreCase = true) || title.contains("Accepted", ignoreCase = true) -> Color(0xFF10B981)
        else -> Color(0xFF3B82F6)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoNotifications(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val ngoId = remember { sessionManager.getNgoId() }
    
    var notifications by remember { mutableStateOf<List<NotificationData>>(emptyList()) }
    var helpReceived by remember { mutableStateOf<List<HelpReceivedItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var unreadCount by remember { mutableStateOf(0) }
    var showHelpReceived by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()
    
    // Fetch notifications and help received
    LaunchedEffect(ngoId) {
        if (ngoId > 0) {
            isLoading = true
            errorMessage = null
            try {
                // Fetch notifications
                val notifResponse = NotificationsRetrofitInstance.api.getNotifications("ngo", ngoId)
                if (notifResponse.status && notifResponse.data != null) {
                    notifications = notifResponse.data.notifications
                    unreadCount = notifResponse.data.unread_count
                }
                
                // Fetch help received
                val helpResponse = NotificationsRetrofitInstance.api.getHelpReceived("ngo", ngoId)
                if (helpResponse.status && helpResponse.data != null) {
                    helpReceived = helpResponse.data.help_received
                }
            } catch (e: Exception) {
                errorMessage = "Failed to load data: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }
    
    fun markAsRead(notificationId: Int) {
        scope.launch {
            try {
                NotificationsRetrofitInstance.api.markAsRead(
                    MarkReadRequest(notificationId, "ngo", ngoId)
                )
                // Refresh notifications
                val response = NotificationsRetrofitInstance.api.getNotifications("ngo", ngoId)
                if (response.status && response.data != null) {
                    notifications = response.data.notifications
                    unreadCount = response.data.unread_count
                }
            } catch (e: Exception) {
                // Handle error silently
            }
        }
    }
    
    fun markAllAsRead() {
        scope.launch {
            try {
                NotificationsRetrofitInstance.api.markAllAsRead(
                    MarkAllReadRequest("ngo", ngoId)
                )
                // Refresh notifications
                val response = NotificationsRetrofitInstance.api.getNotifications("ngo", ngoId)
                if (response.status && response.data != null) {
                    notifications = response.data.notifications
                    unreadCount = response.data.unread_count
                }
            } catch (e: Exception) {
                // Handle error silently
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        bottomBar = { NgoBottomBar(navController) }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
        ) {

            /* ---------- Header ---------- */
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFF22C55E)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "Notifications",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    Text(
                        text = if (unreadCount > 0) "$unreadCount unread" else "All caught up",
                        fontSize = 14.sp,
                        color = Color(0xFF22C55E)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            /* ---------- Toggle Buttons ---------- */
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Toggle between notifications and help received
                Row {
                    TextButton(
                        onClick = { showHelpReceived = false },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = if (!showHelpReceived) Color(0xFF22C55E) else Color.Gray
                        )
                    ) {
                        Text("Requests Status (${notifications.size})")
                    }
                    TextButton(
                        onClick = { showHelpReceived = true },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = if (showHelpReceived) Color(0xFF22C55E) else Color.Gray
                        )
                    ) {
                        Text("Help Received (${helpReceived.size})")
                    }
                }
                
                if (!showHelpReceived && unreadCount > 0) {
                    Text(
                        text = "✓ Mark all as read",
                        modifier = Modifier.clickable { markAllAsRead() },
                        fontSize = 14.sp,
                        color = Color(0xFF22C55E),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            /* ---------- Notifications ---------- */
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Color(0xFF22C55E))
                    }
                }
                errorMessage != null -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = errorMessage ?: "Error loading notifications",
                            color = Color.Red
                        )
                    }
                }
                showHelpReceived -> {
                    if (helpReceived.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Favorite,
                                    contentDescription = null,
                                    modifier = Modifier.size(64.dp),
                                    tint = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "No help received yet",
                                    color = Color.Gray,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    } else {
                        LazyColumn {
                            items(helpReceived) { help ->
                                HelpReceivedItem(
                                    help = help,
                                    onClick = { /* Navigate to details if needed */ }
                                )
                            }
                        }
                    }
                }
                notifications.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.Notifications,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "No notifications",
                                color = Color.Gray,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
                else -> {
                    LazyColumn {
                        items(notifications) { notification ->
                            NotificationItem(
                                icon = getNotificationIcon(notification.title),
                                title = notification.title,
                                message = notification.message,
                                rejectionReason = notification.rejection_reason,
                                time = formatTimeAgo(notification.created_at),
                                iconColor = getNotificationColor(notification.title),
                                isRead = notification.is_read,
                                onClick = {
                                    if (!notification.is_read) {
                                        markAsRead(notification.notification_id)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/* ---------- Notification Item ---------- */
@Composable
fun NotificationItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    message: String,
    rejectionReason: String?,
    time: String,
    iconColor: Color,
    isRead: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(3.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isRead) Color.White else Color(0xFFF0FDF4)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(iconColor.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 14.sp,
                        fontWeight = if (isRead) FontWeight.Normal else FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = message,
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    if (rejectionReason != null && rejectionReason.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Reason: $rejectionReason",
                            fontSize = 12.sp,
                            color = Color(0xFFEF4444),
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = time,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                if (!isRead) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF22C55E), CircleShape)
                    )
                }
            }
        }
    }
}

/* ---------- Help Received Item ---------- */
@Composable
fun HelpReceivedItem(
    help: HelpReceivedItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(3.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF10B981).copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Favorite,
                        contentDescription = null,
                        tint = Color(0xFF10B981)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = help.request_title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "From: ${help.helper_name}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    if (help.payment_amount != null && help.payment_amount > 0) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Amount: ₹${String.format("%.2f", help.payment_amount)}",
                            fontSize = 12.sp,
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = formatTimeAgo(help.interaction_date),
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                // Status indicator
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(
                            when (help.interaction_status) {
                                "completed" -> Color(0xFF10B981)
                                "pending" -> Color(0xFFF59E0B)
                                else -> Color.Gray
                            },
                            CircleShape
                        )
                )
            }
        }
    }
}
