package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import kotlinx.coroutines.launch

// ==================== Constants ====================

private object PaymentConfirmationConstants {
    // Colors
    val BackgroundColor = Color(0xFFF0FDF4)
    val CardBackgroundColor = Color.White
    val PrimaryColor = Color(0xFF22C55E)
    val SuccessBackgroundColor = Color(0xFFD1FAE5)
    val InfoBackgroundColor = Color(0xFFDFF6EA)
    val TextPrimary = Color(0xFF1F2937)
    val TextSecondary = Color(0xFF6B7280)
    val DarkGreen = Color(0xFF14532D)
    
    // Spacing
    val PaddingSmall = 8.dp
    val PaddingMedium = 16.dp
    val PaddingLarge = 20.dp
    val PaddingExtraLarge = 24.dp
    
    // Sizes
    val SuccessIconSize = 80.dp
    val IconSize = 24.dp
    val ButtonHeight = 52.dp
    
    // Text Sizes
    val TitleSize = 28.sp
    val SubtitleSize = 14.sp
    val BodySize = 16.sp
    val SectionTitleSize = 18.sp
    val ButtonTextSize = 16.sp
}

// ==================== Main Screen ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoPaymentConfirmation(
    navController: NavController,
    requestType: String = "",
    requestId: String = "",
    amount: String = "0",
    method: String = "CARD"
) {
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    // Save payment to backend when screen loads
    LaunchedEffect(Unit) {
        scope.launch {
            isLoading = true
            errorMessage = null
            try {
                // TODO: Get actual ngo_id from session/preferences
                // For now, using default value 1
                val ngoId = 1
                
                val request = SaveNgoPaymentRequest(
                    ngoId = ngoId,
                    amount = amount.toDouble(),
                    paymentMethod = method,
                    paymentStatus = "completed",
                    description = "Community support payment"
                )
                
                val response = PaymentRetrofitInstance.api.saveNgoPayment(request)
                if (!response.status) {
                    errorMessage = response.message
                }
            } catch (e: Exception) {
                errorMessage = "Failed to save payment: ${e.message}"
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
    
    Scaffold(
        containerColor = PaymentConfirmationConstants.BackgroundColor
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(PaymentConfirmationConstants.BackgroundColor)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Section
            BackButtonSection(
                onBackClick = {
                    navController.navigate(Routes.NGO_HELP_OTHERS) {
                        popUpTo(Routes.NGO_DASHBOARD)
                    }
                }
            )
            
            Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingLarge))
            
            // Show loading or error state
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
                Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingLarge))
            }
            
            if (errorMessage != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PaymentConfirmationConstants.PaddingLarge),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFFFEBEE)
                    )
                ) {
                    Text(
                        text = errorMessage ?: "",
                        modifier = Modifier.padding(PaymentConfirmationConstants.PaddingMedium),
                        color = Color(0xFFC62828)
                    )
                }
                Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingMedium))
            }
            
            // Success Content
            SuccessContent()
            
            Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingExtraLarge))
            
            // What's Next Card
            WhatsNextCard()
            
            Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingExtraLarge))
            
            // Action Buttons
            ActionButtons(
                onBrowseMore = { navController.navigate(Routes.NGO_HELP_OTHERS) },
                onBackToDashboard = { navController.navigate(Routes.NGO_DASHBOARD) }
            )
            
            Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingLarge))
        }
    }
}

// ==================== Header Components ====================

@Composable
private fun BackButtonSection(onBackClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(PaymentConfirmationConstants.PaddingMedium),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onBackClick,
            colors = ButtonDefaults.textButtonColors(
                contentColor = PaymentConfirmationConstants.PrimaryColor
            )
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "BACK",
                fontSize = PaymentConfirmationConstants.SubtitleSize,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==================== Success Content ====================

@Composable
private fun SuccessContent() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = PaymentConfirmationConstants.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Success Icon
        Box(
            modifier = Modifier
                .size(PaymentConfirmationConstants.SuccessIconSize)
                .background(
                    PaymentConfirmationConstants.SuccessBackgroundColor,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = PaymentConfirmationConstants.PrimaryColor,
                modifier = Modifier.size(48.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingExtraLarge))
        
        // Title
        Text(
            text = "Thank You!",
            fontSize = PaymentConfirmationConstants.TitleSize,
            fontWeight = FontWeight.Bold,
            color = PaymentConfirmationConstants.DarkGreen,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingMedium))
        
        // Subtitle
        Text(
            text = "Your support offer has been successfully submitted",
            fontSize = PaymentConfirmationConstants.BodySize,
            color = Color.DarkGray,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingSmall))
        
        // Additional Info
        Text(
            text = "The organization will contact you soon",
            fontSize = PaymentConfirmationConstants.SubtitleSize,
            color = PaymentConfirmationConstants.TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

// ==================== What's Next Card ====================

@Composable
private fun WhatsNextCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = PaymentConfirmationConstants.PaddingLarge),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = PaymentConfirmationConstants.CardBackgroundColor
        ),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(
            modifier = Modifier.padding(PaymentConfirmationConstants.PaddingLarge)
        ) {
            // Title
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = null,
                    tint = PaymentConfirmationConstants.PrimaryColor,
                    modifier = Modifier.size(PaymentConfirmationConstants.IconSize)
                )
                Spacer(modifier = Modifier.width(PaymentConfirmationConstants.PaddingSmall))
                Text(
                    text = "What's Next?",
                    fontSize = PaymentConfirmationConstants.SectionTitleSize,
                    fontWeight = FontWeight.Bold,
                    color = PaymentConfirmationConstants.DarkGreen
                )
            }
            
            Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingMedium))
            
            // Steps
            NextStepItem(
                icon = Icons.Default.Email,
                text = "You'll receive a confirmation message"
            )
            NextStepItem(
                icon = Icons.Default.Verified,
                text = "Organization will review your offer"
            )
            NextStepItem(
                icon = Icons.Default.Schedule,
                text = "Contact you within 24-48 hours"
            )
            NextStepItem(
                icon = Icons.Default.Phone,
                text = "Coordinate support details"
            )
        }
    }
}

@Composable
private fun NextStepItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = PaymentConfirmationConstants.PaddingSmall),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = PaymentConfirmationConstants.PrimaryColor,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(PaymentConfirmationConstants.PaddingMedium))
        Text(
            text = text,
            fontSize = PaymentConfirmationConstants.SubtitleSize,
            color = PaymentConfirmationConstants.TextSecondary,
            lineHeight = 20.sp
        )
    }
}

// ==================== Action Buttons ====================

@Composable
private fun ActionButtons(
    onBrowseMore: () -> Unit,
    onBackToDashboard: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = PaymentConfirmationConstants.PaddingLarge)
    ) {
        Button(
            onClick = onBrowseMore,
            modifier = Modifier
                .fillMaxWidth()
                .height(PaymentConfirmationConstants.ButtonHeight),
            colors = ButtonDefaults.buttonColors(
                containerColor = PaymentConfirmationConstants.PrimaryColor
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = "Browse More Requests",
                fontSize = PaymentConfirmationConstants.ButtonTextSize,
                fontWeight = FontWeight.SemiBold
            )
        }
        
        Spacer(modifier = Modifier.height(PaymentConfirmationConstants.PaddingMedium))
        
        OutlinedButton(
            onClick = onBackToDashboard,
            modifier = Modifier
                .fillMaxWidth()
                .height(PaymentConfirmationConstants.ButtonHeight),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                PaymentConfirmationConstants.PrimaryColor
            )
        ) {
            Text(
                text = "Back to Dashboard",
                fontSize = PaymentConfirmationConstants.ButtonTextSize,
                color = PaymentConfirmationConstants.PrimaryColor
            )
        }
    }
}
