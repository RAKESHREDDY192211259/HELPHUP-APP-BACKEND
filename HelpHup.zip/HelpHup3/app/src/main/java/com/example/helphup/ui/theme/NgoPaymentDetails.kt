package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes

// ==================== Constants ====================

private object PaymentDetailsConstants {
    // Colors
    val BackgroundColor = Color(0xFFF0FDF4)
    val CardBackgroundColor = Color.White
    val PrimaryColor = Color(0xFF22C55E)
    val TextPrimary = Color(0xFF1F2937)
    val TextSecondary = Color(0xFF6B7280)
    val BorderColor = Color(0xFFE5E7EB)
    val SecurityBackgroundColor = Color(0xFFDFF6EA)
    
    // Spacing
    val PaddingSmall = 8.dp
    val PaddingMedium = 16.dp
    val PaddingLarge = 20.dp
    val PaddingExtraLarge = 24.dp
    
    // Sizes
    val IconSize = 64.dp
    val ButtonHeight = 52.dp
    
    // Text Sizes
    val TitleSize = 24.sp
    val SubtitleSize = 14.sp
    val SectionTitleSize = 18.sp
    val ButtonTextSize = 16.sp
}

// ==================== Main Screen ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoPaymentDetails(
    navController: NavController,
    requestType: String = "",
    requestId: String = "",
    amount: String = "0",
    method: String = ""
) {
    Scaffold(
        containerColor = PaymentDetailsConstants.BackgroundColor
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(PaymentDetailsConstants.BackgroundColor)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Section
            BackButtonSection(
                onBackClick = { navController.popBackStack() }
            )
            
            Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingMedium))
            
            // Hero Section
            HeroSection(amount = amount.toIntOrNull() ?: 0, method = method)
            
            Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingExtraLarge))
            
            // Payment Form Section
            PaymentFormSection(
                method = method,
                amount = amount.toIntOrNull() ?: 0,
                onPayClick = {
                    navController.navigate(Routes.NGO_SUPPORT_CONFIRMATION + "/$requestType/$requestId/$amount/$method")
                }
            )
            
            Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingLarge))
        }
    }
}

// ==================== Header Components ====================

@Composable
private fun BackButtonSection(
    onBackClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(PaymentDetailsConstants.PaddingMedium),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onBackClick,
            colors = ButtonDefaults.textButtonColors(
                contentColor = PaymentDetailsConstants.PrimaryColor
            )
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "BACK",
                fontSize = PaymentDetailsConstants.SubtitleSize,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==================== Hero Section ====================

@Composable
private fun HeroSection(amount: Int, method: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = PaymentDetailsConstants.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Security Icon
        Box(
            modifier = Modifier
                .size(PaymentDetailsConstants.IconSize)
                .background(
                    PaymentDetailsConstants.SecurityBackgroundColor,
                    RoundedCornerShape(32.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Secure Payment",
                tint = PaymentDetailsConstants.PrimaryColor,
                modifier = Modifier.size(32.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingMedium))
        
        // Title
        Text(
            text = "Payment Details",
            fontSize = PaymentDetailsConstants.TitleSize,
            fontWeight = FontWeight.Bold,
            color = PaymentDetailsConstants.TextPrimary
        )
        
        Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingSmall))
        
        // Subtitle
        Text(
            text = "Enter your payment information securely",
            fontSize = PaymentDetailsConstants.SubtitleSize,
            color = PaymentDetailsConstants.TextSecondary
        )
    }
}

// ==================== Payment Form Section ====================

@Composable
private fun PaymentFormSection(
    method: String,
    amount: Int,
    onPayClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = PaymentDetailsConstants.PaddingLarge),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = PaymentDetailsConstants.CardBackgroundColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(PaymentDetailsConstants.PaddingLarge)
        ) {
            // Payment Method Display
            PaymentMethodDisplay(method = method)
            
            Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingLarge))
            
            // Payment Form Based on Method
            when (method) {
                "CARD" -> CardPaymentForm()
                "UPI" -> UpiPaymentForm()
                "NETBANKING" -> NetBankingForm()
                "WALLET" -> WalletForm()
                "EMI" -> EmiForm()
            }
            
            Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingExtraLarge))
            
            // Security Notice
            SecurityNotice()
            
            Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingExtraLarge))
            
            // Pay Button
            PayButton(
                amount = amount,
                onClick = onPayClick
            )
        }
    }
}

@Composable
private fun PaymentMethodDisplay(method: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Payment Method:",
            fontSize = PaymentDetailsConstants.SubtitleSize,
            color = PaymentDetailsConstants.TextSecondary
        )
        Spacer(modifier = Modifier.width(PaymentDetailsConstants.PaddingSmall))
        Text(
            text = method.replace("_", " "),
            fontSize = PaymentDetailsConstants.SectionTitleSize,
            fontWeight = FontWeight.Bold,
            color = PaymentDetailsConstants.PrimaryColor
        )
    }
}

// ==================== Payment Forms ====================

@Composable
private fun CardPaymentForm() {
    var cardNumber by remember { mutableStateOf("") }
    var cardholderName by remember { mutableStateOf("") }
    var expiryDate by remember { mutableStateOf("") }
    var cvv by remember { mutableStateOf("") }
    
    Column {
        OutlinedTextField(
            value = cardNumber,
            onValueChange = { if (it.length <= 19) cardNumber = it },
            label = { Text("Card Number") },
            placeholder = { Text("1234 5678 9012 3456") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PaymentDetailsConstants.PrimaryColor,
                unfocusedBorderColor = PaymentDetailsConstants.BorderColor
            )
        )
        
        Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingMedium))
        
        OutlinedTextField(
            value = cardholderName,
            onValueChange = { cardholderName = it },
            label = { Text("Cardholder Name") },
            placeholder = { Text("John Doe") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PaymentDetailsConstants.PrimaryColor,
                unfocusedBorderColor = PaymentDetailsConstants.BorderColor
            )
        )
        
        Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingMedium))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(PaymentDetailsConstants.PaddingMedium)
        ) {
            OutlinedTextField(
                value = expiryDate,
                onValueChange = { if (it.length <= 5) expiryDate = it },
                label = { Text("MM/YY") },
                placeholder = { Text("12/25") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PaymentDetailsConstants.PrimaryColor,
                    unfocusedBorderColor = PaymentDetailsConstants.BorderColor
                )
            )
            
            OutlinedTextField(
                value = cvv,
                onValueChange = { if (it.length <= 3) cvv = it },
                label = { Text("CVV") },
                placeholder = { Text("123") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PaymentDetailsConstants.PrimaryColor,
                    unfocusedBorderColor = PaymentDetailsConstants.BorderColor
                )
            )
        }
    }
}

@Composable
private fun UpiPaymentForm() {
    var upiId by remember { mutableStateOf("") }
    
    OutlinedTextField(
        value = upiId,
        onValueChange = { upiId = it },
        label = { Text("UPI ID") },
        placeholder = { Text("yourname@paytm") },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = PaymentDetailsConstants.PrimaryColor,
            unfocusedBorderColor = PaymentDetailsConstants.BorderColor
        )
    )
}

@Composable
private fun NetBankingForm() {
    var selectedBank by remember { mutableStateOf("") }
    val banks = listOf("State Bank", "HDFC Bank", "ICICI Bank", "Axis Bank", "Kotak Bank")
    
    Column {
        Text(
            text = "Select your bank",
            fontSize = PaymentDetailsConstants.SectionTitleSize,
            fontWeight = FontWeight.SemiBold,
            color = PaymentDetailsConstants.TextPrimary
        )
        Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingMedium))
        banks.forEach { bank ->
            PaymentMethodOption(
                title = bank,
                isSelected = selectedBank == bank,
                onClick = { selectedBank = bank }
            )
            Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingSmall))
        }
    }
}

@Composable
private fun WalletForm() {
    var selectedWallet by remember { mutableStateOf("") }
    val wallets = listOf("Paytm", "PhonePe", "Google Pay", "Amazon Pay")
    
    Column {
        Text(
            text = "Choose wallet provider",
            fontSize = PaymentDetailsConstants.SectionTitleSize,
            fontWeight = FontWeight.SemiBold,
            color = PaymentDetailsConstants.TextPrimary
        )
        Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingMedium))
        wallets.forEach { wallet ->
            PaymentMethodOption(
                title = wallet,
                isSelected = selectedWallet == wallet,
                onClick = { selectedWallet = wallet }
            )
            Spacer(modifier = Modifier.height(PaymentDetailsConstants.PaddingSmall))
        }
    }
}

@Composable
private fun EmiForm() {
    Text(
        text = "EMI options will be available after card selection",
        fontSize = PaymentDetailsConstants.SubtitleSize,
        color = PaymentDetailsConstants.TextSecondary
    )
}

@Composable
private fun PaymentMethodOption(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) PaymentDetailsConstants.PrimaryColor else PaymentDetailsConstants.BorderColor
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) 
                PaymentDetailsConstants.SecurityBackgroundColor 
            else 
                PaymentDetailsConstants.CardBackgroundColor
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = title,
            modifier = Modifier.padding(PaymentDetailsConstants.PaddingMedium),
            fontSize = PaymentDetailsConstants.SubtitleSize,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isSelected) PaymentDetailsConstants.PrimaryColor else PaymentDetailsConstants.TextPrimary
        )
    }
}

// ==================== Security Notice ====================

@Composable
private fun SecurityNotice() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                PaymentDetailsConstants.SecurityBackgroundColor,
                RoundedCornerShape(12.dp)
            )
            .padding(PaymentDetailsConstants.PaddingMedium)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = PaymentDetailsConstants.PrimaryColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(PaymentDetailsConstants.PaddingSmall))
            Text(
                text = "Your payment information is encrypted and secure",
                fontSize = PaymentDetailsConstants.SubtitleSize,
                color = PaymentDetailsConstants.TextSecondary
            )
        }
    }
}

// ==================== Pay Button ====================

@Composable
private fun PayButton(
    amount: Int,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(PaymentDetailsConstants.ButtonHeight),
        colors = ButtonDefaults.buttonColors(
            containerColor = PaymentDetailsConstants.PrimaryColor,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = "Pay ₹${amount}",
            fontSize = PaymentDetailsConstants.ButtonTextSize,
            fontWeight = FontWeight.SemiBold
        )
    }
}
