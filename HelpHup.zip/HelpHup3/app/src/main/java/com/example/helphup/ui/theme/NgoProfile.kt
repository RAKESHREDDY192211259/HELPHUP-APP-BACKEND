package com.example.helphup.ui.theme

import android.content.Context
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.helphup.R
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoProfileScreen(navController: NavController) {

    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val coroutineScope = rememberCoroutineScope()

    val fullName = remember { mutableStateOf(sessionManager.getNgoFullName()) }
    val email = remember { mutableStateOf(sessionManager.getNgoEmail()) }
    val phone = remember { mutableStateOf(sessionManager.getNgoPhone()) }
    val address = remember { mutableStateOf(sessionManager.getNgoAddress()) }
    val orgName = remember { mutableStateOf(sessionManager.getNgoOrgName()) }
    val regNumber = remember { mutableStateOf(sessionManager.getNgoRegNumber()) }
    val profileImageUrl = remember { mutableStateOf<String?>(null) }

    // Load profile data from session and API
    fun loadProfileData() {
        coroutineScope.launch {
            val ngoId = sessionManager.getNgoId()
            Log.d("NgoProfile", "Loading profile data for NGO ID: $ngoId")
            
            // First, load from session to show immediate data
            val sessionFullName = sessionManager.getNgoFullName()
            val sessionEmail = sessionManager.getNgoEmail()
            val sessionPhone = sessionManager.getNgoPhone()
            val sessionAddress = sessionManager.getNgoAddress()
            val sessionOrgName = sessionManager.getNgoOrgName()
            val sessionRegNumber = sessionManager.getNgoRegNumber()
            
            Log.d("NgoProfile", "Session data - Name: $sessionFullName, Email: $sessionEmail, Phone: $sessionPhone, Address: $sessionAddress, Org: $sessionOrgName, Reg: $sessionRegNumber")
            
            // Update UI with session data immediately
            if (sessionFullName.isNotEmpty()) fullName.value = sessionFullName
            if (sessionEmail.isNotEmpty()) email.value = sessionEmail
            if (sessionPhone.isNotEmpty()) phone.value = sessionPhone
            if (sessionAddress.isNotEmpty()) address.value = sessionAddress
            if (sessionOrgName.isNotEmpty()) orgName.value = sessionOrgName
            if (sessionRegNumber.isNotEmpty()) regNumber.value = sessionRegNumber
            
            // Then try to fetch fresh data from API
            if (ngoId > 0) {
                try {
                    val request = GetNgoProfileRequest(ngoId)
                    Log.d("NgoProfile", "Making API call with request: $request")
                    val response = NgoProfileApiClient.api.getProfile(request)
                    Log.d("NgoProfile", "API response: status=${response.status}, data=${response.data}")
                    if (response.status && response.data != null) {
                        val profile = response.data
                        Log.d("NgoProfile", "Updating UI with fresh API data: $profile")
                        
                        // Update UI with fresh API data
                        fullName.value = profile.fullName
                        email.value = profile.email
                        phone.value = profile.phone
                        address.value = profile.address
                        orgName.value = profile.orgName
                        regNumber.value = profile.regNumber
                        profileImageUrl.value = profile.profileImageUrl
                        
                        // Update session with fresh data
                        sessionManager.saveNgoSession(profile.ngoId, profile.fullName, profile.email)
                        sessionManager.saveNgoProfileData(profile.phone, profile.address, profile.orgName, profile.regNumber)
                    } else {
                        Log.w("NgoProfile", "API returned error: ${response.message}")
                        // Keep session data if API fails
                    }
                } catch (e: Exception) {
                    Log.e("NgoProfile", "Error loading profile data from API, keeping session data", e)
                    // Keep session data if API fails
                }
            } else {
                Log.w("NgoProfile", "No valid NGO ID found in session")
            }
        }
    }

    // Load data on initial composition
    LaunchedEffect(Unit) {
        loadProfileData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Profile") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAF8))
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(24.dp))

            // Profile Picture and Name
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AsyncImage(
                    model = profileImageUrl.value ?: R.drawable.ic_launcher_background, // Fallback to a default image
                    contentDescription = "Profile Picture",
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE2E8F0))
                        .border(BorderStroke(2.dp, Color.White), CircleShape),
                    contentScale = ContentScale.Crop
                )
                
                Text(
                    text = fullName.value,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )
                Text(
                    text = orgName.value,
                    fontSize = 16.sp,
                    color = Color(0xFF6B7280)
                )
                
                // Refresh Button
                IconButton(
                    onClick = { loadProfileData() },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF22C55E), CircleShape)
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Refresh Profile",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))

            // Horizontal Action Menu
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Edit Profile
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.clickable { navController.navigate(Routes.NGO_EDIT_PROFILE) }
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit Profile",
                            tint = Color(0xFF22C55E)
                        )
                        Text(
                            text = "Edit Profile",
                            fontSize = 12.sp,
                            color = Color(0xFF4B5563)
                        )
                    }
                    // Change Password
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.clickable { navController.navigate(Routes.NGO_CHANGE_PASSWORD) }
                    ) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = "Change Password",
                            tint = Color(0xFF22C55E)
                        )
                        Text(
                            text = "Change Password",
                            fontSize = 12.sp,
                            color = Color(0xFF4B5563)
                        )
                    }
                    // Help/Support
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.clickable { /* Navigate to Help/Support */ }
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Help,
                            contentDescription = "Help & Support",
                            tint = Color(0xFF22C55E)
                        )
                        Text(
                            text = "Help Center",
                            fontSize = 12.sp,
                            color = Color(0xFF4B5563)
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))

            // Navigation Links
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Donors History
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { navController.navigate(Routes.NGO_DONORS_HISTORY) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                Icons.Default.Favorite,
                                contentDescription = "Donors History",
                                tint = Color(0xFF22C55E)
                            )
                            Text(
                                text = "Donors History",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Navigate",
                            tint = Color(0xFF9CA3AF)
                        )
                    }
                    
                    Divider(color = Color(0xFFF3F4F6), thickness = 1.dp)
                    
                    // Volunteers History
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { navController.navigate(Routes.NGO_VOLUNTEER_HISTORY) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                Icons.Default.People,
                                contentDescription = "Volunteers History",
                                tint = Color(0xFF22C55E)
                            )
                            Text(
                                text = "Volunteers History",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Navigate",
                            tint = Color(0xFF9CA3AF)
                        )
                    }
                    
                    Divider(color = Color(0xFFF3F4F6), thickness = 1.dp)
                    
                    // Logout
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { 
                                sessionManager.logout() // Clear session
                                navController.navigate(Routes.ROLE_SELECTION) { // Navigate to role selection
                                    popUpTo(navController.graph.id) { inclusive = true } // Clear back stack
                                }
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = "Change Password",
                                tint = Color(0xFF22C55E)
                            )
                            Text(
                                text = "Change Password",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Navigate",
                            tint = Color(0xFF9CA3AF)
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Simple Profile Information Card - Only Registered Account Data
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Account Information",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    
                    Divider(color = Color(0xFFF3F4F6), thickness = 1.dp)
                    
                    // Only show registered account data
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ProfileInfoCard("Full Name", fullName.value, Icons.Default.Person)
                        ProfileInfoCard("Email", email.value, Icons.Default.Email)
                        ProfileInfoCard("Phone", phone.value, Icons.Default.Phone)
                        ProfileInfoCard("Address", address.value, Icons.Default.LocationOn)
                        ProfileInfoCard("Organization Name", orgName.value, Icons.Default.Business)
                        ProfileInfoCard("Registration Number", regNumber.value, Icons.Default.Verified)
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Action Buttons
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Edit Profile Button
                        Button(
                            onClick = { 
                                loadProfileData() // Refresh data before navigating
                                navController.navigate(Routes.NGO_EDIT_PROFILE) 
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Edit Account Details", color = Color.White, fontWeight = FontWeight.Medium)
                        }
                        
                        // Change Password Button
                        OutlinedButton(
                            onClick = { navController.navigate(Routes.NGO_CHANGE_PASSWORD) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            border = BorderStroke(1.dp, Color(0xFF22C55E)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF22C55E))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Change Password", color = Color(0xFF22C55E), fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileInfoCard(
    label: String, 
    value: String, 
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                icon, 
                contentDescription = null,
                tint = Color(0xFF22C55E),
                modifier = Modifier.size(24.dp)
            )
            
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = label,
                    fontSize = 12.sp,
                    color = Color(0xFF6B7280),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = if (value.isNotBlank()) value else "Not provided",
                    fontSize = 16.sp,
                    color = if (value.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}