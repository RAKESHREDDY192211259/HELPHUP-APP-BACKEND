package com.example.helphup.ui.theme

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* -------------------- API MODELS -------------------- */

data class GetNgoProfileRequest(
    @SerializedName("ngo_id") val ngoId: Int
)

data class GetNgoProfileResponse(
    val status: Boolean,
    val message: String,
    val data: NgoProfileData? = null
)

data class NgoProfileData(
    @SerializedName("ngo_id") val ngoId: Int,
    @SerializedName("full_name") val fullName: String,
    val phone: String,
    val email: String,
    val address: String,
    @SerializedName("org_name") val orgName: String,
    @SerializedName("reg_number") val regNumber: String,
    @SerializedName("reg_proof_file") val regProofFile: String? = null,
    @SerializedName("profile_image_url") val profileImageUrl: String? = null
)

data class UpdateNgoProfileRequest(
    @SerializedName("ngo_id") val ngoId: Int,
    @SerializedName("full_name") val fullName: String,
    val phone: String,
    val email: String,
    val address: String,
    @SerializedName("org_name") val orgName: String,
    @SerializedName("reg_number") val regNumber: String
)

data class UpdateNgoProfileResponse(
    val status: Boolean,
    val message: String
)

data class UpdateNgoPasswordRequest(
    @SerializedName("ngo_id") val ngoId: Int,
    @SerializedName("current_password") val currentPassword: String,
    @SerializedName("new_password") val newPassword: String
)

data class UpdateNgoPasswordResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- API SERVICE -------------------- */

interface NgoProfileApiService {
    @POST("get_ngo_profile.php")
    suspend fun getProfile(@Body request: GetNgoProfileRequest): GetNgoProfileResponse

    @POST("update_ngo_profile.php")
    suspend fun updateProfile(@Body request: UpdateNgoProfileRequest): UpdateNgoProfileResponse

    @POST("update_ngo_password.php")
    suspend fun updatePassword(@Body request: UpdateNgoPasswordRequest): UpdateNgoPasswordResponse
}

object NgoProfileApiClient {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: NgoProfileApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(NgoProfileApiService::class.java)
    }
}

