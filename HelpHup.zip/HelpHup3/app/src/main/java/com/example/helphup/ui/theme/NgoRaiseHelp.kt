package com.example.helphup.ui.theme

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.platform.LocalContext
import com.example.helphup.utils.UserSessionManager
import com.example.helphup.ui.data.HelpRequestDataStore
import com.example.helphup.ui.data.UnifiedApiResponse
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* --------------------------------------------------
   API REQUEST + RESPONSE MODELS
-------------------------------------------------- */

data class UnifiedHelpRequest(
    @SerializedName("requester_type") val requesterType: String,
    @SerializedName("requester_id") val requesterId: Int,
    @SerializedName("requester_name") val requesterName: String,
    @SerializedName("requester_email") val requesterEmail: String,
    @SerializedName("requester_phone") val requesterPhone: String,
    @SerializedName("request_title") val requestTitle: String,
    @SerializedName("category") val category: String,
    @SerializedName("description") val description: String,
    @SerializedName("urgency_level") val urgencyLevel: String,
    @SerializedName("required_amount") val requiredAmount: String,
    @SerializedName("date_needed") val dateNeeded: String,
    @SerializedName("contact_number") val contactNumber: String
)

/* --------------------------------------------------
   API SERVICE
-------------------------------------------------- */

interface NgoApiService {

    @POST("unified_create_help_request.php")
    suspend fun raiseHelp(
        @Body request: UnifiedHelpRequest
    ): UnifiedApiResponse
}

/* --------------------------------------------------
   RETROFIT INSTANCE
-------------------------------------------------- */

object NgoRetrofitInstance {

    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: NgoApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(NgoApiService::class.java)
    }
}

/* --------------------------------------------------
   UI COMPOSABLE
-------------------------------------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoRaiseHelp(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }

    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var urgency by remember { mutableStateOf("Medium") }
    var amount by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var dateNeeded by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    
    // Validation error messages
    var countryCodeError by remember { mutableStateOf("") }
    var phoneNumberError by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    val categories = listOf(
        "Food Distribution",
        "Medical Assistance",
        "Education Support",
        "Disaster Relief",
        "Clothing & Essentials",
        "Shelter",
        "Fund Raising",
        "Other"
    )

    val urgencyLevels = listOf("Low", "Medium", "High", "Critical")

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Raise Help Request", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(scrollState)
        ) {

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Request Title") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            Text("Category", fontWeight = FontWeight.Medium)
            FlowRow {
                categories.forEach {                    FilterChip(
                        selected = category == it,
                        onClick = { category = it },
                        label = { Text(it) }
                    )
                    Spacer(Modifier.width(6.dp))
                }
            }

            Spacer(Modifier.height(12.dp))

            Text("Urgency", fontWeight = FontWeight.Medium)
            FlowRow {
                urgencyLevels.forEach {                    FilterChip(
                        selected = urgency == it,
                        onClick = { urgency = it },
                        label = { Text(it) }
                    )
                    Spacer(Modifier.width(6.dp))
                }
            }

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = amount,
                onValueChange = { 
                    // Only allow digits
                    amount = it.filter { char -> char.isDigit() }
                },
                label = { Text("Required Amount (INR)") },
                prefix = { Text("₹", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                placeholder = { Text("Enter amount in INR") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            // Phone Number Field with Country Code
            PhoneNumberField(
                countryCode = countryCode,
                phoneNumber = phoneNumber,
                onCountryCodeChange = { 
                    countryCode = it
                    countryCodeError = ""
                },
                onPhoneNumberChange = { 
                    phoneNumber = it
                    phoneNumberError = ""
                },
                errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneNumberError,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            DatePickerField(
                label = "Date Needed",
                selectedDate = dateNeeded,
                onDateSelected = { dateNeeded = it },
                modifier = Modifier.fillMaxWidth(),
                allowPastDates = false
            )

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            )

            if (errorMessage.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(errorMessage, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(20.dp))

            Button(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = !isLoading,
                onClick = {
                    // Clear previous errors
                    errorMessage = ""
                    countryCodeError = ""
                    phoneNumberError = ""

                    // Validate phone number
                    val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
                    val phoneValidation = ValidationUtils.validatePhoneNumber(phoneNumber)
                    
                    if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
                    if (!phoneValidation.isValid) phoneNumberError = phoneValidation.errorMessage

                    if (
                        title.isBlank() || category.isBlank() ||
                        amount.isBlank() || dateNeeded.isBlank() || description.isBlank() ||
                        !countryCodeValidation.isValid || !phoneValidation.isValid
                    ) {
                        errorMessage = "Please fill all fields correctly"
                        return@Button
                    }

                    isLoading = true
                    errorMessage = ""

                    scope.launch {
                        try {
                            val response = NgoRetrofitInstance.api.raiseHelp(
                                UnifiedHelpRequest(
                                    requesterType = "ngo",
                                    requesterId = sessionManager.getNgoId(),
                                    requesterName = sessionManager.getNgoFullName(),
                                    requesterEmail = sessionManager.getNgoEmail(),
                                    requesterPhone = "$countryCode$phoneNumber",
                                    requestTitle = title,
                                    category = category,
                                    description = description,
                                    urgencyLevel = urgency,
                                    requiredAmount = amount,
                                    dateNeeded = dateNeeded,
                                    contactNumber = "$countryCode$phoneNumber"
                                )
                            )

                            if (response.status) {
                                Log.d("NgoRaiseHelp", "Help request submitted successfully, notifying data store")
                                // Notify all screens that a new help request has been added
                                HelpRequestDataStore.notifyHelpRequestUpdated()
                                navController.navigate("ngo_help_request_submitted")
                            } else {
                                errorMessage = response.message
                            }

                        } catch (e: Exception) {
                            errorMessage = e.localizedMessage ?: "Network error"
                            e.printStackTrace()
                        } finally {
                            isLoading = false
                        }
                    }
                }
            ) {
                Text(if (isLoading) "Submitting..." else "Submit Request")
            }
        }
    }
}