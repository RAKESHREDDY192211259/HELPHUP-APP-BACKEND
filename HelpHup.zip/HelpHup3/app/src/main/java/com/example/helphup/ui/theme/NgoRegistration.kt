package com.example.helphup.ui.theme

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoRegistrationScreen(navController: NavController) {

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var fullName by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var orgName by remember { mutableStateOf("") }
    var regNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }

    var regProofUri by remember { mutableStateOf<Uri?>(null) }

    // Validation error messages
    var fullNameError by remember { mutableStateOf("") }
    var countryCodeError by remember { mutableStateOf("") }
    var phoneError by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf("") }
    var confirmPasswordError by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        regProofUri = uri
    }

    fun registerNgo() {
        // Clear previous errors
        fullNameError = ""
        countryCodeError = ""
        phoneError = ""
        emailError = ""
        passwordError = ""
        confirmPasswordError = ""
        errorMessage = ""

        // Validate all fields
        val fullNameValidation = ValidationUtils.validateFullName(fullName)
        val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
        val phoneValidation = ValidationUtils.validatePhoneNumber(phone)
        val emailValidation = ValidationUtils.validateEmail(email)
        val passwordValidation = ValidationUtils.validatePassword(password)
        val confirmPasswordValidation = ValidationUtils.validateConfirmPassword(password, confirmPassword)

        // Set error messages
        if (!fullNameValidation.isValid) fullNameError = fullNameValidation.errorMessage
        if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
        if (!phoneValidation.isValid) phoneError = phoneValidation.errorMessage
        if (!emailValidation.isValid) emailError = emailValidation.errorMessage
        if (!passwordValidation.isValid) passwordError = passwordValidation.errorMessage
        if (!confirmPasswordValidation.isValid) confirmPasswordError = confirmPasswordValidation.errorMessage

        // Check if other required fields are blank
        if (address.isBlank() || orgName.isBlank() || regNumber.isBlank()) {
            errorMessage = "Please fill all fields"
        }

        // Check if registration proof is uploaded
        if (regProofUri == null) {
            errorMessage = if (errorMessage.isNotEmpty()) {
                "$errorMessage\nRegistration proof document is required"
            } else {
                "Registration proof document is required"
            }
        }

        // If all validations pass, submit form
        if (fullNameValidation.isValid &&
            countryCodeValidation.isValid &&
            phoneValidation.isValid &&
            emailValidation.isValid &&
            passwordValidation.isValid &&
            confirmPasswordValidation.isValid &&
            address.isNotBlank() &&
            orgName.isNotBlank() &&
            regNumber.isNotBlank() &&
            regProofUri != null
        ) {
            errorMessage = ""
            scope.launch {
                isLoading = true
                errorMessage = ""

                try {
                    val response = withContext(Dispatchers.IO) {
                        uploadMultipart(
                            context,
                            "http://10.126.222.192/helphup/api/ngo_register.php",
                            mapOf(
                                "full_name" to fullName,
                                "phone" to "$countryCode$phone",
                                "email" to email,
                                "address" to address,
                                "org_name" to orgName,
                                "reg_number" to regNumber,
                                "password" to password
                            ),
                            regProofUri!!
                        )
                    }

                    // Check if response is HTML (PHP error page)
                    if (response.trim().startsWith("<") || response.contains("<br>") || response.contains("<!DOCTYPE")) {
                        errorMessage = "Connection error: Server returned HTML instead of JSON\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        return@launch
                    }

                    // Try to parse JSON
                    val json = try {
                        JSONObject(response)
                    } catch (e: Exception) {
                        errorMessage = "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        e.printStackTrace()
                        return@launch
                    }

                    if (json.optBoolean("status")) {
                        navController.navigate(Routes.NGO_LOGIN) {
                            popUpTo(Routes.NGO_REGISTER) { inclusive = true }
                        }
                    } else {
                        errorMessage = json.optString("message", "Registration failed")
                    }

                } catch (e: Exception) {
                    val errorMsg = e.message ?: "Unknown error"
                    errorMessage = when {
                        errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        errorMsg.contains("Unable to resolve host") -> "Connection error: Cannot find server\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        errorMsg.contains("Connection reset") || errorMsg.contains("connection reset") -> "Connection error: Connection reset\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        errorMsg.contains("timeout") -> "Connection error: Connection timeout\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        errorMsg.contains("Network is unreachable") -> "Connection error: Network unreachable\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        errorMsg.contains("Unable to read file") -> "Connection error: File upload error\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        errorMsg.contains("HTTP") -> "Connection error: Server error\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                        else -> "Connection error: $errorMsg\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    }
                    e.printStackTrace()
                } finally {
                    isLoading = false
                }
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Register NGO", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                "Create NGO Account",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )
            Spacer(Modifier.height(24.dp))

            // Full Name Field
            OutlinedTextField(
                value = fullName,
                onValueChange = { 
                    fullName = it
                    fullNameError = ""
                },
                label = { Text("Full Name") },
                isError = fullNameError.isNotEmpty(),
                supportingText = if (fullNameError.isNotEmpty()) {
                    { Text(fullNameError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            // Phone Number Field with Country Code
            PhoneNumberField(
                countryCode = countryCode,
                phoneNumber = phone,
                onCountryCodeChange = { 
                    countryCode = it
                    countryCodeError = ""
                },
                onPhoneNumberChange = { 
                    phone = it
                    phoneError = ""
                },
                errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneError,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            // Email Field
            OutlinedTextField(
                value = email,
                onValueChange = { 
                    email = it
                    emailError = ""
                },
                label = { Text("Email") },
                isError = emailError.isNotEmpty(),
                supportingText = if (emailError.isNotEmpty()) {
                    { Text(emailError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            // Address Field
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            // Organization Name Field
            OutlinedTextField(
                value = orgName,
                onValueChange = { orgName = it },
                label = { Text("Organization Name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            // Registration Number Field
            OutlinedTextField(
                value = regNumber,
                onValueChange = { regNumber = it },
                label = { Text("Registration Number") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            // Password Field
            OutlinedTextField(
                value = password,
                onValueChange = { 
                    password = it
                    passwordError = ""
                },
                label = { Text("Password") },
                visualTransformation = if (passwordVisible) VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                isError = passwordError.isNotEmpty(),
                supportingText = if (passwordError.isNotEmpty()) {
                    { Text(passwordError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            // Confirm Password Field
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { 
                    confirmPassword = it
                    confirmPasswordError = ""
                },
                label = { Text("Confirm Password") },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                        Icon(
                            if (confirmPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                isError = confirmPasswordError.isNotEmpty(),
                supportingText = if (confirmPasswordError.isNotEmpty()) {
                    { Text(confirmPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            OutlinedButton(
                onClick = { filePicker.launch("*/*") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.UploadFile, null)
                Spacer(Modifier.width(8.dp))
                Text(
                    regProofUri?.lastPathSegment ?: "Upload Registration Proof"
                )
            }

            if (errorMessage.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(errorMessage, color = Color.Red)
            }

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = { registerNgo() },
                enabled = !isLoading,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text("Create Account", color = Color.White)
            }
        }
    }
}

