package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NgoVolunteersHistory(navController: NavController) {

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Volunteers History", fontWeight = FontWeight.Bold)
                        Text(
                            "View volunteer records",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        bottomBar = { NgoBottomBar(navController) }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(16.dp)
        ) {

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "Volunteers History",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Text(
                "Your time and effort",
                fontSize = 14.sp,
                color = Color(0xFF6B7280)
            )

            Spacer(modifier = Modifier.height(24.dp))

            /* ---------- Total Hours ---------- */
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF22C55E)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Total Hours", color = Color.White)
                    Text(
                        "12",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        "Thank you for your service!",
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            /* ---------- Volunteer Level ---------- */
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFFFFC107),
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFFFFF3CD), CircleShape)
                                .padding(8.dp)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text("Gold Volunteer", fontWeight = FontWeight.Bold)
                            Text("Level 3 Contributor", fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { 0.75f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = Color(0xFF22C55E),
                        trackColor = Color(0xFFD1FAE5)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        "8 more hours to Platinum",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("Activity Log", fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(12.dp))

            ActivityItem(
                title = "Beach Cleanup Drive",
                hours = "4 hours",
                location = "Ocean Beach",
                date = "Jan 15, 2024",
                role = "Team Lead"
            )

            ActivityItem(
                title = "Food Bank Sorting",
                hours = "3 hours",
                location = "City Center",
                date = "Dec 20, 2023",
                role = "Sorter"
            )

            ActivityItem(
                title = "Tree Planting",
                hours = "5 hours",
                location = "Golden Gate Park",
                date = "Nov 05, 2023",
                role = "Planter"
            )
        }
    }
}

/* ---------- Activity Card ---------- */
@Composable
fun ActivityItem(
    title: String,
    hours: String,
    location: String,
    date: String,
    role: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(hours, fontSize = 12.sp)
                Text(role, fontSize = 12.sp, color = Color(0xFF22C55E))
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text("$location • $date", fontSize = 12.sp, color = Color.Gray)
        }
    }
}
