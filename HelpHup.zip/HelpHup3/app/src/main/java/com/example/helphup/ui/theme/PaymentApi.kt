package com.example.helphup.ui.theme

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

/* ===================== PAYMENT API MODELS ===================== */

data class ApiResponse(
    val status: Boolean,
    val message: String,
    val data: Any? = null
)

// Save Donation Request
data class SaveDonationRequest(
    @SerializedName("donor_id") val donorId: Int,
    @SerializedName("campaign_id") val campaignId: Int? = null,
    @SerializedName("ngo_id") val ngoId: Int? = null,
    @SerializedName("volunteer_id") val volunteerId: Int? = null,
    @SerializedName("amount") val amount: Double,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("transaction_id") val transactionId: String? = null,
    @SerializedName("payment_status") val paymentStatus: String = "completed",
    @SerializedName("description") val description: String? = null
)

// Save NGO Payment Request
data class SaveNgoPaymentRequest(
    @SerializedName("ngo_id") val ngoId: Int,
    @SerializedName("amount") val amount: Double,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("transaction_id") val transactionId: String? = null,
    @SerializedName("payment_status") val paymentStatus: String = "completed",
    @SerializedName("description") val description: String? = null
)

// Save Volunteer Payment Request
data class SaveVolunteerPaymentRequest(
    @SerializedName("volunteer_id") val volunteerId: Int,
    @SerializedName("amount") val amount: Double,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("transaction_id") val transactionId: String? = null,
    @SerializedName("payment_status") val paymentStatus: String = "completed",
    @SerializedName("description") val description: String? = null
)

// Donation History Response
data class DonationHistoryResponse(
    val status: Boolean,
    val message: String,
    val data: DonationHistoryData? = null
)

data class DonationHistoryData(
    val donations: List<DonationItem>,
    @SerializedName("total_donations") val totalDonations: Int,
    @SerializedName("total_amount") val totalAmount: Double
)

data class DonationItem(
    val id: Int,
    @SerializedName("campaign_id") val campaignId: Int?,
    @SerializedName("ngo_id") val ngoId: Int?,
    @SerializedName("volunteer_id") val volunteerId: Int?,
    val amount: Double,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("transaction_id") val transactionId: String?,
    @SerializedName("payment_status") val paymentStatus: String,
    val description: String?,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("campaign_title") val campaignTitle: String?,
    @SerializedName("org_name") val orgName: String?
)

// Payment History Response (for NGO and Volunteer)
data class PaymentHistoryResponse(
    val status: Boolean,
    val message: String,
    val data: PaymentHistoryData? = null
)

data class PaymentHistoryData(
    val payments: List<PaymentItem>,
    @SerializedName("total_payments") val totalPayments: Int,
    @SerializedName("total_amount") val totalAmount: Double
)

data class PaymentItem(
    val id: Int,
    val amount: Double,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("transaction_id") val transactionId: String?,
    @SerializedName("payment_status") val paymentStatus: String,
    val description: String?,
    @SerializedName("created_at") val createdAt: String
)

/* ===================== PAYMENT API INTERFACE ===================== */

interface PaymentApi {
    @POST("save_donation.php")
    suspend fun saveDonation(@Body request: SaveDonationRequest): ApiResponse

    @POST("save_ngo_payment.php")
    suspend fun saveNgoPayment(@Body request: SaveNgoPaymentRequest): ApiResponse

    @POST("save_volunteer_payment.php")
    suspend fun saveVolunteerPayment(@Body request: SaveVolunteerPaymentRequest): ApiResponse

    @GET("get_donation_history.php")
    suspend fun getDonationHistory(@Query("donor_id") donorId: Int): DonationHistoryResponse

    @GET("get_ngo_payment_history.php")
    suspend fun getNgoPaymentHistory(@Query("ngo_id") ngoId: Int): PaymentHistoryResponse

    @GET("get_volunteer_payment_history.php")
    suspend fun getVolunteerPaymentHistory(@Query("volunteer_id") volunteerId: Int): PaymentHistoryResponse
}

object PaymentRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: PaymentApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(PaymentApi::class.java)
    }
}

