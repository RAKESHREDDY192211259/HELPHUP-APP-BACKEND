package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import android.util.Log

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentSelectionScreen(
    navController: NavController,
    requestType: String,
    requestId: String
) {
    var selectedPaymentMethod by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    
    // Get amount from navigation arguments
    val backStackEntry = navController.currentBackStackEntry
    val amount = try {
        backStackEntry?.arguments?.getString("amount")?.toDoubleOrNull() ?: 1000.0
    } catch (e: Exception) {
        Log.e("PaymentSelection", "Error parsing amount parameter", e)
        1000.0 // Fallback to default amount
    }

    // Debug logging
    LaunchedEffect(Unit) {
        Log.d("PaymentSelection", "PaymentSelectionScreen initialized")
        Log.d("PaymentSelection", "RequestType: $requestType, RequestId: $requestId, Amount: $amount")
    }

    Scaffold(
        containerColor = Color(0xFFF8FAFC),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Select Payment Method",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Support ${requestType.uppercase()} Request #$requestId",
                            fontSize = 12.sp,
                            color = Color(0xFFE3F2FD)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2)
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Request Summary Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = when (requestType) {
                            "ngo" -> Icons.Outlined.AttachMoney
                            "volunteer" -> Icons.Outlined.VolunteerActivism
                            "donor" -> Icons.Outlined.Handshake
                            else -> Icons.Outlined.Help
                        },
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = Color(0xFF1976D2)
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = when (requestType) {
                            "ngo" -> "Support NGO Request"
                            "volunteer" -> "Help Volunteer Request"
                            "donor" -> "Support Donor Campaign"
                            else -> "Support Request"
                        },
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1976D2)
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "₹${String.format("%,.2f", amount)}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1976D2)
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Choose your preferred payment method to support this cause",
                        fontSize = 14.sp,
                        color = Color.Gray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            // Payment Methods
            val paymentMethods = listOf(
                PaymentMethod(
                    id = "upi",
                    name = "UPI",
                    icon = Icons.Outlined.AccountBalanceWallet,
                    description = "Pay using UPI apps",
                    color = Color(0xFF1E88E5)
                ),
                PaymentMethod(
                    id = "card",
                    name = "Credit/Debit Card",
                    icon = Icons.Outlined.CreditCard,
                    description = "Pay using credit or debit card",
                    color = Color(0xFF2196F3)
                ),
                PaymentMethod(
                    id = "netbanking",
                    name = "Net Banking",
                    icon = Icons.Outlined.AccountBalance,
                    description = "Pay using internet banking",
                    color = Color(0xFF4CAF50)
                ),
                PaymentMethod(
                    id = "wallet",
                    name = "Digital Wallet",
                    icon = Icons.Outlined.Wallet,
                    description = "Pay using digital wallets",
                    color = Color(0xFFFF9800)
                )
            )

            paymentMethods.forEach { method ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .clickable { 
                                Log.d("PaymentSelection", "Payment method clicked: ${method.id}")
                                selectedPaymentMethod = method.id
                                Log.d("PaymentSelection", "selectedPaymentMethod updated to: $selectedPaymentMethod")
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Card(
                            modifier = Modifier.size(56.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = method.color.copy(alpha = 0.1f)
                            )
                        ) {
                            Icon(
                                imageVector = method.icon,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(28.dp)
                                    .padding(8.dp),
                                tint = method.color
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(16.dp))
                        
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = method.name,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1A1A1A)
                            )
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            Text(
                                text = method.description,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        
                        // Selection indicator
                        if (selectedPaymentMethod == method.id) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF4CAF50),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Pay Button
            Button(
                onClick = {
                    Log.d("PaymentSelection", "Pay button clicked!")
                    Log.d("PaymentSelection", "selectedPaymentMethod: '$selectedPaymentMethod'")
                    Log.d("PaymentSelection", "isProcessing: $isProcessing")
                    Log.d("PaymentSelection", "Button enabled: ${selectedPaymentMethod.isNotEmpty() && !isProcessing}")
                    
                    if (selectedPaymentMethod.isNotEmpty()) {
                        Log.d("PaymentSelection", "Payment method selected: $selectedPaymentMethod")
                        isProcessing = true
                        scope.launch {
                            Log.d("PaymentSelection", "Starting navigation coroutine...")
                            delay(2000) // Simulate processing
                            try {
                                // Navigate to payment details with payment method
                                val navigationRoute = "${Routes.PAYMENT_DETAILS}/$requestType/$requestId/$selectedPaymentMethod"
                                Log.d("PaymentSelection", "Navigating to payment details: $navigationRoute")
                                Log.d("PaymentSelection", "Routes.PAYMENT_DETAILS constant: ${Routes.PAYMENT_DETAILS}")
                                navController.navigate(navigationRoute)
                                Log.d("PaymentSelection", "Navigation call completed successfully")
                            } catch (e: Exception) {
                                Log.e("PaymentSelection", "Error navigating to payment details", e)
                                isProcessing = false
                            }
                        }
                    } else {
                        Log.w("PaymentSelection", "No payment method selected")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                enabled = selectedPaymentMethod.isNotEmpty() && !isProcessing,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1976D2),
                    contentColor = Color.White,
                    disabledContainerColor = Color.Gray.copy(alpha = 0.3f),
                    disabledContentColor = Color.Gray
                )
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        text = "Continue to Payment",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

data class PaymentMethod(
    val id: String,
    val name: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val description: String,
    val color: Color
)
