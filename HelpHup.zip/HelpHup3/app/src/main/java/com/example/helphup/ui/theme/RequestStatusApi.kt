﻿package com.example.helphup.ui.theme

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

/* ---------------- API MODELS ---------------- */

data class UpdateStatusRequest(
    val request_id: String,
    val request_type: String, // "ngo", "volunteer", "donor"
    val status: String, // "APPROVED", "REJECTED"
    val rejection_reason: String? = null
)

data class UpdateStatusResponse(
    val status: Boolean,
    val message: String,
    val updated_rows: Int? = null,
    val request_id: String? = null,
    val request_type: String? = null,
    val new_status: String? = null
)

/* ---------------- API SERVICE ---------------- */

interface RequestStatusApiService {
    @POST("update_request_status.php")
    suspend fun updateRequestStatus(@Body request: UpdateStatusRequest): Response<UpdateStatusResponse>
}

object RequestStatusApiClient {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: RequestStatusApiService by lazy {
        retrofit2.Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(retrofit2.converter.gson.GsonConverterFactory.create())
            .build()
            .create(RequestStatusApiService::class.java)
    }
}
