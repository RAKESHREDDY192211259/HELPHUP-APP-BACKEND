package com.example.helphup.ui.role

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun RoleSelectionScreen(
    onNgoClick: () -> Unit = {},
    onVolunteerClick: () -> Unit = {},
    onDonorClick: () -> Unit = {},
    onAdminClick: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "Welcome to HelpHup",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "A community support platform connecting NGOs, volunteers, and donors. Choose how you want to contribute today.",
            fontSize = 14.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        RoleCard(
            icon = Icons.Outlined.FavoriteBorder,
            iconBg = Color(0xFFE8F8F1),
            iconTint = Color(0xFF22C55E),
            title = "NGO",
            description = "Register your organization to raise funds and request volunteers.",
            onClick = onNgoClick
        )

        Spacer(modifier = Modifier.height(16.dp))

        RoleCard(
            icon = Icons.Outlined.Person,
            iconBg = Color(0xFFFFF3E8),
            iconTint = Color(0xFFF97316),
            title = "Volunteer",
            description = "Join to offer your skills and time to help those in need.",
            onClick = onVolunteerClick
        )

        Spacer(modifier = Modifier.height(16.dp))

        RoleCard(
            icon = Icons.Outlined.Person,
            iconBg = Color(0xFFEFF6FF),
            iconTint = Color(0xFF3B82F6),
            title = "Donor",
            description = "Support causes and people directly with financial contributions.",
            onClick = onDonorClick
        )

        Spacer(modifier = Modifier.height(16.dp))

        RoleCard(
            icon = Icons.Outlined.Settings,
            iconBg = Color(0xFFF3E8FF),
            iconTint = Color(0xFF9333EA),
            title = "Admin",
            description = "Administrator access to manage the platform and users.",
            onClick = onAdminClick
        )
    }
}

@Composable
private fun RoleCard(
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(iconBg, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = description,
                fontSize = 13.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Continue as $title →",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = iconTint,
                modifier = Modifier.clickable { onClick() }
            )
        }
    }
}
