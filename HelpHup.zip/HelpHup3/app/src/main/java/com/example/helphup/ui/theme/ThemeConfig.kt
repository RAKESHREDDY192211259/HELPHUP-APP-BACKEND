package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* ---------------- THEME CONFIGURATION ---------------- */

@Composable
fun HelpHupTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        DarkColorScheme
    } else {
        LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

/* ---------------- SCREEN-SPECIFIC THEMES ---------------- */

@Composable
fun NgoScreenTheme(
    content: @Composable () -> Unit
) {
    HelpHupTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = NgoColors.Background
        ) {
            content()
        }
    }
}

@Composable
fun VolunteerScreenTheme(
    content: @Composable () -> Unit
) {
    HelpHupTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = VolunteerColors.Background
        ) {
            content()
        }
    }
}

@Composable
fun DonorScreenTheme(
    content: @Composable () -> Unit
) {
    HelpHupTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = DonorColors.Background
        ) {
            content()
        }
    }
}

@Composable
fun AuthScreenTheme(
    content: @Composable () -> Unit
) {
    HelpHupTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = AuthColors.Background
        ) {
            content()
        }
    }
}

/* ---------------- EXAMPLE IMPLEMENTATIONS ---------------- */

@Composable
fun ExampleNgoDashboard() {
    NgoScreenTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NGO Dashboard",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextColors.Primary
                    )
                    Text(
                        text = "Manage your organization",
                        fontSize = 14.sp,
                        color = TextColors.Secondary
                    )
                }
                
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = null,
                    tint = NgoColors.Primary
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Stats Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatsCard(
                    modifier = Modifier.weight(1f),
                    title = "Total Raised",
                    value = "₹24,500",
                    subtitle = "This month",
                    icon = Icons.Outlined.AttachMoney,
                    color = NgoColors.Success
                )
                
                StatsCard(
                    modifier = Modifier.weight(1f),
                    title = "Volunteers",
                    value = "142",
                    subtitle = "Active",
                    icon = Icons.Outlined.People,
                    color = NgoColors.Secondary
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Impact Card
            ImpactCard(
                title = "Your Impact",
                stats = listOf(
                    "1,250" to "Lives Helped",
                    "45" to "Campaigns",
                    "12" to "Communities"
                ),
                gradient = GradientColors.NatureGradient
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Action Cards
            DashboardActionCard(
                icon = Icons.Outlined.Add,
                title = "Raise Help Request",
                subtitle = "Create a new campaign",
                color = NgoColors.Primary,
                onClick = { }
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            DashboardActionCard(
                icon = Icons.Outlined.History,
                title = "View History",
                subtitle = "Check past activities",
                color = NgoColors.Secondary,
                onClick = { }
            )
        }
    }
}

@Composable
fun ExampleVolunteerDashboard() {
    VolunteerScreenTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Volunteer Dashboard",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextColors.Primary
                    )
                    Text(
                        text = "Make a difference today",
                        fontSize = 14.sp,
                        color = TextColors.Secondary
                    )
                }
                
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = null,
                    tint = VolunteerColors.Primary
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Stats Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatsCard(
                    modifier = Modifier.weight(1f),
                    title = "Hours Volunteered",
                    value = "156",
                    subtitle = "This month",
                    icon = Icons.Outlined.Schedule,
                    color = VolunteerColors.Primary
                )
                
                StatsCard(
                    modifier = Modifier.weight(1f),
                    title = "People Helped",
                    value = "89",
                    subtitle = "Direct impact",
                    icon = Icons.Outlined.Favorite,
                    color = VolunteerColors.Success
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Impact Card
            ImpactCard(
                title = "Your Contribution",
                stats = listOf(
                    "156" to "Hours",
                    "89" to "People",
                    "12" to "Projects"
                ),
                gradient = GradientColors.WarmGradient
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Action Cards
            DashboardActionCard(
                icon = Icons.Outlined.Search,
                title = "Find Opportunities",
                subtitle = "Discover ways to help",
                color = VolunteerColors.Primary,
                onClick = { }
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            DashboardActionCard(
                icon = Icons.Outlined.History,
                title = "My History",
                subtitle = "View your contributions",
                color = VolunteerColors.Accent,
                onClick = { }
            )
        }
    }
}

@Composable
fun ExampleDonorDashboard() {
    DonorScreenTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Donor Dashboard",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextColors.Primary
                    )
                    Text(
                        text = "Your generosity changes lives",
                        fontSize = 14.sp,
                        color = TextColors.Secondary
                    )
                }
                
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = null,
                    tint = DonorColors.Primary
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Stats Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatsCard(
                    modifier = Modifier.weight(1f),
                    title = "Total Donated",
                    value = "₹5,200",
                    subtitle = "All time",
                    icon = Icons.Outlined.AttachMoney,
                    color = DonorColors.Success
                )
                
                StatsCard(
                    modifier = Modifier.weight(1f),
                    title = "Campaigns",
                    value = "23",
                    subtitle = "Supported",
                    icon = Icons.Outlined.Favorite,
                    color = DonorColors.Accent
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Impact Card
            ImpactCard(
                title = "Your Giving Impact",
                stats = listOf(
                    "₹5.2K" to "Total Given",
                    "23" to "Causes",
                    "342" to "Lives Impacted"
                ),
                gradient = GradientColors.SunsetGradient
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Action Cards
            DashboardActionCard(
                icon = Icons.Outlined.Search,
                title = "Browse Causes",
                subtitle = "Find campaigns to support",
                color = DonorColors.Primary,
                onClick = { }
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            DashboardActionCard(
                icon = Icons.Outlined.Add,
                title = "Make a Donation",
                subtitle = "Support a cause today",
                color = DonorColors.Secondary,
                onClick = { }
            )
        }
    }
}

/* ---------------- USAGE GUIDE ---------------- */

/*
HOW TO USE THIS TEMPLATE:

1. IMPORT THE REQUIRED FILES:
   import com.example.helphup.ui.theme.ColorPalette
   import com.example.helphup.ui.theme.ModernComponents
   import com.example.helphup.ui.theme.ThemeConfig

2. WRAP YOUR SCREEN WITH THE APPROPRIATE THEME:
   
   For NGO Screens:
   NgoScreenTheme {
       YourScreenContent()
   }
   
   For Volunteer Screens:
   VolunteerScreenTheme {
       YourScreenContent()
   }
   
   For Donor Screens:
   DonorScreenTheme {
       YourScreenContent()
   }
   
   For Auth Screens:
   AuthScreenTheme {
       YourScreenContent()
   }

3. USE THE MODERN COMPONENTS:
   
   - ModernCard: For general card layouts
   - GradientCard: For highlighted cards with gradients
   - StatsCard: For displaying statistics
   - DashboardActionCard: For dashboard actions
   - ImpactCard: For impact metrics
   - ModernButton: For primary actions
   - GradientButton: For highlighted actions
   - OutlinedButton: For secondary actions
   - ModernTextField: For input fields
   - StatusChip: For status indicators
   - LoadingCard: For loading states
   - EmptyStateCard: For empty states

4. COLOR USAGE:
   
   - Primary Colors: Use for main actions and branding
   - Secondary Colors: Use for complementary elements
   - Accent Colors: Use for highlights and special features
   - Semantic Colors: Use for status and feedback
   - Neutral Colors: Use for text, borders, and backgrounds

5. CONSISTENCY TIPS:
   
   - Use the appropriate screen theme for each user type
   - Follow the color scheme for each user type
   - Use consistent corner radius (12-16dp for cards, 12dp for buttons)
   - Use consistent spacing (8dp, 12dp, 16dp, 24dp)
   - Use consistent typography from MaterialTheme
   - Use semantic colors for status indicators

6. EXAMPLE COMPONENT USAGE:
   
   StatsCard(
       title = "Total Raised",
       value = "$24,500",
       subtitle = "This month",
       icon = Icons.Outlined.AttachMoney,
       color = NgoColors.Success,
       onClick = { /* Handle click */ }
   )
   
   ModernButton(
       text = "Create Campaign",
       onClick = { /* Handle click */ },
       backgroundColor = NgoColors.Primary,
       icon = Icons.Outlined.Add
   )
   
   StatusChip(
       text = "Active",
       status = StatusType.SUCCESS
   )
*/
