package com.example.helphup.ui.theme

import java.text.NumberFormat
import java.util.Locale

object ValidationUtils {
    
    // Country codes list
    val countryCodes = listOf("+91", "+1", "+44", "+86", "+81", "+49", "+33", "+39", "+61", "+7", "+82", "+34", "+31", "+46", "+41", "+65", "+60", "+66", "+62", "+84")
    
    /**
     * Validate Full Name
     * Must contain full name (First Name + Last Name)
     * No nicknames, short forms, or single-word names
     * Only alphabets and spaces allowed
     * Minimum 2 words required
     */
    fun validateFullName(name: String): ValidationResult {
        when {
            name.isBlank() -> return ValidationResult(false, "Please enter your full name (first and last name)")
            name.trim().split("\\s+".toRegex()).size < 2 -> return ValidationResult(false, "Please enter your full name (first and last name)")
            !name.matches(Regex("^[a-zA-Z\\s]+$")) -> return ValidationResult(false, "Name should contain only letters and spaces")
            name.trim().split("\\s+".toRegex()).any { it.length < 2 } -> return ValidationResult(false, "Short names or nicknames are not allowed")
            else -> return ValidationResult(true, "")
        }
    }
    
    /**
     * Validate Email Address
     * Email must be in valid email/Gmail format
     * No spaces allowed
     */
    fun validateEmail(email: String): ValidationResult {
        val emailRegex = "^[A-Za-z0-9+_.-]+@([A-Za-z0-9.-]+\\.[A-Za-z]{2,})$"
        return when {
            email.isBlank() -> ValidationResult(false, "Invalid email format. Please enter a valid email address")
            email.contains(" ") -> ValidationResult(false, "Invalid email format. Please enter a valid email address")
            !email.matches(Regex(emailRegex)) -> ValidationResult(false, "Email should be in correct format (example@gmail.com)")
            else -> ValidationResult(true, "")
        }
    }
    
    /**
     * Validate Phone Number (without country code)
     * Only numeric values allowed
     * Phone number must be exactly 10 digits
     */
    fun validatePhoneNumber(phone: String): ValidationResult {
        return when {
            phone.isBlank() -> ValidationResult(false, "Mobile number must contain exactly 10 digits")
            !phone.matches(Regex("^[0-9]+$")) -> ValidationResult(false, "Only numbers are allowed in mobile number")
            phone.length != 10 -> ValidationResult(false, "Mobile number must contain exactly 10 digits")
            else -> ValidationResult(true, "")
        }
    }
    
    /**
     * Validate Country Code
     */
    fun validateCountryCode(countryCode: String): ValidationResult {
        return if (countryCode.isBlank()) {
            ValidationResult(false, "Please select a country code")
        } else {
            ValidationResult(true, "")
        }
    }
    
    /**
     * Validate Password
     * Must contain:
     * - At least 1 Capital letter (A–Z)
     * - At least 1 Small letter (a–z)
     * - At least 1 Number (0–9)
     * - At least 1 Special character (@ # $ % & * !)
     * - Minimum 8 characters
     */
    fun validatePassword(password: String): ValidationResult {
        when {
            password.length < 8 -> return ValidationResult(false, "Password must be at least 8 characters long")
            !password.matches(Regex(".*[A-Z].*")) -> return ValidationResult(false, "Password must contain at least one capital letter")
            !password.matches(Regex(".*[a-z].*")) -> return ValidationResult(false, "Password must contain at least one small letter")
            !password.matches(Regex(".*[0-9].*")) -> return ValidationResult(false, "Password must contain at least one number")
            !password.matches(Regex(".*[@#\$%&*!].*")) -> return ValidationResult(false, "Password must contain at least one special character")
            else -> return ValidationResult(true, "")
        }
    }
    
    /**
     * Validate Confirm Password
     */
    fun validateConfirmPassword(password: String, confirmPassword: String): ValidationResult {
        return if (password != confirmPassword) {
            ValidationResult(false, "Passwords do not match")
        } else {
            ValidationResult(true, "")
        }
    }
    
    /**
     * Format amount in Indian Rupee (INR) format
     * Example: 1000 -> "₹1,000" or "₹1,000.00"
     */
    fun formatCurrencyINR(amount: Double): String {
        val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        return formatter.format(amount)
    }
    
    /**
     * Format amount in Indian Rupee (INR) format without decimals
     * Example: 1000 -> "₹1,000"
     */
    fun formatCurrencyINR(amount: Int): String {
        return formatCurrencyINR(amount.toDouble())
    }
    
    /**
     * Format amount in Indian Rupee (INR) format from String
     * Example: "1000" -> "₹1,000"
     */
    fun formatCurrencyINR(amount: String): String {
        val amountValue = amount.toDoubleOrNull() ?: 0.0
        return formatCurrencyINR(amountValue)
    }
    
    /**
     * Get INR symbol
     */
    fun getINRSymbol(): String = "₹"
    
    /**
     * Get currency suffix for labels
     */
    fun getCurrencyLabel(): String = "INR"
}

data class ValidationResult(
    val isValid: Boolean,
    val errorMessage: String
)

