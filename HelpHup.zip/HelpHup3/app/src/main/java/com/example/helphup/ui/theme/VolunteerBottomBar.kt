package com.example.helphup.ui.theme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes

/* ---------------- Bottom Navigation ---------------- */

@Composable
fun VolunteerBottomBar(navController: NavController, currentScreen: String = "dashboard") {
    NavigationBar {
        NavigationBarItem(
            selected = currentScreen == "dashboard",
            onClick = { navController.navigate(Routes.VOLUNTEER_DASHBOARD) },
            icon = { Icon(Icons.Outlined.Home, null) },
            label = { Text("Home") }
        )
        NavigationBarItem(
            selected = currentScreen == "notifications",
            onClick = { navController.navigate(Routes.VOLUNTEER_NOTIFICATIONS) },
            icon = { Icon(Icons.Outlined.Notifications, null) },
            label = { Text("Notifications") }
        )
        NavigationBarItem(
            selected = currentScreen == "profile",
            onClick = { navController.navigate(Routes.VOLUNTEER_PROFILE) },
            icon = { Icon(Icons.Outlined.Person, null) },
            label = { Text("Profile") }
        )
    }
}
