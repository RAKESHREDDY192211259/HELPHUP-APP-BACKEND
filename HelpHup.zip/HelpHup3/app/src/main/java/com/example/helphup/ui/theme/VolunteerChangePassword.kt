package com.example.helphup.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.utils.UserSessionManager
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.util.Log
import com.example.helphup.ui.theme.VolunteerProfileApiClient
import com.example.helphup.ui.theme.UpdateVolunteerPasswordRequest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerChangePassword(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val scope = rememberCoroutineScope()

    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    
    var currentPasswordVisible by remember { mutableStateOf(false) }
    var newPasswordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    
    // Validation error messages
    var newPasswordError by remember { mutableStateOf("") }
    var confirmPasswordError by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Change Password", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Current Password
            OutlinedTextField(
                value = currentPassword,
                onValueChange = { currentPassword = it },
                label = { Text("Current Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                visualTransformation = if (currentPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { currentPasswordVisible = !currentPasswordVisible }) {
                        Icon(
                            if (currentPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            // New Password with validation
            OutlinedTextField(
                value = newPassword,
                onValueChange = { 
                    newPassword = it
                    newPasswordError = ""
                },
                label = { Text("New Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                visualTransformation = if (newPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                isError = newPasswordError.isNotEmpty(),
                supportingText = if (newPasswordError.isNotEmpty()) {
                    { Text(newPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                trailingIcon = {
                    IconButton(onClick = { newPasswordVisible = !newPasswordVisible }) {
                        Icon(
                            if (newPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            // Confirm Password with validation
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { 
                    confirmPassword = it
                    confirmPasswordError = ""
                },
                label = { Text("Confirm New Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                isError = confirmPasswordError.isNotEmpty(),
                supportingText = if (confirmPasswordError.isNotEmpty()) {
                    { Text(confirmPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                trailingIcon = {
                    IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                        Icon(
                            if (confirmPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            
            if (errorMessage.isNotEmpty()) {
                Text(errorMessage, color = Color(0xFFEF4444))
            }
            
            if (successMessage.isNotEmpty()) {
                Text(successMessage, color = Color(0xFF22C55E))
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                enabled = !isLoading,
                onClick = {
                    // Clear previous errors
                    newPasswordError = ""
                    confirmPasswordError = ""
                    errorMessage = ""
                    
                    // Check if current password is filled
                    if (currentPassword.isBlank()) {
                        errorMessage = "Please enter your current password"
                    }
                    
                    // Validate new password
                    val newPasswordValidation = ValidationUtils.validatePassword(newPassword)
                    if (!newPasswordValidation.isValid) {
                        newPasswordError = newPasswordValidation.errorMessage
                    }
                    
                    // Validate confirm password
                    val confirmPasswordValidation = ValidationUtils.validateConfirmPassword(newPassword, confirmPassword)
                    if (!confirmPasswordValidation.isValid) {
                        confirmPasswordError = confirmPasswordValidation.errorMessage
                    }
                    
                    // Check if new password is different from current password
                    if (currentPassword.isNotBlank() && newPassword == currentPassword) {
                        errorMessage = "New password must be different from current password"
                    }
                    
                    // If all validations pass, update password
                    if (currentPassword.isNotBlank() &&
                        newPasswordValidation.isValid &&
                        confirmPasswordValidation.isValid &&
                        newPassword != currentPassword) {
                        errorMessage = ""
                        successMessage = ""
                        
                        scope.launch {
                            isLoading = true
                            try {
                                val volunteerId = sessionManager.getVolunteerId()
                                if (volunteerId <= 0) {
                                    errorMessage = "Invalid session. Please login again."
                                    return@launch
                                }
                                
                                val response = VolunteerProfileApiClient.api.updatePassword(
                                    UpdateVolunteerPasswordRequest(
                                        volunteerId = volunteerId,
                                        currentPassword = currentPassword,
                                        newPassword = newPassword
                                    )
                                )
                                
                                if (response.status) {
                                    successMessage = "Password updated successfully!"
                                    // Navigate back after delay
                                    kotlinx.coroutines.delay(2000)
                                    navController.popBackStack()
                                } else {
                                    errorMessage = response.message
                                }
                            } catch (e: Exception) {
                                Log.e("VolunteerChangePassword", "Error changing password: ${e.message}", e)
                                errorMessage = "Failed to update password. Please try again."
                            } finally {
                                isLoading = false
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22C55E)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = if (isLoading) "Updating..." else "Update Password",
                    color = Color.White
                )
            }
        }
    }
}
