package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerCommunitySupport(
    navController: NavController,
    requestType: String = "",
    requestId: String = "",
    helpRequestTitle: String = "Weekend Food Distribution"
) {
    var selectedSupportType by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    var availability by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val supportTypes = listOf(
        "Volunteer Time",
        "Donate Items",
        "Financial Support",
        "Transportation",
        "Professional Services",
        "Other"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Community Support", fontWeight = FontWeight.Bold)
                        Text(
                            text = "Offer your help",
                            fontSize = 12.sp,
                            color = Color(0xFF22C55E)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFEAF7EC))
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            // Help Request Summary Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Help Request",
                        fontSize = 14.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = helpRequestTitle,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF14532D)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "How would you like to help?",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF14532D)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Support Type Selection
            supportTypes.forEach { type ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedSupportType == type,
                        onClick = { selectedSupportType = type },
                        colors = RadioButtonDefaults.colors(
                            selectedColor = Color(0xFF22C55E)
                        )
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = type,
                        fontSize = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                label = { Text("Your Message") },
                placeholder = { Text("Describe how you can help...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = contactNumber,
                onValueChange = { contactNumber = it },
                label = { Text("Contact Number") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = availability,
                onValueChange = { availability = it },
                label = { Text("Availability") },
                placeholder = { Text("e.g., Weekends, Evenings, Immediate") },
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMessage.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (
                        selectedSupportType.isBlank() ||
                        message.isBlank() ||
                        contactNumber.isBlank() ||
                        availability.isBlank()
                    ) {
                        errorMessage = "Please fill all required fields"
                    } else {
                        errorMessage = ""
                        if (selectedSupportType == "Financial Support") {
                            // Default amount for financial support, can be made configurable
                            val defaultAmount = 100
                            navController.navigate(Routes.VOLUNTEER_PAYMENT_METHODS + "/$requestType/$requestId/$defaultAmount") {
                                popUpTo(Routes.VOLUNTEER_REQUEST_DETAILS) { inclusive = false }
                            }
                        } else {
                            navController.navigate(Routes.VOLUNTEER_SUPPORT_CONFIRMATION) {
                                popUpTo(Routes.VOLUNTEER_REQUEST_DETAILS) { inclusive = false }
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22C55E)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Submit Support Offer",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Cancel",
                    fontSize = 16.sp,
                    color = Color(0xFF22C55E)
                )
            }
        }
    }
}
