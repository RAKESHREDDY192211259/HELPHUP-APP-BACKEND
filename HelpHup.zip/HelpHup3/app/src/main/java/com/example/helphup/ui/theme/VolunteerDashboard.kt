package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.utils.UserSessionManager
import androidx.compose.runtime.remember

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerDashboard(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    
    fun handleLogout() {
        sessionManager.clearSession()
        navController.navigate(Routes.VOLUNTEER_LOGIN) {
            popUpTo(Routes.VOLUNTEER_DASHBOARD) { inclusive = true }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        bottomBar = {
            VolunteerBottomBar(navController)
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
        ) {

            /* ---------- Header ---------- */
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Column {
                    Text(
                        text = "Volunteer Dashboard",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    Text(
                        text = "Make a difference today",
                        fontSize = 14.sp,
                        color = Color(0xFF22C55E)
                    )
                }

                Row {
                    IconButton(
                        onClick = {
                            navController.navigate(Routes.VOLUNTEER_NOTIFICATIONS)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = Color(0xFF22C55E)
                        )
                    }
                    
                    IconButton(
                        onClick = { handleLogout() }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ExitToApp,
                            contentDescription = "Logout",
                            tint = Color(0xFFEF4444)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            /* ---------- Welcome Section ---------- */
            Text(
                text = "Welcome Back!",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Ready to make a difference today?",
                fontSize = 14.sp,
                color = Color(0xFF6B7280)
            )

            Spacer(modifier = Modifier.height(20.dp))

            VolunteerDashboardCard(
                icon = Icons.Outlined.FavoriteBorder,
                title = "Help Others",
                subtitle = "Browse and support requests",
                iconColor = Color(0xFF10B981)
            ) {
                navController.navigate(Routes.VOLUNTEER_HELP_OTHERS)
            }

            VolunteerDashboardCard(
                icon = Icons.Outlined.AddCircle,
                title = "Request Help",
                subtitle = "Create a help request",
                iconColor = Color(0xFF3B82F6)
            ) {
                navController.navigate(Routes.VOLUNTEER_RAISE_HELP)
            }

            VolunteerDashboardCard(
                icon = Icons.Outlined.History,
                title = "My Volunteer History",
                subtitle = "View your contributions",
                iconColor = Color(0xFF8B5CF6)
            ) {
                navController.navigate(Routes.VOLUNTEER_HISTORY)
            }

            // ✅ REQUIRED NAVIGATION
            VolunteerDashboardCard(
                icon = Icons.Outlined.People,
                title = "Donation Records",
                subtitle = "Track your donations",
                iconColor = Color(0xFFF59E0B)
            ) {
                navController.navigate(Routes.VOLUNTEER_DONATION_RECORDS)
            }

            Spacer(modifier = Modifier.height(12.dp))

            ImpactCard()
        }
    }
}

/* ---------------- Reusable Components ---------------- */

@Composable
fun VolunteerDashboardCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    iconColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .clickable { onClick() },
            verticalAlignment = Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(iconColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White)
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(
                    subtitle,
                    color = Color.Gray,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun ImpactCard() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ImpactItem("12", "Hours")
            ImpactItem("8", "Helped")
            ImpactItem("4.9", "Rating")
        }
    }
}

@Composable
fun ImpactItem(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold)
        Text(label, color = Color.White.copy(alpha = 0.8f))
    }
}
