package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerDonationRecords(navController: NavController) {

    val donations = listOf(
        DonationRecord("Oct 01, 2023", "City Food Bank", "₹50.00"),
        DonationRecord("Sep 15, 2023", "Red Cross", "₹100.00"),
        DonationRecord("Aug 22, 2023", "Animal Shelter", "₹25.00"),
        DonationRecord("Jul 10, 2023", "Education Fund", "₹250.00")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Donation Records", fontWeight = FontWeight.Bold)
                        Text(
                            "View your donation history and download tax receipts.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { /* CSV export */ }) {
                        Icon(
                            Icons.Outlined.Download,
                            contentDescription = "Export",
                            tint = Color(0xFF10B981)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export All (CSV)", color = Color(0xFF10B981))
                    }
                }
            )
        },
        bottomBar = {
            // ✅ FIX: removed `selected`
            VolunteerBottomBar(navController)
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
        ) {

            DonationHeaderRow()

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(donations) { record ->
                    DonationItem(record)
                }
            }
        }
    }
}

/* ---------------- Models ---------------- */

data class DonationRecord(
    val date: String,
    val organization: String,
    val amount: String
)

/* ---------------- UI Components ---------------- */

@Composable
fun DonationHeaderRow() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Date", fontWeight = FontWeight.Bold, color = Color.Gray)
        Text("Organization", fontWeight = FontWeight.Bold, color = Color.Gray)
        Text("Amount", fontWeight = FontWeight.Bold, color = Color.Gray)
    }
}

@Composable
fun DonationItem(record: DonationRecord) {
    Card(
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(record.date)
            Text(record.organization, fontWeight = FontWeight.Medium)
            Text(record.amount, fontWeight = FontWeight.Bold)
        }
    }
}
