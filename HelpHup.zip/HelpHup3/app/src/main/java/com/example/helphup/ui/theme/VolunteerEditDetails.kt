package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.helphup.ui.theme.ValidationUtils
import com.example.helphup.utils.UserSessionManager
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.util.Log
import com.example.helphup.ui.theme.VolunteerProfileApiClient
import com.example.helphup.ui.theme.GetVolunteerProfileRequest
import com.example.helphup.ui.theme.UpdateVolunteerProfileRequest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerEditDetails(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val scope = rememberCoroutineScope()
    
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    
    // Load user data from session initially
    val loadedFullName = sessionManager.getVolunteerFullName()
    val loadedEmail = sessionManager.getVolunteerEmail()
    val loadedPhone = sessionManager.getVolunteerPhone()
    val loadedSkills = sessionManager.getVolunteerSkills()
    val loadedAvailability = sessionManager.getVolunteerAvailability()
    
    // Initialize state variables with session data
    var fullName by remember { mutableStateOf(loadedFullName) }
    var email by remember { mutableStateOf(loadedEmail) }
    var countryCode by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var skills by remember { mutableStateOf(loadedSkills) }
    
    val availabilityOptions = listOf("Weekdays", "Weekends", "Evenings", "Flexible")
    val selectedAvailability = remember { mutableStateListOf<String>() }
    
    // Validation error messages
    var fullNameError by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf("") }
    var countryCodeError by remember { mutableStateOf("") }
    var phoneNumberError by remember { mutableStateOf("") }
    
    // Fetch profile data from API when screen loads
    LaunchedEffect(Unit) {
        val volunteerId = sessionManager.getVolunteerId()
        if (volunteerId > 0) {
            isLoading = true
            try {
                val response = VolunteerProfileApiClient.api.getProfile(
                    GetVolunteerProfileRequest(volunteerId)
                )
                if (response.status && response.data != null) {
                    val data = response.data
                    fullName = data.fullName
                    email = data.email
                    skills = data.skills
                    
                    // Parse phone number
                    val phoneParts = if (data.phone.isNotEmpty() && data.phone.startsWith("+")) {
                        val match = Regex("^(\\+\\d{1,4})(\\d+)$").find(data.phone)
                        if (match != null) {
                            match.groupValues[1] to match.groupValues[2]
                        } else {
                            when {
                                data.phone.startsWith("+91") && data.phone.length > 3 -> "+91" to data.phone.substring(3)
                                data.phone.startsWith("+1") && data.phone.length > 2 -> "+1" to data.phone.substring(2)
                                data.phone.startsWith("+44") && data.phone.length > 3 -> "+44" to data.phone.substring(3)
                                else -> "" to data.phone
                            }
                        }
                    } else {
                        "" to data.phone
                    }
                    countryCode = phoneParts.first
                    phoneNumber = phoneParts.second
                    
                    // Parse availability
                    if (data.availability.isNotEmpty()) {
                        selectedAvailability.clear()
                        selectedAvailability.addAll(data.availability.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                    }
                    
                    // Update session
                    sessionManager.saveVolunteerSession(volunteerId, data.fullName, data.email)
                    sessionManager.saveVolunteerProfileData(data.phone, data.skills, data.availability)
                } else {
                    errorMessage = "Failed to load profile: ${response.message}"
                }
            } catch (e: Exception) {
                Log.e("VolunteerEditDetails", "Error loading profile: ${e.message}", e)
                errorMessage = "Failed to load profile: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Edit Details", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "Edit Details",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Full Name with validation
            OutlinedTextField(
                value = fullName,
                onValueChange = { 
                    fullName = it
                    fullNameError = ""
                },
                label = { Text("Full Name") },
                isError = fullNameError.isNotEmpty(),
                supportingText = if (fullNameError.isNotEmpty()) {
                    { Text(fullNameError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            // Email with validation
            OutlinedTextField(
                value = email,
                onValueChange = { 
                    email = it
                    emailError = ""
                },
                label = { Text("Email") },
                isError = emailError.isNotEmpty(),
                supportingText = if (emailError.isNotEmpty()) {
                    { Text(emailError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            // Phone Number with Country Code
            PhoneNumberField(
                countryCode = countryCode,
                phoneNumber = phoneNumber,
                onCountryCodeChange = { 
                    countryCode = it
                    countryCodeError = ""
                },
                onPhoneNumberChange = { 
                    phoneNumber = it
                    phoneNumberError = ""
                },
                errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneNumberError,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            // Skills Field (matching registration)
            OutlinedTextField(
                value = skills,
                onValueChange = { skills = it },
                label = { Text("Skills (comma separated)") },
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Availability Field (matching registration)
            Text(
                "Availability",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1F2937),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            availabilityOptions.forEach { option ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = selectedAvailability.contains(option),
                        onCheckedChange = {
                            if (it) selectedAvailability.add(option)
                            else selectedAvailability.remove(option)
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(option)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            
            // Add extra bottom padding to ensure button is always accessible
            Spacer(modifier = Modifier.height(16.dp))
            
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            
            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color(0xFFEF4444),
                    fontSize = 14.sp
                )
            }
            
            if (successMessage.isNotEmpty()) {
                Text(
                    text = successMessage,
                    color = Color(0xFF22C55E),
                    fontSize = 14.sp
                )
            }

            Button(
                enabled = !isLoading,
                onClick = {
                    // Clear previous errors
                    fullNameError = ""
                    emailError = ""
                    countryCodeError = ""
                    phoneNumberError = ""
                    
                    // Validate all fields
                    val fullNameValidation = ValidationUtils.validateFullName(fullName)
                    val emailValidation = ValidationUtils.validateEmail(email)
                    val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
                    val phoneNumberValidation = ValidationUtils.validatePhoneNumber(phoneNumber)
                    
                    // Set error messages
                    if (!fullNameValidation.isValid) fullNameError = fullNameValidation.errorMessage
                    if (!emailValidation.isValid) emailError = emailValidation.errorMessage
                    if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
                    if (!phoneNumberValidation.isValid) phoneNumberError = phoneNumberValidation.errorMessage
                    
                    // If all validations pass, save changes
                    if (fullNameValidation.isValid &&
                        emailValidation.isValid &&
                        countryCodeValidation.isValid &&
                        phoneNumberValidation.isValid) {
                        
                        scope.launch {
                            isLoading = true
                            try {
                                val volunteerId = sessionManager.getVolunteerId()
                                val fullPhone = "$countryCode$phoneNumber"
                                val availabilityStr = selectedAvailability.joinToString(",")
                                
                                val response = VolunteerProfileApiClient.api.updateProfile(
                                    UpdateVolunteerProfileRequest(
                                        volunteerId = volunteerId,
                                        fullName = fullName,
                                        phone = fullPhone,
                                        email = email,
                                        skills = skills,
                                        availability = availabilityStr
                                    )
                                )
                                
                                if (response.status) {
                                    // Save updated data to session
                                    sessionManager.saveVolunteerProfileData(fullPhone, skills, availabilityStr)
                                    sessionManager.saveVolunteerSession(volunteerId, fullName, email)
                                    successMessage = "Profile updated successfully"
                                    
                                    // Navigate back after short delay
                                    kotlinx.coroutines.delay(1500)
                                    navController.popBackStack()
                                } else {
                                    errorMessage = response.message
                                }
                            } catch (e: Exception) {
                                Log.e("VolunteerEditDetails", "Error updating profile: ${e.message}", e)
                                errorMessage = "Failed to update profile: ${e.message}"
                            } finally {
                                isLoading = false
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22C55E)
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = if (isLoading) "Saving..." else "Save Changes",
                    color = Color.White
                )
            }
            
            // Add bottom padding to ensure Save button is always accessible when scrolling
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
