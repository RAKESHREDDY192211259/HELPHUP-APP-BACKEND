package com.example.helphup.ui.theme

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material.icons.outlined.VolunteerActivism
import androidx.compose.material.icons.outlined.Handshake
import androidx.compose.material.icons.outlined.Help
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.data.HelpRequest
import com.example.helphup.ui.data.HelpRequestDataStore
import com.example.helphup.ui.navigation.Routes
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

/* ---------------- API MODELS ---------------- */

data class NgoHelpRequestItem(
    @SerializedName("request_id") val requestId: Int,
    @SerializedName("ngo_id") val ngoId: Int,
    @SerializedName("ngo_name") val ngoName: String,
    @SerializedName("org_name") val orgName: String,
    @SerializedName("request_title") val requestTitle: String,
    @SerializedName("category") val category: String,
    @SerializedName("urgency_level") val urgencyLevel: String,
    @SerializedName("required_amount") val requiredAmount: String,
    @SerializedName("date_needed") val dateNeeded: String,
    @SerializedName("contact_number") val contactNumber: String,
    @SerializedName("description") val description: String,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("request_type") val requestType: String
)

data class VolunteerRequestItem(
    @SerializedName("request_id") val requestId: Int,
    @SerializedName("volunteer_id") val volunteerId: Int,
    @SerializedName("volunteer_name") val volunteerName: String,
    @SerializedName("request_title") val requestTitle: String,
    @SerializedName("category") val category: String,
    @SerializedName("description") val description: String,
    @SerializedName("location") val location: String,
    @SerializedName("help_date") val helpDate: String,
    @SerializedName("start_time") val startTime: String,
    @SerializedName("volunteers_needed") val volunteersNeeded: Int,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("request_type") val requestType: String
)

data class UnifiedRequestsResponse(
    val status: Boolean,
    val message: String,
    val data: List<UnifiedHelpRequestItem>?,
    val filters: Map<String, Any>? = null,
    val statistics: Map<String, Any>? = null
)

data class UnifiedHelpRequestItem(
    @SerializedName("request_id") val requestId: Int,
    @SerializedName("requester_type") val requesterType: String,
    @SerializedName("requester_name") val requesterName: String,
    @SerializedName("requester_display") val requesterDisplay: String,
    @SerializedName("request_title") val requestTitle: String,
    @SerializedName("category") val category: String,
    @SerializedName("description") val description: String,
    @SerializedName("urgency_level") val urgencyLevel: String,
    @SerializedName("required_amount") val requiredAmount: Double?,
    @SerializedName("date_needed") val dateNeeded: String?,
    @SerializedName("location") val location: String?,
    @SerializedName("help_date") val helpDate: String?,
    @SerializedName("volunteers_needed") val volunteersNeeded: Int?,
    @SerializedName("fundraising_goal") val fundraisingGoal: Double?,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("created_at_formatted") val createdAtFormatted: String
)

data class RequestsResponse(
    val status: Boolean,
    val message: String,
    val data: List<Map<String, Any>>?
)

/* ---------------- API SERVICE ---------------- */

interface HelpRequestsApiService {
    @GET("unified_get_public_requests.php?exclude_requester_type=volunteer")
    suspend fun getPublicRequests(): UnifiedRequestsResponse
}

object HelpRequestsRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"
    
    val api: HelpRequestsApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(HelpRequestsApiService::class.java)
    }
}


/* ---------------- HELPER FUNCTIONS ---------------- */

private fun fetchHelpRequestsData(
    scope: CoroutineScope,
    onLoading: (Boolean) -> Unit,
    onError: (String) -> Unit,
    onSuccess: (List<HelpRequest>) -> Unit
) {
    scope.launch {
        onLoading(true)
        onError("")
        Log.d("VolunteerHelpOthers", "Starting to fetch help requests data")
        try {
            // Use unified endpoint - Volunteers should NOT see Volunteer requests
            val response = HelpRequestsRetrofitInstance.api.getPublicRequests()
            
            Log.d("VolunteerHelpOthers", "API response status: ${response.status}")
            
            val allRequests = mutableListOf<HelpRequest>()
            
            // Process unified requests
            if (response.status && response.data != null) {
                response.data.forEach { item ->
                    try {
                        val helpRequest = UnifiedHelpRequestItem(
                            requestId = item.requestId,
                            requesterType = item.requesterType,
                            requesterName = item.requesterName,
                            requesterDisplay = item.requesterDisplay,
                            requestTitle = item.requestTitle,
                            category = item.category,
                            description = item.description,
                            urgencyLevel = item.urgencyLevel,
                            requiredAmount = item.requiredAmount,
                            dateNeeded = item.dateNeeded,
                            location = item.location,
                            helpDate = item.helpDate,
                            volunteersNeeded = item.volunteersNeeded,
                            fundraisingGoal = item.fundraisingGoal,
                            createdAt = item.createdAt,
                            createdAtFormatted = item.createdAtFormatted
                        )
                        
                        // Convert to display format
                        allRequests.add(
                            HelpRequest(
                                id = "${helpRequest.requesterType}_${helpRequest.requestId}",
                                title = helpRequest.requestTitle,
                                category = helpRequest.category,
                                location = helpRequest.location ?: helpRequest.dateNeeded ?: "",
                                description = helpRequest.description,
                                ngoName = if (helpRequest.requesterType == "ngo") helpRequest.requesterName else null,
                                volunteerName = if (helpRequest.requesterType == "volunteer") helpRequest.requesterName else null,
                                donorName = if (helpRequest.requesterType == "donor") helpRequest.requesterName else null,
                                requestType = helpRequest.requesterType.uppercase()
                            )
                        )
                    } catch (e: Exception) {
                        Log.e("VolunteerHelpOthers", "Error processing request: ${e.message}")
                    }
                }
            }
            
            onSuccess(allRequests)
            Log.d("VolunteerHelpOthers", "Successfully fetched ${allRequests.size} help requests")
            
        } catch (e: Exception) {
            Log.e("VolunteerHelpOthers", "Exception in fetch: ${e.message}", e)
            val errorMsg = e.message ?: "Unknown error"
            onError(when {
                errorMsg.contains("404") || errorMsg.contains("Not Found") -> "API endpoint not found. Please ensure the PHP files (get_all_ngo_requests.php, get_all_volunteer_requests.php) are in C:\\xampp\\htdocs\\helphup\\api\\ directory"
                errorMsg.contains("HTTP") && errorMsg.contains("404") -> "Server error 404: API files not found. Check if files exist in web server directory."
                errorMsg.contains("Unable to resolve host") -> "Connection error: Cannot find server\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                errorMsg.contains("Connection refused") -> "Connection error: Connection refused\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                errorMsg.contains("timeout") -> "Connection error: Connection timeout\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                errorMsg.contains("Network is unreachable") -> "Connection error: Network unreachable\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                else -> "Connection error: $errorMsg\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
            })
            
            // ❌ Remove sample data - show error message instead
            Log.d("VolunteerHelpOthers", "API failed, showing error message")
            onError("Failed to load help requests. Please check your internet connection.")
            onSuccess(emptyList())
        } finally {
            onLoading(false)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerHelpOthers(navController: NavController) {

    // Observe data store for help request updates
    val refreshTrigger by remember { HelpRequestDataStore.refreshTrigger }
    val newHelpRequestAdded by remember { HelpRequestDataStore.newHelpRequestAdded }
    
    val categories = listOf(
        "All", "Community", "Education",
        "Environment", "Healthcare", "Animals", "Technology"
    )

    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var helpRequests by remember { mutableStateOf<List<HelpRequest>>(emptyList()) }

    val scope = rememberCoroutineScope()
    
    // Reset update flag when component recomposes
    LaunchedEffect(newHelpRequestAdded) {
        if (newHelpRequestAdded) {
            Log.d("VolunteerHelpOthers", "Help request update detected, triggering refresh")
            HelpRequestDataStore.resetUpdateFlag()
            // Trigger data refresh
            fetchHelpRequestsData(scope, { isLoading = it }, { errorMessage = it }, { helpRequests = it })
        }
    }

    // Fetch requests on composable initialization and when screen comes into focus
    LaunchedEffect(Unit) {
        fetchHelpRequestsData(scope, { isLoading = it }, { errorMessage = it }, { helpRequests = it })
    }

    // Filter requests based on category and search
    val filteredRequests = helpRequests.filter { request ->
        val matchesCategory = selectedCategory == "All" || request.category == selectedCategory
        val matchesSearch = searchQuery.isBlank() || 
            request.title.contains(searchQuery, ignoreCase = true) ||
            request.description?.contains(searchQuery, ignoreCase = true) == true
        matchesCategory && matchesSearch
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Help Requests", fontWeight = FontWeight.Bold)
                        Text(
                            "Find opportunities to make a difference",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Outlined.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
        ) {

            // 🔍 Search
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search opportunities...") },
                leadingIcon = {
                    Icon(Icons.Outlined.Search, contentDescription = null)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 🏷 Category Filters
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { category ->
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        label = { Text(category) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color.Red,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                // 📋 Help Requests
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (filteredRequests.isEmpty()) {
                        item {
                            Text(
                                text = "No help requests found",
                                modifier = Modifier.padding(16.dp),
                                color = Color.Gray
                            )
                        }
                    } else {
                        items(filteredRequests) { request ->
                            val requestId = request.id.split("_").getOrNull(1) ?: "0"
                            HelpRequestCard(
                                priority = when (request.requestType) {
                                    "NGO" -> "High Priority"
                                    "Volunteer" -> "Medium Priority"
                                    "Donor" -> "Medium Priority"
                                    else -> "Low Priority"
                                },
                                priorityColor = when (request.requestType) {
                                    "NGO" -> Color(0xFFE53935)
                                    "Volunteer" -> Color(0xFF9C27B0)
                                    "Donor" -> Color(0xFF2E7D32)
                                    else -> Color(0xFF757575)
                                },
                                title = request.title,
                                description = request.description ?: "",
                                location = request.location,
                                time = when (request.requestType) {
                                    "NGO" -> "Urgent"
                                    "Volunteer" -> "Weekend"
                                    "Donor" -> "Ongoing"
                                    else -> "Flexible"
                                },
                                requestType = request.requestType,
                                requestId = requestId,
                                onOfferHelpClick = {
                                    // Navigate to Volunteer community support first, then payment flow
                                    if (requestId.isNotEmpty() && requestId != "0") {
                                        Log.d("VolunteerHelpOthers", "Navigating to Volunteer community support for ${request.requestType} request #$requestId")
                                        try {
                                            navController.navigate("${Routes.VOLUNTEER_COMMUNITY_SUPPORT}/${request.requestType}/$requestId")
                                        } catch (e: Exception) {
                                            Log.e("VolunteerHelpOthers", "Error navigating to Volunteer community support", e)
                                        }
                                    } else {
                                        Log.w("VolunteerHelpOthers", "Invalid request ID: $requestId")
                                    }
                                },
                                onViewDetailsClick = {
                                    // Navigate to Volunteer help others details
                                    if (requestId.isNotEmpty() && requestId != "0") {
                                        Log.d("VolunteerHelpOthers", "Viewing Volunteer help others details for ${request.requestType} request #$requestId")
                                        try {
                                            navController.navigate("${Routes.VOLUNTEER_REQUEST_DETAILS}/${request.requestType}/$requestId")
                                        } catch (e: Exception) {
                                            Log.e("VolunteerHelpOthers", "Error navigating to Volunteer request details", e)
                                        }
                                    } else {
                                        Log.w("VolunteerHelpOthers", "Invalid request ID: $requestId")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/* ---------------- UI COMPONENTS ---------------- */

@Composable
private fun HelpRequestCard(
    priority: String,
    priorityColor: Color,
    title: String,
    description: String,
    location: String,
    time: String,
    requestType: String,
    requestId: String,
    onOfferHelpClick: () -> Unit,
    onViewDetailsClick: () -> Unit,
    content: @Composable () -> Unit = {}
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Request Type Badge
            Surface(
                color = when (requestType) {
                    "NGO" -> Color(0xFFE3F2FD)
                    "Volunteer" -> Color(0xFFF3E5F5)
                    "Donor Campaign" -> Color(0xFFE8F5E9)
                    else -> Color(0xFFF3E5F5)
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Text(
                    text = requestType,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 12.sp,
                    color = when (requestType) {
                        "NGO" -> Color(0xFF1976D2)
                        "Volunteer" -> Color(0xFF7B1FA2)
                        "Donor Campaign" -> Color(0xFF16A34A)
                        else -> Color(0xFF7B1FA2)
                    },
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = priority,
                color = priorityColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(6.dp))

            Text(description, fontSize = 13.sp, color = Color.DarkGray)

            Spacer(modifier = Modifier.height(12.dp))

            // 📋 Show more details from user submission
            when (requestType) {
                "NGO" -> {
                    Row {
                        Icon(Icons.Filled.AttachMoney, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("₹${String.format("%,.2f", 1000.00)} Required", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                        TextButton(
                            onClick = onViewDetailsClick,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("View Details", fontSize = 12.sp, color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
                        }
                    }
                }
                "Volunteer" -> {
                    Row {
                        Icon(Icons.Outlined.Group, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Volunteers Needed", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                        TextButton(
                            onClick = onViewDetailsClick,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("View Details", fontSize = 12.sp, color = Color(0xFF7B1FA2), fontWeight = FontWeight.Bold)
                        }
                    }
                }
                "Donor" -> {
                    Row {
                        Icon(Icons.Outlined.TrendingUp, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("₹${String.format("%,.2f", 5000.00)} Goal", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                        TextButton(
                            onClick = onViewDetailsClick,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("View Details", fontSize = 12.sp, color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 💳 Payment/Action Button
            Button(
                onClick = onOfferHelpClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (requestType) {
                        "NGO" -> Color(0xFFE3F2FD)
                        "Volunteer" -> Color(0xFFF3E5F5)
                        "Donor" -> Color(0xFFE8F5E9)
                        else -> Color(0xFFF3E5F5)
                    },
                    contentColor = when (requestType) {
                        "NGO" -> Color(0xFF1976D2)
                        "Volunteer" -> Color(0xFF7B1FA2)
                        "Donor" -> Color(0xFF16A34A)
                        else -> Color(0xFF7B1FA2)
                    }
                )
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (requestType) {
                        "NGO" -> {
                            Icon(Icons.Filled.AttachMoney, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Donate Now", fontWeight = FontWeight.Bold)
                        }
                        "Volunteer" -> {
                            Icon(Icons.Outlined.VolunteerActivism, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Offer Help", fontWeight = FontWeight.Bold)
                        }
                        "Donor" -> {
                            Icon(Icons.Outlined.Handshake, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Support Campaign", fontWeight = FontWeight.Bold)
                        }
                        else -> {
                            Icon(Icons.Outlined.Help, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Offer Help →", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.LocationOn,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "$location • $time",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun InfoItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )
    }
}
