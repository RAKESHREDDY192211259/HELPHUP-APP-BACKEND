package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight   // ✅ FIX 1
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerHistory(navController: NavController) {

    val historyList = listOf(
        VolunteerHistoryItem("Food Bank Distribution", "Oct 17, 2023", "City Food Bank", "4 hours logged", true),
        VolunteerHistoryItem("Beach Cleanup", "Sep 28, 2023", "Ocean Blue", "3 hours logged", true),
        VolunteerHistoryItem("Reading Buddy", "Sep 16, 2023", "Public Library", "2 hours logged", true),
        VolunteerHistoryItem("Charity Run Marshal", "Aug 20, 2023", "Health First", "5 hours logged", true),
        VolunteerHistoryItem("Upcoming: Tree Planting", "Nov 05, 2023", "Green City", "0 hours logged", false)
    )

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Volunteer History", fontWeight = FontWeight.Bold)
                        Text(
                            "Track your impact and past contributions",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Outlined.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    TextButton(onClick = { }) {
                        Icon(Icons.Outlined.FileDownload, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export", color = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            VolunteerBottomBar(navController, "history")
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
        ) {

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(historyList) { item ->
                    VolunteerHistoryCard(item)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            ImpactSummaryCard()

            Spacer(modifier = Modifier.height(16.dp))

            LevelProgressCard()
        }
    }
}

/* ---------------- DATA MODEL ---------------- */

data class VolunteerHistoryItem(
    val title: String,
    val date: String,
    val organization: String,
    val hours: String,
    val completed: Boolean
)

/* ---------------- HISTORY CARD ---------------- */

@Composable
fun VolunteerHistoryCard(item: VolunteerHistoryItem) {

    Card(
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(3.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {

            Icon(
                imageVector = if (item.completed)
                    Icons.Outlined.CheckCircle
                else Icons.Outlined.Schedule,
                contentDescription = null,
                tint = if (item.completed) Color(0xFF22C55E) else Color(0xFFF59E0B),
                modifier = Modifier.size(22.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column {

                Text(item.title, fontWeight = FontWeight.Bold)

                Text(
                    item.date,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )

                Text(
                    item.organization,
                    style = MaterialTheme.typography.bodySmall
                )

                Text(
                    item.hours,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF22C55E)
                )
            }
        }
    }
}

/* ---------------- IMPACT SUMMARY ---------------- */

@Composable
fun ImpactSummaryCard() {

    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            Text("Impact Summary", fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(12.dp))

            ImpactRow("Total Hours", "14")
            ImpactRow("Events Attended", "4")
            ImpactRow("Organizations Supported", "4")
        }
    }
}

@Composable
fun ImpactRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Text(value, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
    }
}

/* ---------------- LEVEL PROGRESS ---------------- */

@Composable
fun LevelProgressCard() {

    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2563EB)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            Text("Level 3 Volunteer", color = Color.White, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                "You're 6 hours away from reaching the next level. Keep up the great work!",
                color = Color.White,
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(12.dp))

            // ✅ FIX 2: New API
            LinearProgressIndicator(
                progress = { 0.7f },
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.3f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                "70% Complete",
                color = Color.White,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.align(Alignment.End)
            )
        }
    }
}
