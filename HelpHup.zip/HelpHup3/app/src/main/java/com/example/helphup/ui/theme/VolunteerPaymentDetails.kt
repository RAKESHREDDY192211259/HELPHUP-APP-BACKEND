package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.ui.navigation.Routes

// ==================== Constants ====================

private object VolunteerPaymentDetailsConstants {
    // Colors
    val BackgroundColor = Color(0xFFF0FDF4)
    val CardBackgroundColor = Color.White
    val PrimaryColor = Color(0xFF22C55E)
    val TextPrimary = Color(0xFF1F2937)
    val TextSecondary = Color(0xFF6B7280)
    val BorderColor = Color(0xFFE5E7EB)
    val SecurityBackgroundColor = Color(0xFFDFF6EA)
    val SummaryBackgroundColor = Color(0xFFF8FAFC)
    
    // Spacing
    val PaddingSmall = 8.dp
    val PaddingMedium = 16.dp
    val PaddingLarge = 20.dp
    val PaddingExtraLarge = 24.dp
    
    // Sizes
    val IconSize = 64.dp
    val ButtonHeight = 52.dp
    
    // Text Sizes
    val TitleSize = 24.sp
    val SubtitleSize = 14.sp
    val SectionTitleSize = 18.sp
    val ButtonTextSize = 16.sp
}

// ==================== Main Screen ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerPaymentDetails(
    navController: NavController,
    requestType: String = "",
    requestId: String = "",
    amount: String = "100",
    method: String = "CARD"
) {
    Scaffold(
        containerColor = VolunteerPaymentDetailsConstants.BackgroundColor
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(VolunteerPaymentDetailsConstants.BackgroundColor)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Section
            BackButtonSection(
                onBackClick = { navController.popBackStack() }
            )
            
            Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingMedium))
            
            // Hero Section
            HeroSection(amount = amount.toIntOrNull() ?: 100, method = method)
            
            Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingExtraLarge))
            
            // Payment Summary Card
            PaymentSummaryCard(amount = amount.toIntOrNull() ?: 100)
            
            Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingMedium))
            
            // Payment Form Section
            PaymentFormSection(
                method = method,
                amount = amount.toIntOrNull() ?: 100,
                onPayClick = {
                    navController.navigate(Routes.VOLUNTEER_SUPPORT_CONFIRMATION + "/$requestType/$requestId/$amount/$method")
                }
            )
            
            Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingLarge))
        }
    }
}

// ==================== Header Components ====================

@Composable
private fun BackButtonSection(
    onBackClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(VolunteerPaymentDetailsConstants.PaddingMedium),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onBackClick,
            colors = ButtonDefaults.textButtonColors(
                contentColor = VolunteerPaymentDetailsConstants.PrimaryColor
            )
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "BACK",
                fontSize = VolunteerPaymentDetailsConstants.SubtitleSize,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==================== Hero Section ====================

@Composable
private fun HeroSection(amount: Int, method: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = VolunteerPaymentDetailsConstants.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Security Icon
        Box(
            modifier = Modifier
                .size(VolunteerPaymentDetailsConstants.IconSize)
                .background(
                    VolunteerPaymentDetailsConstants.SecurityBackgroundColor,
                    RoundedCornerShape(32.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Secure Payment",
                tint = VolunteerPaymentDetailsConstants.PrimaryColor,
                modifier = Modifier.size(32.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingMedium))
        
        // Title
        Text(
            text = "Payment Details",
            fontSize = VolunteerPaymentDetailsConstants.TitleSize,
            fontWeight = FontWeight.Bold,
            color = VolunteerPaymentDetailsConstants.TextPrimary
        )
        
        Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingSmall))
        
        // Subtitle
        Text(
            text = "Complete your support payment securely",
            fontSize = VolunteerPaymentDetailsConstants.SubtitleSize,
            color = VolunteerPaymentDetailsConstants.TextSecondary
        )
    }
}

// ==================== Payment Summary Card ====================

@Composable
private fun PaymentSummaryCard(amount: Int) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = VolunteerPaymentDetailsConstants.PaddingLarge),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = VolunteerPaymentDetailsConstants.SummaryBackgroundColor
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(VolunteerPaymentDetailsConstants.PaddingMedium),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Supporting Amount",
                    fontSize = VolunteerPaymentDetailsConstants.SubtitleSize,
                    color = VolunteerPaymentDetailsConstants.TextSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "₹${amount}",
                    fontSize = VolunteerPaymentDetailsConstants.SectionTitleSize,
                    fontWeight = FontWeight.Bold,
                    color = VolunteerPaymentDetailsConstants.PrimaryColor
                )
            }
            Icon(
                imageVector = Icons.Default.CreditCard,
                contentDescription = null,
                tint = VolunteerPaymentDetailsConstants.PrimaryColor,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

// ==================== Payment Form Section ====================

@Composable
private fun PaymentFormSection(
    method: String,
    amount: Int,
    onPayClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = VolunteerPaymentDetailsConstants.PaddingLarge),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = VolunteerPaymentDetailsConstants.CardBackgroundColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(VolunteerPaymentDetailsConstants.PaddingLarge)
        ) {
            // Payment Method Display
            PaymentMethodDisplay(method = method)
            
            Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingLarge))
            
            // Payment Form Based on Method
            when (method) {
                "CARD" -> CardPaymentForm()
                "UPI" -> UpiPaymentForm()
                else -> InfoText("Payment method: ${method.replace("_", " ")}")
            }
            
            Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingExtraLarge))
            
            // Security Notice
            SecurityNotice()
            
            Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingExtraLarge))
            
            // Pay Button
            PayButton(
                amount = amount,
                onClick = onPayClick
            )
        }
    }
}

@Composable
private fun PaymentMethodDisplay(method: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Payment Method:",
            fontSize = VolunteerPaymentDetailsConstants.SubtitleSize,
            color = VolunteerPaymentDetailsConstants.TextSecondary
        )
        Spacer(modifier = Modifier.width(VolunteerPaymentDetailsConstants.PaddingSmall))
        Text(
            text = method.replace("_", " "),
            fontSize = VolunteerPaymentDetailsConstants.SectionTitleSize,
            fontWeight = FontWeight.Bold,
            color = VolunteerPaymentDetailsConstants.PrimaryColor
        )
    }
}

// ==================== Payment Forms ====================

@Composable
private fun CardPaymentForm() {
    var cardNumber by remember { mutableStateOf("") }
    var cardholderName by remember { mutableStateOf("") }
    var expiryDate by remember { mutableStateOf("") }
    var cvv by remember { mutableStateOf("") }
    
    Column {
        OutlinedTextField(
            value = cardNumber,
            onValueChange = { if (it.length <= 19) cardNumber = it },
            label = { Text("Card Number") },
            placeholder = { Text("1234 5678 9012 3456") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = VolunteerPaymentDetailsConstants.PrimaryColor,
                unfocusedBorderColor = VolunteerPaymentDetailsConstants.BorderColor
            )
        )
        
        Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingMedium))
        
        OutlinedTextField(
            value = cardholderName,
            onValueChange = { cardholderName = it },
            label = { Text("Cardholder Name") },
            placeholder = { Text("John Doe") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = VolunteerPaymentDetailsConstants.PrimaryColor,
                unfocusedBorderColor = VolunteerPaymentDetailsConstants.BorderColor
            )
        )
        
        Spacer(modifier = Modifier.height(VolunteerPaymentDetailsConstants.PaddingMedium))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(VolunteerPaymentDetailsConstants.PaddingMedium)
        ) {
            OutlinedTextField(
                value = expiryDate,
                onValueChange = { if (it.length <= 5) expiryDate = it },
                label = { Text("MM/YY") },
                placeholder = { Text("12/25") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VolunteerPaymentDetailsConstants.PrimaryColor,
                    unfocusedBorderColor = VolunteerPaymentDetailsConstants.BorderColor
                )
            )
            
            OutlinedTextField(
                value = cvv,
                onValueChange = { if (it.length <= 3) cvv = it },
                label = { Text("CVV") },
                placeholder = { Text("123") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VolunteerPaymentDetailsConstants.PrimaryColor,
                    unfocusedBorderColor = VolunteerPaymentDetailsConstants.BorderColor
                )
            )
        }
    }
}

@Composable
private fun UpiPaymentForm() {
    var upiId by remember { mutableStateOf("") }
    
    OutlinedTextField(
        value = upiId,
        onValueChange = { upiId = it },
        label = { Text("UPI ID") },
        placeholder = { Text("yourname@paytm") },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = VolunteerPaymentDetailsConstants.PrimaryColor,
            unfocusedBorderColor = VolunteerPaymentDetailsConstants.BorderColor
        )
    )
}

@Composable
private fun InfoText(text: String) {
    Text(
        text = text,
        fontSize = VolunteerPaymentDetailsConstants.SubtitleSize,
        color = VolunteerPaymentDetailsConstants.TextSecondary
    )
}

// ==================== Security Notice ====================

@Composable
private fun SecurityNotice() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                VolunteerPaymentDetailsConstants.SecurityBackgroundColor,
                RoundedCornerShape(12.dp)
            )
            .padding(VolunteerPaymentDetailsConstants.PaddingMedium)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = VolunteerPaymentDetailsConstants.PrimaryColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(VolunteerPaymentDetailsConstants.PaddingSmall))
            Text(
                text = "Your payment information is encrypted and secure",
                fontSize = VolunteerPaymentDetailsConstants.SubtitleSize,
                color = VolunteerPaymentDetailsConstants.TextSecondary
            )
        }
    }
}

// ==================== Pay Button ====================

@Composable
private fun PayButton(
    amount: Int,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(VolunteerPaymentDetailsConstants.ButtonHeight),
        colors = ButtonDefaults.buttonColors(
            containerColor = VolunteerPaymentDetailsConstants.PrimaryColor,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = "Proceed to Payment",
            fontSize = VolunteerPaymentDetailsConstants.ButtonTextSize,
            fontWeight = FontWeight.SemiBold
        )
    }
}
