package com.example.helphup.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.R
import com.example.helphup.ui.navigation.Routes
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.util.Log
import com.example.helphup.ui.theme.VolunteerProfileApiClient
import com.example.helphup.ui.theme.GetVolunteerProfileRequest
import com.example.helphup.utils.UserSessionManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerProfile(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }
    val scope = rememberCoroutineScope()
    
    // Load user data from session initially
    var fullName by remember { mutableStateOf(sessionManager.getVolunteerFullName()) }
    var email by remember { mutableStateOf(sessionManager.getVolunteerEmail()) }
    var phone by remember { mutableStateOf(sessionManager.getVolunteerPhone()) }
    var skills by remember { mutableStateOf(sessionManager.getVolunteerSkills()) }
    var availability by remember { mutableStateOf(sessionManager.getVolunteerAvailability()) }
    
    var isLoading by remember { mutableStateOf(false) }
    
    // Function to load profile data from API
    fun loadProfileData() {
        scope.launch {
            // First, load from session
            fullName = sessionManager.getVolunteerFullName()
            email = sessionManager.getVolunteerEmail()
            phone = sessionManager.getVolunteerPhone()
            skills = sessionManager.getVolunteerSkills()
            availability = sessionManager.getVolunteerAvailability()
            
            // Then try to fetch from API to get latest data
            val volunteerId = sessionManager.getVolunteerId()
            if (volunteerId > 0) {
                isLoading = true
                try {
                    val response = VolunteerProfileApiClient.api.getProfile(
                        GetVolunteerProfileRequest(volunteerId)
                    )
                    if (response.status && response.data != null) {
                        val data = response.data
                        fullName = data.fullName
                        email = data.email
                        phone = data.phone
                        skills = data.skills
                        availability = data.availability
                        
                        // Update session with full data from API
                        sessionManager.saveVolunteerSession(data.volunteerId, data.fullName, data.email)
                        sessionManager.saveVolunteerProfileData(data.phone, data.skills, data.availability)
                    }
                } catch (e: Exception) {
                    Log.e("VolunteerProfile", "API call failed: ${e.message}", e)
                } finally {
                    isLoading = false
                }
            }
        }
    }
    
    // Load profile data when screen opens
    LaunchedEffect(Unit) {
        loadProfileData()
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Profile Settings",
                        fontWeight = FontWeight.Bold
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Spacer(modifier = Modifier.height(16.dp))

            // Profile Header
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .background(Color(0xFFDFF6EA), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profile",
                            modifier = Modifier.size(50.dp),
                            tint = Color(0xFF22C55E)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (fullName.isNotBlank()) fullName else "Volunteer",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                    Text(
                        text = "Active Volunteer",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Personal Information - Read-only display of registration data
            Text(
                text = "Personal Information",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Full Name - Read-only
                    Column {
                        Text(
                            text = "Full Name",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (fullName.isNotBlank()) fullName else "Not set",
                            fontSize = 16.sp,
                            color = if (fullName.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Email - Read-only
                    Column {
                        Text(
                            text = "Email Address",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (email.isNotBlank()) email else "Not set",
                            fontSize = 16.sp,
                            color = if (email.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Phone - Read-only
                    Column {
                        Text(
                            text = "Phone Number",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (phone.isNotBlank()) phone else "Not set",
                            fontSize = 16.sp,
                            color = if (phone.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Skills - Read-only
                    Column {
                        Text(
                            text = "Skills",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (skills.isNotBlank()) skills else "Not set",
                            fontSize = 16.sp,
                            color = if (skills.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Availability - Read-only
                    Column {
                        Text(
                            text = "Availability",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (availability.isNotBlank()) availability else "Not set",
                            fontSize = 16.sp,
                            color = if (availability.isNotBlank()) Color(0xFF1F2937) else Color(0xFF9CA3AF)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Account Actions
            Text(
                text = "Account Actions",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Button(
                        onClick = {
                            navController.navigate(Routes.VOLUNTEER_EDIT_DETAILS)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Edit Details", color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            navController.navigate(Routes.VOLUNTEER_CHANGE_PASSWORD)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF22C55E))
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF22C55E))
                        Spacer(Modifier.width(8.dp))
                        Text("Change Password", color = Color(0xFF22C55E))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            sessionManager.clearSession()
                            navController.navigate(Routes.VOLUNTEER_LOGIN) {
                                popUpTo(Routes.VOLUNTEER_PROFILE) { inclusive = true }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Logout", color = Color.White)
                    }
                }
            }
        }
    }
}
