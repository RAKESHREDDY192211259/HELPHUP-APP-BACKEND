package com.example.helphup.ui.theme

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* -------------------- API MODELS -------------------- */

data class GetVolunteerProfileRequest(
    @SerializedName("volunteer_id") val volunteerId: Int
)

data class GetVolunteerProfileResponse(
    val status: Boolean,
    val message: String,
    val data: VolunteerProfileData? = null
)

data class VolunteerProfileData(
    @SerializedName("volunteer_id") val volunteerId: Int,
    @SerializedName("full_name") val fullName: String,
    val phone: String,
    val email: String,
    val skills: String,
    val availability: String
)

data class UpdateVolunteerProfileRequest(
    @SerializedName("volunteer_id") val volunteerId: Int,
    @SerializedName("full_name") val fullName: String,
    val phone: String,
    val email: String,
    val skills: String,
    val availability: String
)

data class UpdateVolunteerProfileResponse(
    val status: Boolean,
    val message: String
)

data class UpdateVolunteerPasswordRequest(
    @SerializedName("volunteer_id") val volunteerId: Int,
    @SerializedName("current_password") val currentPassword: String,
    @SerializedName("new_password") val newPassword: String
)

data class UpdateVolunteerPasswordResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- API SERVICE -------------------- */

interface VolunteerProfileApiService {
    @POST("get_volunteer_profile.php")
    suspend fun getProfile(@Body request: GetVolunteerProfileRequest): GetVolunteerProfileResponse

    @POST("update_volunteer_profile.php")
    suspend fun updateProfile(@Body request: UpdateVolunteerProfileRequest): UpdateVolunteerProfileResponse

    @POST("update_volunteer_password.php")
    suspend fun updatePassword(@Body request: UpdateVolunteerPasswordRequest): UpdateVolunteerPasswordResponse
}

object VolunteerProfileApiClient {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: VolunteerProfileApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(VolunteerProfileApiService::class.java)
    }
}

