package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.platform.LocalContext
import com.example.helphup.utils.UserSessionManager
import com.example.helphup.ui.theme.ValidationUtils
import com.example.helphup.ui.navigation.Routes
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

/* -------------------- API MODELS -------------------- */

data class VolunteerRaiseHelpRequest(
    val volunteer_id: Int,
    val request_title: String,
    val category: String,
    val description: String,
    val location: String,
    val help_date: String,
    val start_time: String,
    val volunteers_needed: Int,
    val contact_phone: String
)

data class VolunteerApiResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- API SERVICE -------------------- */

interface VolunteerApi {
    @POST("volunteer_raise_help.php")
    suspend fun raiseHelp(
        @Body request: VolunteerRaiseHelpRequest
    ): VolunteerApiResponse
}

/* -------------------- RETROFIT INSTANCE -------------------- */

object VolunteerRetrofitInstance {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: VolunteerApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(VolunteerApi::class.java)
    }
}

/* -------------------- UI SCREEN -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerRaiseHelp(navController: NavController) {
    val context = LocalContext.current
    val sessionManager = remember { UserSessionManager(context) }

    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Community Service") }
    var description by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var volunteersNeeded by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    
    // Validation error messages
    var countryCodeError by remember { mutableStateOf("") }
    var phoneNumberError by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    val serviceCategories = listOf(
        "Community Service",
        "Healthcare",
        "Education",
        "Environmental",
        "Animal Welfare"
    )
    var expanded by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Request Help", fontWeight = FontWeight.Bold)
                        Text(
                            "Fill out the details below to find volunteers for your cause",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Outlined.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            /* -------- BASIC INFORMATION -------- */

            SectionCard(title = "Basic Information") {

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Request Title") },
                    placeholder = { Text("e.g., Weekend Food Drive") },
                    modifier = Modifier.fillMaxWidth()
                )

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        label = { Text("Category") },
                        readOnly = true,
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                        },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        serviceCategories.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(selectionOption) },
                                onClick = {
                                    category = selectionOption
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    placeholder = { Text("Describe what volunteers will be doing...") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(16.dp))

            /* -------- LOGISTICS -------- */

            SectionCard(title = "Logistics") {

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Location") },
                    leadingIcon = { Icon(Icons.Outlined.Place, null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {

                    DatePickerField(
                        label = "Date",
                        selectedDate = date,
                        onDateSelected = { date = it },
                        modifier = Modifier.weight(1f),
                        allowPastDates = false
                    )

                    TimePickerField(
                        label = "Start Time",
                        selectedTime = time,
                        onTimeSelected = { time = it },
                        modifier = Modifier.weight(1f),
                        selectedDate = date,
                        allowPastTime = false
                    )
                }

                OutlinedTextField(
                    value = volunteersNeeded,
                    onValueChange = { volunteersNeeded = it },
                    label = { Text("Volunteers Needed") },
                    leadingIcon = { Icon(Icons.Outlined.Group, null) },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(Modifier.height(12.dp))
                
                // Phone Number Field with Country Code
                PhoneNumberField(
                    countryCode = countryCode,
                    phoneNumber = phoneNumber,
                    onCountryCodeChange = { 
                        countryCode = it
                        countryCodeError = ""
                    },
                    onPhoneNumberChange = { 
                        phoneNumber = it
                        phoneNumberError = ""
                    },
                    errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneNumberError,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (errorMessage.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(errorMessage, color = Color.Red, fontSize = 13.sp)
            }

            Spacer(Modifier.height(24.dp))

            /* -------- ACTION BUTTONS -------- */

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                TextButton(onClick = { navController.popBackStack() }) {
                    Text("Cancel")
                }

                Button(
                    enabled = !loading,
                    onClick = {

                        if (
                            title.isBlank() ||
                            description.isBlank() ||
                            location.isBlank() ||
                            date.isBlank() ||
                            time.isBlank() ||
                            volunteersNeeded.isBlank()
                        ) {
                            errorMessage = "Please fill all required fields"
                            return@Button
                        }

                        // Validate phone number
                        val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
                        val phoneValidation = ValidationUtils.validatePhoneNumber(phoneNumber)
                        
                        if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
                        if (!phoneValidation.isValid) phoneNumberError = phoneValidation.errorMessage
                        
                        if (!countryCodeValidation.isValid || !phoneValidation.isValid) {
                            errorMessage = "Please enter a valid phone number"
                            return@Button
                        }

                        loading = true
                        errorMessage = ""

                        scope.launch {
                            try {
                                val response = VolunteerRetrofitInstance.api.raiseHelp(
                                    VolunteerRaiseHelpRequest(
                                        volunteer_id = sessionManager.getVolunteerId(),
                                        request_title = title,
                                        category = category,
                                        description = description,
                                        location = location,
                                        help_date = date,
                                        start_time = time,
                                        volunteers_needed = volunteersNeeded.toInt(),
                                        contact_phone = "$countryCode$phoneNumber"
                                    )
                                )

                                if (response.status) {
                                    navController.navigate(Routes.VOLUNTEER_HELP_REQUEST_SUBMITTED)
                                } else {
                                    errorMessage = response.message
                                }

                            } catch (e: Exception) {
                                errorMessage = "Network Error"
                            } finally {
                                loading = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF10B981)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (loading)
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                    else
                        Text("Submit Request", color = Color.White)
                }
            }
        }
    }
}

/* -------------------- SECTION CARD -------------------- */

@Composable
fun SectionCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(3.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, fontWeight = FontWeight.Bold)
            content()
        }
    }
}
