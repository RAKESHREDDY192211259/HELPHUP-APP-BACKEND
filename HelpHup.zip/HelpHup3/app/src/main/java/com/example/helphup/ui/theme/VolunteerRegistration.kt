package com.example.helphup.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Response

/* -------------------- API MODELS -------------------- */

data class VolunteerRegisterRequest(
    val full_name: String,
    val phone: String,
    val email: String,
    val password: String,
    val skills: List<String>,
    val availability: List<String>
)

data class VolunteerRegisterResponse(
    val status: Boolean,
    val message: String
)

/* -------------------- API SERVICE -------------------- */

interface VolunteerApiService {
    @POST("volunteer_register.php")
    suspend fun registerVolunteer(
        @Body request: VolunteerRegisterRequest
    ): Response<VolunteerRegisterResponse>
}

object ApiClient {
    private const val BASE_URL = "http://10.126.222.192/helphup/api/"

    val api: VolunteerApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(VolunteerApiService::class.java)
    }
}

/* -------------------- VIEWMODEL -------------------- */

class VolunteerRegisterViewModel : ViewModel() {

    var isLoading by mutableStateOf(false)
    var errorMessage by mutableStateOf("")
    var success by mutableStateOf(false)

    fun registerVolunteer(
        fullName: String,
        phone: String,
        email: String,
        password: String,
        skills: List<String>,
        availability: List<String>
    ) {
        viewModelScope.launch {
            isLoading = true
            errorMessage = ""

            try {
                val response = ApiClient.api.registerVolunteer(
                    VolunteerRegisterRequest(
                        full_name = fullName,
                        phone = phone,
                        email = email,
                        password = password,
                        skills = skills,
                        availability = availability
                    )
                )

                if (response.isSuccessful && response.body()?.status == true) {
                    success = true
                } else if (response.isSuccessful) {
                    errorMessage = response.body()?.message ?: "Registration failed"
                } else {
                    errorMessage = "Connection error: Server error\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                }

            } catch (e: Exception) {
                val errorMsg = e.message ?: "Unknown error"
                errorMessage = when {
                    errorMsg.contains("JSON") || errorMsg.contains("End of input") -> "Connection error: Invalid server response\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Unable to resolve host") -> "Connection error: Cannot find server\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Connection reset") || errorMsg.contains("connection reset") -> "Connection error: Connection reset\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("timeout") -> "Connection error: Connection timeout\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    errorMsg.contains("Network is unreachable") -> "Connection error: Network unreachable\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                    else -> "Connection error: $errorMsg\nCheck:\n1. XAMPP Apache running\n2. IP: 10.126.222.192\n3. Same WiFi network"
                }
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
}

/* -------------------- COMPOSABLE -------------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerRegistration(
    navController: NavController,
    viewModel: VolunteerRegisterViewModel = viewModel()
) {

    var fullName by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var skills by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }

    // Validation error messages
    var fullNameError by remember { mutableStateOf("") }
    var countryCodeError by remember { mutableStateOf("") }
    var phoneNumberError by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf("") }
    var confirmPasswordError by remember { mutableStateOf("") }

    val availabilityOptions = listOf("Weekdays", "Weekends", "Evenings", "Flexible")
    val selectedAvailability = remember { mutableStateListOf<String>() }

    if (viewModel.success) {
        LaunchedEffect(Unit) {
            navController.navigate("volunteer_login") {
                popUpTo("volunteer_registration") { inclusive = true }
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = { Text("Register as Volunteer", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate("volunteer_login") }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF22C55E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Register as Volunteer",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Full Name Field
            OutlinedTextField(
                value = fullName,
                onValueChange = { 
                    fullName = it
                    fullNameError = ""
                },
                label = { Text("Full Name") },
                isError = fullNameError.isNotEmpty(),
                supportingText = if (fullNameError.isNotEmpty()) {
                    { Text(fullNameError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Phone Number Field with Country Code
            PhoneNumberField(
                countryCode = countryCode,
                phoneNumber = phoneNumber,
                onCountryCodeChange = { 
                    countryCode = it
                    countryCodeError = ""
                },
                onPhoneNumberChange = { 
                    phoneNumber = it
                    phoneNumberError = ""
                },
                errorMessage = if (countryCodeError.isNotEmpty()) countryCodeError else phoneNumberError,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Email Field
            OutlinedTextField(
                value = email,
                onValueChange = { 
                    email = it
                    emailError = ""
                },
                label = { Text("Email Address") },
                isError = emailError.isNotEmpty(),
                supportingText = if (emailError.isNotEmpty()) {
                    { Text(emailError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = skills,
                onValueChange = { skills = it },
                label = { Text("Skills (comma separated)") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            availabilityOptions.forEach { option ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = selectedAvailability.contains(option),
                        onCheckedChange = {
                            if (it) selectedAvailability.add(option)
                            else selectedAvailability.remove(option)
                        }
                    )
                    Text(option)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Password Field
            OutlinedTextField(
                value = password,
                onValueChange = { 
                    password = it
                    passwordError = ""
                },
                label = { Text("Password") },
                visualTransformation = if (passwordVisible) VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                isError = passwordError.isNotEmpty(),
                supportingText = if (passwordError.isNotEmpty()) {
                    { Text(passwordError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Confirm Password Field
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { 
                    confirmPassword = it
                    confirmPasswordError = ""
                },
                label = { Text("Confirm Password") },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                        Icon(
                            if (confirmPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = "Toggle password visibility"
                        )
                    }
                },
                isError = confirmPasswordError.isNotEmpty(),
                supportingText = if (confirmPasswordError.isNotEmpty()) {
                    { Text(confirmPasswordError, color = Color(0xFFEF4444)) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (viewModel.errorMessage.isNotEmpty()) {
                Text(
                    text = viewModel.errorMessage,
                    color = Color.Red
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    // Clear previous errors
                    fullNameError = ""
                    countryCodeError = ""
                    phoneNumberError = ""
                    emailError = ""
                    passwordError = ""
                    confirmPasswordError = ""
                    viewModel.errorMessage = ""

                    // Validate all fields
                    val fullNameValidation = ValidationUtils.validateFullName(fullName)
                    val countryCodeValidation = ValidationUtils.validateCountryCode(countryCode)
                    val phoneNumberValidation = ValidationUtils.validatePhoneNumber(phoneNumber)
                    val emailValidation = ValidationUtils.validateEmail(email)
                    val passwordValidation = ValidationUtils.validatePassword(password)
                    val confirmPasswordValidation = ValidationUtils.validateConfirmPassword(password, confirmPassword)

                    // Set error messages
                    if (!fullNameValidation.isValid) fullNameError = fullNameValidation.errorMessage
                    if (!countryCodeValidation.isValid) countryCodeError = countryCodeValidation.errorMessage
                    if (!phoneNumberValidation.isValid) phoneNumberError = phoneNumberValidation.errorMessage
                    if (!emailValidation.isValid) emailError = emailValidation.errorMessage
                    if (!passwordValidation.isValid) passwordError = passwordValidation.errorMessage
                    if (!confirmPasswordValidation.isValid) confirmPasswordError = confirmPasswordValidation.errorMessage

                    // If all validations pass, submit form
                    if (fullNameValidation.isValid &&
                        countryCodeValidation.isValid &&
                        phoneNumberValidation.isValid &&
                        emailValidation.isValid &&
                        passwordValidation.isValid &&
                        confirmPasswordValidation.isValid
                    ) {
                        viewModel.registerVolunteer(
                            fullName,
                            "$countryCode$phoneNumber",
                            email,
                            password,
                            skills.split(",").map { it.trim() }.filter { it.isNotBlank() },
                            selectedAvailability
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !viewModel.isLoading
            ) {
                if (viewModel.isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color.White
                    )
                } else {
                    Text("Create Account")
                }
            }
        }
    }
}
