package com.example.helphup.ui.theme

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.helphup.R
import com.example.helphup.ui.data.HelpRequestDataStore
import com.example.helphup.ui.navigation.Routes
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerRequestDetailsScreen(
    navController: NavController,
    requestType: String = "",
    requestId: String = ""
) {
    // Observe data store for help request updates
    val refreshTrigger by remember { HelpRequestDataStore.refreshTrigger }
    val newHelpRequestAdded by remember { HelpRequestDataStore.newHelpRequestAdded }
    
    // State variables for data fetching
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var helpRequests by remember { mutableStateOf<List<Any>>(emptyList()) }
    val scope = rememberCoroutineScope()
    
    // Reset the update flag when component recomposes
    LaunchedEffect(newHelpRequestAdded) {
        if (newHelpRequestAdded) {
            HelpRequestDataStore.resetUpdateFlag()
            Log.d("VolunteerRequestDetails", "Help request update detected")
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Request Details", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "View complete request information",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF10B981),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0FDF4))
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {

            // Request Image
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_foreground),
                    contentDescription = "Request Image",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(Modifier.height(16.dp))

            // Request Title and Type
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Weekend Food Distribution",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                
                // Request Type Badge
                Surface(
                    color = Color(0xFFF3E5F5),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "NGO Request",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontSize = 12.sp,
                        color = Color(0xFF7B1FA2),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Info Row
            IconInfoRow(Icons.Outlined.LocationOn, "Hyderabad, India")
            IconInfoRow(Icons.Outlined.Schedule, "This Weekend")
            IconInfoRow(Icons.Outlined.People, "50 volunteers needed")
            IconInfoRow(Icons.Outlined.PriorityHigh, "Medium Priority")

            Spacer(Modifier.height(20.dp))

            // About
            SectionTitle("About This Request")
            SectionText(
                "Join us for our weekend food distribution drive! We need volunteers to help pack and distribute food packages to families in need. This is a great opportunity to make a direct impact in your community."
            )

            Spacer(Modifier.height(16.dp))

            // Requirements
            SectionTitle("Requirements")
            SectionText("• Available on weekends (Saturday/Sunday)")
            SectionText("• Able to lift and carry food packages")
            SectionText("• Comfortable working with diverse communities")
            SectionText("• Basic communication skills")

            Spacer(Modifier.height(16.dp))

            // Impact
            SectionTitle("Expected Impact")
            SectionText("• Feed 200+ families in need")
            SectionText("• Distribute essential food supplies")
            SectionText("• Build community connections")
            SectionText("• Make a difference in local communities")

            Spacer(Modifier.height(20.dp))

            // Support Button
            Button(
                onClick = {
                    navController.navigate(Routes.VOLUNTEER_COMMUNITY_SUPPORT)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
            ) {
                Text("OFFER HELP NOW", color = Color.White)
            }

            Spacer(Modifier.height(24.dp))

            // Organizer
            SectionTitle("Request Organizer")
            OrganizerCard()

            Spacer(Modifier.height(24.dp))

            /* Contact Information */
            SectionTitle("Contact Information")
            ContactInfoCard()

            Spacer(Modifier.height(24.dp))

            /* Updates */
            SectionTitle("Request Updates")
            UpdatesCard()

            Spacer(Modifier.height(24.dp))

            /* Share */
            SectionTitle("Share This Request")
            ShareRow()
        }
    }
}

/* ---------- Reusable Components ---------- */

@Composable
private fun IconInfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 13.sp, color = Color.Gray)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun SectionText(text: String) {
    Text(
        text = text,
        fontSize = 13.sp,
        color = Color.Gray,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun OrganizerCard() {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Profile Image
            Card(
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(60.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_foreground),
                    contentDescription = "NGO Profile",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "HelpCare Foundation",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Verified NGO • 4.8 ⭐",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                Text(
                    text = "Active since 2019 • 50+ campaigns",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Icon(
                Icons.Outlined.Verified,
                contentDescription = "Verified",
                tint = Color(0xFF10B981),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ContactInfoCard() {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            IconInfoRow(Icons.Outlined.Phone, "+91-9876543210")
            IconInfoRow(Icons.Outlined.Email, "contact@helpcare.org")
            IconInfoRow(Icons.Outlined.LocationOn, "Hyderabad, Telangana")
            IconInfoRow(Icons.Outlined.Schedule, "Response time: 24 hours")
        }
    }
}

@Composable
private fun UpdatesCard() {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            SectionText("• Food kits prepared for distribution")
            SectionText("• Volunteers mobilized across 3 zones")
            SectionText("• Distribution centers set up")
            SectionText("• Partnered with local restaurants")
        }
    }
}

@Composable
private fun ShareRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Share buttons
        ShareButton(Icons.Outlined.Share, "Share")
        ShareButton(Icons.Outlined.Message, "Message")
        ShareButton(Icons.Outlined.Call, "Call")
        ShareButton(Icons.Outlined.Email, "Email")
    }
}

@Composable
private fun ShareButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* Handle share action */ }
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.size(50.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    icon,
                    contentDescription = text,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            color = Color.Gray
        )
    }
}
