package com.example.helphup.ui.theme

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.helphup.R
import com.example.helphup.ui.navigation.Routes
import com.example.helphup.ui.theme.VolunteerBottomBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolunteerViewHelpRequestDetails(
    navController: NavController,
    requestType: String = "",
    requestId: String = ""
) {
    // State variables for data fetching
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf("") }
    var requestDetails by remember { mutableStateOf<HelpRequestDetailsItem?>(null) }
    val scope = rememberCoroutineScope()
    
    // Fetch request details when screen loads
    LaunchedEffect(requestId) {
        if (requestId.isNotEmpty() && requestId != "0") {
            isLoading = true
            errorMessage = ""
            try {
                val requestIdInt = requestId.toIntOrNull()
                if (requestIdInt != null) {
                    val response = HelpRequestDetailsRetrofit.api.getRequestDetails(requestIdInt)
                    if (response.status && response.data != null) {
                        requestDetails = response.data
                        Log.d("VolunteerViewHelpRequestDetails", "Loaded request: ${response.data.requestTitle}")
                    } else {
                        errorMessage = response.message
                    }
                } else {
                    errorMessage = "Invalid request ID"
                }
            } catch (e: Exception) {
                errorMessage = "Failed to load request: ${e.message}"
                Log.e("VolunteerViewHelpRequestDetails", "Error loading request", e)
            } finally {
                isLoading = false
            }
        } else {
            errorMessage = "Invalid request ID"
            isLoading = false
        }
    }

    Scaffold(
        containerColor = Color(0xFFF0FDF4),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Help Request Details", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "View complete request information",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF10B981),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            VolunteerBottomBar(navController, Routes.VOLUNTEER_REQUEST_DETAILS)
        }
    ) { padding ->

        when {
            isLoading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            errorMessage.isNotEmpty() -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Error",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Red
                        )
                        Text(
                            text = errorMessage,
                            fontSize = 14.sp,
                            color = Color.Gray
                        )
                        Button(onClick = { navController.popBackStack() }) {
                            Text("Go Back")
                        }
                    }
                }
            }
            requestDetails != null -> {
                val request = requestDetails!!
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFFF0FDF4))
                        .padding(padding)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Request Image
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (request.coverImageUrl != null && request.coverImageUrl.isNotEmpty()) {
                            AsyncImage(
                                model = request.coverImageUrl,
                                contentDescription = "Request Image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                                contentDescription = "Request Image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Request Title and Type
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = request.requestTitle,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        
                        // Request Type Badge
                        val badgeColor = when (request.requesterType.lowercase()) {
                            "ngo" -> Color(0xFFE3F2FD)
                            "volunteer" -> Color(0xFFF3E5F5)
                            "donor" -> Color(0xFFFFF3E0)
                            else -> Color(0xFFE3F2FD)
                        }
                        val textColor = when (request.requesterType.lowercase()) {
                            "ngo" -> Color(0xFF1976D2)
                            "volunteer" -> Color(0xFF7B1FA2)
                            "donor" -> Color(0xFFE65100)
                            else -> Color(0xFF1976D2)
                        }
                        Surface(
                            color = badgeColor,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "${request.requesterType.replaceFirstChar { it.uppercase() }} Request",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 12.sp,
                                color = textColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Info Row - Dynamic based on request type
                    request.location?.let { IconInfoRow(Icons.Outlined.LocationOn, it) }
                    request.dateNeeded?.let { IconInfoRow(Icons.Outlined.Schedule, "Date Needed: $it") }
                    request.helpDate?.let { IconInfoRow(Icons.Outlined.Schedule, "Help Date: $it") }
                    request.endDate?.let { IconInfoRow(Icons.Outlined.Schedule, "Ends: $it") }
                    request.requiredAmount?.let { IconInfoRow(Icons.Outlined.AttachMoney, "Amount: ₹${String.format("%.2f", it)}") }
                    request.fundraisingGoal?.let { IconInfoRow(Icons.Outlined.AttachMoney, "Goal: ₹${String.format("%.2f", it)}") }
                    request.volunteersNeeded?.let { IconInfoRow(Icons.Outlined.People, "Volunteers Needed: $it") }
                    IconInfoRow(Icons.Outlined.PriorityHigh, "Priority: ${request.urgencyLevel}")

                    Spacer(Modifier.height(20.dp))

                    // About
                    SectionTitle("About This Request")
                    SectionText(request.description)

                    Spacer(Modifier.height(16.dp))

                    // Request-specific details
                    when (request.requesterType.lowercase()) {
                        "ngo" -> {
                            request.requiredAmount?.let {
                                SectionTitle("Amount Required")
                                SectionText("₹${String.format("%.2f", it)}")
                            }
                            request.dateNeeded?.let {
                                SectionTitle("Date Needed")
                                SectionText(it)
                            }
                        }
                        "volunteer" -> {
                            request.location?.let {
                                SectionTitle("Location")
                                SectionText(it)
                            }
                            request.helpDate?.let {
                                SectionTitle("Help Date")
                                SectionText(it)
                            }
                            request.startTime?.let {
                                SectionTitle("Start Time")
                                SectionText(it)
                            }
                            request.volunteersNeeded?.let {
                                SectionTitle("Volunteers Needed")
                                SectionText("$it volunteers")
                            }
                        }
                        "donor" -> {
                            request.fundraisingGoal?.let {
                                SectionTitle("Fundraising Goal")
                                SectionText("₹${String.format("%.2f", it)}")
                            }
                            request.duration?.let {
                                SectionTitle("Duration")
                                SectionText(it)
                            }
                            request.endDate?.let {
                                SectionTitle("End Date")
                                SectionText(it)
                            }
                            request.beneficiaryName?.let {
                                SectionTitle("Beneficiary")
                                SectionText(it)
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))

                    // Support Button
                    Button(
                        onClick = {
                            navController.navigate(Routes.VOLUNTEER_COMMUNITY_SUPPORT)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text("OFFER HELP NOW", color = Color.White)
                    }

                    Spacer(Modifier.height(24.dp))

                    // Organizer
                    SectionTitle("Request Organizer")
                    OrganizerCard(
                        organizerName = request.requesterName,
                        organizerEmail = request.requesterEmail,
                        organizerPhone = request.requesterPhone ?: request.contactNumber
                    )

                    Spacer(Modifier.height(24.dp))

                    /* Contact Information */
                    SectionTitle("Contact Information")
                    ContactInfoCard(
                        phone = request.contactNumber ?: request.requesterPhone ?: "N/A",
                        email = request.contactEmail ?: request.requesterEmail,
                        location = request.location ?: "N/A"
                    )

                    Spacer(Modifier.height(24.dp))

                    /* Share */
                    SectionTitle("Share This Request")
                    ShareRow()
                }
            }
            else -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No request data available")
                }
            }
        }
    }
}

/* ---------- Reusable Components ---------- */

@Composable
private fun IconInfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 13.sp, color = Color.Gray)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun SectionText(text: String) {
    Text(
        text = text,
        fontSize = 13.sp,
        color = Color.Gray,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun OrganizerCard(
    organizerName: String = "Education First Initiative",
    organizerEmail: String = "education@firstinitiative.org",
    organizerPhone: String? = null
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Profile Image
            Card(
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(60.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_foreground),
                    contentDescription = "Organizer Profile",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = organizerName,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = organizerEmail,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                organizerPhone?.let {
                    Text(
                        text = it,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            Icon(
                Icons.Outlined.Verified,
                contentDescription = "Verified",
                tint = Color(0xFF10B981),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ContactInfoCard(
    phone: String = "+91-8765432109",
    email: String = "education@firstinitiative.org",
    location: String = "Community Learning Center"
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            IconInfoRow(Icons.Outlined.Phone, phone)
            IconInfoRow(Icons.Outlined.Email, email)
            if (location != "N/A") {
                IconInfoRow(Icons.Outlined.LocationOn, location)
            }
            IconInfoRow(Icons.Outlined.Schedule, "Response time: 24 hours")
        }
    }
}


@Composable
private fun ShareRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Share buttons
        ShareButton(Icons.Outlined.Share, "Share")
        ShareButton(Icons.Outlined.Message, "Message")
        ShareButton(Icons.Outlined.Call, "Call")
        ShareButton(Icons.Outlined.Email, "Email")
    }
}

@Composable
private fun ShareButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* Handle share action */ }
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.size(50.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    icon,
                    contentDescription = text,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            color = Color.Gray
        )
    }
}
