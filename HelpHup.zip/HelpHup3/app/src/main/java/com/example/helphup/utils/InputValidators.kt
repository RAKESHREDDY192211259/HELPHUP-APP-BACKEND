package com.example.helphup.utils

import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText

/**
 * Visual transformation for amount input - only allows digits
 */
object AmountInputFilter {
    /**
     * Filters input to only allow digits (0-9)
     */
    fun filterAmountInput(input: String): String {
        return input.filter { it.isDigit() }
    }
    
    /**
     * Visual transformation that only allows digits
     */
    val AmountVisualTransformation = object : VisualTransformation {
        override fun filter(text: AnnotatedString): TransformedText {
            val filtered = text.text.filter { it.isDigit() }
            return TransformedText(
                AnnotatedString(filtered),
                OffsetMapping.Identity
            )
        }
    }
}

