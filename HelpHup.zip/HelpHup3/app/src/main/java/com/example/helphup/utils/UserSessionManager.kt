package com.example.helphup.utils

import android.content.Context
import android.content.SharedPreferences

class UserSessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "HelpHupUserSession"
        
        // NGO Keys
        private const val KEY_NGO_ID = "ngo_id"
        private const val KEY_NGO_FULL_NAME = "ngo_full_name"
        private const val KEY_NGO_EMAIL = "ngo_email"
        private const val KEY_NGO_PHONE = "ngo_phone"
        private const val KEY_NGO_ADDRESS = "ngo_address"
        private const val KEY_NGO_ORG_NAME = "ngo_org_name"
        private const val KEY_NGO_REG_NUMBER = "ngo_reg_number"
        
        // Donor Keys
        private const val KEY_DONOR_ID = "donor_id"
        private const val KEY_DONOR_FULL_NAME = "donor_full_name"
        private const val KEY_DONOR_EMAIL = "donor_email"
        private const val KEY_DONOR_PHONE = "donor_phone"
        private const val KEY_DONOR_ADDRESS = "donor_address"
        
        // Volunteer Keys
        private const val KEY_VOLUNTEER_ID = "volunteer_id"
        private const val KEY_VOLUNTEER_FULL_NAME = "volunteer_full_name"
        private const val KEY_VOLUNTEER_EMAIL = "volunteer_email"
        private const val KEY_VOLUNTEER_PHONE = "volunteer_phone"
        private const val KEY_VOLUNTEER_SKILLS = "volunteer_skills"
        private const val KEY_VOLUNTEER_AVAILABILITY = "volunteer_availability"
        
        // Admin Keys
        private const val KEY_ADMIN_ID = "admin_id"
        private const val KEY_ADMIN_FULL_NAME = "admin_full_name"
        private const val KEY_ADMIN_EMAIL = "admin_email"
        
        // User Type
        private const val KEY_USER_TYPE = "user_type"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
    }

    // NGO Session Management
    fun saveNgoSession(ngoId: Int, fullName: String, email: String) {
        prefs.edit().apply {
            putInt(KEY_NGO_ID, ngoId)
            putString(KEY_NGO_FULL_NAME, fullName)
            putString(KEY_NGO_EMAIL, email)
            putString(KEY_USER_TYPE, "ngo")
            putBoolean(KEY_IS_LOGGED_IN, true)
            apply()
        }
    }
    
    fun saveNgoProfileData(phone: String, address: String, orgName: String, regNumber: String) {
        prefs.edit().apply {
            putString(KEY_NGO_PHONE, phone)
            putString(KEY_NGO_ADDRESS, address)
            putString(KEY_NGO_ORG_NAME, orgName)
            putString(KEY_NGO_REG_NUMBER, regNumber)
            apply()
        }
    }
    
    fun getNgoId(): Int = prefs.getInt(KEY_NGO_ID, -1)
    fun getNgoFullName(): String = prefs.getString(KEY_NGO_FULL_NAME, "") ?: ""
    fun getNgoEmail(): String = prefs.getString(KEY_NGO_EMAIL, "") ?: ""
    fun getNgoPhone(): String = prefs.getString(KEY_NGO_PHONE, "") ?: ""
    fun getNgoAddress(): String = prefs.getString(KEY_NGO_ADDRESS, "") ?: ""
    fun getNgoOrgName(): String = prefs.getString(KEY_NGO_ORG_NAME, "") ?: ""
    fun getNgoRegNumber(): String = prefs.getString(KEY_NGO_REG_NUMBER, "") ?: ""
    
    // Donor Session Management
    fun saveDonorSession(donorId: Int, fullName: String, email: String) {
        prefs.edit().apply {
            putInt(KEY_DONOR_ID, donorId)
            putString(KEY_DONOR_FULL_NAME, fullName)
            putString(KEY_DONOR_EMAIL, email)
            putString(KEY_USER_TYPE, "donor")
            putBoolean(KEY_IS_LOGGED_IN, true)
            apply()
        }
    }
    
    fun saveDonorProfileData(phone: String, address: String) {
        prefs.edit().apply {
            putString(KEY_DONOR_PHONE, phone)
            putString(KEY_DONOR_ADDRESS, address)
            apply()
        }
    }
    
    fun getDonorId(): Int = prefs.getInt(KEY_DONOR_ID, -1)
    fun getDonorFullName(): String = prefs.getString(KEY_DONOR_FULL_NAME, "") ?: ""
    fun getDonorEmail(): String = prefs.getString(KEY_DONOR_EMAIL, "") ?: ""
    fun getDonorPhone(): String = prefs.getString(KEY_DONOR_PHONE, "") ?: ""
    fun getDonorAddress(): String = prefs.getString(KEY_DONOR_ADDRESS, "") ?: ""
    
    // Volunteer Session Management
    fun saveVolunteerSession(volunteerId: Int, fullName: String, email: String) {
        prefs.edit().apply {
            putInt(KEY_VOLUNTEER_ID, volunteerId)
            putString(KEY_VOLUNTEER_FULL_NAME, fullName)
            putString(KEY_VOLUNTEER_EMAIL, email)
            putString(KEY_USER_TYPE, "volunteer")
            putBoolean(KEY_IS_LOGGED_IN, true)
            apply()
        }
    }
    
    fun saveVolunteerProfileData(phone: String, skills: String, availability: String) {
        prefs.edit().apply {
            putString(KEY_VOLUNTEER_PHONE, phone)
            putString(KEY_VOLUNTEER_SKILLS, skills)
            putString(KEY_VOLUNTEER_AVAILABILITY, availability)
            apply()
        }
    }
    
    fun getVolunteerId(): Int = prefs.getInt(KEY_VOLUNTEER_ID, -1)
    fun getVolunteerFullName(): String = prefs.getString(KEY_VOLUNTEER_FULL_NAME, "") ?: ""
    fun getVolunteerEmail(): String = prefs.getString(KEY_VOLUNTEER_EMAIL, "") ?: ""
    fun getVolunteerPhone(): String = prefs.getString(KEY_VOLUNTEER_PHONE, "") ?: ""
    fun getVolunteerSkills(): String = prefs.getString(KEY_VOLUNTEER_SKILLS, "") ?: ""
    fun getVolunteerAvailability(): String = prefs.getString(KEY_VOLUNTEER_AVAILABILITY, "") ?: ""
    
    // Admin Session Management
    fun saveAdminSession(adminId: Int, fullName: String, email: String) {
        prefs.edit().apply {
            putInt(KEY_ADMIN_ID, adminId)
            putString(KEY_ADMIN_FULL_NAME, fullName)
            putString(KEY_ADMIN_EMAIL, email)
            putString(KEY_USER_TYPE, "admin")
            putBoolean(KEY_IS_LOGGED_IN, true)
            apply()
        }
    }
    
    fun getAdminId(): Int = prefs.getInt(KEY_ADMIN_ID, -1)
    fun getAdminFullName(): String = prefs.getString(KEY_ADMIN_FULL_NAME, "") ?: ""
    fun getAdminEmail(): String = prefs.getString(KEY_ADMIN_EMAIL, "") ?: ""
    
    // General Session Management
    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    fun getUserType(): String = prefs.getString(KEY_USER_TYPE, "") ?: ""
    
    fun clearSession() {
        prefs.edit().clear().apply()
    }
    
    fun logout() {
        prefs.edit().clear().apply()
    }
}
