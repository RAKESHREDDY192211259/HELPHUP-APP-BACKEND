<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'helphup';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit();
}

try {
    // Get all donor campaigns with user details (only approved campaigns)
    $sql = "SELECT 
                dc.campaign_id,
                dc.donor_id,
                dc.campaign_title,
                dc.category,
                dc.description,
                dc.urgency_level,
                dc.required_amount,
                dc.date_needed,
                dc.status,
                dc.created_at,
                dc.updated_at,
                u.full_name as donor_name,
                u.email as donor_email,
                u.phone_number as donor_phone
            FROM donor_campaigns dc
            LEFT JOIN donor u ON dc.donor_id = u.donor_id
            WHERE u.status = 'active' 
            AND dc.admin_status = 'accepted'
            ORDER BY dc.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $campaigns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Convert numeric values to proper types
    foreach ($campaigns as &$campaign) {
        $campaign['campaign_id'] = (int)$campaign['campaign_id'];
        $campaign['donor_id'] = (int)$campaign['donor_id'];
        $campaign['required_amount'] = $campaign['required_amount'] ? (float)$campaign['required_amount'] : null;
    }
    
    echo json_encode([
        'status' => true,
        'message' => 'Donor campaigns retrieved successfully',
        'data' => $campaigns
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
