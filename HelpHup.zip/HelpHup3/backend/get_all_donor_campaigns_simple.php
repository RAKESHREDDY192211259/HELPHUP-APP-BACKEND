<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Return mock data for testing
$mockData = [
    [
        'campaign_id' => 1,
        'donor_id' => 2,
        'campaign_title' => 'School Supplies Fund',
        'category' => 'Education',
        'description' => 'Help us provide school supplies to underprivileged children.',
        'urgency_level' => 'High',
        'required_amount' => '75000',
        'date_needed' => '2024-01-15',
        'status' => 'APPROVED',
        'created_at' => '2024-01-01 10:00:00',
        'updated_at' => '2024-01-02 15:30:00',
        'donor_name' => 'Michael Brown',
        'donor_email' => 'michael.brown@email.com',
        'donor_phone' => '+91-9876543210'
    ],
    [
        'campaign_id' => 2,
        'donor_id' => 3,
        'campaign_title' => 'Medical Equipment Fund',
        'category' => 'Medical',
        'description' => 'Raise funds to buy medical equipment for the local clinic.',
        'urgency_level' => 'Medium',
        'required_amount' => '50000',
        'date_needed' => '2024-01-20',
        'status' => 'APPROVED',
        'created_at' => '2024-01-03 09:00:00',
        'updated_at' => '2024-01-04 11:00:00',
        'donor_name' => 'Emily Davis',
        'donor_email' => 'emily.davis@email.com',
        'donor_phone' => '+91-9876543211'
    ]
];

echo json_encode([
    'status' => true,
    'message' => 'Donor campaigns retrieved successfully (mock data)',
    'data' => $mockData
]);
?>
