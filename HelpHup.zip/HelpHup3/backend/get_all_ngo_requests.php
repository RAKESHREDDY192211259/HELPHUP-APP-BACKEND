<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'helphup';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit();
}

try {
    // Get all NGO help requests with user details (only approved requests)
    $sql = "SELECT 
                hr.request_id,
                hr.ngo_id,
                hr.request_title,
                hr.category,
                hr.description,
                hr.urgency_level,
                hr.required_amount,
                hr.date_needed,
                hr.status,
                hr.created_at,
                hr.updated_at,
                u.full_name as ngo_name,
                u.email as ngo_email,
                u.phone_number as ngo_phone
            FROM ngo_help_requests hr
            LEFT JOIN ngo u ON hr.ngo_id = u.ngo_id
            WHERE u.status = 'active' 
            AND hr.admin_status = 'accepted'
            ORDER BY hr.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Convert numeric values to proper types
    foreach ($requests as &$request) {
        $request['request_id'] = (int)$request['request_id'];
        $request['ngo_id'] = (int)$request['ngo_id'];
        $request['required_amount'] = $request['required_amount'] ? (float)$request['required_amount'] : null;
    }
    
    echo json_encode([
        'status' => true,
        'message' => 'NGO requests retrieved successfully',
        'data' => $requests
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
