<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Return mock data for testing
$mockData = [
    [
        'request_id' => 1,
        'ngo_id' => 2,
        'request_title' => 'Food Distribution Drive',
        'category' => 'Food',
        'description' => 'We need help distributing food to 500 families in the rural area.',
        'urgency_level' => 'High',
        'required_amount' => '50000',
        'date_needed' => '2024-01-15',
        'status' => 'APPROVED',
        'created_at' => '2024-01-01 10:00:00',
        'updated_at' => '2024-01-02 15:30:00',
        'ngo_name' => 'Helping Hands NGO',
        'ngo_email' => 'contact@helpinghands.org',
        'ngo_phone' => '+91-9876543210'
    ],
    [
        'request_id' => 2,
        'ngo_id' => 3,
        'request_title' => 'Medical Camp Setup',
        'category' => 'Medical',
        'description' => 'Need volunteers to help set up a free medical camp in the village.',
        'urgency_level' => 'Medium',
        'required_amount' => '25000',
        'date_needed' => '2024-01-20',
        'status' => 'APPROVED',
        'created_at' => '2024-01-03 09:00:00',
        'updated_at' => '2024-01-04 11:00:00',
        'ngo_name' => 'Health Care Foundation',
        'ngo_email' => 'info@healthcare.org',
        'ngo_phone' => '+91-9876543211'
    ]
];

echo json_encode([
    'status' => true,
    'message' => 'NGO requests retrieved successfully (mock data)',
    'data' => $mockData
]);
?>
