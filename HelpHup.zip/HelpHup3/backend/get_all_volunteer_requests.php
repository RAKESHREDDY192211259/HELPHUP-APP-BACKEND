<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'helphup';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit();
}

try {
    // Get all volunteer help requests with user details (only approved requests)
    $sql = "SELECT 
                vr.request_id,
                vr.volunteer_id,
                vr.request_title,
                vr.category,
                vr.description,
                vr.urgency_level,
                vr.required_amount,
                vr.date_needed,
                vr.status,
                vr.created_at,
                vr.updated_at,
                u.full_name as volunteer_name,
                u.email as volunteer_email,
                u.phone_number as volunteer_phone
            FROM volunteer_requests vr
            LEFT JOIN volunteer u ON vr.volunteer_id = u.volunteer_id
            WHERE u.status = 'active' 
            AND vr.admin_status = 'accepted'
            ORDER BY vr.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Convert numeric values to proper types
    foreach ($requests as &$request) {
        $request['request_id'] = (int)$request['request_id'];
        $request['volunteer_id'] = (int)$request['volunteer_id'];
        $request['required_amount'] = $request['required_amount'] ? (float)$request['required_amount'] : null;
    }
    
    echo json_encode([
        'status' => true,
        'message' => 'Volunteer requests retrieved successfully',
        'data' => $requests
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
