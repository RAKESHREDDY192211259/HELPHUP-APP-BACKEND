<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Return mock data for testing
$mockData = [
    [
        'request_id' => 1,
        'volunteer_id' => 2,
        'request_title' => 'Teaching Support Needed',
        'category' => 'Education',
        'description' => 'Need volunteers to help teach children in the community center.',
        'urgency_level' => 'High',
        'required_amount' => '10000',
        'date_needed' => '2024-01-15',
        'status' => 'APPROVED',
        'created_at' => '2024-01-01 10:00:00',
        'updated_at' => '2024-01-02 15:30:00',
        'volunteer_name' => 'John Smith',
        'volunteer_email' => 'john.smith@email.com',
        'volunteer_phone' => '+91-9876543210'
    ],
    [
        'request_id' => 2,
        'volunteer_id' => 3,
        'request_title' => 'Community Cleanup Drive',
        'category' => 'Environment',
        'description' => 'Looking for volunteers to help clean up the local park and beach area.',
        'urgency_level' => 'Medium',
        'required_amount' => '5000',
        'date_needed' => '2024-01-20',
        'status' => 'APPROVED',
        'created_at' => '2024-01-03 09:00:00',
        'updated_at' => '2024-01-04 11:00:00',
        'volunteer_name' => 'Sarah Johnson',
        'volunteer_email' => 'sarah.j@email.com',
        'volunteer_phone' => '+91-9876543211'
    ]
];

echo json_encode([
    'status' => true,
    'message' => 'Volunteer requests retrieved successfully (mock data)',
    'data' => $mockData
]);
?>
