<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database configuration
$host = 'localhost';
$dbname = 'helphup_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit();
}

// Get POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!isset($data['ngo_id']) || empty($data['ngo_id'])) {
    echo json_encode([
        'status' => false,
        'message' => 'NGO ID is required'
    ]);
    exit();
}

$ngoId = intval($data['ngo_id']);

try {
    // Query to get NGO profile data
    $stmt = $pdo->prepare("
        SELECT 
            id as ngo_id,
            full_name,
            email,
            phone,
            address,
            org_name,
            reg_number,
            reg_proof_file
        FROM ngos 
        WHERE id = :ngo_id
    ");
    
    $stmt->bindParam(':ngo_id', $ngoId, PDO::PARAM_INT);
    $stmt->execute();
    
    $ngoData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($ngoData) {
        echo json_encode([
            'status' => true,
            'message' => 'Profile data retrieved successfully',
            'data' => [
                'ngoId' => intval($ngoData['ngo_id']),
                'fullName' => $ngoData['full_name'],
                'email' => $ngoData['email'],
                'phone' => $ngoData['phone'],
                'address' => $ngoData['address'],
                'orgName' => $ngoData['org_name'],
                'regNumber' => $ngoData['reg_number'],
                'regProofFile' => $ngoData['reg_proof_file']
            ]
        ]);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'NGO not found'
        ]);
    }
    
} catch(PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
