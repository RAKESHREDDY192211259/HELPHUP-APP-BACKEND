<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database configuration
$host = 'localhost';
$dbname = 'helphup_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit();
}

// Get POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate required fields
$requiredFields = ['ngo_id', 'full_name', 'email', 'phone', 'address', 'org_name', 'reg_number'];
foreach ($requiredFields as $field) {
    if (!isset($data[$field]) || empty($data[$field])) {
        echo json_encode([
            'status' => false,
            'message' => "Field '$field' is required"
        ]);
        exit();
    }
}

$ngoId = intval($data['ngo_id']);
$fullName = trim($data['full_name']);
$email = trim($data['email']);
$phone = trim($data['phone']);
$address = trim($data['address']);
$orgName = trim($data['org_name']);
$regNumber = trim($data['reg_number']);

try {
    // Check if NGO exists
    $checkStmt = $pdo->prepare("SELECT id FROM ngos WHERE id = :ngo_id");
    $checkStmt->bindParam(':ngo_id', $ngoId, PDO::PARAM_INT);
    $checkStmt->execute();
    
    if (!$checkStmt->fetch()) {
        echo json_encode([
            'status' => false,
            'message' => 'NGO not found'
        ]);
        exit();
    }
    
    // Update NGO profile
    $stmt = $pdo->prepare("
        UPDATE ngos SET 
            full_name = :full_name,
            email = :email,
            phone = :phone,
            address = :address,
            org_name = :org_name,
            reg_number = :reg_number,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = :ngo_id
    ");
    
    $stmt->bindParam(':ngo_id', $ngoId, PDO::PARAM_INT);
    $stmt->bindParam(':full_name', $fullName);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':org_name', $orgName);
    $stmt->bindParam(':reg_number', $regNumber);
    
    $result = $stmt->execute();
    
    if ($result) {
        echo json_encode([
            'status' => true,
            'message' => 'Profile updated successfully'
        ]);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to update profile'
        ]);
    }
    
} catch(PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
