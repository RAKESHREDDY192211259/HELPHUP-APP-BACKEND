<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'helphup';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid JSON data'
    ]);
    exit();
}

$requestId = $data['request_id'] ?? '';
$requestType = $data['request_type'] ?? ''; // 'ngo', 'volunteer', 'donor'
$newStatus = $data['status'] ?? ''; // 'APPROVED', 'REJECTED'
$rejectionReason = $data['rejection_reason'] ?? '';

if (empty($requestId) || empty($requestType) || empty($newStatus)) {
    echo json_encode([
        'status' => false,
        'message' => 'Missing required fields: request_id, request_type, status'
    ]);
    exit();
}

try {
    // Update status based on request type
    $tableName = '';
    $idField = '';
    
    switch (strtolower($requestType)) {
        case 'ngo':
            $tableName = 'ngo_help_requests';
            $idField = 'request_id';
            break;
        case 'volunteer':
            $tableName = 'volunteer_requests';
            $idField = 'request_id';
            break;
        case 'donor':
            $tableName = 'donor_campaigns';
            $idField = 'campaign_id';
            break;
        default:
            echo json_encode([
                'status' => false,
                'message' => 'Invalid request type. Must be: ngo, volunteer, or donor'
            ]);
            exit();
    }
    
    // Prepare update query
    if ($newStatus === 'REJECTED') {
        // Include rejection reason for rejected requests
        $sql = "UPDATE $tableName SET status = :status, admin_status = 'rejected', rejection_reason = :rejection_reason, admin_reviewed_at = NOW(), updated_at = NOW() WHERE $idField = :request_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':status', $newStatus);
        $stmt->bindParam(':rejection_reason', $rejectionReason);
        $stmt->bindParam(':request_id', $requestId);
    } else {
        // For approved requests, clear rejection reason and set status
        $sql = "UPDATE $tableName SET status = :status, admin_status = 'accepted', rejection_reason = NULL, admin_reviewed_at = NOW(), updated_at = NOW() WHERE $idField = :request_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':status', $newStatus);
        $stmt->bindParam(':request_id', $requestId);
    }
    
    $stmt->execute();
    
    // Check if update was successful
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'status' => true,
            'message' => "Request status updated to $newStatus successfully",
            'updated_rows' => $stmt->rowCount(),
            'request_id' => $requestId,
            'request_type' => $requestType,
            'new_status' => $newStatus
        ]);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'No rows updated. Request ID may not exist.',
            'request_id' => $requestId,
            'request_type' => $requestType
        ]);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
