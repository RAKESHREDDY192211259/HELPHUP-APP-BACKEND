# PowerShell Script to Copy PHP Files to XAMPP Server
# Run this script as Administrator

Write-Host "Copying PHP files to XAMPP server..." -ForegroundColor Green

# Get the current script directory
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDir = Join-Path $scriptDir "xampp_files"
$targetDir = "C:\xampp\htdocs\helphup\api"

# Files to copy
$files = @(
    "ngo_verify_otp.php",
    "ngo_reset_password.php",
    "donor_verify_otp.php",
    "donor_reset_password.php",
    "volunteer_verify_otp.php",
    "volunteer_reset_password.php",
    "ngoforgot.php",
    "donor_forgot.php",
    "volunteer_forgot.php",
    "debug_otp.php",
    "setup_password_reset_table.php",
    "migrate_to_separate_tables.php"
)

# Check if source directory exists
if (-not (Test-Path $sourceDir)) {
    Write-Host "ERROR: Source directory not found: $sourceDir" -ForegroundColor Red
    exit 1
}

# Check if target directory exists
if (-not (Test-Path $targetDir)) {
    Write-Host "Creating target directory: $targetDir" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
}

# Copy each file
foreach ($file in $files) {
    $sourceFile = Join-Path $sourceDir $file
    $targetFile = Join-Path $targetDir $file
    
    if (Test-Path $sourceFile) {
        Copy-Item -Path $sourceFile -Destination $targetFile -Force
        Write-Host "✓ Copied: $file" -ForegroundColor Green
    } else {
        Write-Host "✗ Not found: $file" -ForegroundColor Red
    }
}

Write-Host "`nDone! Files copied to: $targetDir" -ForegroundColor Green
Write-Host "`nVerify files exist:" -ForegroundColor Yellow
foreach ($file in $files) {
    $targetFile = Join-Path $targetDir $file
    if (Test-Path $targetFile) {
        Write-Host "  ✓ $file" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $file" -ForegroundColor Red
    }
}

Write-Host "`nTest URL: http://localhost/helphup/api/ngo_verify_otp.php" -ForegroundColor Cyan

