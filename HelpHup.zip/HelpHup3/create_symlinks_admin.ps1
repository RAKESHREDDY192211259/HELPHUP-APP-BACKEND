# Create Symlinks for Android Studio Config (Requires Admin)
# Run this script as Administrator

Write-Host "=== Creating Symlinks for Android Studio Config ===" -ForegroundColor Cyan
Write-Host ""

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "ERROR: This script must be run as Administrator!" -ForegroundColor Red
    Write-Host "Right-click PowerShell → Run as Administrator" -ForegroundColor Yellow
    exit 1
}

$targetPath = "D:\Android\AndroidStudio"

# Symlink 1: Main config
$config1Source = "$env:APPDATA\Google\AndroidStudio2025.2.2"
$config1Target = "$targetPath\AndroidStudio2025.2.2"

if (-not (Test-Path $config1Source) -and (Test-Path $config1Target)) {
    Write-Host "Creating symlink 1: $config1Source -> $config1Target" -ForegroundColor Yellow
    try {
        New-Item -ItemType SymbolicLink -Path $config1Source -Target $config1Target -Force | Out-Null
        Write-Host "[OK] Symlink 1 created successfully" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Failed to create symlink 1: $_" -ForegroundColor Red
    }
} else {
    Write-Host "[INFO] Symlink 1 already exists or target missing" -ForegroundColor Gray
}

# Symlink 2: Local cache
$config2Source = "$env:LOCALAPPDATA\Google\AndroidStudio2025.2.2"
$config2Target = "$targetPath\AndroidStudio2025.2.2_Local"

if (-not (Test-Path $config2Source) -and (Test-Path $config2Target)) {
    Write-Host "Creating symlink 2: $config2Source -> $config2Target" -ForegroundColor Yellow
    try {
        New-Item -ItemType SymbolicLink -Path $config2Source -Target $config2Target -Force | Out-Null
        Write-Host "[OK] Symlink 2 created successfully" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Failed to create symlink 2: $_" -ForegroundColor Red
    }
} else {
    Write-Host "[INFO] Symlink 2 already exists or target missing" -ForegroundColor Gray
}

Write-Host ""
Write-Host "=== Verification ===" -ForegroundColor Cyan
$symlink1 = Get-Item $config1Source -ErrorAction SilentlyContinue
$symlink2 = Get-Item $config2Source -ErrorAction SilentlyContinue

if ($symlink1 -and $symlink1.LinkType -eq "SymbolicLink") {
    Write-Host "[OK] Symlink 1 verified: $($symlink1.Target)" -ForegroundColor Green
} else {
    Write-Host "[WARNING] Symlink 1 not verified" -ForegroundColor Yellow
}

if ($symlink2 -and $symlink2.LinkType -eq "SymbolicLink") {
    Write-Host "[OK] Symlink 2 verified: $($symlink2.Target)" -ForegroundColor Green
} else {
    Write-Host "[WARNING] Symlink 2 not verified" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Done! Android Studio config files are now on D: drive." -ForegroundColor Green
Write-Host "You can reopen Android Studio - it will work normally!" -ForegroundColor Green

