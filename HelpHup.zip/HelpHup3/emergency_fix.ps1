# Emergency Fix Script - Run this if you can access PowerShell
Write-Host 'Killing all Android Studio processes...' -ForegroundColor Yellow
Get-Process | Where-Object {$_.ProcessName -like '*studio*' -or $_.ProcessName -like '*idea*'} | Stop-Process -Force
Get-Process -Name 'java' -ErrorAction SilentlyContinue | Stop-Process -Force
Write-Host 'Restarting Windows Explorer...' -ForegroundColor Yellow
taskkill /F /IM explorer.exe
Start-Sleep -Seconds 2
Start-Process explorer.exe
Write-Host 'Done! Screen should refresh now.' -ForegroundColor Green
