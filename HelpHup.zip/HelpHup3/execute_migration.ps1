# Execute Android Studio Migration to D: Drive
# Run this as Administrator

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Android Studio Migration to D: Drive" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "WARNING: Not running as Administrator!" -ForegroundColor Yellow
    Write-Host "Some operations may fail. Please run PowerShell as Administrator." -ForegroundColor Yellow
    Write-Host ""
}

# Check for Android Studio processes
Write-Host "Step 1: Checking for Android Studio processes..." -ForegroundColor Yellow
$studioProcesses = Get-Process | Where-Object {$_.ProcessName -like "*studio*" -or ($_.ProcessName -eq "java" -and $_.MainWindowTitle -like "*Android Studio*")}
if ($studioProcesses) {
    Write-Host "WARNING: Android Studio is still running!" -ForegroundColor Red
    Write-Host "Found processes:" -ForegroundColor Yellow
    $studioProcesses | ForEach-Object { Write-Host "  - $($_.ProcessName) (PID: $($_.Id))" -ForegroundColor Gray }
    Write-Host ""
    $kill = Read-Host "Close Android Studio processes? (y/n)"
    if ($kill -eq "y" -or $kill -eq "Y") {
        $studioProcesses | Stop-Process -Force
        Start-Sleep -Seconds 2
        Write-Host "[OK] Android Studio processes closed" -ForegroundColor Green
    } else {
        Write-Host "Please close Android Studio manually and run this script again." -ForegroundColor Yellow
        exit 1
    }
} else {
    Write-Host "[OK] No Android Studio processes running" -ForegroundColor Green
}
Write-Host ""

# Create target directories
Write-Host "Step 2: Creating target directories on D: drive..." -ForegroundColor Yellow
$directories = @(
    "D:\Android\AndroidSdk",
    "D:\Android\Gradle\.gradle",
    "D:\Android\AndroidStudio"
)

foreach ($dir in $directories) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "[OK] Created: $dir" -ForegroundColor Green
    } else {
        Write-Host "[OK] Already exists: $dir" -ForegroundColor Gray
    }
}
Write-Host ""

# Step 3: Move Android SDK
Write-Host "Step 3: Moving Android SDK..." -ForegroundColor Yellow
$sdkSource = "$env:LOCALAPPDATA\Android\Sdk"
$sdkTarget = "D:\Android\AndroidSdk"

if (Test-Path $sdkSource) {
    $sdkSize = (Get-ChildItem -Path $sdkSource -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum / 1GB
    Write-Host "SDK found at: $sdkSource" -ForegroundColor Gray
    Write-Host "SDK size: $([math]::Round($sdkSize, 2)) GB" -ForegroundColor Gray
    Write-Host "Moving to: $sdkTarget" -ForegroundColor Gray
    Write-Host ""
    Write-Host "This may take 5-15 minutes depending on size..." -ForegroundColor Yellow
    
    try {
        if (Test-Path "$sdkTarget\*") {
            Write-Host "WARNING: Target directory already has files!" -ForegroundColor Yellow
            $overwrite = Read-Host "Continue and overwrite? (y/n)"
            if ($overwrite -ne "y" -and $overwrite -ne "Y") {
                Write-Host "Skipping SDK move" -ForegroundColor Yellow
            } else {
                Write-Host "Moving SDK..." -ForegroundColor Yellow
                Move-Item -Path "$sdkSource\*" -Destination $sdkTarget -Force -ErrorAction Stop
                Remove-Item -Path $sdkSource -Force -ErrorAction SilentlyContinue
                Write-Host "[OK] SDK moved successfully" -ForegroundColor Green
            }
        } else {
            Write-Host "Moving SDK..." -ForegroundColor Yellow
            Move-Item -Path $sdkSource -Destination $sdkTarget -Force -ErrorAction Stop
            Write-Host "[OK] SDK moved successfully" -ForegroundColor Green
        }
        
        # Create symlink
        Write-Host "Creating symlink for compatibility..." -ForegroundColor Yellow
        if (Test-Path $sdkSource) {
            Remove-Item -Path $sdkSource -Force -ErrorAction SilentlyContinue
        }
        New-Item -ItemType SymbolicLink -Path $sdkSource -Target $sdkTarget -Force | Out-Null
        Write-Host "[OK] Symlink created: $sdkSource -> $sdkTarget" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Error moving SDK: $_" -ForegroundColor Red
        Write-Host "You may need to run this script as Administrator" -ForegroundColor Yellow
    }
} else {
    Write-Host "[WARNING] SDK not found at: $sdkSource" -ForegroundColor Yellow
    Write-Host "  SDK may already be moved or not installed" -ForegroundColor Gray
}
Write-Host ""

# Step 4: Move Gradle cache
Write-Host "Step 4: Moving Gradle cache..." -ForegroundColor Yellow
$gradleSource = "$env:USERPROFILE\.gradle"
$gradleTarget = "D:\Android\Gradle\.gradle"

if (Test-Path $gradleSource) {
    $gradleSize = (Get-ChildItem -Path $gradleSource -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum / 1GB
    Write-Host "Gradle cache found at: $gradleSource" -ForegroundColor Gray
    Write-Host "Gradle cache size: $([math]::Round($gradleSize, 2)) GB" -ForegroundColor Gray
    Write-Host "Moving to: $gradleTarget" -ForegroundColor Gray
    Write-Host ""
    
    try {
        if (Test-Path "$gradleTarget\*") {
            Write-Host "WARNING: Target directory already has files!" -ForegroundColor Yellow
            $overwrite = Read-Host "Continue and overwrite? (y/n)"
            if ($overwrite -ne "y" -and $overwrite -ne "Y") {
                Write-Host "Skipping Gradle cache move" -ForegroundColor Yellow
            } else {
                Write-Host "Moving Gradle cache..." -ForegroundColor Yellow
                Move-Item -Path "$gradleSource\*" -Destination $gradleTarget -Force -ErrorAction Stop
                Remove-Item -Path $gradleSource -Force -ErrorAction SilentlyContinue
                Write-Host "[OK] Gradle cache moved successfully" -ForegroundColor Green
            }
        } else {
            Write-Host "Moving Gradle cache..." -ForegroundColor Yellow
            Move-Item -Path $gradleSource -Destination $gradleTarget -Force -ErrorAction Stop
            Write-Host "[OK] Gradle cache moved successfully" -ForegroundColor Green
        }
        
        # Create symlink
        Write-Host "Creating symlink for compatibility..." -ForegroundColor Yellow
        if (Test-Path $gradleSource) {
            Remove-Item -Path $gradleSource -Force -ErrorAction SilentlyContinue
        }
        New-Item -ItemType SymbolicLink -Path $gradleSource -Target $gradleTarget -Force | Out-Null
        Write-Host "[OK] Symlink created: $gradleSource -> $gradleTarget" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Error moving Gradle cache: $_" -ForegroundColor Red
    }
} else {
    Write-Host "[WARNING] Gradle cache not found at: $gradleSource" -ForegroundColor Yellow
}
Write-Host ""

# Step 5: Update local.properties
Write-Host "Step 5: Updating local.properties..." -ForegroundColor Yellow
$localProps = ".\local.properties"
if (Test-Path $localProps) {
    $content = Get-Content $localProps -Raw
    $newSdkPath = "D\:\\Android\\AndroidSdk"
    $content = $content -replace 'sdk\.dir=.*', "sdk.dir=$newSdkPath"
    Set-Content -Path $localProps -Value $content -NoNewline
    Write-Host "[OK] Updated local.properties" -ForegroundColor Green
    Write-Host "  New SDK path: D:\Android\AndroidSdk" -ForegroundColor Gray
} else {
    Write-Host "[WARNING] local.properties not found" -ForegroundColor Yellow
    Write-Host "  Creating new local.properties..." -ForegroundColor Yellow
    $newContent = "## This file is automatically generated by Android Studio.`r`n# Do not modify this file -- YOUR CHANGES WILL BE ERASED!`r`n#`r`n# This file should *NOT* be checked into Version Control Systems,`r`n# as it contains information specific to your local configuration.`r`n#`r`n# Location of the SDK. This is only used by Gradle.`r`n# For customization when using a Version Control System, please read the`r`n# header note.`r`nsdk.dir=D\:\\Android\\AndroidSdk`r`n"
    Set-Content -Path $localProps -Value $newContent
    Write-Host "[OK] Created local.properties" -ForegroundColor Green
}
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Migration Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Files moved:" -ForegroundColor Yellow
Write-Host "  SDK: D:\Android\AndroidSdk" -ForegroundColor Gray
Write-Host "  Gradle: D:\Android\Gradle\.gradle" -ForegroundColor Gray
Write-Host ""
Write-Host "NEXT STEPS (IMPORTANT):" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. Set Environment Variables:" -ForegroundColor White
Write-Host "   - Press Win + X -> System -> Advanced system settings" -ForegroundColor Gray
Write-Host "   - Click 'Environment Variables'" -ForegroundColor Gray
Write-Host "   - Under 'User variables', click 'New'" -ForegroundColor Gray
Write-Host "   - Add: ANDROID_HOME = D:\Android\AndroidSdk" -ForegroundColor Gray
Write-Host "   - Add: ANDROID_SDK_ROOT = D:\Android\AndroidSdk" -ForegroundColor Gray
Write-Host "   - Click OK and RESTART COMPUTER" -ForegroundColor Gray
Write-Host ""
Write-Host "2. Update Android Studio Settings:" -ForegroundColor White
Write-Host "   - Reopen Android Studio" -ForegroundColor Gray
Write-Host "   - File -> Settings -> Appearance & Behavior -> System Settings -> Android SDK" -ForegroundColor Gray
Write-Host "   - Verify SDK Location shows: D:\Android\AndroidSdk" -ForegroundColor Gray
Write-Host "   - If not, click 'Edit' and set the path" -ForegroundColor Gray
Write-Host ""
Write-Host "3. Verify:" -ForegroundColor White
Write-Host "   - Gradle sync should complete successfully" -ForegroundColor Gray
Write-Host "   - Project should build without errors" -ForegroundColor Gray
Write-Host ""
