# Finish Android Studio Migration - Move Remaining Files
# Run this AFTER closing File Explorer and Android Studio

Write-Host "=== Finishing Android Studio Migration ===" -ForegroundColor Cyan
Write-Host ""

# Step 1: Move Projects
Write-Host "Step 1: Moving Projects..." -ForegroundColor Yellow
$sourceProjects = "$env:USERPROFILE\AndroidStudioProjects"
$targetProjects = "D:\Android\Projects"

if (Test-Path $sourceProjects) {
    $items = Get-ChildItem -Path $sourceProjects -ErrorAction SilentlyContinue
    if ($items) {
        foreach ($item in $items) {
            Write-Host "  Moving: $($item.Name)" -ForegroundColor Cyan
            try {
                Move-Item -Path $item.FullName -Destination $targetProjects -Force -ErrorAction Stop
                Write-Host "    [OK] Moved successfully!" -ForegroundColor Green
            } catch {
                Write-Host "    [ERROR] Still in use: $_" -ForegroundColor Red
                Write-Host "    Please close File Explorer and try again" -ForegroundColor Yellow
            }
        }
    } else {
        Write-Host "  [INFO] Projects folder is empty" -ForegroundColor Gray
    }
} else {
    Write-Host "  [INFO] Projects folder not found (already moved?)" -ForegroundColor Gray
}

Write-Host ""

# Step 2: Remove empty folders
Write-Host "Step 2: Cleaning up empty folders..." -ForegroundColor Yellow
$foldersToCheck = @(
    "$env:USERPROFILE\AndroidStudioProjects",
    "$env:APPDATA\Google\AndroidStudio2025.2.2",
    "$env:LOCALAPPDATA\Google\AndroidStudio2025.2.2"
)

foreach ($folder in $foldersToCheck) {
    if (Test-Path $folder) {
        $items = Get-ChildItem -Path $folder -ErrorAction SilentlyContinue
        if ($items.Count -eq 0) {
            Write-Host "  Removing empty folder: $folder" -ForegroundColor Gray
            Remove-Item -Path $folder -Force -ErrorAction SilentlyContinue
        } else {
            Write-Host "  [WARNING] Folder not empty: $folder" -ForegroundColor Yellow
        }
    }
}

Write-Host ""

# Step 3: Create symlinks (if needed)
Write-Host "Step 3: Creating symlinks..." -ForegroundColor Yellow
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($isAdmin) {
    # Projects symlink
    if (-not (Test-Path "$env:USERPROFILE\AndroidStudioProjects") -and (Test-Path "D:\Android\Projects")) {
        try {
            New-Item -ItemType SymbolicLink -Path "$env:USERPROFILE\AndroidStudioProjects" -Target "D:\Android\Projects" -Force | Out-Null
            Write-Host "  [OK] Projects symlink created" -ForegroundColor Green
        } catch {
            Write-Host "  [ERROR] Failed to create projects symlink: $_" -ForegroundColor Red
        }
    }
    
    # Config symlink
    if (-not (Test-Path "$env:APPDATA\Google\AndroidStudio2025.2.2") -and (Test-Path "D:\Android\AndroidStudio\AndroidStudio2025.2.2")) {
        try {
            New-Item -ItemType SymbolicLink -Path "$env:APPDATA\Google\AndroidStudio2025.2.2" -Target "D:\Android\AndroidStudio\AndroidStudio2025.2.2" -Force | Out-Null
            Write-Host "  [OK] Config symlink created" -ForegroundColor Green
        } catch {
            Write-Host "  [ERROR] Failed to create config symlink: $_" -ForegroundColor Red
        }
    }
} else {
    Write-Host "  [WARNING] Not running as Administrator" -ForegroundColor Yellow
    Write-Host "  Symlinks require admin privileges" -ForegroundColor Gray
    Write-Host "  Run this script as Administrator to create symlinks" -ForegroundColor Gray
}

Write-Host ""

# Step 4: Final verification
Write-Host "=== Final Verification ===" -ForegroundColor Cyan
Write-Host ""

Write-Host "Files on D: drive:" -ForegroundColor Yellow
if (Test-Path "D:\Android\Projects") {
    $projects = Get-ChildItem -Path "D:\Android\Projects" -ErrorAction SilentlyContinue
    Write-Host "  Projects: $($projects.Count) found" -ForegroundColor Green
    $projects | ForEach-Object { Write-Host "    - $($_.Name)" -ForegroundColor Gray }
} else {
    Write-Host "  Projects: Not found" -ForegroundColor Yellow
}

if (Test-Path "D:\Android\AndroidStudio") {
    $configs = Get-ChildItem -Path "D:\Android\AndroidStudio" -ErrorAction SilentlyContinue
    Write-Host "  Config files: $($configs.Count) found" -ForegroundColor Green
}

if (Test-Path "D:\Android\AndroidSdk") {
    Write-Host "  SDK: Found" -ForegroundColor Green
}

if (Test-Path "D:\Android\Gradle\.gradle") {
    Write-Host "  Gradle cache: Found" -ForegroundColor Green
}

Write-Host ""
Write-Host "Remaining on C: drive:" -ForegroundColor Yellow
$remaining = @()
if (Test-Path "$env:USERPROFILE\AndroidStudioProjects") {
    $items = Get-ChildItem -Path "$env:USERPROFILE\AndroidStudioProjects" -ErrorAction SilentlyContinue
    if ($items) {
        $remaining += "Projects folder has $($items.Count) item(s)"
    }
}

if ($remaining.Count -eq 0) {
    Write-Host "  ✅ All files moved from C: drive!" -ForegroundColor Green
} else {
    Write-Host "  ⚠️ Some files still on C: drive:" -ForegroundColor Yellow
    $remaining | ForEach-Object { Write-Host "    - $_" -ForegroundColor Gray }
}

Write-Host ""
Write-Host "=== Migration Summary ===" -ForegroundColor Cyan
Write-Host "✅ SDK: D:\Android\AndroidSdk" -ForegroundColor Green
Write-Host "✅ Gradle: D:\Android\Gradle\.gradle" -ForegroundColor Green
Write-Host "✅ Config: D:\Android\AndroidStudio" -ForegroundColor Green
if (Test-Path "D:\Android\Projects") {
    Write-Host "✅ Projects: D:\Android\Projects" -ForegroundColor Green
} else {
    Write-Host "⚠️ Projects: Need to move manually (close File Explorer first)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Done! Check the results above." -ForegroundColor Green

