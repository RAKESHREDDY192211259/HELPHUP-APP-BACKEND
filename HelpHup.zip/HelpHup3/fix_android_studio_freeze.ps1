# Fix Android Studio Freeze - Clean Build Script
# Run this script to stop Gradle daemons and clean build cache

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Android Studio Freeze Fix Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Stop all Gradle daemons
Write-Host "Step 1: Stopping Gradle daemons..." -ForegroundColor Yellow
& .\gradlew.bat --stop
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Gradle daemons stopped successfully" -ForegroundColor Green
} else {
    Write-Host "⚠ Could not stop Gradle daemons (may not be running)" -ForegroundColor Yellow
}
Write-Host ""

# Step 2: Clean build directories
Write-Host "Step 2: Cleaning build directories..." -ForegroundColor Yellow
if (Test-Path ".\app\build") {
    Remove-Item -Recurse -Force ".\app\build"
    Write-Host "✓ Removed app\build directory" -ForegroundColor Green
}
if (Test-Path ".\build") {
    Remove-Item -Recurse -Force ".\build"
    Write-Host "✓ Removed build directory" -ForegroundColor Green
}
Write-Host ""

# Step 3: Clean Gradle cache (optional, but recommended)
Write-Host "Step 3: Cleaning Gradle cache..." -ForegroundColor Yellow
$gradleCache = "$env:USERPROFILE\.gradle\caches"
if (Test-Path $gradleCache) {
    Write-Host "Gradle cache found at: $gradleCache" -ForegroundColor Gray
    $response = Read-Host "Do you want to clean Gradle cache? This may take time. (y/n)"
    if ($response -eq "y" -or $response -eq "Y") {
        Remove-Item -Recurse -Force "$gradleCache\build-cache-*" -ErrorAction SilentlyContinue
        Write-Host "✓ Gradle build cache cleaned" -ForegroundColor Green
    } else {
        Write-Host "Skipped Gradle cache cleanup" -ForegroundColor Yellow
    }
}
Write-Host ""

# Step 4: Clean .gradle directory in project
Write-Host "Step 4: Cleaning project .gradle directory..." -ForegroundColor Yellow
if (Test-Path "\.gradle") {
    Remove-Item -Recurse -Force "\.gradle"
    Write-Host "✓ Removed .gradle directory" -ForegroundColor Green
}
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Cleanup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Close Android Studio completely" -ForegroundColor White
Write-Host "2. Increase Android Studio memory (see instructions below)" -ForegroundColor White
Write-Host "3. Reopen Android Studio" -ForegroundColor White
Write-Host "4. Wait for Gradle sync to complete" -ForegroundColor White
Write-Host ""

