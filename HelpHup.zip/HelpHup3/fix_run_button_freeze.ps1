# Fix Android Studio Run Button Freeze Script
# This script helps resolve issues when Run button causes Android Studio to freeze

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Fix Run Button Freeze Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Stop all Gradle daemons
Write-Host "Step 1: Stopping all Gradle daemons..." -ForegroundColor Yellow
& .\gradlew.bat --stop
Start-Sleep -Seconds 2
Write-Host "✓ Gradle daemons stopped" -ForegroundColor Green
Write-Host ""

# Step 2: Kill any hanging Java/Gradle processes
Write-Host "Step 2: Checking for hanging Java processes..." -ForegroundColor Yellow
$javaProcesses = Get-Process -Name "java" -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -eq "" }
if ($javaProcesses) {
    Write-Host "Found $($javaProcesses.Count) Java process(es) that may be hanging" -ForegroundColor Yellow
    $response = Read-Host "Do you want to kill these processes? (y/n)"
    if ($response -eq "y" -or $response -eq "Y") {
        $javaProcesses | Stop-Process -Force
        Write-Host "✓ Killed hanging Java processes" -ForegroundColor Green
    }
} else {
    Write-Host "✓ No hanging Java processes found" -ForegroundColor Green
}
Write-Host ""

# Step 3: Clean build directories
Write-Host "Step 3: Cleaning build directories..." -ForegroundColor Yellow
if (Test-Path ".\app\build") {
    Remove-Item -Recurse -Force ".\app\build" -ErrorAction SilentlyContinue
    Write-Host "✓ Cleaned app\build" -ForegroundColor Green
}
if (Test-Path ".\build") {
    Remove-Item -Recurse -Force ".\build" -ErrorAction SilentlyContinue
    Write-Host "✓ Cleaned build" -ForegroundColor Green
}
if (Test-Path "\.gradle") {
    Remove-Item -Recurse -Force "\.gradle" -ErrorAction SilentlyContinue
    Write-Host "✓ Cleaned .gradle" -ForegroundColor Green
}
Write-Host ""

# Step 4: Clean Gradle cache (optional)
Write-Host "Step 4: Gradle cache cleanup (optional)..." -ForegroundColor Yellow
$response = Read-Host "Do you want to clean Gradle cache? This may take time but can fix build issues. (y/n)"
if ($response -eq "y" -or $response -eq "Y") {
    $gradleCache = "$env:USERPROFILE\.gradle\caches"
    if (Test-Path $gradleCache) {
        Write-Host "Cleaning Gradle cache (this may take a few minutes)..." -ForegroundColor Yellow
        Remove-Item -Recurse -Force "$gradleCache\build-cache-*" -ErrorAction SilentlyContinue
        Remove-Item -Recurse -Force "$gradleCache\modules-2\files-2.1" -ErrorAction SilentlyContinue
        Write-Host "✓ Gradle cache cleaned" -ForegroundColor Green
    }
}
Write-Host ""

# Step 5: Invalidate Android Studio caches (instructions)
Write-Host "Step 5: Android Studio cache invalidation..." -ForegroundColor Yellow
Write-Host "After closing Android Studio, you should:" -ForegroundColor White
Write-Host "1. Close Android Studio completely" -ForegroundColor Gray
Write-Host "2. Delete: C:\Users\mnand\.AndroidStudio\system\caches" -ForegroundColor Gray
Write-Host "3. Or use: File → Invalidate Caches → Invalidate and Restart" -ForegroundColor Gray
Write-Host ""

# Step 6: Check ADB (Android Debug Bridge)
Write-Host "Step 6: Checking ADB status..." -ForegroundColor Yellow
$adbPath = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
if (Test-Path $adbPath) {
    Write-Host "ADB found at: $adbPath" -ForegroundColor Gray
    Write-Host "Attempting to restart ADB server..." -ForegroundColor Yellow
    & $adbPath kill-server 2>$null
    Start-Sleep -Seconds 1
    & $adbPath start-server 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ ADB server restarted" -ForegroundColor Green
    } else {
        Write-Host "⚠ ADB server restart failed (may not be needed)" -ForegroundColor Yellow
    }
} else {
    Write-Host "⚠ ADB not found at expected location" -ForegroundColor Yellow
    Write-Host "  This is normal if you haven't set up Android SDK yet" -ForegroundColor Gray
}
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Cleanup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Close Android Studio completely" -ForegroundColor White
Write-Host "2. Wait 10 seconds" -ForegroundColor White
Write-Host "3. Reopen Android Studio" -ForegroundColor White
Write-Host "4. Wait for Gradle sync to complete" -ForegroundColor White
Write-Host "5. Try running the app again" -ForegroundColor White
Write-Host ""
Write-Host "If still freezing, check:" -ForegroundColor Yellow
Write-Host "- Device/Emulator is connected and running" -ForegroundColor Gray
Write-Host "- No antivirus blocking Gradle/Java processes" -ForegroundColor Gray
Write-Host "- Sufficient disk space (need 10GB+ free)" -ForegroundColor Gray
Write-Host "- Internet connection (for downloading dependencies)" -ForegroundColor Gray
Write-Host ""

