# Move Android Studio Files from C: to D: Drive
# This script helps move Android SDK, Gradle cache, and Android Studio config to D: drive

param(
    [string]$DDrivePath = "D:\Android"
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Move Android Studio to D: Drive" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if D: drive exists
if (-not (Test-Path "D:\")) {
    Write-Host "ERROR: D: drive not found!" -ForegroundColor Red
    Write-Host "Please ensure D: drive is available." -ForegroundColor Yellow
    exit 1
}

Write-Host "Target location: $DDrivePath" -ForegroundColor Yellow
Write-Host ""

# Create target directories
Write-Host "Step 1: Creating target directories..." -ForegroundColor Yellow
$directories = @(
    "$DDrivePath\AndroidSdk",
    "$DDrivePath\AndroidStudio",
    "$DDrivePath\Gradle",
    "$DDrivePath\Projects"
)

foreach ($dir in $directories) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "✓ Created: $dir" -ForegroundColor Green
    } else {
        Write-Host "✓ Already exists: $dir" -ForegroundColor Gray
    }
}
Write-Host ""

# Step 2: Move Android SDK
Write-Host "Step 2: Moving Android SDK..." -ForegroundColor Yellow
$sdkSource = "$env:LOCALAPPDATA\Android\Sdk"
$sdkTarget = "$DDrivePath\AndroidSdk"

if (Test-Path $sdkSource) {
    Write-Host "Found SDK at: $sdkSource" -ForegroundColor Gray
    Write-Host "Moving to: $sdkTarget" -ForegroundColor Gray
    Write-Host ""
    Write-Host "WARNING: This will move the entire Android SDK folder." -ForegroundColor Yellow
    Write-Host "This may take 10-30 minutes depending on SDK size." -ForegroundColor Yellow
    $response = Read-Host "Continue? (y/n)"
    
    if ($response -eq "y" -or $response -eq "Y") {
        Write-Host "Moving SDK (this may take a while)..." -ForegroundColor Yellow
        try {
            Move-Item -Path $sdkSource -Destination $sdkTarget -Force
            Write-Host "✓ SDK moved successfully" -ForegroundColor Green
            
            # Create symlink for compatibility
            Write-Host "Creating symlink for compatibility..." -ForegroundColor Yellow
            $symlinkPath = Split-Path $sdkSource -Parent
            if (-not (Test-Path $sdkSource)) {
                New-Item -ItemType SymbolicLink -Path $sdkSource -Target $sdkTarget -Force | Out-Null
                Write-Host "✓ Symlink created: $sdkSource -> $sdkTarget" -ForegroundColor Green
            }
        } catch {
            Write-Host "✗ Error moving SDK: $_" -ForegroundColor Red
            Write-Host "You may need to run this script as Administrator" -ForegroundColor Yellow
        }
    } else {
        Write-Host "Skipped SDK move" -ForegroundColor Yellow
    }
} else {
    Write-Host "⚠ SDK not found at: $sdkSource" -ForegroundColor Yellow
    Write-Host "  SDK may already be moved or not installed yet" -ForegroundColor Gray
}
Write-Host ""

# Step 3: Move Gradle cache
Write-Host "Step 3: Moving Gradle cache..." -ForegroundColor Yellow
$gradleSource = "$env:USERPROFILE\.gradle"
$gradleTarget = "$DDrivePath\Gradle\.gradle"

if (Test-Path $gradleSource) {
    Write-Host "Found Gradle cache at: $gradleSource" -ForegroundColor Gray
    Write-Host "Moving to: $gradleTarget" -ForegroundColor Gray
    Write-Host ""
    $response = Read-Host "Move Gradle cache? (y/n)"
    
    if ($response -eq "y" -or $response -eq "Y") {
        Write-Host "Moving Gradle cache..." -ForegroundColor Yellow
        try {
            # Create parent directory
            $gradleParent = Split-Path $gradleTarget -Parent
            if (-not (Test-Path $gradleParent)) {
                New-Item -ItemType Directory -Path $gradleParent -Force | Out-Null
            }
            
            Move-Item -Path $gradleSource -Destination $gradleTarget -Force
            Write-Host "✓ Gradle cache moved successfully" -ForegroundColor Green
            
            # Create symlink
            New-Item -ItemType SymbolicLink -Path $gradleSource -Target $gradleTarget -Force | Out-Null
            Write-Host "✓ Symlink created: $gradleSource -> $gradleTarget" -ForegroundColor Green
        } catch {
            Write-Host "✗ Error moving Gradle cache: $_" -ForegroundColor Red
        }
    } else {
        Write-Host "Skipped Gradle cache move" -ForegroundColor Yellow
    }
} else {
    Write-Host "⚠ Gradle cache not found at: $gradleSource" -ForegroundColor Yellow
}
Write-Host ""

# Step 4: Move Android Studio config (optional)
Write-Host "Step 4: Moving Android Studio configuration..." -ForegroundColor Yellow
$studioConfigPaths = @(
    "$env:APPDATA\Google\AndroidStudio*",
    "$env:USERPROFILE\.AndroidStudio*"
)

$movedConfig = $false
foreach ($configPath in $studioConfigPaths) {
    $configDirs = Get-ChildItem -Path (Split-Path $configPath -Parent) -Directory -Filter (Split-Path $configPath -Leaf) -ErrorAction SilentlyContinue
    foreach ($configDir in $configDirs) {
        Write-Host "Found config at: $($configDir.FullName)" -ForegroundColor Gray
        $configTarget = "$DDrivePath\AndroidStudio\$($configDir.Name)"
        Write-Host "Would move to: $configTarget" -ForegroundColor Gray
        Write-Host ""
        $response = Read-Host "Move this config? (y/n)"
        
        if ($response -eq "y" -or $response -eq "Y") {
            try {
                Move-Item -Path $configDir.FullName -Destination $configTarget -Force
                Write-Host "✓ Config moved successfully" -ForegroundColor Green
                
                # Create symlink
                New-Item -ItemType SymbolicLink -Path $configDir.FullName -Target $configTarget -Force | Out-Null
                Write-Host "✓ Symlink created" -ForegroundColor Green
                $movedConfig = $true
            } catch {
                Write-Host "✗ Error moving config: $_" -ForegroundColor Red
            }
        }
    }
}

if (-not $movedConfig) {
    Write-Host "⚠ No Android Studio config moved" -ForegroundColor Yellow
    Write-Host "  You can manually move config later if needed" -ForegroundColor Gray
}
Write-Host ""

# Step 5: Update environment variables (instructions)
Write-Host "Step 5: Environment variables setup..." -ForegroundColor Yellow
Write-Host ""
Write-Host "IMPORTANT: You need to set these environment variables:" -ForegroundColor Yellow
Write-Host ""
Write-Host "ANDROID_HOME = $DDrivePath\AndroidSdk" -ForegroundColor White
Write-Host "ANDROID_SDK_ROOT = $DDrivePath\AndroidSdk" -ForegroundColor White
Write-Host ""
Write-Host "To set environment variables:" -ForegroundColor Yellow
Write-Host "1. Press Win + X → System → Advanced system settings" -ForegroundColor Gray
Write-Host "2. Click 'Environment Variables'" -ForegroundColor Gray
Write-Host "3. Under 'User variables', click 'New'" -ForegroundColor Gray
Write-Host "4. Add ANDROID_HOME = $DDrivePath\AndroidSdk" -ForegroundColor Gray
Write-Host "5. Add ANDROID_SDK_ROOT = $DDrivePath\AndroidSdk" -ForegroundColor Gray
Write-Host "6. Click OK and restart computer" -ForegroundColor Gray
Write-Host ""

# Step 6: Update local.properties
Write-Host "Step 6: Updating local.properties..." -ForegroundColor Yellow
$localProps = ".\local.properties"
if (Test-Path $localProps) {
    $content = Get-Content $localProps -Raw
    $newSdkPath = $sdkTarget -replace '\\', '\\'
    $content = $content -replace 'sdk\.dir=.*', "sdk.dir=$newSdkPath"
    Set-Content -Path $localProps -Value $content
    Write-Host "✓ Updated local.properties" -ForegroundColor Green
    Write-Host "  New SDK path: $sdkTarget" -ForegroundColor Gray
} else {
    Write-Host "⚠ local.properties not found" -ForegroundColor Yellow
    Write-Host "  Will be created automatically by Android Studio" -ForegroundColor Gray
}
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Migration Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Set ANDROID_HOME and ANDROID_SDK_ROOT environment variables" -ForegroundColor White
Write-Host "2. Restart your computer" -ForegroundColor White
Write-Host "3. Reopen Android Studio" -ForegroundColor White
Write-Host "4. Go to: File → Settings → Appearance & Behavior → System Settings → Android SDK" -ForegroundColor White
Write-Host "5. Verify SDK path shows: $DDrivePath\AndroidSdk" -ForegroundColor White
Write-Host "6. If needed, update SDK path in Android Studio settings" -ForegroundColor White
Write-Host ""
Write-Host "Files moved to:" -ForegroundColor Yellow
Write-Host "  SDK: $DDrivePath\AndroidSdk" -ForegroundColor Gray
Write-Host "  Gradle: $DDrivePath\Gradle\.gradle" -ForegroundColor Gray
Write-Host "  Config: $DDrivePath\AndroidStudio\" -ForegroundColor Gray
Write-Host ""

