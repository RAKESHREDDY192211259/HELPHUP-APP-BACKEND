-- ============================================
-- Add Admin Status Columns to Help Request Tables
-- Run this in phpMyAdmin SQL tab on 'helphup' database
-- ============================================

-- Add admin_status column to ngo_help_requests
ALTER TABLE `ngo_help_requests` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

-- Add admin_id column to ngo_help_requests
ALTER TABLE `ngo_help_requests` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this request';

-- Add admin_reviewed_at column to ngo_help_requests
ALTER TABLE `ngo_help_requests` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this request';

-- Add rejection_reason column to ngo_help_requests
ALTER TABLE `ngo_help_requests` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes for ngo_help_requests
ALTER TABLE `ngo_help_requests` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `ngo_help_requests` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- ============================================

-- Add admin_status column to volunteer_requests
ALTER TABLE `volunteer_requests` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

-- Add admin_id column to volunteer_requests
ALTER TABLE `volunteer_requests` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this request';

-- Add admin_reviewed_at column to volunteer_requests
ALTER TABLE `volunteer_requests` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this request';

-- Add rejection_reason column to volunteer_requests
ALTER TABLE `volunteer_requests` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes for volunteer_requests
ALTER TABLE `volunteer_requests` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `volunteer_requests` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- ============================================

-- Add admin_status column to donor_campaigns
ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

-- Add admin_id column to donor_campaigns
ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this campaign';

-- Add admin_reviewed_at column to donor_campaigns
ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this campaign';

-- Add rejection_reason column to donor_campaigns
ALTER TABLE `donor_campaigns` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes for donor_campaigns
ALTER TABLE `donor_campaigns` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `donor_campaigns` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- ============================================
-- Update existing records to 'pending' status
-- ============================================

UPDATE `ngo_help_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

UPDATE `volunteer_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

UPDATE `donor_campaigns` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

-- ============================================
-- Success message
-- ============================================
SELECT 'Admin status columns added successfully!' AS message;

