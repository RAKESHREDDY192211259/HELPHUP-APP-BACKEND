-- ============================================
-- Add Admin Status Columns to EXISTING Tables
-- Your tables are: ngoraisehelp, volunteerraisehelp, donor_campaigns
-- Run this in phpMyAdmin SQL tab on 'helphup' database
-- ============================================

-- 1. ADD ADMIN COLUMNS TO ngoraisehelp TABLE
ALTER TABLE `ngoraisehelp` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

ALTER TABLE `ngoraisehelp` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this request';

ALTER TABLE `ngoraisehelp` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this request';

ALTER TABLE `ngoraisehelp` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes
ALTER TABLE `ngoraisehelp` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `ngoraisehelp` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- Update existing records to 'pending'
UPDATE `ngoraisehelp` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

-- ============================================

-- 2. ADD ADMIN COLUMNS TO volunteerraisehelp TABLE
ALTER TABLE `volunteerraisehelp` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

ALTER TABLE `volunteerraisehelp` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this request';

ALTER TABLE `volunteerraisehelp` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this request';

ALTER TABLE `volunteerraisehelp` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes
ALTER TABLE `volunteerraisehelp` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `volunteerraisehelp` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- Update existing records to 'pending'
UPDATE `volunteerraisehelp` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

-- ============================================

-- 3. ADD ADMIN COLUMNS TO donor_campaigns TABLE (if it exists)
ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this campaign';

ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this campaign';

ALTER TABLE `donor_campaigns` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes
ALTER TABLE `donor_campaigns` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `donor_campaigns` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- Update existing records to 'pending'
UPDATE `donor_campaigns` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

-- ============================================
-- Success message
-- ============================================
SELECT 'Admin status columns added to existing tables successfully!' AS message;

