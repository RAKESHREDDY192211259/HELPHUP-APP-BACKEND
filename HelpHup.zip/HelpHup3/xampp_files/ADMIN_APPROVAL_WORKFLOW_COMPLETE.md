# ✅ Admin Approval Workflow - Complete Implementation

## 📋 Overview

Complete admin approval workflow where:
1. **User submits request** → Status: `pending`
2. **Admin can Verify** → Status: `verified` (optional step)
3. **Admin can Accept** → Status: `accepted`, visible to other roles
4. **Admin can Reject** → Status: `rejected`, user gets notification with reason

---

## 🔄 Workflow Steps

### Step 1: User Submits Request
- NGO/Volunteer/Donor submits help request
- Request is saved with `admin_status = 'pending'`
- Request is **NOT visible** to other users yet

### Step 2: Admin Reviews
- Admin logs in → Dashboard → Manage Requests
- Sees all pending requests
- Can click to view full details

### Step 3: Admin Actions

#### Option A: Verify (Optional)
- Click "Verify Request" button
- Status changes to `verified`
- Still not visible to other users
- Can then Accept or Reject

#### Option B: Accept
- Click "Accept" button
- Status changes to `accepted`
- Request becomes **visible** to:
  - Other NGOs (in "Help Others")
  - Volunteers (in "Help Others")
  - Donors (in "Browse Causes")
- Request can now receive help from other users

#### Option C: Reject
- Click "Reject" button
- Enter rejection reason (required)
- Status changes to `rejected`
- **Notification is created** for the user
- Request is **NOT visible** to other users

---

## 📊 Database Setup

### 1. Create Notifications Table

Run this SQL in phpMyAdmin:

```sql
CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_type` VARCHAR(20) NOT NULL COMMENT 'ngo, volunteer, donor',
  `user_id` INT(11) NOT NULL COMMENT 'ID of the user',
  `request_type` VARCHAR(20) NOT NULL COMMENT 'ngo, volunteer, donor',
  `request_id` INT(11) NOT NULL COMMENT 'ID of the rejected request',
  `title` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `rejection_reason` TEXT DEFAULT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`),
  INDEX `idx_user` (`user_type`, `user_id`),
  INDEX `idx_is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 2. Add Admin Status Columns (if not already done)

Run `ADD_ADMIN_STATUS_TO_EXISTING_TABLES.sql` for:
- `ngoraisehelp`
- `volunteerraisehelp`
- `donor_campaigns`

---

## 🔧 PHP Endpoints Updated

### ✅ Updated Files:

1. **`admin_accept_request.php`**
   - Works with `ngoraisehelp` and `ngo_help_requests` tables
   - Sets `admin_status = 'accepted'`
   - Sets `status = 'active'` (makes it visible)
   - Request becomes visible to other roles

2. **`admin_reject_request.php`**
   - Works with actual table names
   - Sets `admin_status = 'rejected'`
   - Stores rejection reason
   - **Creates notification** for the user

3. **`admin_verify_request.php`**
   - Sets `admin_status = 'verified'`
   - Optional step before accept/reject

4. **`get_all_ngo_requests.php`**
   - **Only shows accepted requests** (`admin_status = 'accepted'`)
   - Used by "Help Others" screens

5. **`get_all_volunteer_requests.php`**
   - **Only shows accepted requests**
   - Used by "Help Others" screens

6. **`get_all_donor_campaigns.php`**
   - **Only shows accepted campaigns**
   - Used by "Browse Causes" screens

---

## 📱 Android App Updates

### ✅ Updated Files:

1. **`AdminRequestDetails.kt`**
   - Shows "Verify Request" button (if status is `pending`)
   - Shows "Accept" and "Reject" buttons (if status is `pending` or `verified`)
   - Reject requires reason input
   - Better button layout

2. **`AdminManageRequests.kt`**
   - Lists all pending requests
   - Filter by type (All, NGO, Volunteer, Donor)

---

## 🎯 How It Works

### When Admin Accepts:
1. Request `admin_status` → `accepted`
2. Request `status` → `active`
3. Request appears in:
   - NGO "Help Others" screen
   - Volunteer "Help Others" screen
   - Donor "Browse Causes" screen
4. Other users can now help with this request

### When Admin Rejects:
1. Request `admin_status` → `rejected`
2. Request `status` → `rejected`
3. Rejection reason is stored
4. **Notification is created** in `notifications` table
5. User will see notification when they log in
6. Request is **NOT visible** to other users

### When Admin Verifies:
1. Request `admin_status` → `verified`
2. Request still not visible to others
3. Admin can then Accept or Reject

---

## 📝 Notification System

### Notification Table Structure:
- `user_type`: 'ngo', 'volunteer', or 'donor'
- `user_id`: ID of the user who submitted the request
- `request_type`: Type of request that was rejected
- `request_id`: ID of the rejected request
- `title`: "Request Rejected: [Request Title]"
- `message`: "Your help request has been rejected by the administrator."
- `rejection_reason`: The reason provided by admin
- `is_read`: 0 = unread, 1 = read

### To Show Notifications to Users:
Create an endpoint to fetch notifications:
```php
// get_notifications.php
SELECT * FROM notifications 
WHERE user_type = ? AND user_id = ? AND is_read = 0 
ORDER BY created_at DESC
```

---

## ✅ Testing Checklist

1. ✅ Submit request as NGO → Should be `pending`
2. ✅ Login as Admin → Should see request in "Manage Requests"
3. ✅ Click "Verify" → Status should change to `verified`
4. ✅ Click "Accept" → Status should be `accepted`
5. ✅ Check "Help Others" as Volunteer/NGO/Donor → Should see accepted request
6. ✅ Submit another request
7. ✅ Login as Admin → Reject with reason
8. ✅ Check notifications table → Should have entry
9. ✅ Check "Help Others" → Rejected request should NOT appear

---

## 🚀 Next Steps (Optional)

1. **Create notification screen** in Android app to show rejections
2. **Email notifications** when request is rejected
3. **Push notifications** for real-time updates
4. **Notification badge** on dashboard showing unread count

---

## 📋 Files Summary

**SQL:**
- ✅ `create_notifications_table.sql` - Create notifications table
- ✅ `ADD_ADMIN_STATUS_TO_EXISTING_TABLES.sql` - Add admin columns

**PHP (Updated):**
- ✅ `admin_accept_request.php` - Accept request (makes visible)
- ✅ `admin_reject_request.php` - Reject request (creates notification)
- ✅ `admin_verify_request.php` - Verify request
- ✅ `get_all_ngo_requests.php` - Only shows accepted
- ✅ `get_all_volunteer_requests.php` - Only shows accepted
- ✅ `get_all_donor_campaigns.php` - Only shows accepted

**Android (Updated):**
- ✅ `AdminRequestDetails.kt` - Better button layout
- ✅ `AdminManageRequests.kt` - Lists pending requests

---

## 🎉 Complete!

The admin approval workflow is now fully implemented:
- ✅ Verify option
- ✅ Accept makes requests visible to other roles
- ✅ Reject creates notification with reason
- ✅ Only accepted requests are visible in "Help Others" screens

