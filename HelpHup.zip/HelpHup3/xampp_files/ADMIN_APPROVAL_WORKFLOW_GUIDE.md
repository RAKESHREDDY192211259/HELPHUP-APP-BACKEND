# ✅ Admin Approval Workflow - Complete Setup Guide

## 📋 Overview

All help requests (NGO, Volunteer, Donor) now require admin approval before being visible to other users. This ensures quality control and prevents spam.

## 🔄 Workflow

1. **User Submits Request** → Status: `pending` (waiting for admin approval)
2. **Admin Reviews** → Can verify, accept, or reject
3. **If Accepted** → Status: `accepted`, visible to other users
4. **If Rejected** → Status: `rejected`, not visible to users

---

## 📊 Database Setup

### Step 1: Run SQL Migration

**File:** `admin_approval_workflow_setup.sql`

1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `helphup` database
3. Click "SQL" tab
4. Copy and paste content from `admin_approval_workflow_setup.sql`
5. Click "Go"

**What it does:**
- Adds `admin_status` column (pending, verified, accepted, rejected)
- Adds `admin_id` column (who reviewed it)
- Adds `admin_reviewed_at` timestamp
- Adds `rejection_reason` text field
- Updates existing records to 'pending' status

**Tables Updated:**
- ✅ `ngo_help_requests`
- ✅ `volunteer_requests`
- ✅ `donor_campaigns`

---

## 🔧 PHP Backend Files

### Updated Files (Already Modified):

1. ✅ **`ngo_raise_help.php`**
   - Sets `admin_status = 'pending'` when creating request
   - Sets `status = 'pending'` (not visible until approved)

2. ✅ **`volunteer_raise_help.php`**
   - Sets `admin_status = 'pending'` when creating request
   - Sets `status = 'pending'` (not visible until approved)

3. ✅ **`Donor_raise_help.php`**
   - Sets `admin_status = 'pending'` when creating campaign
   - Sets `status = 'pending'` (not visible until approved)

### New PHP Files Created:

1. ✅ **`admin_get_pending_requests.php`**
   - **Endpoint:** `GET /helphup/api/admin_get_pending_requests.php?request_type=all`
   - **Returns:** All pending requests from all roles
   - **Query Params:** `request_type` (optional: 'all', 'ngo', 'volunteer', 'donor')

2. ✅ **`admin_verify_request.php`**
   - **Endpoint:** `POST /helphup/api/admin_verify_request.php`
   - **Request:** `{ "request_type": "ngo", "request_id": 1, "admin_id": 1 }`
   - **Action:** Sets `admin_status = 'verified'`

3. ✅ **`admin_accept_request.php`**
   - **Endpoint:** `POST /helphup/api/admin_accept_request.php`
   - **Request:** `{ "request_type": "ngo", "request_id": 1, "admin_id": 1 }`
   - **Action:** Sets `admin_status = 'accepted'` and `status = 'active'` (visible to users)

4. ✅ **`admin_reject_request.php`**
   - **Endpoint:** `POST /helphup/api/admin_reject_request.php`
   - **Request:** `{ "request_type": "ngo", "request_id": 1, "admin_id": 1, "rejection_reason": "..." }`
   - **Action:** Sets `admin_status = 'rejected'` and `status = 'rejected'`

---

## 📱 Android App Files

### New Screens Created:

1. ✅ **`AdminManageRequests.kt`**
   - Lists all pending requests
   - Filter by type (All, NGO, Volunteer, Donor)
   - Click to view details

2. ✅ **`AdminRequestDetails.kt`**
   - Shows full request details
   - Action buttons: Verify, Accept, Reject
   - Reject dialog with reason input

### Updated Files:

1. ✅ **`AdminDashboard.kt`**
   - Added navigation to "Manage Requests" screen

2. ✅ **`Routes.kt`**
   - Added `ADMIN_MANAGE_REQUESTS`
   - Added `ADMIN_REQUEST_DETAILS`

3. ✅ **`AppNavigation.kt`**
   - Added navigation routes for new screens

---

## 🚀 Setup Steps

### 1. Database Setup
```sql
-- Run in phpMyAdmin
-- File: admin_approval_workflow_setup.sql
```

### 2. Copy PHP Files
Copy these files to `C:\xampp\htdocs\helphup\api\`:
- ✅ `admin_get_pending_requests.php`
- ✅ `admin_verify_request.php`
- ✅ `admin_accept_request.php`
- ✅ `admin_reject_request.php`

### 3. Verify Updated PHP Files
Make sure these files are updated (they should already be):
- ✅ `ngo_raise_help.php`
- ✅ `volunteer_raise_help.php`
- ✅ `Donor_raise_help.php`

### 4. Test the Flow

1. **Submit a request** (as NGO/Volunteer/Donor)
   - Should see: "Request submitted successfully. It will be reviewed by admin..."

2. **Login as Admin**
   - Go to Dashboard → "Manage Requests"
   - Should see the pending request

3. **Review Request**
   - Click on request to view details
   - Click "Verify" (optional)
   - Click "Accept" or "Reject"
   - If reject, provide reason

4. **Check Visibility**
   - Accepted requests should be visible to other users
   - Rejected requests should NOT be visible

---

## 📋 Admin Status Values

- **`pending`** - New request, waiting for admin review
- **`verified`** - Admin has verified (optional step)
- **`accepted`** - Approved, visible to users
- **`rejected`** - Rejected, not visible to users

---

## 🔍 Verification Queries

### Count Pending Requests
```sql
SELECT 'NGO' as type, COUNT(*) as pending 
FROM ngo_help_requests 
WHERE admin_status = 'pending'
UNION ALL
SELECT 'Volunteer' as type, COUNT(*) as pending 
FROM volunteer_requests 
WHERE admin_status = 'pending'
UNION ALL
SELECT 'Donor' as type, COUNT(*) as pending 
FROM donor_campaigns 
WHERE admin_status = 'pending';
```

### View All Pending Requests
```sql
SELECT 'ngo' as type, request_id, request_title, created_at 
FROM ngo_help_requests 
WHERE admin_status = 'pending'
UNION ALL
SELECT 'volunteer' as type, request_id, request_title, created_at 
FROM volunteer_requests 
WHERE admin_status = 'pending'
UNION ALL
SELECT 'donor' as type, campaign_id, campaign_title, created_at 
FROM donor_campaigns 
WHERE admin_status = 'pending'
ORDER BY created_at DESC;
```

---

## ✅ Features

1. ✅ **Automatic Pending Status** - All new requests start as 'pending'
2. ✅ **Admin Review Interface** - Easy-to-use admin panel
3. ✅ **Filter by Type** - Filter requests by role
4. ✅ **Detailed View** - See all request information
5. ✅ **Action Buttons** - Verify, Accept, Reject
6. ✅ **Rejection Reason** - Required when rejecting
7. ✅ **Visibility Control** - Only accepted requests are visible
8. ✅ **Audit Trail** - Tracks who reviewed and when

---

## 🎯 Next Steps (Optional Enhancements)

1. **Email Notifications**
   - Notify admin when new request is submitted
   - Notify user when request is accepted/rejected

2. **Bulk Actions**
   - Accept/reject multiple requests at once

3. **Request History**
   - View all requests (not just pending)
   - Filter by status

4. **Statistics Dashboard**
   - Count of pending/accepted/rejected requests
   - Charts and graphs

---

## 📝 Notes

- All existing requests are set to 'pending' status
- Only requests with `admin_status = 'accepted'` are visible to users
- Rejected requests are stored but not displayed
- Admin can verify before accepting (optional step)

---

## 🔗 Related Files

**SQL:**
- `admin_approval_workflow_setup.sql`

**PHP:**
- `admin_get_pending_requests.php`
- `admin_verify_request.php`
- `admin_accept_request.php`
- `admin_reject_request.php`
- `ngo_raise_help.php` (updated)
- `volunteer_raise_help.php` (updated)
- `Donor_raise_help.php` (updated)

**Android:**
- `AdminManageRequests.kt`
- `AdminRequestDetails.kt`
- `AdminDashboard.kt` (updated)
- `Routes.kt` (updated)
- `AppNavigation.kt` (updated)

