# Admin Database Setup Guide

This guide will help you set up the database tables for Admin registration and password reset functionality.

## 📋 Tables Required

1. **`admin`** - Stores admin user accounts (for registration and login)
2. **`admin_password_reset_tokens`** - Stores OTP tokens for password reset (for forgot password)

## 🚀 Quick Setup

### Option 1: Complete Setup (Recommended)
Run the complete setup file that creates both tables:

```sql
-- File: admin_complete_setup.sql
```

**Steps:**
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `helphup` database from left sidebar
3. Click on "SQL" tab
4. Copy and paste the entire content from `admin_complete_setup.sql`
5. Click "Go" button

### Option 2: Separate Setup
If you already have the `admin` table, you can just create the password reset table:

```sql
-- File: create_admin_password_reset_table.sql
```

## 📊 Table Structures

### 1. `admin` Table
Stores admin user accounts for registration and login.

**Fields:**
- `admin_id` - Primary key, auto-increment
- `full_name` - Admin's full name (VARCHAR 100)
- `email` - Admin's email (VARCHAR 100, UNIQUE)
- `password` - Hashed password (VARCHAR 255)
- `created_at` - Account creation timestamp
- `updated_at` - Last update timestamp

**SQL:**
```sql
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `unique_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 2. `admin_password_reset_tokens` Table
Stores OTP tokens for password reset functionality.

**Fields:**
- `id` - Primary key, auto-increment
- `email` - Admin's email address
- `otp` - 6-digit OTP code (VARCHAR 6)
- `expires_at` - OTP expiration timestamp
- `used` - Whether OTP has been used (0 = not used, 1 = used)
- `created_at` - Token creation timestamp

**Indexes:**
- `idx_email` - For quick email lookups
- `idx_email_otp` - For quick email+OTP verification
- `idx_expires_at` - For cleanup of expired tokens

**SQL:**
```sql
CREATE TABLE IF NOT EXISTS `admin_password_reset_tokens` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL,
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_email` (`email`),
  INDEX `idx_email_otp` (`email`, `otp`),
  INDEX `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## ✅ Verification

After running the SQL, verify the tables were created:

```sql
-- Check admin table
SHOW TABLES LIKE 'admin';

-- Check admin_password_reset_tokens table
SHOW TABLES LIKE 'admin_password_reset_tokens';

-- View table structure
DESCRIBE admin;
DESCRIBE admin_password_reset_tokens;
```

## 🔧 Maintenance

### Clean Expired OTPs
To clean up expired OTP tokens (run periodically):

```sql
DELETE FROM admin_password_reset_tokens 
WHERE expires_at < NOW() OR used = 1;
```

### Fix Expired OTPs
If you have OTP records with incorrect expiration times, run:

```sql
-- File: fix_expired_otps.sql (updated to include admin)
```

This will fix any OTP records where `expires_at` is before `created_at`.

## 📝 Notes

- The `admin` table structure matches the registration requirements (full_name, email, password)
- The `admin_password_reset_tokens` table follows the same pattern as other roles (ngo, donor, volunteer)
- OTP tokens expire after 15 minutes (as set in PHP backend)
- Used OTPs are marked with `used = 1` to prevent reuse

## 🔗 Related Files

- `admin_complete_setup.sql` - Complete setup (both tables)
- `create_admin_password_reset_table.sql` - Password reset table only
- `create_admin_table.sql` - Admin table only (if needed separately)
- `fix_expired_otps.sql` - Fix expired OTP records (includes admin)

