# ✅ Admin Database & Backend Setup Complete

All database tables and PHP backend files for Admin registration and password reset have been created.

## 📊 Database Tables Created

### 1. **`admin` Table** (for registration and login)
**File:** `admin_complete_setup.sql` or `create_admin_table.sql`

**Structure:**
- `admin_id` - Primary key (INT, AUTO_INCREMENT)
- `full_name` - Admin's full name (VARCHAR 100)
- `email` - Admin's email (VARCHAR 100, UNIQUE)
- `password` - Hashed password (VARCHAR 255)
- `created_at` - Account creation timestamp
- `updated_at` - Last update timestamp

### 2. **`admin_password_reset_tokens` Table** (for forgot password with OTP)
**File:** `admin_complete_setup.sql` or `create_admin_password_reset_table.sql`

**Structure:**
- `id` - Primary key (INT, AUTO_INCREMENT)
- `email` - Admin's email (VARCHAR 100)
- `otp` - 6-digit OTP code (VARCHAR 6)
- `expires_at` - OTP expiration timestamp (15 minutes from creation)
- `used` - Whether OTP has been used (TINYINT, 0 = not used, 1 = used)
- `created_at` - Token creation timestamp

**Indexes:**
- `idx_email` - For quick email lookups
- `idx_email_otp` - For quick email+OTP verification
- `idx_expires_at` - For cleanup of expired tokens

## 🚀 Setup Instructions

### Step 1: Create Database Tables

**Option A: Complete Setup (Recommended)**
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `helphup` database
3. Click "SQL" tab
4. Copy and paste content from `admin_complete_setup.sql`
5. Click "Go"

**Option B: Separate Setup**
- If `admin` table already exists, just run `create_admin_password_reset_table.sql`

### Step 2: Copy PHP Files to XAMPP

Copy these files from `xampp_files/` to `C:\xampp\htdocs\helphup\api\`:

1. ✅ `admin_register.php` - Admin registration endpoint
2. ✅ `admin_forgot.php` - Send OTP for password reset
3. ✅ `admin_verify_otp.php` - Verify OTP code
4. ✅ `admin_reset_password.php` - Reset password with new password

**Note:** `admin_login.php` already exists.

## 📝 PHP Files Created

### 1. `admin_register.php`
- **Endpoint:** `POST /helphup/api/admin_register.php`
- **Request:** `{ "full_name": "...", "email": "...", "password": "..." }`
- **Response:** `{ "status": true/false, "message": "..." }`
- **Functionality:**
  - Validates required fields
  - Checks if email already exists
  - Hashes password using `password_hash()`
  - Inserts new admin record

### 2. `admin_forgot.php`
- **Endpoint:** `POST /helphup/api/admin_forgot.php`
- **Request:** `{ "email": "..." }`
- **Response:** `{ "status": true/false, "message": "..." }`
- **Functionality:**
  - Validates email exists in admin table
  - Generates 6-digit OTP
  - Saves OTP to `admin_password_reset_tokens` table
  - Sets expiration to 15 minutes from creation
  - Sends OTP via email (if email_config.php is configured)
  - Deletes old tokens for the email before creating new one

### 3. `admin_verify_otp.php`
- **Endpoint:** `POST /helphup/api/admin_verify_otp.php`
- **Request:** `{ "email": "...", "otp": "123456" }`
- **Response:** `{ "status": true/false, "message": "..." }`
- **Functionality:**
  - Validates email and OTP are provided
  - Normalizes OTP to 6 digits
  - Checks OTP exists, not expired, and not used
  - Uses database time for expiration check (avoids timezone issues)
  - Returns detailed error messages if OTP is invalid/expired/used

### 4. `admin_reset_password.php`
- **Endpoint:** `POST /helphup/api/admin_reset_password.php`
- **Request:** `{ "email": "...", "otp": "123456", "new_password": "..." }`
- **Response:** `{ "status": true/false, "message": "..." }`
- **Functionality:**
  - Validates all required fields
  - Validates password length (minimum 6 characters)
  - Verifies OTP is valid and not expired/used
  - Hashes new password
  - Updates password in admin table
  - Marks OTP as used (doesn't delete, for audit trail)

## ✅ Verification

### Check Tables Exist
```sql
SHOW TABLES LIKE 'admin';
SHOW TABLES LIKE 'admin_password_reset_tokens';
```

### Check Table Structure
```sql
DESCRIBE admin;
DESCRIBE admin_password_reset_tokens;
```

### Test Registration
```bash
POST http://localhost/helphup/api/admin_register.php
Body: {
  "full_name": "Admin User",
  "email": "admin@example.com",
  "password": "password123"
}
```

### Test Forgot Password Flow
1. Request OTP: `POST /admin_forgot.php` with email
2. Verify OTP: `POST /admin_verify_otp.php` with email and OTP
3. Reset Password: `POST /admin_reset_password.php` with email, OTP, and new_password

## 🔧 Maintenance

### Clean Expired OTPs
```sql
DELETE FROM admin_password_reset_tokens 
WHERE expires_at < NOW() OR used = 1;
```

### Fix Expired OTPs (if needed)
Run `fix_expired_otps.sql` (updated to include admin)

## 📋 Files Summary

### SQL Files:
- ✅ `admin_complete_setup.sql` - Complete setup (both tables)
- ✅ `create_admin_password_reset_table.sql` - Password reset table only
- ✅ `create_admin_table.sql` - Admin table only (if needed)
- ✅ `fix_expired_otps.sql` - Updated to include admin

### PHP Files:
- ✅ `admin_register.php` - Registration endpoint
- ✅ `admin_forgot.php` - Forgot password (send OTP)
- ✅ `admin_verify_otp.php` - Verify OTP
- ✅ `admin_reset_password.php` - Reset password
- ✅ `admin_login.php` - Already exists

### Documentation:
- ✅ `ADMIN_DATABASE_SETUP.md` - Detailed setup guide
- ✅ `ADMIN_SETUP_COMPLETE.md` - This file

## 🎯 Next Steps

1. ✅ Run `admin_complete_setup.sql` in phpMyAdmin
2. ✅ Copy all PHP files to `C:\xampp\htdocs\helphup\api\`
3. ✅ Test registration flow in Android app
4. ✅ Test forgot password flow in Android app
5. ✅ Configure SMTP in `email_config.php` for email sending (optional)

## 🔗 Related Files

All admin files follow the same pattern as:
- NGO files: `ngo_register.php`, `ngoforgot.php`, `ngo_verify_otp.php`, `ngo_reset_password.php`
- Donor files: `donor_register.php`, `donor_forgot.php`, `donor_verify_otp.php`, `donor_reset_password.php`
- Volunteer files: `volunteer_register.php`, `volunteer_forgot.php`, `volunteer_verify_otp.php`, `volunteer_reset_password.php`

