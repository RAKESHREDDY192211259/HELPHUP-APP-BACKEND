-- Check current OTP status for your email
-- Replace the email below with your actual email

SET @your_email = 'rakeshreddyk1259.sse@saveetha.com';

SELECT 
    'Current Status' as info,
    id,
    email,
    otp,
    created_at,
    expires_at,
    used,
    TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds,
    TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry,
    CASE 
        WHEN expires_at < created_at THEN '❌ INVALID - expires before created'
        WHEN TIMESTAMPDIFF(SECOND, NOW(), expires_at) > 0 AND used = 0 THEN '✅ VALID - can verify'
        WHEN used = 1 THEN '❌ USED - already verified'
        WHEN TIMESTAMPDIFF(SECOND, NOW(), expires_at) <= 0 THEN '❌ EXPIRED - too old'
        ELSE '❓ UNKNOWN'
    END as status
FROM ngo_password_reset_tokens
WHERE email = @your_email
ORDER BY created_at DESC
LIMIT 3;

