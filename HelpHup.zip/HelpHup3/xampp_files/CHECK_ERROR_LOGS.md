# How to Check Error Logs

## Location of Error Logs

1. **Apache Error Log:**
   - Path: `C:\xampp\apache\logs\error.log`
   - This will show PHP errors and warnings

2. **PHP Error Log:**
   - Check XAMPP Control Panel for PHP error log location
   - Usually: `C:\xampp\php\logs\php_error_log`

## What to Look For

After resetting password, check the logs for:
- "Volunteer password update - Table: ..., Email: ..., Affected rows: ..."
- "Volunteer password reset verified successfully" OR "Volunteer password update verification failed"

If "Affected rows: 0", the UPDATE didn't match any rows (case sensitivity issue).
If verification fails, the password hash wasn't saved correctly.

## Test Scripts

1. Test password update directly:
   ```
   http://10.22.186.166/helphup/api/test_password_update_direct.php?email=rakeshreddyk1259.sse@saveetha.com&password=NewPass123
   ```

2. Diagnose password reset:
   ```
   http://10.22.186.166/helphup/api/diagnose_password_reset.php?email=rakeshreddyk1259.sse@saveetha.com
   ```

