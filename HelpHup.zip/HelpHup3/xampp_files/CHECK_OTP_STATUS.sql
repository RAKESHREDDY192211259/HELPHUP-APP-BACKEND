-- Run this to check OTP status for a specific email
-- Replace 'your-email@example.com' with the actual email

SET @email = 'rakeshreddyk1259.sse@saveetha.com';

SELECT 
    'ngo_password_reset_tokens' as table_name,
    id,
    email,
    otp,
    created_at,
    expires_at,
    used,
    TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds,
    TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry,
    CASE 
        WHEN TIMESTAMPDIFF(SECOND, NOW(), expires_at) > 0 AND used = 0 THEN 'VALID'
        WHEN used = 1 THEN 'USED'
        WHEN TIMESTAMPDIFF(SECOND, NOW(), expires_at) <= 0 THEN 'EXPIRED'
        ELSE 'INVALID'
    END as status
FROM ngo_password_reset_tokens
WHERE email = @email
ORDER BY created_at DESC;

