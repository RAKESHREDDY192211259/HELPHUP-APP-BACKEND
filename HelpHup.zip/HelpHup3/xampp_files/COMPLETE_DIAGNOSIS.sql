-- Complete Diagnosis Script
-- Run this in phpMyAdmin to check the current state

-- 1. Check NGO table - show all records with status
SELECT 
    id,
    email,
    otp,
    created_at,
    expires_at,
    used,
    TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds,
    TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry,
    CASE 
        WHEN expires_at < created_at THEN '❌ INVALID (expires before created)'
        WHEN TIMESTAMPDIFF(SECOND, NOW(), expires_at) > 0 AND used = 0 THEN '✅ VALID'
        WHEN used = 1 THEN '❌ USED'
        WHEN TIMESTAMPDIFF(SECOND, NOW(), expires_at) <= 0 THEN '❌ EXPIRED'
        ELSE '❓ UNKNOWN'
    END as status,
    LENGTH(otp) as otp_length
FROM ngo_password_reset_tokens
ORDER BY created_at DESC
LIMIT 10;

-- 2. Fix any invalid records (run this if needed)
UPDATE ngo_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE expires_at < created_at OR expires_at IS NULL;

UPDATE donor_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE expires_at < created_at OR expires_at IS NULL;

UPDATE volunteer_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE expires_at < created_at OR expires_at IS NULL;

-- 3. Check specific email (replace with your email)
SET @test_email = 'rakeshreddyk1259.sse@saveetha.com';

SELECT 
    id,
    email,
    otp,
    created_at,
    expires_at,
    used,
    TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds,
    TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry,
    CASE 
        WHEN expires_at < created_at THEN '❌ INVALID (expires before created)'
        WHEN TIMESTAMPDIFF(SECOND, NOW(), expires_at) > 0 AND used = 0 THEN '✅ VALID'
        WHEN used = 1 THEN '❌ USED'
        WHEN TIMESTAMPDIFF(SECOND, NOW(), expires_at) <= 0 THEN '❌ EXPIRED'
        ELSE '❓ UNKNOWN'
    END as status
FROM ngo_password_reset_tokens
WHERE email = @test_email
ORDER BY created_at DESC;

