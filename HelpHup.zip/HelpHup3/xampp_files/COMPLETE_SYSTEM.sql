-- ============================================
-- COMPLETE HELP REQUEST & PAYMENT SYSTEM
-- ============================================
-- Single SQL file to create all necessary tables

-- Use the helphup_db database
USE helphup_db;

-- Check for existing tables
SELECT 'Checking for existing tables...' AS status_message;

-- Drop existing tables if they exist (for clean deployment)
SET FOREIGN_KEY_CHECKS = 0;

-- Drop tables in correct order to avoid foreign key issues
DROP TABLE IF EXISTS `payment_refunds`;
DROP TABLE IF EXISTS `admin_notifications`;
DROP TABLE IF EXISTS `help_interactions`;
DROP TABLE IF EXISTS `payment_method_details`;
DROP TABLE IF EXISTS `payment_transactions`;
DROP TABLE IF EXISTS `user_profiles`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `request_status_history`;
DROP TABLE IF EXISTS `unified_help_requests`;

-- Enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Use the helphup_db database
USE helphup_db;

-- ============================================
-- CORE HELP REQUEST SYSTEM
-- ============================================

-- Unified Help Requests Table (Main table for all help requests)
CREATE TABLE IF NOT EXISTS `unified_help_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `requester_type` ENUM('ngo', 'volunteer', 'donor') NOT NULL,
  `requester_name` VARCHAR(200) NOT NULL,
  `requester_email` VARCHAR(100) NOT NULL,
  `requester_phone` VARCHAR(20) DEFAULT NULL,
  
  -- Request Details (Common fields)
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `description` TEXT NOT NULL,
  `urgency_level` ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL,
  
  -- Type-specific fields
  -- For NGO requests
  `required_amount` DECIMAL(10,2) DEFAULT NULL,
  `date_needed` DATE DEFAULT NULL,
  `contact_number` VARCHAR(20) DEFAULT NULL,
  
  -- For Volunteer requests
  `location` VARCHAR(200) DEFAULT NULL,
  `help_date` DATE DEFAULT NULL,
  `start_time` TIME DEFAULT NULL,
  `volunteers_needed` INT(11) DEFAULT NULL,
  
  -- For Donor campaigns
  `fundraising_goal` DECIMAL(10,2) DEFAULT NULL,
  `duration` VARCHAR(50) DEFAULT NULL,
  `end_date` DATE DEFAULT NULL,
  `beneficiary_name` VARCHAR(100) DEFAULT NULL,
  `relationship` VARCHAR(50) DEFAULT NULL,
  `contact_email` VARCHAR(100) DEFAULT NULL,
  
  -- Status and timestamps
  `status` ENUM('pending', 'approved', 'rejected', 'completed') NOT NULL DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_notes` TEXT DEFAULT NULL,
  `completed_at` TIMESTAMP NULL,
  
  PRIMARY KEY (`request_id`),
  KEY `idx_requester` (`requester_id`),
  KEY `idx_status` (`status`),
  KEY `idx_category` (`category`),
  KEY `idx_created` (`created_at`),
  KEY `idx_urgency` (`urgency_level`)
);

-- Request Status History Table
CREATE TABLE IF NOT EXISTS `request_status_history` (
  `history_id` INT(11) NOT NULL AUTO_INCREMENT,
  `request_id` INT(11) NOT NULL,
  `status_from` ENUM('pending', 'approved', 'rejected', 'completed') NOT NULL,
  `status_to` ENUM('pending', 'approved', 'rejected', 'completed') NOT NULL,
  `changed_by` INT(11) DEFAULT NULL, -- Admin ID who changed status
  `change_reason` VARCHAR(500) DEFAULT NULL,
  `admin_notes` TEXT DEFAULT NULL,
  `changed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`history_id`),
  KEY `idx_request` (`request_id`),
  KEY `idx_changed_by` (`changed_by`),
  KEY `idx_changed_at` (`changed_at`),
  
  FOREIGN KEY (`request_id`) REFERENCES `unified_help_requests`(`request_id`) ON DELETE CASCADE,
  FOREIGN KEY (`changed_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL
);

-- Help Interactions Table (Who helped whom)
CREATE TABLE IF NOT EXISTS `help_interactions` (
  `interaction_id` INT(11) NOT NULL AUTO_INCREMENT,
  `request_id` INT(11) NOT NULL,
  `helper_id` INT(11) NOT NULL, -- User who provided help
  `receiver_id` INT(11) NOT NULL, -- User who received help
  `interaction_type` ENUM('help', 'volunteer', 'donate') NOT NULL DEFAULT 'help',
  `interaction_status` ENUM('pending', 'completed', 'cancelled', 'refunded') NOT NULL DEFAULT 'pending',
  `interaction_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `notes` TEXT DEFAULT NULL,
  
  -- Payment information (added when payment is made)
  `payment_id` INT(11) DEFAULT NULL,
  `payment_amount` DECIMAL(10,2) DEFAULT NULL,
  `payment_method` VARCHAR(20) DEFAULT NULL,
  `payment_status` ENUM('pending', 'completed', 'failed') DEFAULT NULL,
  `payment_date` TIMESTAMP DEFAULT NULL,
  
  PRIMARY KEY (`interaction_id`),
  KEY `idx_request` (`request_id`),
  KEY `idx_helper` (`helper_id`),
  KEY `idx_receiver` (`receiver_id`),
  KEY `idx_interaction_date` (`interaction_date`),
  
  FOREIGN KEY (`request_id`) REFERENCES `unified_help_requests`(`request_id`) ON DELETE CASCADE,
  FOREIGN KEY (`helper_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiver_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
);

-- ============================================
-- USER MANAGEMENT SYSTEM
-- ============================================

-- Users Table (Enhanced for payment and help tracking)
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_type` ENUM('ngo', 'volunteer', 'donor', 'admin') NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(20) DEFAULT NULL,
  `password` VARCHAR(255) NOT NULL,
  `is_verified` BOOLEAN DEFAULT FALSE,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_login` TIMESTAMP DEFAULT NULL,
  
  -- Help and Payment Statistics
  `total_help_given` DECIMAL(10,2) DEFAULT 0.00,
  `total_help_received` DECIMAL(10,2) DEFAULT 0.00,
  `total_amount_given` DECIMAL(10,2) DEFAULT 0.00,
  `total_amount_received` DECIMAL(10,2) DEFAULT 0.00,
  `total_payments_made` INT(11) DEFAULT 0,
  `last_help_given_date` TIMESTAMP DEFAULT NULL,
  `last_help_received_date` TIMESTAMP DEFAULT NULL,
  `last_payment_date` TIMESTAMP DEFAULT NULL,
  `last_amount_given_date` TIMESTAMP DEFAULT NULL,
  `last_payment_date` TIMESTAMP DEFAULT NULL,
  
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_user_type` (`user_type`),
  KEY `idx_active` (`is_active`)
);

-- User Profiles Table (Additional user information)
CREATE TABLE IF NOT EXISTS `user_profiles` (
  `profile_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `profile_type` ENUM('ngo', 'volunteer', 'donor') NOT NULL,
  
  -- NGO specific fields
  `organization_name` VARCHAR(200) DEFAULT NULL,
  `registration_number` VARCHAR(50) DEFAULT NULL,
  `ngo_type` VARCHAR(100) DEFAULT NULL,
  `website` VARCHAR(200) DEFAULT NULL,
  
  -- Volunteer specific fields
  `skills` TEXT DEFAULT NULL,
  `availability` VARCHAR(200) DEFAULT NULL,
  `preferences` TEXT DEFAULT NULL,
  
  -- Donor specific fields
  `donation_preferences` TEXT DEFAULT NULL,
  `tax_id` VARCHAR(50) DEFAULT NULL,
  
  -- Common fields
  `bio` TEXT DEFAULT NULL,
  `location` VARCHAR(200) DEFAULT NULL,
  `social_links` JSON DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`profile_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_profile_type` (`profile_type`),
  
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
);

-- ============================================
-- PAYMENT SYSTEM
-- ============================================

-- Payment Transactions Table (Main payment tracking)
CREATE TABLE IF NOT EXISTS `payment_transactions` (
  `payment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` VARCHAR(100) NOT NULL UNIQUE,
  `payer_id` INT(11) NOT NULL,
  `payer_type` ENUM('ngo', 'volunteer', 'donor') NOT NULL,
  `payer_name` VARCHAR(200) NOT NULL,
  `payer_email` VARCHAR(100) NOT NULL,
  `payer_phone` VARCHAR(20) DEFAULT NULL,
  `request_id` INT(11) NOT NULL,
  `request_type` ENUM('ngo', 'volunteer', 'donor') NOT NULL,
  `payment_method` ENUM('upi', 'card', 'netbanking', 'wallet', 'other') NOT NULL,
  `payment_method_details` JSON DEFAULT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `currency` VARCHAR(3) DEFAULT 'INR',
  `status` ENUM('pending', 'processing', 'completed', 'failed', 'refunded') NOT NULL DEFAULT 'pending',
  `gateway_response` JSON DEFAULT NULL,
  `failure_reason` VARCHAR(500) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` TIMESTAMP NULL,
  `refunded_at` TIMESTAMP NULL,
  
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_payer` (`payer_id`),
  KEY `idx_request` (`request_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`),
  KEY `idx_completed` (`completed_at`),
  
  FOREIGN KEY (`payer_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`request_id`) REFERENCES `unified_help_requests`(`request_id`) ON DELETE CASCADE
);

-- Payment Method Details Table (Secure storage of payment method info)
CREATE TABLE IF NOT EXISTS `payment_method_details` (
  `detail_id` INT(11) NOT NULL AUTO_INCREMENT,
  `payment_id` INT(11) NOT NULL,
  `payment_method` ENUM('upi', 'card', 'netbanking', 'wallet') NOT NULL,
  `field_name` VARCHAR(50) NOT NULL,
  `field_value` VARCHAR(500) DEFAULT NULL,
  `is_encrypted` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`detail_id`),
  KEY `idx_payment` (`payment_id`),
  KEY `idx_method` (`payment_method`),
  KEY `idx_field` (`field_name`),
  
  FOREIGN KEY (`payment_id`) REFERENCES `payment_transactions`(`payment_id`) ON DELETE CASCADE
);

-- Payment Refunds Table (Track refunds and disputes)
CREATE TABLE IF NOT EXISTS `payment_refunds` (
  `refund_id` INT(11) NOT NULL AUTO_INCREMENT,
  `payment_id` INT(11) NOT NULL,
  `refund_amount` DECIMAL(10,2) NOT NULL,
  `refund_reason` VARCHAR(500) NOT NULL,
  `refund_status` ENUM('pending', 'processed', 'completed') NOT NULL DEFAULT 'pending',
  `processed_by` INT(11) DEFAULT NULL, -- Admin ID
  `refund_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `notes` TEXT DEFAULT NULL,
  
  PRIMARY KEY (`refund_id`),
  KEY `idx_payment` (`payment_id`),
  KEY `idx_status` (`refund_status`),
  KEY `idx_date` (`refund_date`),
  
  FOREIGN KEY (`payment_id`) REFERENCES `payment_transactions`(`payment_id`) ON DELETE CASCADE,
  FOREIGN KEY (`processed_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL
);

-- ============================================
-- ADMIN NOTIFICATIONS
-- ============================================

-- Admin Notifications Table (Track all admin actions)
CREATE TABLE IF NOT EXISTS `admin_notifications` (
  `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
  `admin_id` INT(11) NOT NULL,
  `notification_type` ENUM('new_request', 'status_change', 'payment_completed', 'user_registered', 'system_alert') NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `related_id` INT(11) DEFAULT NULL, -- Request ID, User ID, Payment ID, etc.
  `related_type` VARCHAR(50) DEFAULT NULL, -- 'request', 'user', 'payment', etc.
  `is_read` BOOLEAN DEFAULT FALSE,
  `priority` ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `read_at` TIMESTAMP DEFAULT NULL,
  
  PRIMARY KEY (`notification_id`),
  KEY `idx_admin` (`admin_id`),
  KEY `idx_type` (`notification_type`),
  KEY `idx_priority` (`priority`),
  KEY `idx_read` (`is_read`),
  KEY `idx_created` (`created_at`),
  
  FOREIGN KEY (`admin_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
);

-- ============================================
-- VIEWS FOR EASY ACCESS
-- ============================================

-- Admin Dashboard View
CREATE OR REPLACE VIEW `admin_dashboard_view` AS
SELECT 
    u.user_id,
    u.name as admin_name,
    u.email as admin_email,
    COUNT(CASE WHEN ur.request_id IS NOT NULL THEN 1 ELSE 0 END) as pending_requests,
    COUNT(CASE WHEN ur.request_id IS NOT NULL AND uhr.status = 'pending' THEN 1 ELSE 0 END) as pending_count,
    COUNT(CASE WHEN pt.payment_id IS NOT NULL THEN 1 ELSE 0 END) as total_payments,
    SUM(CASE WHEN pt.amount IS NOT NULL THEN pt.amount ELSE 0 END) as total_amount,
    MAX(pt.created_at) as last_payment_date
FROM users u
LEFT JOIN user_profiles urp ON u.user_id = urp.user_id AND urp.profile_type = 'admin'
LEFT JOIN unified_help_requests uhr ON uhr.requester_id = u.user_id AND uhr.status = 'pending'
LEFT JOIN payment_transactions pt ON pt.payer_id = u.user_id
WHERE u.user_type = 'admin'
GROUP BY u.user_id;

-- User Payment History View
CREATE OR REPLACE VIEW `user_payment_history_view` AS
SELECT 
    u.user_id,
    u.name as user_name,
    u.email as user_email,
    u.user_type,
    pt.payment_id,
    pt.transaction_id,
    uhr.request_id,
    uhr.request_title,
    uhr.request_type as request_type,
    uhr.requester_name as helped_person,
    pt.payment_method,
    pt.amount,
    pt.currency,
    pt.status,
    pt.created_at,
    pt.completed_at,
    CASE 
        WHEN pt.status = 'completed' THEN 'Payment Successful'
        WHEN pt.status = 'failed' THEN 'Payment Failed'
        WHEN pt.status = 'processing' THEN 'Processing'
        ELSE 'Pending'
    END as payment_status_text
FROM users u
JOIN payment_transactions pt ON pt.payer_id = u.user_id
JOIN unified_help_requests uhr ON pt.request_id = uhr.request_id
ORDER BY pt.created_at DESC;

-- Help Received History View
CREATE OR REPLACE VIEW `help_received_history_view` AS
SELECT 
    u.user_id,
    u.name as receiver_name,
    u.email as receiver_email,
    hi.interaction_id,
    uhr.request_id,
    uhr.request_title,
    uhr.request_type as request_type,
    uhr.requester_name as helper_name,
    hi.helper_id,
    helper.name as helper_name,
    helper.email as helper_email,
    hi.payment_id,
    hi.payment_amount,
    hi.payment_method,
    hi.payment_status,
    hi.interaction_date,
    CASE 
        WHEN hi.interaction_status = 'completed' THEN 'Help Received'
        WHEN hi.interaction_status = 'pending' THEN 'Help Pending'
        ELSE 'Unknown'
    END as help_status_text
FROM help_interactions hi
JOIN unified_help_requests uhr ON hi.request_id = uhr.request_id
JOIN users u ON hi.receiver_id = u.user_id
JOIN users helper ON hi.helper_id = helper.user_id
ORDER BY hi.interaction_date DESC;

-- Help Given History View
CREATE OR REPLACE VIEW `help_given_history_view` AS
SELECT 
    u.user_id,
    u.name as helper_name,
    u.email as helper_email,
    hi.interaction_id,
    uhr.request_id,
    uhr.request_title,
    uhr.request_type as request_type,
    uhr.requester_name as helped_person,
    hi.receiver_id,
    receiver.name as receiver_name,
    receiver.email as receiver_email,
    hi.payment_id,
    hi.payment_amount,
    hi.payment_method,
    hi.payment_status,
    hi.interaction_date,
    CASE 
        WHEN hi.interaction_status = 'completed' THEN 'Help Provided'
        WHEN hi.interaction_status = 'pending' THEN 'Help Pending'
        ELSE 'Unknown'
    END as help_status_text
FROM help_interactions hi
JOIN unified_help_requests uhr ON hi.request_id = uhr.request_id
JOIN users u ON hi.helper_id = u.user_id
JOIN users receiver ON hi.receiver_id = receiver.user_id
ORDER BY hi.interaction_date DESC;

-- ============================================
-- TRIGGERS FOR AUTOMATIC UPDATES
-- ============================================

-- Trigger: Update help_interactions when payment is completed
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `update_help_interaction_on_payment_completion`
AFTER UPDATE ON `payment_transactions`
FOR EACH ROW
BEGIN
    -- Only update if status changed to completed
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        
        -- Update help_interactions table
        UPDATE `help_interactions` 
        SET 
            `payment_id` = NEW.payment_id,
            `payment_amount` = NEW.amount,
            `payment_method` = NEW.payment_method,
            `payment_status` = 'completed',
            `payment_date` = NEW.completed_at,
            `interaction_status` = 'completed'
        WHERE `request_id` = NEW.request_id 
          AND `helper_id` = NEW.payer_id 
          AND `interaction_type` = 'help';
        
        -- Update receiver (user who got help) totals
        UPDATE `users` 
        SET 
            `total_help_received` = IFNULL(`total_help_received`, 0) + NEW.amount,
            `total_payments_made` = IFNULL(`total_payments_made`, 0) + 1,
            `last_help_received_date` = NEW.completed_at,
            `last_payment_date` = NEW.completed_at
        WHERE `user_id` = (SELECT requester_id FROM unified_help_requests WHERE request_id = NEW.request_id LIMIT 1);
        
        -- Update helper (user who gave help/payment) totals
        UPDATE `users` 
        SET 
            `total_help_given` = IFNULL(`total_help_given`, 0) + 1,
            `total_amount_given` = IFNULL(`total_amount_given`, 0) + NEW.amount,
            `last_help_given_date` = NEW.completed_at
        WHERE `user_id` = NEW.payer_id;
        
    END IF;
END//
DELIMITER ;

-- Trigger: Update request status when payment is completed
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `update_request_status_on_payment_completion`
AFTER UPDATE ON `payment_transactions`
FOR EACH ROW
BEGIN
    -- Only update if status changed to completed
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        
        -- Update unified_help_requests table
        UPDATE `unified_help_requests` 
        SET 
            `status` = 'completed',
            `completed_at` = NEW.completed_at
        WHERE `request_id` = NEW.request_id;
        
    END IF;
END//
DELIMITER ;

-- Trigger: Create admin notification when payment is completed
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `create_payment_notification`
AFTER UPDATE ON `payment_transactions`
FOR EACH ROW
BEGIN
    -- Only create notification if status changed to completed
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        
        -- Create admin notification
        INSERT INTO `admin_notifications` 
        (`admin_id`, `notification_type`, `title`, `message`, `related_id`, `related_type`, `priority`)
        SELECT 
            u.user_id, 
            'payment_completed',
            CONCAT('Payment Completed: ', UPPER(NEW.payment_method)),
            CONCAT('Payment of ₹', NEW.amount, ' completed for ', NEW.request_type, ' request #', NEW.request_id),
            NEW.payment_id,
            'payment',
            'high'
        FROM users u 
        WHERE u.user_type = 'admin' 
        LIMIT 1;
        
    END IF;
END//
DELIMITER ;

-- ============================================
-- SAMPLE DATA FOR TESTING
-- ============================================

-- Insert sample users (if not exists)
INSERT IGNORE INTO `users` 
(`user_type`, `name`, `email`, `password`, `is_verified`, `is_active`) 
VALUES 
('admin', 'Admin User', 'admin@helphup.com', 'admin123', TRUE, TRUE),
('ngo', 'Help Foundation', 'ngo@helphup.org', 'ngo123', TRUE, TRUE),
('volunteer', 'John Volunteer', 'volunteer@helphup.com', 'vol123', TRUE, TRUE),
('donor', 'Jane Donor', 'donor@helphup.com', 'donor123', TRUE, TRUE);

-- Insert sample help requests
INSERT IGNORE INTO `unified_help_requests` 
(`requester_type`, `requester_id`, `requester_name`, `requester_email`, `requester_phone`, `request_title`, `category`, `description`, `urgency_level`, `required_amount`, `date_needed`, `contact_number`, `location`, `help_date`, `start_time`, `volunteers_needed`, `fundraising_goal`, `duration`, `end_date`, `beneficiary_name`, `relationship`, `contact_email`, `status`) 
VALUES 
('ngo', 2, 'Help Foundation', 'ngo@helphup.org', '9876543210', 'Emergency Medical Supplies', 'Medical', 'URGENT: We need medical supplies including bandages, antiseptics, and basic medications for our flood relief camp.', 'Critical', 50000.00, '2024-01-15', '9876543210', 'City General Hospital', '2024-01-20', '09:00:00', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending'),
('volunteer', 3, 'John Volunteer', 'volunteer@helphup.com', '9876543211', 'Teaching Volunteers Required', 'Education', 'Looking for volunteers to teach basic subjects to underprivileged children. Weekend commitment preferred.', 'Medium', NULL, NULL, NULL, 'Community Learning Center', '2024-01-20', '10:00:00', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending'),
('donor', 4, 'Jane Donor', 'donor@helphup.com', '9876543212', 'Clean Water Campaign', 'Water', 'Fundraising for water purification systems in rural villages lacking clean drinking water access.', 'High', 100000.00, NULL, NULL, NULL, NULL, NULL, 30, '2024-02-15', 'Rural Village Areas', 'Water for Life Foundation', 'clean.water@example.com', 'pending');

-- Insert sample payment transaction
INSERT IGNORE INTO `payment_transactions` 
(`transaction_id`, `payer_id`, `payer_type`, `payer_name`, `payer_email`, `request_id`, `request_type`, `payment_method`, `amount`, `status`, `gateway_response`, `completed_at`) 
VALUES 
('TXN001', 3, 'volunteer', 'John Volunteer', 'volunteer@helphup.com', '9876543211', 2, 'volunteer', 'upi', 1000.00, 'completed', '{"status": "success", "transaction_id": "TXN001"}', NOW()),
('TXN002', 4, 'donor', 'Jane Donor', 'donor@helphup.com', '9876543212', 3, 'donor', 'card', 2500.00, 'completed', '{"status": "success", "auth_code": "AUTH123"}', NOW());

-- Insert sample help interactions
INSERT IGNORE INTO `help_interactions` 
(`request_id`, `helper_id`, `receiver_id`, `interaction_type`, `interaction_status`, `payment_id`, `payment_amount`, `payment_method`, `payment_status`, `payment_date`, `interaction_date`) 
VALUES 
(2, 3, 2, 'help', 'completed', 1, 1000.00, 'upi', 'completed', NOW(), NOW()),
(3, 4, 4, 'help', 'completed', 1, 2500.00, 'card', 'completed', NOW(), NOW());

-- Update user statistics
UPDATE `users` 
SET 
    `total_help_given` = 1,
    `total_amount_given` = 1000.00,
    `last_help_given_date` = NOW(),
    `total_help_received` = 1000.00,
    `total_payments_made` = 1,
    `last_help_received_date` = NOW(),
    `last_payment_date` = NOW()
WHERE `user_id` = 3;

UPDATE `users` 
SET 
    `total_help_given` = 1,
    `total_amount_given` = 2500.00,
    `last_help_given_date` = NOW(),
    `total_help_received` = 2500.00,
    `total_payments_made` = 1,
    `last_help_received_date` = NOW(),
    `last_payment_date` = NOW()
WHERE `user_id` = 4;

-- ============================================
-- SUCCESS MESSAGE
-- ============================================

-- All tables created successfully!
SELECT 'Complete Help Request & Payment System Created' AS success_message;
