# 📋 Step-by-Step Guide: Copy Admin PHP Files to XAMPP

## Files to Copy

Copy these 5 files from `xampp_files/` to `C:\xampp\htdocs\helphup\api\`:

1. ✅ `admin_register.php`
2. ✅ `admin_forgot.php`
3. ✅ `admin_verify_otp.php`
4. ✅ `admin_reset_password.php`
5. ✅ `admin_login.php` (if not already there)

---

## Method 1: Manual Copy (Windows File Explorer) ⭐ Easiest

### Step 1: Open Source Folder
1. Open File Explorer (Windows key + E)
2. Navigate to: `D:\Android\Projects\HelpHup3\xampp_files\`

### Step 2: Select Admin Files
1. In the `xampp_files` folder, select these files:
   - `admin_register.php`
   - `admin_forgot.php`
   - `admin_verify_otp.php`
   - `admin_reset_password.php`
   - `admin_login.php` (if updating)

   **Tip:** Hold `Ctrl` and click each file to select multiple files

### Step 3: Copy Files
1. Right-click on selected files
2. Click **"Copy"** (or press `Ctrl + C`)

### Step 4: Navigate to Destination
1. In File Explorer, navigate to: `C:\xampp\htdocs\helphup\api\`
   
   **If the folder doesn't exist:**
   - Navigate to `C:\xampp\htdocs\helphup\`
   - Create a new folder named `api` if it doesn't exist
   - Open the `api` folder

### Step 5: Paste Files
1. Right-click in the `api` folder
2. Click **"Paste"** (or press `Ctrl + V`)
3. If Windows asks to replace existing files, click **"Replace"** or **"Yes to All"**

### Step 6: Verify
1. Check that all 5 files are now in `C:\xampp\htdocs\helphup\api\`
2. You should see:
   - ✅ `admin_register.php`
   - ✅ `admin_forgot.php`
   - ✅ `admin_verify_otp.php`
   - ✅ `admin_reset_password.php`
   - ✅ `admin_login.php`

---

## Method 2: Using PowerShell Script (Automated) ⚡ Fastest

### Step 1: Open PowerShell as Administrator
1. Press `Windows key + X`
2. Select **"Windows PowerShell (Admin)"** or **"Terminal (Admin)"**
3. Click **"Yes"** if prompted by User Account Control

### Step 2: Navigate to Project Directory
```powershell
cd "D:\Android\Projects\HelpHup3"
```

### Step 3: Run the Copy Script
```powershell
.\xampp_files\copy_admin_files.ps1
```

**OR** run this command directly:
```powershell
$source = "D:\Android\Projects\HelpHup3\xampp_files"
$target = "C:\xampp\htdocs\helphup\api"
$files = @("admin_register.php", "admin_forgot.php", "admin_verify_otp.php", "admin_reset_password.php", "admin_login.php")

foreach ($file in $files) {
    $sourceFile = Join-Path $source $file
    $targetFile = Join-Path $target $file
    if (Test-Path $sourceFile) {
        Copy-Item -Path $sourceFile -Destination $targetFile -Force
        Write-Host "✓ Copied: $file" -ForegroundColor Green
    } else {
        Write-Host "✗ Not found: $file" -ForegroundColor Red
    }
}
Write-Host "`nDone! Files copied to: $target" -ForegroundColor Green
```

---

## Method 3: Using Command Prompt

### Step 1: Open Command Prompt as Administrator
1. Press `Windows key + R`
2. Type `cmd`
3. Press `Ctrl + Shift + Enter` (to run as admin)

### Step 2: Run Copy Commands
```cmd
cd /d "D:\Android\Projects\HelpHup3\xampp_files"
copy admin_register.php "C:\xampp\htdocs\helphup\api\"
copy admin_forgot.php "C:\xampp\htdocs\helphup\api\"
copy admin_verify_otp.php "C:\xampp\htdocs\helphup\api\"
copy admin_reset_password.php "C:\xampp\htdocs\helphup\api\"
copy admin_login.php "C:\xampp\htdocs\helphup\api\"
```

---

## Method 4: Using Batch File

### Step 1: Create Batch File
1. Create a new file named `copy_admin_files.bat` in the project root
2. Add this content:

```batch
@echo off
echo Copying Admin PHP files to XAMPP...
copy "xampp_files\admin_register.php" "C:\xampp\htdocs\helphup\api\" /Y
copy "xampp_files\admin_forgot.php" "C:\xampp\htdocs\helphup\api\" /Y
copy "xampp_files\admin_verify_otp.php" "C:\xampp\htdocs\helphup\api\" /Y
copy "xampp_files\admin_reset_password.php" "C:\xampp\htdocs\helphup\api\" /Y
copy "xampp_files\admin_login.php" "C:\xampp\htdocs\helphup\api\" /Y
echo.
echo Done! Files copied successfully.
pause
```

### Step 2: Run Batch File
1. Double-click `copy_admin_files.bat`
2. Files will be copied automatically

---

## ✅ Verification Steps

After copying, verify the files:

### Option 1: Check in File Explorer
1. Navigate to `C:\xampp\htdocs\helphup\api\`
2. Verify all 5 admin files are present

### Option 2: Check via Browser
Open these URLs in your browser (should show JSON responses or errors, not 404):

- `http://localhost/helphup/api/admin_register.php`
- `http://localhost/helphup/api/admin_forgot.php`
- `http://localhost/helphup/api/admin_verify_otp.php`
- `http://localhost/helphup/api/admin_reset_password.php`
- `http://localhost/helphup/api/admin_login.php`

**Expected:** Should see JSON error (like "Email is required") or connection error, but NOT "404 Not Found"

### Option 3: Check via PowerShell
```powershell
$target = "C:\xampp\htdocs\helphup\api"
$files = @("admin_register.php", "admin_forgot.php", "admin_verify_otp.php", "admin_reset_password.php", "admin_login.php")

Write-Host "Checking files in: $target" -ForegroundColor Cyan
foreach ($file in $files) {
    $filePath = Join-Path $target $file
    if (Test-Path $filePath) {
        Write-Host "✓ $file" -ForegroundColor Green
    } else {
        Write-Host "✗ $file (NOT FOUND)" -ForegroundColor Red
    }
}
```

---

## 🔧 Troubleshooting

### Problem: "Access Denied" Error
**Solution:** Run File Explorer, PowerShell, or Command Prompt as Administrator

### Problem: Folder `C:\xampp\htdocs\helphup\api\` doesn't exist
**Solution:** 
1. Navigate to `C:\xampp\htdocs\helphup\`
2. Create new folder named `api`
3. Then copy files

### Problem: Files copied but getting 404 errors
**Solution:**
1. Make sure XAMPP Apache is running
2. Check file permissions (files should be readable)
3. Verify the path is exactly: `C:\xampp\htdocs\helphup\api\`

### Problem: Files not updating
**Solution:**
1. Make sure you're copying to the correct location
2. Check if files are read-only (right-click → Properties → uncheck "Read-only")
3. Try deleting old files first, then copy new ones

---

## 📝 Quick Reference

**Source:** `D:\Android\Projects\HelpHup3\xampp_files\`  
**Destination:** `C:\xampp\htdocs\helphup\api\`  
**Files:** 5 admin PHP files

**Recommended Method:** Method 1 (Manual Copy) - Most reliable and easy to verify

