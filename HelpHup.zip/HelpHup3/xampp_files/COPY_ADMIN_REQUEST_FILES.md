# 📋 Copy Admin Request Management PHP Files

## ❌ Error: HTTP 404 Not Found

The error "Failed to load requests: HTTP 404 Not Found" means the PHP file `admin_get_pending_requests.php` is not found on the server.

## ✅ Solution: Copy PHP Files to XAMPP

### Files to Copy:

Copy these files from `xampp_files/` to `C:\xampp\htdocs\helphup\api\`:

1. ✅ `admin_get_pending_requests.php` - **REQUIRED** (this is the missing file causing 404)
2. ✅ `admin_verify_request.php`
3. ✅ `admin_accept_request.php`
4. ✅ `admin_reject_request.php`

### Quick Copy Steps:

1. **Open File Explorer**
2. **Navigate to:** `D:\Android\Projects\HelpHup3\xampp_files\`
3. **Select these 4 files:**
   - `admin_get_pending_requests.php`
   - `admin_verify_request.php`
   - `admin_accept_request.php`
   - `admin_reject_request.php`
4. **Copy** (Ctrl + C)
5. **Navigate to:** `C:\xampp\htdocs\helphup\api\`
6. **Paste** (Ctrl + V)

### Verify Files Exist:

After copying, check that these files exist in `C:\xampp\htdocs\helphup\api\`:
- ✅ `admin_get_pending_requests.php`
- ✅ `admin_verify_request.php`
- ✅ `admin_accept_request.php`
- ✅ `admin_reject_request.php`

### Test the Endpoint:

Open in browser:
```
http://localhost/helphup/api/admin_get_pending_requests.php?request_type=all
```

**Expected:** Should return JSON response (not 404 error)

---

## 🔍 Additional Checks

### 1. Check Database Tables

Make sure you've run the SQL setup:
- Run `admin_approval_complete_setup.sql` in phpMyAdmin
- This adds `admin_status` column to tables

### 2. Check NGO Request Submission

When NGO submits a request:
- Check database: `SELECT * FROM ngo_help_requests ORDER BY created_at DESC LIMIT 1;`
- Verify `admin_status` = 'pending'

### 3. Check API Base URL

In Android app, the base URL is:
```
http://10.22.186.166/helphup/api/
```

Make sure:
- XAMPP Apache is running
- Your computer IP is `10.22.186.166` (or update the IP in the app)
- Phone/emulator is on the same WiFi network

---

## 🚀 After Copying Files

1. **Restart XAMPP Apache** (if needed)
2. **Test in browser:** `http://localhost/helphup/api/admin_get_pending_requests.php?request_type=all`
3. **Open Admin app** → Manage Requests
4. **Should now load requests** (or show "No pending requests" if none exist)

---

## 📝 Quick PowerShell Copy Command

```powershell
Copy-Item "D:\Android\Projects\HelpHup3\xampp_files\admin_get_pending_requests.php" "C:\xampp\htdocs\helphup\api\" -Force
Copy-Item "D:\Android\Projects\HelpHup3\xampp_files\admin_verify_request.php" "C:\xampp\htdocs\helphup\api\" -Force
Copy-Item "D:\Android\Projects\HelpHup3\xampp_files\admin_accept_request.php" "C:\xampp\htdocs\helphup\api\" -Force
Copy-Item "D:\Android\Projects\HelpHup3\xampp_files\admin_reject_request.php" "C:\xampp\htdocs\helphup\api\" -Force
```

