-- ============================================
-- Create Parent Tables (ngo, volunteer, donor)
-- Run this FIRST before creating help request tables
-- Run this in phpMyAdmin SQL tab on 'helphup' database
-- ============================================

-- 1. CREATE NGO TABLE
CREATE TABLE IF NOT EXISTS `ngo` (
  `ngo_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `address` TEXT NOT NULL,
  `org_name` VARCHAR(200) NOT NULL,
  `reg_number` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `reg_proof_file` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ngo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. CREATE VOLUNTEER TABLE
CREATE TABLE IF NOT EXISTS `volunteer` (
  `volunteer_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `skills` TEXT DEFAULT NULL,
  `availability` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`volunteer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. CREATE DONOR TABLE
CREATE TABLE IF NOT EXISTS `donor` (
  `donor_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `address` TEXT NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`donor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Success message
-- ============================================
SELECT 'Parent tables (ngo, volunteer, donor) created successfully!' AS message;

