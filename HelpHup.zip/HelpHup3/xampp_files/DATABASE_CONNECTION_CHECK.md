# ✅ Database Connection Check

## 🔍 How to Test Database Connection

### Method 1: Quick Visual Test (Recommended)
Open in your browser:
```
http://localhost/helphup/api/quick_db_test.php
```

This will show:
- ✅ Database connection status
- ✅ All tables and their primary keys
- ✅ Required columns (email, password, full_name)
- ✅ Query test results
- ✅ Record counts

### Method 2: Detailed Text Test
Open in your browser:
```
http://localhost/helphup/api/test_database_connection.php
```

This shows detailed information in text format.

---

## 📋 What Gets Checked

### 1. **Configuration File**
- ✅ `config.php` exists
- ✅ Database credentials are correct

### 2. **Database Connection**
- ✅ Connection to MySQL server
- ✅ Database `helphup` exists
- ✅ Connection is active

### 3. **Required Tables**
Checks for:
- **Volunteer**: `volunteer` or `volunteers`
- **Donor**: `donor` or `donors`
- **NGO**: `ngo` or `ngos`
- **Admin**: `admin` or `admins`

### 4. **Table Structure**
For each table:
- ✅ Primary key column name (`id` or `volunteer_id`/`donor_id`/`ngo_id`)
- ✅ Required columns: `email`, `password`, `full_name`
- ✅ Record count

### 5. **Query Test**
Tests the actual login queries:
- ✅ Volunteer login query
- ✅ Donor login query

---

## 🔧 Current Configuration

From `config.php`:
```php
Host: localhost
Username: root
Password: (empty)
Database: helphup
```

---

## ✅ Expected Results

### If Everything Works:
- ✅ All tables found
- ✅ All required columns present
- ✅ Queries work correctly
- ✅ Connection is active

### Common Issues:

#### ❌ "Table not found"
**Solution:** Create the missing table using SQL scripts

#### ❌ "Column not found"
**Solution:** Add missing columns to the table

#### ❌ "Connection failed"
**Solution:**
1. Check XAMPP MySQL is running
2. Check database name is `helphup`
3. Check username/password in `config.php`

#### ❌ "Query failed"
**Solution:**
1. Check primary key column name matches
2. Check all required columns exist
3. Check table structure

---

## 🚀 Quick Fixes

### If Volunteer Table Missing:
```sql
CREATE TABLE IF NOT EXISTS `volunteer` (
  `volunteer_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`volunteer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### If Donor Table Missing:
```sql
CREATE TABLE IF NOT EXISTS `donor` (
  `donor_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`donor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## 📝 Next Steps

1. **Run the test**: `http://localhost/helphup/api/quick_db_test.php`
2. **Check results**: All items should show ✅
3. **Fix any issues**: Follow the solutions above
4. **Test login**: Try logging in from Android app

---

## 🎯 Summary

The test files will show you:
- ✅ Which tables exist
- ✅ Which columns are present
- ✅ What the primary key column names are
- ✅ If queries work correctly

**Run the test now to verify everything is working!** 🚀

