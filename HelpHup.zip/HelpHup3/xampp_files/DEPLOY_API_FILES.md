# Deploy API Files to Web Server

## Important: Copy API Files to Web Server Directory

The new API files (`get_all_ngo_requests.php`, `get_all_volunteer_requests.php`, `get_all_donor_campaigns.php`) need to be copied to your XAMPP web server directory.

### Steps:

1. **Locate your XAMPP htdocs directory:**
   - Usually located at: `C:\xampp\htdocs\helphup\api\`

2. **Copy the following files** from `xampp_files/` to `C:\xampp\htdocs\helphup\api\`:
   - `get_all_ngo_requests.php`
   - `get_all_volunteer_requests.php`
   - `get_all_donor_campaigns.php`

3. **Verify the files are accessible:**
   - Open browser and go to: `http://10.22.186.166/helphup/api/get_all_ngo_requests.php`
   - You should see JSON response (not a 404 error)

4. **Restart Apache** (if needed):
   - Open XAMPP Control Panel
   - Stop and Start Apache

### Quick Copy Command (Run in PowerShell as Administrator):

```powershell
Copy-Item "D:\Android\Projects\HelpHup3\xampp_files\get_all_ngo_requests.php" -Destination "C:\xampp\htdocs\helphup\api\get_all_ngo_requests.php"
Copy-Item "D:\Android\Projects\HelpHup3\xampp_files\get_all_volunteer_requests.php" -Destination "C:\xampp\htdocs\helphup\api\get_all_volunteer_requests.php"
Copy-Item "D:\Android\Projects\HelpHup3\xampp_files\get_all_donor_campaigns.php" -Destination "C:\xampp\htdocs\helphup\api\get_all_donor_campaigns.php"
```

**Note:** Adjust the source path if your project is in a different location.

