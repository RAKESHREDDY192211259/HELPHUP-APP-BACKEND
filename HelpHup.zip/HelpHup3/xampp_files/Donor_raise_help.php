<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$donor_id = $data['donor_id'] ?? 0;
$campaign_title = $data['campaign_title'] ?? '';
$fundraising_goal = $data['fundraising_goal'] ?? '';
$category = $data['category'] ?? '';
$cover_image_url = $data['cover_image_url'] ?? null;
$video_url = $data['video_url'] ?? null;
$duration = $data['duration'] ?? '';
$end_date = $data['end_date'] ?? '';
$beneficiary_name = $data['beneficiary_name'] ?? '';
$relationship = $data['relationship'] ?? '';
$contact_email = $data['contact_email'] ?? '';

// Validate required fields
if (empty($donor_id) || empty($campaign_title) || empty($fundraising_goal) || 
    empty($category) || empty($duration) || empty($end_date) || 
    empty($beneficiary_name) || empty($relationship) || empty($contact_email)) {
    sendResponse(false, "All required fields must be filled");
}

// Check if admin_status column exists
$checkColumn = $conn->query("SHOW COLUMNS FROM donor_campaigns LIKE 'admin_status'");
$hasAdminStatus = $checkColumn && $checkColumn->num_rows > 0;

// Build INSERT query based on column existence
if ($hasAdminStatus) {
    // Column exists - include it in INSERT
    $stmt = $conn->prepare("INSERT INTO donor_campaigns (donor_id, campaign_title, fundraising_goal, category, cover_image_url, video_url, duration, end_date, beneficiary_name, relationship, contact_email, admin_status, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending')");
} else {
    // Column doesn't exist - insert without it (will need to run SQL script to add column)
    $stmt = $conn->prepare("INSERT INTO donor_campaigns (donor_id, campaign_title, fundraising_goal, category, cover_image_url, video_url, duration, end_date, beneficiary_name, relationship, contact_email, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
}

if (!$stmt) {
    sendResponse(false, "Failed to prepare query: " . $conn->error);
}

$stmt->bind_param("issssssssss", $donor_id, $campaign_title, $fundraising_goal, $category, $cover_image_url, $video_url, $duration, $end_date, $beneficiary_name, $relationship, $contact_email);

if ($stmt->execute()) {
    // If admin_status column doesn't exist, update it separately (if column was just added)
    if (!$hasAdminStatus) {
        // Try to add the column if it doesn't exist
        $conn->query("ALTER TABLE donor_campaigns ADD COLUMN admin_status VARCHAR(20) DEFAULT 'pending'");
        // Update the just-inserted record
        $lastId = $stmt->insert_id;
        $conn->query("UPDATE donor_campaigns SET admin_status = 'pending' WHERE campaign_id = $lastId");
    }
    sendResponse(true, "Campaign submitted successfully. It will be reviewed by admin before being published.");
} else {
    sendResponse(false, "Failed to create campaign: " . $stmt->error . " | " . $conn->error);
}

$stmt->close();
$conn->close();
?>

