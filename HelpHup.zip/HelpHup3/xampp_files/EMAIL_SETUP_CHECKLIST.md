# Email Setup Checklist - Quick Guide

## ✅ Step 1: Enable SMTP (REQUIRED)

1. Open: `C:\xampp\htdocs\helphup\api\email_config.php`
2. Change **line 12** from:
   ```php
   define('USE_PHP_MAIL', true);
   ```
   To:
   ```php
   define('USE_PHP_MAIL', false);  // Use SMTP instead of PHP mail()
   ```
3. **Save the file**

---

## ✅ Step 2: Configure Gmail SMTP Credentials

1. In the same file (`email_config.php`), update **lines 25-26**:

   ```php
   define('SMTP_USERNAME', 'your-actual-email@gmail.com');  // Your Gmail address
   define('SMTP_PASSWORD', 'your-16-char-app-password');    // Gmail App Password (see Step 3)
   ```

2. Also update **line 18**:
   ```php
   define('SMTP_FROM_EMAIL', 'your-actual-email@gmail.com'); // Same as SMTP_USERNAME
   ```

3. **Save the file**

---

## ✅ Step 3: Get Gmail App Password

1. Go to: https://myaccount.google.com/
2. Click **Security** (left sidebar)
3. Enable **2-Step Verification** (if not already enabled)
4. Scroll down and click **App passwords**
5. Select **Mail** and **Other (Custom name)**
6. Enter name: "HelpHup"
7. Click **Generate**
8. **Copy the 16-character password** (it will look like: `abcd efgh ijkl mnop`)
9. **Use this password** in `email_config.php` (remove spaces)

---

## ✅ Step 4: Verify PHPMailer Installation

1. Check if this folder exists:
   ```
   C:\xampp\htdocs\helphup\api\PHPMailer\src\Exception.php
   ```

2. If **NOT found**, download PHPMailer:
   - Download: https://github.com/PHPMailer/PHPMailer/archive/refs/heads/master.zip
   - Extract the ZIP file
   - Copy the `PHPMailer` folder to: `C:\xampp\htdocs\helphup\api\`

---

## ✅ Step 5: Restart Apache

1. Open **XAMPP Control Panel**
2. Click **Stop** next to Apache (wait for it to stop)
3. Click **Start** next to Apache (wait until it shows "Running" in green)

---

## ✅ Step 6: Test Email Sending

1. Open in browser: `http://localhost/helphup/api/test_email.php`
2. Enter your email address
3. Click "Send Test Email"
4. Check your email inbox

---

## 🔍 Troubleshooting

### Issue: "PHPMailer not found"
- **Solution**: Make sure PHPMailer folder is at: `C:\xampp\htdocs\helphup\api\PHPMailer\`

### Issue: "SMTP authentication failed"
- **Solution**: 
  - Make sure you're using **App Password** (not your regular Gmail password)
  - Verify 2-Step Verification is enabled
  - Generate a new App Password if needed

### Issue: "Email sending failed"
- **Solution**: 
  - Check error logs: `C:\xampp\apache\logs\error.log`
  - Verify all credentials are correct
  - Make sure no extra spaces in email/password

---

## 📝 Quick Configuration Summary

After setup, your `email_config.php` should have:

```php
define('USE_PHP_MAIL', false);  // ✅ Changed to false

define('SMTP_USERNAME', 'youremail@gmail.com');  // ✅ Your Gmail
define('SMTP_PASSWORD', 'abcdefghijklmnop');     // ✅ 16-char App Password
define('SMTP_FROM_EMAIL', 'youremail@gmail.com'); // ✅ Same as username
```

---

**✅ Once all steps are complete, emails should be sent successfully!**

