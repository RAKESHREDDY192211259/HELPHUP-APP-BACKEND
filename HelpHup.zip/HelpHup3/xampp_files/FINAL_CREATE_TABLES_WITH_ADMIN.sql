-- ============================================
-- Create Tables with Admin Status Columns
-- Run this in phpMyAdmin SQL tab on 'helphup' database
-- ============================================
-- IMPORTANT: Make sure 'ngo', 'volunteer', and 'donor' tables exist first!
-- ============================================

-- 1. CREATE NGO HELP REQUESTS TABLE
CREATE TABLE IF NOT EXISTS `ngo_help_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ngo_id` INT(11) NOT NULL,
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `urgency_level` VARCHAR(20) NOT NULL,
  `required_amount` DECIMAL(10,2) NOT NULL,
  `date_needed` DATE NOT NULL,
  `contact_number` VARCHAR(20) NOT NULL,
  `description` TEXT NOT NULL,
  `status` VARCHAR(20) DEFAULT 'pending',
  `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected',
  `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this request',
  `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this request',
  `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  INDEX `idx_admin_status` (`admin_status`),
  INDEX `idx_admin_id` (`admin_id`),
  FOREIGN KEY (`ngo_id`) REFERENCES `ngo`(`ngo_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. CREATE VOLUNTEER REQUESTS TABLE
CREATE TABLE IF NOT EXISTS `volunteer_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `volunteer_id` INT(11) NOT NULL,
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `description` TEXT NOT NULL,
  `location` VARCHAR(200) NOT NULL,
  `help_date` DATE NOT NULL,
  `start_time` TIME NOT NULL,
  `volunteers_needed` INT(11) NOT NULL,
  `status` VARCHAR(20) DEFAULT 'active',
  `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected',
  `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this request',
  `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this request',
  `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  INDEX `idx_admin_status` (`admin_status`),
  INDEX `idx_admin_id` (`admin_id`),
  FOREIGN KEY (`volunteer_id`) REFERENCES `volunteer`(`volunteer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. CREATE DONOR CAMPAIGNS TABLE
CREATE TABLE IF NOT EXISTS `donor_campaigns` (
  `campaign_id` INT(11) NOT NULL AUTO_INCREMENT,
  `donor_id` INT(11) NOT NULL,
  `campaign_title` VARCHAR(200) NOT NULL,
  `fundraising_goal` DECIMAL(10,2) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `cover_image_url` VARCHAR(255) DEFAULT NULL,
  `video_url` VARCHAR(255) DEFAULT NULL,
  `duration` VARCHAR(50) NOT NULL,
  `end_date` DATE NOT NULL,
  `beneficiary_name` VARCHAR(100) NOT NULL,
  `relationship` VARCHAR(50) NOT NULL,
  `contact_email` VARCHAR(100) NOT NULL,
  `status` VARCHAR(20) DEFAULT 'active',
  `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected',
  `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this campaign',
  `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this campaign',
  `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`campaign_id`),
  INDEX `idx_admin_status` (`admin_status`),
  INDEX `idx_admin_id` (`admin_id`),
  FOREIGN KEY (`donor_id`) REFERENCES `donor`(`donor_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Success message
-- ============================================
SELECT 'Tables created successfully with admin status columns!' AS message;

