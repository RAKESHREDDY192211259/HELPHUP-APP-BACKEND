# ✅ FIXED: Status Column Error

## 🔴 Error You Saw

```
"Unknown column 'nhr.status' in 'field list'"
```

## ✅ Fix Applied

The code now **checks if the `status` column exists** before using it:

```php
// Check if status column exists
$statusColumnCheck = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'status'");
$hasStatusColumn = $statusColumnCheck && $statusColumnCheck->num_rows > 0;
$statusField = $hasStatusColumn ? "COALESCE(nhr.status, 'pending') as status" : "'pending' as status";
```

This means:
- If `status` column exists → uses it
- If `status` column doesn't exist → uses default `'pending'`

---

## 🧪 TEST NOW

1. **Refresh browser:** `http://localhost/helphup/api/get_all_ngo_requests.php`
2. **Should see:** JSON with your NGO requests (not HTTP 500 error)
3. **Then test:** Android app - Volunteer and Donor screens should show NGO requests

---

## ✅ What This Means

- ✅ Works with `ngoraisehelp` table (no status column)
- ✅ Works with `ngo_help_requests` table (has status column)
- ✅ Automatically detects which structure you have
- ✅ No more "Unknown column" errors!

---

**File has been fixed and copied to server! Test now!** ✅

