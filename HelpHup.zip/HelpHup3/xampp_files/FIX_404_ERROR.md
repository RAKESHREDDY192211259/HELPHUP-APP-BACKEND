# 🔧 Fix HTTP 404 Not Found Error

## Problem
Getting **HTTP 404 Not Found** when trying to update profile.

## Solution: Copy PHP Files to Server

The update profile PHP files need to be in the correct server directory.

### Step 1: Locate Your XAMPP Directory
The files should be in:
```
C:\xampp\htdocs\helphup\api\
```

### Step 2: Copy Update Profile Files
Copy these 3 files from `xampp_files/` folder to `C:\xampp\htdocs\helphup\api\`:

1. ✅ `update_ngo_profile.php`
2. ✅ `update_donor_profile.php`
3. ✅ `update_volunteer_profile.php`

### Step 3: Verify Files Are Copied
Check that these files exist in:
```
C:\xampp\htdocs\helphup\api\update_ngo_profile.php
C:\xampp\htdocs\helphup\api\update_donor_profile.php
C:\xampp\htdocs\helphup\api\update_volunteer_profile.php
```

### Step 4: Test in Browser
Test each endpoint in your browser:

1. **NGO Update Profile:**
   ```
   http://10.26.77.227/helphup/api/update_ngo_profile.php
   ```
   Should show an error about missing data (not 404) - this means the file exists!

2. **Donor Update Profile:**
   ```
   http://10.26.77.227/helphup/api/update_donor_profile.php
   ```

3. **Volunteer Update Profile:**
   ```
   http://10.26.77.227/helphup/api/update_volunteer_profile.php
   ```

### Step 5: Verify config.php Exists
Make sure `config.php` is also in the same directory:
```
C:\xampp\htdocs\helphup\api\config.php
```

---

## Quick Copy Script (PowerShell)

Run this in PowerShell (as Administrator):

```powershell
# Set source and destination
$sourceDir = "D:\Android\Projects\HelpHup3\xampp_files"
$targetDir = "C:\xampp\htdocs\helphup\api"

# Copy update profile files
Copy-Item "$sourceDir\update_ngo_profile.php" -Destination "$targetDir\update_ngo_profile.php" -Force
Copy-Item "$sourceDir\update_donor_profile.php" -Destination "$targetDir\update_donor_profile.php" -Force
Copy-Item "$sourceDir\update_volunteer_profile.php" -Destination "$targetDir\update_volunteer_profile.php" -Force

Write-Host "Files copied successfully!" -ForegroundColor Green
Write-Host "Test URLs:" -ForegroundColor Yellow
Write-Host "http://10.26.77.227/helphup/api/update_ngo_profile.php"
Write-Host "http://10.26.77.227/helphup/api/update_donor_profile.php"
Write-Host "http://10.26.77.227/helphup/api/update_volunteer_profile.php"
```

---

## Manual Copy Steps

1. Open File Explorer
2. Navigate to: `D:\Android\Projects\HelpHup3\xampp_files`
3. Select these 3 files:
   - `update_ngo_profile.php`
   - `update_donor_profile.php`
   - `update_volunteer_profile.php`
4. Copy them (Ctrl+C)
5. Navigate to: `C:\xampp\htdocs\helphup\api\`
6. Paste them (Ctrl+V)
7. If files already exist, choose "Replace"

---

## Verify Apache is Running

1. Open XAMPP Control Panel
2. Make sure **Apache** is running (green)
3. If not running, click **Start**

---

## Check File Permissions

Make sure the files are readable:
- Right-click on the PHP files
- Properties → Security
- Make sure "Users" have "Read" permission

---

## Still Getting 404?

1. **Check the exact URL:**
   - Base URL: `http://10.26.77.227/helphup/api/`
   - Endpoint: `update_ngo_profile.php`
   - Full URL: `http://10.26.77.227/helphup/api/update_ngo_profile.php`

2. **Check case sensitivity:**
   - File names are case-sensitive on some servers
   - Make sure: `update_ngo_profile.php` (lowercase)

3. **Check .htaccess:**
   - If you have `.htaccess` file, make sure it's not blocking these files

4. **Check Apache error logs:**
   - Location: `C:\xampp\apache\logs\error.log`
   - Look for any errors related to these files

---

## Success Indicators

✅ Files exist in `C:\xampp\htdocs\helphup\api\`
✅ Apache is running
✅ Browser test shows error about missing data (not 404)
✅ App can now update profiles successfully

