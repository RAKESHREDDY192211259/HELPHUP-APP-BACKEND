# 🔧 Fix HTTP 500 Internal Server Error

## 🚨 Problem
Getting "failed to load requests: http 500 internal server error" when trying to fetch requests.

## 🔍 Most Common Causes

### 1. **Database Name Mismatch** (MOST LIKELY)
- Config file uses: `helphup`
- Documentation says: `helphup_db`
- **Check which database name is correct in your system**

### 2. **Table Doesn't Exist**
- `ngo_help_requests` table missing
- `ngo` table missing
- Database not created

### 3. **PHP Error**
- Syntax error in PHP file
- Missing config.php
- Database connection failed

---

## ✅ STEP-BY-STEP FIX

### Step 1: Check Database Name

1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Look at the left sidebar - what database names do you see?
3. Check if you have:
   - `helphup` OR
   - `helphup_db`

### Step 2: Update config.php

**If your database is `helphup`:**
- ✅ Keep config.php as is (it already uses `helphup`)

**If your database is `helphup_db`:**
- Change line 6 in `config.php`:
```php
$database = "helphup_db";  // Change from "helphup"
```

### Step 3: Verify Tables Exist

1. Open phpMyAdmin
2. Select your database (`helphup` or `helphup_db`)
3. Check if these tables exist:
   - ✅ `ngo_help_requests`
   - ✅ `ngo` (or `ngos`)
   - ✅ `volunteer_requests`
   - ✅ `volunteer`
   - ✅ `donor_campaigns`
   - ✅ `donor`

### Step 4: Run Debug Script

1. Copy `debug_get_requests.php` to: `C:\xampp\htdocs\helphup\api\`
2. Open browser: `http://localhost/helphup/api/debug_get_requests.php`
3. This will show you exactly what's wrong

### Step 5: Check PHP Error Logs

1. Open XAMPP Control Panel
2. Click **"Logs"** button next to Apache
3. Look for PHP errors
4. Or check: `C:\xampp\apache\logs\error.log`

---

## 🔧 QUICK FIXES

### Fix 1: Create Missing Tables

If tables don't exist, run this in phpMyAdmin:

```sql
-- Create NGO help requests table
CREATE TABLE IF NOT EXISTS `ngo_help_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ngo_id` INT(11) NOT NULL,
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `urgency_level` VARCHAR(20) NOT NULL,
  `required_amount` DECIMAL(10,2) NOT NULL,
  `date_needed` DATE NOT NULL,
  `contact_number` VARCHAR(20) NOT NULL,
  `description` TEXT NOT NULL,
  `status` VARCHAR(20) DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create NGO table (if missing)
CREATE TABLE IF NOT EXISTS `ngo` (
  `ngo_id` INT(11) NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(100) NOT NULL,
  `org_name` VARCHAR(200) NOT NULL,
  PRIMARY KEY (`ngo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Fix 2: Test API Directly

Open in browser:
- `http://localhost/helphup/api/get_all_ngo_requests.php`

If you see JSON, it's working!
If you see error, check the message.

---

## 🧪 TEST COMMANDS

### Test 1: Check Database Connection
```sql
-- Run in phpMyAdmin SQL tab
SELECT DATABASE();
SHOW TABLES;
```

### Test 2: Check Table Structure
```sql
-- Run in phpMyAdmin
DESCRIBE ngo_help_requests;
DESCRIBE ngo;
```

### Test 3: Check for Data
```sql
-- Run in phpMyAdmin
SELECT COUNT(*) FROM ngo_help_requests;
SELECT * FROM ngo_help_requests LIMIT 5;
```

---

## 📋 CHECKLIST

- [ ] XAMPP Apache is running
- [ ] XAMPP MySQL is running
- [ ] Database exists (check name: `helphup` or `helphup_db`)
- [ ] config.php has correct database name
- [ ] `ngo_help_requests` table exists
- [ ] `ngo` table exists
- [ ] PHP files are in: `C:\xampp\htdocs\helphup\api\`
- [ ] Can access: `http://localhost/helphup/api/config.php`
- [ ] Debug script shows no errors

---

## 🆘 STILL NOT WORKING?

1. **Check PHP Error Log:**
   - `C:\xampp\apache\logs\error.log`

2. **Enable Error Display Temporarily:**
   - Add to top of `get_all_ngo_requests.php`:
   ```php
   ini_set('display_errors', 1);
   error_reporting(E_ALL);
   ```

3. **Test Direct Database Connection:**
   ```php
   <?php
   $conn = new mysqli("localhost", "root", "", "helphup");
   if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
   }
   echo "Connected!";
   ?>
   ```

