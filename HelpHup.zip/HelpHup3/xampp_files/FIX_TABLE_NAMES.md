# Fix for Table Name Issues

## Problems Found:
1. **Table name mismatch**: Code uses `ngo` but database has `ngos` (plural)
2. **Missing password reset tables**: Need to create `ngo_password_reset_tokens`, `donor_password_reset_tokens`, `volunteer_password_reset_tokens`

## Solutions Applied:

### 1. Fixed Table Names
Updated all forgot password files to use correct table names:
- `ngoforgot.php` → uses `ngos` table
- `donor_forgot.php` → uses `donors` table  
- `volunteer_forgot.php` → uses `volunteers` table

### 2. Create Password Reset Tables
Run this in your browser:
```
http://localhost/helphup/api/setup_password_reset_table.php
```

This will create:
- `ngo_password_reset_tokens`
- `donor_password_reset_tokens`
- `volunteer_password_reset_tokens`

### 3. Verify Table Names
Check actual table names in your database:
```
http://localhost/helphup/api/check_table_names.php
```

## Next Steps:

1. **Create the password reset tables:**
   - Open: `http://localhost/helphup/api/setup_password_reset_table.php`
   - Should show success message

2. **Test the forgot password flow:**
   - Try "Send OTP" in your Android app
   - Should work now!

3. **If still having issues:**
   - Check: `http://localhost/helphup/api/check_table_names.php`
   - Verify which table names actually exist
   - Update the code if table names are different

## Files Updated:
- ✅ `ngoforgot.php` - Fixed table name to `ngos`
- ✅ `donor_forgot.php` - Fixed table name to `donors`
- ✅ `volunteer_forgot.php` - Fixed table name to `volunteers`
- ✅ All files copied to XAMPP server

