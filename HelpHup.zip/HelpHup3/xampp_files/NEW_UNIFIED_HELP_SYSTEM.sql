-- ============================================
-- NEW UNIFIED HELP REQUEST SYSTEM
-- Clean implementation following the help request flow
-- Leaves old tables untouched
-- ============================================

-- ============================================
-- 1. UNIFIED HELP REQUESTS TABLE
-- This table handles ALL help requests from NGO, Donor, Volunteer
-- ============================================

CREATE TABLE IF NOT EXISTS `unified_help_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `requester_type` ENUM('ngo', 'donor', 'volunteer') NOT NULL,
  `requester_id` INT(11) NOT NULL,
  `requester_name` VARCHAR(200) NOT NULL,
  `requester_email` VARCHAR(100) NOT NULL,
  `requester_phone` VARCHAR(20) NOT NULL,
  
  -- Request Details (Common fields)
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `description` TEXT NOT NULL,
  `urgency_level` ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL,
  
  -- Type-specific fields
  -- For NGO requests
  `required_amount` DECIMAL(10,2) DEFAULT NULL,
  `date_needed` DATE DEFAULT NULL,
  `contact_number` VARCHAR(20) DEFAULT NULL,
  
  -- For Volunteer requests
  `location` VARCHAR(200) DEFAULT NULL,
  `help_date` DATE DEFAULT NULL,
  `start_time` TIME DEFAULT NULL,
  `volunteers_needed` INT(11) DEFAULT NULL,
  
  -- For Donor campaigns
  `fundraising_goal` DECIMAL(10,2) DEFAULT NULL,
  `duration` VARCHAR(50) DEFAULT NULL,
  `end_date` DATE DEFAULT NULL,
  `beneficiary_name` VARCHAR(100) DEFAULT NULL,
  `relationship` VARCHAR(50) DEFAULT NULL,
  `contact_email` VARCHAR(100) DEFAULT NULL,
  `cover_image_url` VARCHAR(255) DEFAULT NULL,
  `video_url` VARCHAR(255) DEFAULT NULL,
  
  -- Status fields (following the help request flow)
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who approved/rejected',
  `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL,
  `rejection_reason` TEXT DEFAULT NULL,
  
  -- Timestamps
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`request_id`),
  INDEX `idx_requester` (`requester_type`, `requester_id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_category` (`category`),
  INDEX `idx_admin_review` (`admin_id`, `admin_reviewed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 2. REQUEST STATUS TRACKING TABLE
-- Tracks status changes for each request
-- ============================================

CREATE TABLE IF NOT EXISTS `request_status_history` (
  `history_id` INT(11) NOT NULL AUTO_INCREMENT,
  `request_id` INT(11) NOT NULL,
  `old_status` ENUM('pending', 'approved', 'rejected') DEFAULT NULL,
  `new_status` ENUM('pending', 'approved', 'rejected') NOT NULL,
  `changed_by` ENUM('system', 'admin', 'ngo', 'donor', 'volunteer') NOT NULL,
  `changed_by_id` INT(11) DEFAULT NULL,
  `change_reason` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`history_id`),
  INDEX `idx_request_history` (`request_id`),
  INDEX `idx_status_change` (`new_status`, `created_at`),
  FOREIGN KEY (`request_id`) REFERENCES `unified_help_requests`(`request_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 3. ADMIN NOTIFICATIONS TABLE
-- Tracks notifications sent to admins about new requests
-- ============================================

CREATE TABLE IF NOT EXISTS `admin_notifications` (
  `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
  `request_id` INT(11) NOT NULL,
  `notification_type` ENUM('new_request', 'status_update', 'urgent_request') NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` BOOLEAN DEFAULT FALSE,
  `admin_id` INT(11) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`notification_id`),
  INDEX `idx_unread_notifications` (`is_read`, `created_at`),
  INDEX `idx_request_notifications` (`request_id`),
  FOREIGN KEY (`request_id`) REFERENCES `unified_help_requests`(`request_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 4. HELP INTERACTIONS TABLE
-- Tracks when users show interest in helping
-- ============================================

CREATE TABLE IF NOT EXISTS `help_interactions` (
  `interaction_id` INT(11) NOT NULL AUTO_INCREMENT,
  `request_id` INT(11) NOT NULL,
  `helper_type` ENUM('ngo', 'donor', 'volunteer') NOT NULL,
  `helper_id` INT(11) NOT NULL,
  `helper_name` VARCHAR(200) NOT NULL,
  `interaction_type` ENUM('viewed', 'interested', 'contacted', 'committed') NOT NULL,
  `interaction_notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`interaction_id`),
  INDEX `idx_request_interactions` (`request_id`),
  INDEX `idx_helper_interactions` (`helper_type`, `helper_id`),
  INDEX `idx_interaction_type` (`interaction_type`),
  FOREIGN KEY (`request_id`) REFERENCES `unified_help_requests`(`request_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 5. SAMPLE DATA (Optional - for testing)
-- ============================================

-- Insert sample NGO request
INSERT INTO `unified_help_requests` (
  `requester_type`, `requester_id`, `requester_name`, `requester_email`, `requester_phone`,
  `request_title`, `category`, `description`, `urgency_level`,
  `required_amount`, `date_needed`, `contact_number`
) VALUES (
  'ngo', 1, 'Hope Foundation', 'contact@hope.org', '+91-9876543210',
  'Food Distribution Drive', 'Food Distribution', 'Need help distributing food to 500 families', 'High',
  50000.00, '2026-01-25', '+91-9876543210'
);

-- Insert sample Volunteer request
INSERT INTO `unified_help_requests` (
  `requester_type`, `requester_id`, `requester_name`, `requester_email`, `requester_phone`,
  `request_title`, `category`, `description`, `urgency_level`,
  `location`, `help_date`, `start_time`, `volunteers_needed`
) VALUES (
  'volunteer', 1, 'John Smith', 'john@email.com', '+91-9876543211',
  'Teaching Support', 'Education', 'Need volunteers to help teach children', 'Medium',
  'Community Center', '2026-01-26', '09:00:00', 5
);

-- Insert sample Donor campaign
INSERT INTO `unified_help_requests` (
  `requester_type`, `requester_id`, `requester_name`, `requester_email`, `requester_phone`,
  `request_title`, `category`, `description`, `urgency_level`,
  `fundraising_goal`, `duration`, `end_date`, `beneficiary_name`, `relationship`, `contact_email`
) VALUES (
  'donor', 1, 'Michael Brown', 'michael@email.com', '+91-9876543212',
  'School Supplies Fund', 'Education', 'Help provide school supplies to underprivileged children', 'High',
  75000.00, '30 days', '2026-02-20', 'Local School Children', 'Community Support', 'michael@email.com'
);

-- ============================================
-- 6. VIEWS FOR EASY QUERYING
-- ============================================

-- View for Admin Dashboard (shows all pending requests)
CREATE OR REPLACE VIEW `admin_pending_requests` AS
SELECT 
  r.*,
  CASE 
    WHEN r.requester_type = 'ngo' THEN CONCAT('NGO: ', r.requester_name)
    WHEN r.requester_type = 'volunteer' THEN CONCAT('Volunteer: ', r.requester_name)
    WHEN r.requester_type = 'donor' THEN CONCAT('Donor: ', r.requester_name)
  END as requester_display
FROM `unified_help_requests` r
WHERE r.status = 'pending'
ORDER BY r.created_at DESC;

-- View for Help Others pages (shows only approved requests)
CREATE OR REPLACE VIEW `public_help_requests` AS
SELECT 
  r.*,
  CASE 
    WHEN r.requester_type = 'ngo' THEN CONCAT('NGO: ', r.requester_name)
    WHEN r.requester_type = 'volunteer' THEN CONCAT('Volunteer: ', r.requester_name)
    WHEN r.requester_type = 'donor' THEN CONCAT('Donor: ', r.requester_name)
  END as requester_display
FROM `unified_help_requests` r
WHERE r.status = 'approved'
ORDER BY r.created_at DESC;

-- View for My Requests pages (shows user's own requests)
CREATE OR REPLACE VIEW `my_requests` AS
SELECT 
  r.*,
  CASE 
    WHEN r.requester_type = 'ngo' THEN CONCAT('NGO: ', r.requester_name)
    WHEN r.requester_type = 'volunteer' THEN CONCAT('Volunteer: ', r.requester_name)
    WHEN r.requester_type = 'donor' THEN CONCAT('Donor: ', r.requester_name)
  END as requester_display
FROM `unified_help_requests` r
ORDER BY r.created_at DESC;
