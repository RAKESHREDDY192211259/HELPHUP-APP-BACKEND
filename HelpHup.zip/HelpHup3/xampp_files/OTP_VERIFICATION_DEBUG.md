# OTP Verification Debugging Guide

## 🔍 Quick Debug Steps

### Step 1: Check What's in the Database

1. Open in browser: `http://localhost/helphup/api/test_otp_debug.php?email=YOUR-EMAIL@example.com`
   - Replace `YOUR-EMAIL@example.com` with the actual email you're testing
   - This will show you all OTPs stored in the database for that email

2. Look for:
   - The exact OTP stored in the database
   - The OTP length (should be 6)
   - Whether it's expired or used
   - The exact email stored (should be lowercase)

### Step 2: Check Error Logs

1. Open the error log file:
   - Path: `C:\xampp\apache\logs\error.log`
   - Or check: `C:\xampp\php\logs\php_error_log`

2. Look for entries containing:
   - "OTP Verification Request"
   - "Debug: OTP in DB"
   - "OTP mismatch"

### Step 3: Important - Request NEW OTP

⚠️ **IMPORTANT**: After the code changes, you MUST request a NEW OTP because:
- Old OTPs might have been stored with inconsistent email casing
- The new code stores emails in lowercase, so old OTPs won't match

**Steps:**
1. Go back to the "Forgot Password" screen
2. Enter your email again
3. Click "Send OTP" to generate a NEW OTP
4. Use the NEW OTP from your email to verify

### Step 4: Test Verification

1. Make sure you're using the NEW OTP (from the latest email)
2. Enter the exact 6-digit code from your email
3. Click "Verify"

---

## 🔧 Common Issues and Solutions

### Issue: "OTP verification failed"
- **Solution**: Request a NEW OTP after the code changes

### Issue: OTP mismatch in logs
- **Check**: Compare the OTP in database vs. what you entered
- **Note**: Make sure there are no extra spaces or characters

### Issue: "No OTP found for this email"
- **Check**: Email must match exactly (case-insensitive, but stored as lowercase)
- **Solution**: Request a new OTP

### Issue: "OTP has expired"
- **Solution**: Request a new OTP (OTPs expire after 15 minutes)

---

## 📝 Verification Query Details

The verification query checks:
```sql
SELECT * FROM ngo_password_reset_tokens 
WHERE email = ? 
AND otp = ? 
AND expires_at > NOW() 
AND used = 0
```

All conditions must be true:
- ✅ Email matches (exact match, lowercase)
- ✅ OTP matches (exact 6-digit match)
- ✅ Not expired (expires_at > current time)
- ✅ Not used (used = 0)

---

## 🚀 Quick Fix

**If verification is still failing:**

1. **Request a NEW OTP** (most important!)
2. Check the database using `test_otp_debug.php`
3. Compare the OTP from email with what's in database
4. Check error logs for detailed debug information

