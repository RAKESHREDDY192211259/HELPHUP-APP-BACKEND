-- ============================================
-- PAYMENT SYSTEM TABLES
-- ============================================

-- Payment Transactions Table
-- Stores all payment transactions
CREATE TABLE IF NOT EXISTS `payment_transactions` (
  `payment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` VARCHAR(100) NOT NULL UNIQUE,
  `payer_id` INT(11) NOT NULL,
  `payer_type` ENUM('ngo', 'volunteer', 'donor') NOT NULL,
  `payer_name` VARCHAR(200) NOT NULL,
  `payer_email` VARCHAR(100) NOT NULL,
  `payer_phone` VARCHAR(20) DEFAULT NULL,
  `request_id` INT(11) NOT NULL,
  `request_type` ENUM('ngo', 'volunteer', 'donor') NOT NULL,
  `payment_method` ENUM('upi', 'card', 'netbanking', 'wallet', 'other') NOT NULL,
  `payment_method_details` JSON DEFAULT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `currency` VARCHAR(3) DEFAULT 'INR',
  `status` ENUM('pending', 'processing', 'completed', 'failed', 'refunded') NOT NULL DEFAULT 'pending',
  `gateway_response` JSON DEFAULT NULL,
  `failure_reason` VARCHAR(500) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` TIMESTAMP NULL,
  
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `idx_payer` (`payer_id`),
  KEY `idx_request` (`request_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`),
  
  FOREIGN KEY (`payer_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`request_id`) REFERENCES `unified_help_requests`(`request_id`) ON DELETE CASCADE
);

-- Payment Method Details Table
-- Stores specific details for each payment method
CREATE TABLE IF NOT EXISTS `payment_method_details` (
  `detail_id` INT(11) NOT NULL AUTO_INCREMENT,
  `payment_id` INT(11) NOT NULL,
  `payment_method` ENUM('upi', 'card', 'netbanking', 'wallet') NOT NULL,
  `field_name` VARCHAR(50) NOT NULL,
  `field_value` VARCHAR(500) DEFAULT NULL,
  `is_encrypted` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`detail_id`),
  KEY `idx_payment` (`payment_id`),
  KEY `idx_method` (`payment_method`),
  
  FOREIGN KEY (`payment_id`) REFERENCES `payment_transactions`(`payment_id`) ON DELETE CASCADE
);

-- ============================================
-- USER HISTORY UPDATES
-- ============================================

-- Update Receiver History Table
-- Add payment info to existing help_interactions table
ALTER TABLE `help_interactions` 
ADD COLUMN `payment_id` INT(11) DEFAULT NULL,
ADD COLUMN `payment_amount` DECIMAL(10,2) DEFAULT NULL,
ADD COLUMN `payment_method` VARCHAR(20) DEFAULT NULL,
ADD COLUMN `payment_status` ENUM('pending', 'completed', 'failed') DEFAULT NULL,
ADD COLUMN `payment_date` TIMESTAMP DEFAULT NULL;

-- Update Helper History Table  
-- Add payment info to users who received help
ALTER TABLE `users` 
ADD COLUMN `total_help_received` DECIMAL(10,2) DEFAULT 0.00,
ADD COLUMN `total_payments_made` DECIMAL(10,2) DEFAULT 0.00,
ADD COLUMN `last_help_received_date` TIMESTAMP DEFAULT NULL,
ADD COLUMN `last_payment_date` TIMESTAMP DEFAULT NULL;

-- ============================================
-- TRIGGERS FOR AUTOMATIC UPDATES
-- ============================================

-- Trigger to update receiver history when payment is completed
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `update_receiver_history_on_payment`
AFTER UPDATE ON `payment_transactions`
FOR EACH ROW
BEGIN
    -- Only update if status changed to completed
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        
        -- Update help_interactions table
        UPDATE `help_interactions` 
        SET 
            `payment_id` = NEW.payment_id,
            `payment_amount` = NEW.amount,
            `payment_method` = NEW.payment_method,
            `payment_status` = 'completed',
            `payment_date` = NEW.completed_at,
            `interaction_status` = 'completed'
        WHERE `request_id` = NEW.request_id AND `helper_id` = NEW.payer_id;
        
        -- Update receiver (user who got help) totals
        UPDATE `users` 
        SET 
            `total_help_received` = `total_help_received` + NEW.amount,
            `total_payments_made` = `total_payments_made` + 1,
            `last_help_received_date` = NEW.completed_at,
            `last_payment_date` = NEW.completed_at
        WHERE `user_id` = NEW.payer_id;
        
    END IF;
END//
DELIMITER ;

-- Trigger to update helper history when payment is completed
DELIMITER //
CREATE TRIGGER IF NOT EXISTS `update_helper_history_on_payment`
AFTER UPDATE ON `payment_transactions`
FOR EACH ROW
BEGIN
    -- Only update if status changed to completed
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        
        -- Update helper (user who gave help) totals
        UPDATE `users` 
        SET 
            `total_help_given` = IFNULL(`total_help_given`, 0) + 1,
            `total_amount_given` = IFNULL(`total_amount_given`, 0) + NEW.amount,
            `last_help_given_date` = NEW.completed_at
        WHERE `user_id` = NEW.payer_id;
        
    END IF;
END//
DELIMITER ;

-- ============================================
-- VIEWS FOR EASY ACCESS
-- ============================================

-- Payment History View for Users
CREATE OR REPLACE VIEW `user_payment_history` AS
SELECT 
    pt.payment_id,
    pt.transaction_id,
    pt.payer_id,
    pt.payer_name,
    pt.payer_email,
    pt.request_id,
    uhr.request_title,
    uhr.request_type,
    uhr.requester_name as helped_person,
    pt.payment_method,
    pt.amount,
    pt.currency,
    pt.status,
    pt.created_at,
    pt.completed_at,
    CASE 
        WHEN pt.status = 'completed' THEN 'Payment Successful'
        WHEN pt.status = 'failed' THEN 'Payment Failed'
        WHEN pt.status = 'processing' THEN 'Processing'
        ELSE 'Pending'
    END as payment_status_text
FROM `payment_transactions` pt
JOIN `unified_help_requests` uhr ON pt.request_id = uhr.request_id
JOIN `users` u ON pt.payer_id = u.user_id
ORDER BY pt.created_at DESC;

-- Help Received History View for Users
CREATE OR REPLACE VIEW `help_received_history` AS
SELECT 
    hi.interaction_id,
    hi.request_id,
    uhr.request_title,
    uhr.request_type as request_type,
    uhr.requester_name as helper_name,
    hi.helper_id,
    u.user_name as receiver_name,
    u.user_email as receiver_email,
    hi.payment_id,
    hi.payment_amount,
    hi.payment_method,
    hi.payment_status,
    hi.interaction_date,
    hi.interaction_status,
    CASE 
        WHEN hi.interaction_status = 'completed' THEN 'Help Received'
        WHEN hi.interaction_status = 'pending' THEN 'Help Pending'
        ELSE 'Unknown'
    END as help_status_text
FROM `help_interactions` hi
JOIN `unified_help_requests` uhr ON hi.request_id = uhr.request_id
JOIN `users` u ON hi.helper_id = u.user_id
ORDER BY hi.interaction_date DESC;

-- ============================================
-- SAMPLE DATA FOR TESTING
-- ============================================

-- Insert sample payment transactions (for testing)
INSERT IGNORE INTO `payment_transactions` 
(`transaction_id`, `payer_id`, `payer_type`, `payer_name`, `payer_email`, `request_id`, `request_type`, `payment_method`, `amount`, `status`, `gateway_response`) 
VALUES 
('TXN001', 1, 'volunteer', 'John Doe', 'john@example.com', '1234567890', 1, 'ngo', 'upi', 1000.00, 'completed', '{"status": "success", "transaction_id": "TXN001"}'),
('TXN002', 2, 'donor', 'Jane Smith', 'jane@example.com', '1234567891', 2, 'volunteer', 'card', 2500.00, 'completed', '{"status": "success", "auth_code": "AUTH123"}'),
('TXN003', 3, 'ngo', 'Help Foundation', 'help@foundation.org', '1234567892', 3, 'donor', 'netbanking', 5000.00, 'completed', '{"status": "success", "bank_ref": "BANK456"}');

-- Insert sample payment method details
INSERT IGNORE INTO `payment_method_details` 
(`payment_id`, `payment_method`, `field_name`, `field_value`) 
VALUES 
(1, 'upi', 'upi_id', 'john@upi'),
(1, 'upi', 'upi_name', 'John Doe UPI'),
(2, 'card', 'card_number', '****-****-****-1234'),
(2, 'card', 'card_holder', 'John Doe'),
(2, 'card', 'expiry_date', '12/25'),
(2, 'card', 'cvv', '***'),
(3, 'netbanking', 'bank_name', 'HDFC Bank'),
(3, 'netbanking', 'account_number', '****-****-5678'),
(3, 'netbanking', 'transaction_id', 'TXN987654321');

-- Update help_interactions with payment info
UPDATE `help_interactions` 
SET 
    `payment_id` = 1,
    `payment_amount` = 1000.00,
    `payment_method` = 'upi',
    `payment_status` = 'completed',
    `payment_date` = NOW(),
    `interaction_status` = 'completed'
WHERE `request_id` = 1 AND `helper_id` = 1;

UPDATE `help_interactions` 
SET 
    `payment_id` = 2,
    `payment_amount` = 2500.00,
    `payment_method` = 'card',
    `payment_status` = 'completed',
    `payment_date` = NOW(),
    `interaction_status` = 'completed'
WHERE `request_id` = 2 AND `helper_id` = 2;

UPDATE `help_interactions` 
SET 
    `payment_id` = 3,
    `payment_amount` = 5000.00,
    `payment_method` = 'netbanking',
    `payment_status` = 'completed',
    `payment_date` = NOW(),
    `interaction_status` = 'completed'
WHERE `request_id` = 3 AND `helper_id` = 3;

-- Update user totals
UPDATE `users` 
SET 
    `total_help_received` = 1000.00,
    `total_payments_made` = 1,
    `last_help_received_date` = NOW(),
    `last_payment_date` = NOW()
WHERE `user_id` = 1;

UPDATE `users` 
SET 
    `total_help_given` = 1,
    `total_amount_given` = 2500.00,
    `last_help_given_date` = NOW()
WHERE `user_id` = 2;

UPDATE `users` 
SET 
    `total_help_given` = 1,
    `total_amount_given` = 5000.00,
    `last_help_given_date` = NOW()
WHERE `user_id` = 3;
