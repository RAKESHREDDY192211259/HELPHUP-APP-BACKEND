-- QUICK FIX: Run this in phpMyAdmin SQL tab
-- This will fix all invalid expires_at timestamps

-- Fix NGO table
UPDATE ngo_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE expires_at < created_at OR expires_at IS NULL;

-- Fix Donor table  
UPDATE donor_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE expires_at < created_at OR expires_at IS NULL;

-- Fix Volunteer table
UPDATE volunteer_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE expires_at < created_at OR expires_at IS NULL;

-- Check results (run this separately to verify)
SELECT 'ngo_password_reset_tokens' as table_name, id, email, created_at, expires_at,
       TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds,
       TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry
FROM ngo_password_reset_tokens
ORDER BY id DESC LIMIT 5;

