# 🚨 QUICK FIX FOR HTTP 500 ERROR

## ⚡ IMMEDIATE STEPS:

### Step 1: Run the Test Script

1. Copy `test_simple_ngo_requests.php` to: `C:\xampp\htdocs\helphup\api\`
2. Open browser: `http://localhost/helphup/api/test_simple_ngo_requests.php`
3. **This will show you EXACTLY what's wrong!**

### Step 2: Replace the File

1. Copy `get_all_ngo_requests_FIXED.php` 
2. Rename it to `get_all_ngo_requests.php` (replace the old one)
3. Put it in: `C:\xampp\htdocs\helphup\api\`

### Step 3: Test Again

Open: `http://localhost/helphup/api/get_all_ngo_requests.php`

---

## 🔍 COMMON ISSUES:

### Issue 1: Table doesn't exist
**Solution:** Create the table:
```sql
CREATE TABLE IF NOT EXISTS `ngo_help_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ngo_id` INT(11) NOT NULL,
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `urgency_level` VARCHAR(20) NOT NULL,
  `required_amount` DECIMAL(10,2) NOT NULL,
  `date_needed` DATE NOT NULL,
  `contact_number` VARCHAR(20) NOT NULL,
  `description` TEXT NOT NULL,
  `status` VARCHAR(20) DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Issue 2: Wrong column name (id vs ngo_id)
**The FIXED version handles this automatically!**

### Issue 3: Database name wrong
Check `config.php` line 6:
- Should be: `$database = "helphup";`
- OR: `$database = "helphup_db";`
- **Use whatever database name actually exists in phpMyAdmin!**

---

## ✅ AFTER FIXING:

1. Test in browser first: `http://localhost/helphup/api/get_all_ngo_requests.php`
2. Should see JSON with `{"status":true,"message":"Requests fetched successfully","data":[...]}`
3. Then test in Android app

---

## 📞 IF STILL NOT WORKING:

1. **Check PHP error log:**
   - `C:\xampp\apache\logs\error.log`
   - Look for the latest error

2. **Check database:**
   - Open phpMyAdmin
   - Select your database
   - Check if `ngo_help_requests` table exists
   - Check if `ngo` or `ngos` table exists

3. **Run the test script:**
   - `test_simple_ngo_requests.php` will show you exactly what's wrong

