# ⚡ Quick Email Setup (3 Steps)

## 🚀 Fastest Way: Use Setup Helper

1. **Open Setup Helper:**
   ```
   http://localhost/helphup/api/setup_email.php
   ```

2. **Follow the on-screen instructions:**
   - Install PHPMailer (if needed)
   - Enter your Gmail credentials
   - Test email sending

3. **Done!** OTP emails will now work.

---

## 📋 Manual Setup (If Helper Doesn't Work)

### Step 1: Get Gmail App Password (2 min)
1. Go to: https://myaccount.google.com/apppasswords
2. Enable 2-Step Verification (if needed)
3. Generate App Password → Copy 16-character code

### Step 2: Install PHPMailer (1 min)
1. Download: https://github.com/PHPMailer/PHPMailer/archive/refs/heads/master.zip
2. Extract → Copy `PHPMailer` folder to: `C:\xampp\htdocs\helphup\api\PHPMailer\`

### Step 3: Configure (1 min)
1. Open: `C:\xampp\htdocs\helphup\api\setup_email.php`
2. Enter Gmail and App Password
3. Click "Save Configuration"

---

## ✅ Test

Open: `http://localhost/helphup/api/test_email.php?email=your-email@gmail.com`

Check your inbox!

---

**That's it!** 🎉

