# XAMPP Setup Files for HelpHup App

## 📁 Files in this folder

### Database Setup
- `database_setup.sql` - Run this in phpMyAdmin to create all tables

### PHP API Files (Copy to: `C:\xampp\htdocs\helphup\api\`)
1. `config.php` - Database connection (REQUIRED - copy this first!)
2. `ngo_login.php`
3. `ngo_register.php`
4. `ngoforgot.php`
5. `volunteer_login.php`
6. `volunteer_register.php`
7. `volunteer_forgot.php`
8. `donor_login.php`
9. `donor_register.php`
10. `donor_forgot.php`
11. `ngo_raise_help.php`
12. `volunteer_raise_help.php`
13. `Donor_raise_help.php`

---

## 🚀 Setup Instructions

### Step 1: Start XAMPP
1. Open XAMPP Control Panel
2. Start **Apache**
3. Start **MySQL**

### Step 2: Create Database
1. Open browser: `http://localhost/phpmyadmin`
2. Click **"New"** in left sidebar
3. Database name: `helphup_db`
4. Collation: `utf8mb4_general_ci`
5. Click **"Create"**

### Step 3: Create Tables
1. Select `helphup_db` database
2. Click **"SQL"** tab
3. Copy entire content of `database_setup.sql`
4. Paste and click **"Go"**
5. All 7 tables should be created

### Step 4: Copy PHP Files
1. Copy ALL PHP files from this folder
2. Paste to: `C:\xampp\htdocs\helphup\api\`
3. Make sure `config.php` is included

### Step 5: Create Upload Directory
1. Create folder: `C:\xampp\htdocs\helphup\uploads\`
2. Inside it, create: `registration_proofs\`
3. Full path: `C:\xampp\htdocs\helphup\uploads\registration_proofs\`

### Step 6: Test
1. Open browser: `http://localhost/helphup/api/config.php`
2. Should show blank page (no errors = working!)

---

## ✅ Verification Checklist

- [ ] XAMPP Apache is running
- [ ] XAMPP MySQL is running
- [ ] Database `helphup_db` created
- [ ] All 7 tables created (check in phpMyAdmin)
- [ ] All 13 PHP files copied to `api\` folder
- [ ] Upload directory created
- [ ] Test URL works: `http://localhost/helphup/api/`

---

## 🔧 Configuration

### Database Settings (in config.php)
- Host: `localhost`
- Username: `root`
- Password: `` (empty)
- Database: `helphup_db`

### If you need to change database credentials:
Edit `config.php` file:
```php
$host = "localhost";
$username = "root";
$password = "";  // Your MySQL password
$database = "helphup_db";
```

---

## 📱 Android App Configuration

### Current Base URL in App:
```
http://10.22.186.166/helphup/api/
```

### For Localhost Testing:
Change to:
```
http://localhost/helphup/api/
```

### For Network Testing (Android Device):
1. Find your PC IP: Open CMD → type `ipconfig` → find IPv4 Address
2. Change base URL to: `http://YOUR_IP/helphup/api/`
3. Ensure PC and Android on same WiFi

---

## 🐛 Troubleshooting

**"Connection failed"**
- Check MySQL is running in XAMPP
- Verify database name is `helphup_db`
- Check username/password in config.php

**"Access denied"**
- Default XAMPP: username=`root`, password=`` (empty)
- Check MySQL user permissions

**"File upload failed"**
- Check `uploads\registration_proofs\` folder exists
- Check folder has write permissions

**"Cannot connect from Android"**
- PC and Android must be on same WiFi
- Check firewall allows Apache
- Verify IP address is correct

---

## 📞 Quick Reference

- **PHP Files Location:** `C:\xampp\htdocs\helphup\api\`
- **Database Name:** `helphup_db`
- **phpMyAdmin:** `http://localhost/phpmyadmin`
- **Test API:** `http://localhost/helphup/api/`

---

## ⚠️ Important Notes

1. **Copy `config.php` FIRST** - All other files depend on it
2. **File names are case-sensitive** - Keep exact names
3. **Donor file:** `Donor_raise_help.php` (capital D) - matches app code
4. **All files must be in `api\` folder** - Not in root

---

## 🎯 Next Steps After Setup

1. Test NGO registration
2. Test NGO login
3. Test Volunteer registration
4. Test Volunteer login
5. Test Donor registration
6. Test Donor login
7. Test Forgot Password (all 3 roles)
8. Test Raise Help requests

All files are ready to use! 🚀

