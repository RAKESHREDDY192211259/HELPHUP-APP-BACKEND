# 📋 QUICK INSTRUCTIONS - Copy Files to Server

## ⚡ FASTEST WAY: Use the Script

### Option 1: PowerShell Script (Recommended)
1. Right-click on `copy_files_to_server.ps1`
2. Select "Run with PowerShell"
3. Files will be copied automatically

### Option 2: Batch Script (Easier)
1. Double-click `copy_files_to_server.bat`
2. Files will be copied automatically

---

## 📁 MANUAL COPY (If Script Doesn't Work)

### Step 1: Locate Files
Go to: `D:\Android\Projects\HelpHup3\xampp_files\`

### Step 2: Copy These 3 Files
1. `get_all_ngo_requests.php`
2. `get_all_volunteer_requests.php`
3. `get_all_donor_campaigns.php`

### Step 3: Paste to Server
Paste to: `C:\xampp\htdocs\helphup\api\`

**Important:** Replace the old files if they exist!

---

## ✅ VERIFY FILES COPIED

1. Go to: `C:\xampp\htdocs\helphup\api\`
2. Open `get_all_ngo_requests.php` in Notepad
3. Check line 24 - should say:
   ```php
   $possibleTables = ['ngoraisehelp', 'ngo_help_requests', 'ngohelprequests'];
   ```
4. If you see this, file is updated ✅

---

## 🧪 TEST

1. Open browser: `http://localhost/helphup/api/get_all_ngo_requests.php`
2. Should see JSON response (not HTTP 500)
3. Test in Android app - should work now!

---

**All files are ready in `xampp_files\` folder!** ✅

