-- ============================================
-- STEP BY STEP HELP REQUEST & PAYMENT SYSTEM
-- ============================================

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS helphup_db;

-- Use the database
USE helphup_db;

-- ============================================
-- STEP 1: CREATE USERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    user_type ENUM('ngo', 'volunteer', 'donor', 'admin') NOT NULL,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    is_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP DEFAULT NULL
);

-- ============================================
-- STEP 2: CREATE UNIFIED HELP REQUESTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS unified_help_requests (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    requester_type ENUM('ngo', 'volunteer', 'donor') NOT NULL,
    requester_id INT NOT NULL,
    requester_name VARCHAR(200) NOT NULL,
    requester_email VARCHAR(100) NOT NULL,
    requester_phone VARCHAR(20) DEFAULT NULL,
    
    request_title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    urgency_level ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL,
    
    -- NGO specific
    required_amount DECIMAL(10,2) DEFAULT NULL,
    date_needed DATE DEFAULT NULL,
    contact_number VARCHAR(20) DEFAULT NULL,
    
    -- Volunteer specific
    location VARCHAR(200) DEFAULT NULL,
    help_date DATE DEFAULT NULL,
    start_time TIME DEFAULT NULL,
    volunteers_needed INT DEFAULT NULL,
    
    -- Donor specific
    fundraising_goal DECIMAL(10,2) DEFAULT NULL,
    duration VARCHAR(50) DEFAULT NULL,
    end_date DATE DEFAULT NULL,
    beneficiary_name VARCHAR(100) DEFAULT NULL,
    relationship VARCHAR(50) DEFAULT NULL,
    contact_email VARCHAR(100) DEFAULT NULL,
    
    -- Status and timestamps
    status ENUM('pending', 'approved', 'rejected', 'completed') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    admin_notes TEXT DEFAULT NULL,
    completed_at TIMESTAMP DEFAULT NULL,
    
    FOREIGN KEY (requester_id) REFERENCES users(user_id)
);

-- ============================================
-- STEP 3: CREATE HELP INTERACTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS help_interactions (
    interaction_id INT PRIMARY KEY AUTO_INCREMENT,
    request_id INT NOT NULL,
    helper_id INT NOT NULL,
    receiver_id INT NOT NULL,
    interaction_type ENUM('help', 'volunteer', 'donate') NOT NULL DEFAULT 'help',
    interaction_status ENUM('pending', 'completed', 'cancelled', 'refunded') NOT NULL DEFAULT 'pending',
    interaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT DEFAULT NULL,
    
    -- Payment information (added when payment is made)
    payment_id INT DEFAULT NULL,
    payment_amount DECIMAL(10,2) DEFAULT NULL,
    payment_method VARCHAR(20) DEFAULT NULL,
    payment_status ENUM('pending', 'completed', 'failed') DEFAULT NULL,
    payment_date TIMESTAMP DEFAULT NULL,
    
    FOREIGN KEY (request_id) REFERENCES unified_help_requests(request_id),
    FOREIGN KEY (helper_id) REFERENCES users(user_id),
    FOREIGN KEY (receiver_id) REFERENCES users(user_id)
);

-- ============================================
-- STEP 4: CREATE PAYMENT TRANSACTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS payment_transactions (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_id VARCHAR(100) NOT NULL UNIQUE,
    payer_id INT NOT NULL,
    payer_type ENUM('ngo', 'volunteer', 'donor') NOT NULL,
    payer_name VARCHAR(200) NOT NULL,
    payer_email VARCHAR(100) NOT NULL,
    payer_phone VARCHAR(20) DEFAULT NULL,
    
    request_id INT NOT NULL,
    request_type ENUM('ngo', 'volunteer', 'donor') NOT NULL,
    payment_method ENUM('upi', 'card', 'netbanking', 'wallet', 'other') NOT NULL,
    payment_method_details JSON DEFAULT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'INR',
    status ENUM('pending', 'processing', 'completed', 'failed', 'refunded') NOT NULL DEFAULT 'pending',
    gateway_response JSON DEFAULT NULL,
    failure_reason VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    completed_at TIMESTAMP DEFAULT NULL,
    refunded_at TIMESTAMP DEFAULT NULL,
    
    FOREIGN KEY (payer_id) REFERENCES users(user_id),
    FOREIGN KEY (request_id) REFERENCES unified_help_requests(request_id)
);

-- ============================================
-- STEP 5: INSERT SAMPLE DATA
-- ============================================

-- Insert sample users
INSERT IGNORE INTO users (user_type, name, email, password, is_verified, is_active) VALUES
('admin', 'Admin User', 'admin@helphup.com', 'admin123', TRUE, TRUE),
('ngo', 'Help Foundation', 'ngo@helphup.org', 'ngo123', TRUE, TRUE),
('volunteer', 'John Volunteer', 'volunteer@helphup.com', 'vol123', TRUE, TRUE),
('donor', 'Jane Donor', 'donor@helphup.com', 'donor123', TRUE, TRUE);

-- Insert sample help requests
INSERT IGNORE INTO unified_help_requests 
(requester_type, requester_id, requester_name, requester_email, request_title, category, description, urgency_level, required_amount, date_needed, contact_number, location, help_date, start_time, volunteers_needed, fundraising_goal, duration, end_date, beneficiary_name, relationship, contact_email, status) 
VALUES 
('ngo', 2, 'Help Foundation', 'ngo@helphup.org', 'Emergency Medical Supplies', 'Medical', 'URGENT: We need medical supplies for flood relief.', 'Critical', 50000.00, '2024-01-15', '9876543210', 'City General Hospital', '2024-01-20', '09:00:00', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending'),
('volunteer', 3, 'John Volunteer', 'volunteer@helphup.com', 'Teaching Volunteers', 'Education', 'Looking for volunteers to teach children.', 'Medium', NULL, NULL, NULL, 'Community Learning Center', '2024-01-20', '10:00:00', 10, NULL, NULL, NULL, NULL, NULL, NULL, 'pending'),
('donor', 4, 'Jane Donor', 'donor@helphup.com', 'Clean Water Campaign', 'Water', 'Fundraising for water purification systems.', 'High', 100000.00, NULL, NULL, NULL, NULL, 30, '2024-02-15', 'Rural Village Areas', 'Water for Life Foundation', 'clean.water@example.com', 'pending');

-- Insert sample payment transactions
INSERT IGNORE INTO payment_transactions 
(transaction_id, payer_id, payer_type, payer_name, payer_email, request_id, request_type, payment_method, amount, status, gateway_response, completed_at) 
VALUES 
('TXN001', 3, 'volunteer', 'John Volunteer', 'volunteer@helphup.com', '9876543211', 2, 'volunteer', 'upi', 1000.00, 'completed', '{"status": "success"}', NOW()),
('TXN002', 4, 'donor', 'Jane Donor', 'donor@helphup.com', '9876543212', 3, 'donor', 'card', 2500.00, 'completed', '{"status": "success"}', NOW());

-- Insert sample help interactions
INSERT IGNORE INTO help_interactions 
(request_id, helper_id, receiver_id, interaction_type, interaction_status, payment_id, payment_amount, payment_method, payment_status, payment_date, interaction_date) 
VALUES 
(2, 3, 2, 'help', 'completed', 1, 1000.00, 'upi', 'completed', NOW(), NOW()),
(3, 4, 4, 'help', 'completed', 1, 2500.00, 'card', 'completed', NOW(), NOW());

-- Update user statistics
UPDATE users SET 
    total_help_given = 1, total_amount_given = 1000.00, last_help_given_date = NOW(), last_help_received_date = NOW()
WHERE user_id = 3;

UPDATE users SET 
    total_help_given = 1, total_amount_given = 2500.00, last_help_given_date = NOW(), last_help_received_date = NOW()
WHERE user_id = 4;

-- ============================================
-- STEP 6: SUCCESS MESSAGE
-- ============================================
SELECT 'Step-by-step database creation completed successfully!' AS success_message;
