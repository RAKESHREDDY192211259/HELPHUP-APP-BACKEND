# 🚨 URGENT: Fix HTTP 404 Error for Profile Update

## Problem
Getting **"Failed to update profile: HTTP 404 Not Found"** when trying to save profile changes.

## Root Cause
The update profile PHP files are **NOT** in the server directory where Apache can access them.

---

## ✅ IMMEDIATE FIX (3 Steps)

### Step 1: Copy Files to Server

**Copy these 3 files:**
1. `update_ngo_profile.php`
2. `update_donor_profile.php`
3. `update_volunteer_profile.php`

**From:** `D:\Android\Projects\HelpHup3\xampp_files\`  
**To:** `C:\xampp\htdocs\helphup\api\`

### Step 2: Verify Files Exist

Check that these files are now in:
```
C:\xampp\htdocs\helphup\api\update_ngo_profile.php
C:\xampp\htdocs\helphup\api\update_donor_profile.php
C:\xampp\htdocs\helphup\api\update_volunteer_profile.php
```

### Step 3: Test in Browser

Open these URLs in your browser (should NOT show 404):

1. **NGO Update:**
   ```
   http://10.26.77.227/helphup/api/update_ngo_profile.php
   ```
   ✅ Should show: `{"status":false,"message":"NGO ID is required"}`  
   ❌ If 404: File is missing!

2. **Donor Update:**
   ```
   http://10.26.77.227/helphup/api/update_donor_profile.php
   ```

3. **Volunteer Update:**
   ```
   http://10.26.77.227/helphup/api/update_volunteer_profile.php
   ```

---

## 🔧 Automated Fix (PowerShell)

**Run this in PowerShell (as Administrator):**

```powershell
# Set paths
$source = "D:\Android\Projects\HelpHup3\xampp_files"
$target = "C:\xampp\htdocs\helphup\api"

# Copy files
Copy-Item "$source\update_ngo_profile.php" -Destination "$target\update_ngo_profile.php" -Force
Copy-Item "$source\update_donor_profile.php" -Destination "$target\update_donor_profile.php" -Force
Copy-Item "$source\update_volunteer_profile.php" -Destination "$target\update_volunteer_profile.php" -Force

Write-Host "✅ Files copied!" -ForegroundColor Green
Write-Host ""
Write-Host "Test URLs:" -ForegroundColor Yellow
Write-Host "http://10.26.77.227/helphup/api/update_ngo_profile.php"
Write-Host "http://10.26.77.227/helphup/api/update_donor_profile.php"
Write-Host "http://10.26.77.227/helphup/api/update_volunteer_profile.php"
```

---

## 📋 Manual Copy Steps

1. **Open File Explorer**
2. **Navigate to:** `D:\Android\Projects\HelpHup3\xampp_files`
3. **Select these 3 files:**
   - `update_ngo_profile.php`
   - `update_donor_profile.php`
   - `update_volunteer_profile.php`
4. **Right-click → Copy** (or Ctrl+C)
5. **Navigate to:** `C:\xampp\htdocs\helphup\api\`
6. **Right-click → Paste** (or Ctrl+V)
7. **If prompted to replace:** Click "Yes" or "Replace"

---

## 🧪 Test All Endpoints

**Copy `test_update_endpoints.php` to server, then open:**
```
http://10.26.77.227/helphup/api/test_update_endpoints.php
```

This will show you:
- ✅ Which files exist
- ❌ Which files are missing
- 📍 Exact file paths
- 🔗 Test URLs

---

## ✅ Success Indicators

After copying files, you should see:

1. **Browser Test:**
   - Opening the PHP files shows JSON error (not 404)
   - Error message like: `"NGO ID is required"` or `"All fields are required"`

2. **App Test:**
   - Profile update works
   - No more "HTTP 404 Not Found" error
   - Success message: "Profile updated successfully"

---

## ⚠️ Common Issues

### Issue 1: Still Getting 404
**Solution:** 
- Make sure Apache is running in XAMPP
- Check file names are exactly: `update_ngo_profile.php` (lowercase)
- Verify files are in: `C:\xampp\htdocs\helphup\api\` (not in subfolder)

### Issue 2: Permission Denied
**Solution:**
- Right-click files → Properties → Security
- Make sure "Users" have "Read" permission

### Issue 3: Wrong Directory
**Solution:**
- Files MUST be in: `C:\xampp\htdocs\helphup\api\`
- NOT in: `C:\xampp\htdocs\helphup\` (missing `/api/` folder)

---

## 📞 Quick Checklist

- [ ] Apache is running in XAMPP
- [ ] Files copied to `C:\xampp\htdocs\helphup\api\`
- [ ] All 3 update profile files exist
- [ ] Browser test shows JSON (not 404)
- [ ] App can now update profiles

---

**After fixing, test profile update in the app - it should work!** ✅

