-- Add admin_status column to volunteer_requests and donor_campaigns tables
-- This ensures submitted requests appear in admin portal
-- MySQL doesn't support IF NOT EXISTS for ALTER TABLE, so run each ALTER separately
-- If column exists, you'll get an error - ignore it

USE helphup;

-- Add admin_status to volunteer_requests table
-- If column already exists, this will fail - that's okay, just ignore the error
SET @dbname = DATABASE();
SET @tablename = "volunteer_requests";
SET @columnname = "admin_status";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 'Column already exists'",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected'")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Update existing volunteer_requests to set admin_status = 'pending' if NULL
UPDATE `volunteer_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL;

-- Add admin_status to donor_campaigns table
SET @tablename = "donor_campaigns";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 'Column already exists'",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected'")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Update existing donor_campaigns to set admin_status = 'pending' if NULL
UPDATE `donor_campaigns` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL;

-- Add admin_id to volunteer_requests
SET @tablename = "volunteer_requests";
SET @columnname = "admin_id";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 'Column already exists'",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " INT(11) DEFAULT NULL")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add admin_id to donor_campaigns
SET @tablename = "donor_campaigns";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 'Column already exists'",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " INT(11) DEFAULT NULL")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add admin_reviewed_at to volunteer_requests
SET @tablename = "volunteer_requests";
SET @columnname = "admin_reviewed_at";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 'Column already exists'",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " TIMESTAMP NULL DEFAULT NULL")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add admin_reviewed_at to donor_campaigns
SET @tablename = "donor_campaigns";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 'Column already exists'",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " TIMESTAMP NULL DEFAULT NULL")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add rejection_reason to volunteer_requests
SET @tablename = "volunteer_requests";
SET @columnname = "rejection_reason";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 'Column already exists'",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " TEXT DEFAULT NULL")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add rejection_reason to donor_campaigns
SET @tablename = "donor_campaigns";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 'Column already exists'",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " TEXT DEFAULT NULL")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Verify the columns exist
SELECT 'volunteer_requests columns:' as info;
SHOW COLUMNS FROM `volunteer_requests` LIKE 'admin_status';
SHOW COLUMNS FROM `volunteer_requests` LIKE 'admin_id';
SHOW COLUMNS FROM `volunteer_requests` LIKE 'admin_reviewed_at';
SHOW COLUMNS FROM `volunteer_requests` LIKE 'rejection_reason';

SELECT 'donor_campaigns columns:' as info;
SHOW COLUMNS FROM `donor_campaigns` LIKE 'admin_status';
SHOW COLUMNS FROM `donor_campaigns` LIKE 'admin_id';
SHOW COLUMNS FROM `donor_campaigns` LIKE 'admin_reviewed_at';
SHOW COLUMNS FROM `donor_campaigns` LIKE 'rejection_reason';

-- Show count of pending requests
SELECT 'Pending Requests Count:' as info;
SELECT 'volunteer_requests' as table_name, COUNT(*) as pending_count 
FROM volunteer_requests 
WHERE admin_status = 'pending' OR admin_status IS NULL
UNION ALL
SELECT 'donor_campaigns' as table_name, COUNT(*) as pending_count 
FROM donor_campaigns 
WHERE admin_status = 'pending' OR admin_status IS NULL;

