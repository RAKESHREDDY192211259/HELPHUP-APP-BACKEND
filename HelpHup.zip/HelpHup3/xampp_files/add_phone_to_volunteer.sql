-- Migration script to add phone column to volunteer table
-- Run this if your volunteer table doesn't have a phone column

-- Check if phone column exists, if not add it
ALTER TABLE `volunteer` 
ADD COLUMN IF NOT EXISTS `phone` VARCHAR(20) NOT NULL DEFAULT '' AFTER `full_name`;

-- If the column already exists but allows NULL, make it NOT NULL
-- ALTER TABLE `volunteer` MODIFY COLUMN `phone` VARCHAR(20) NOT NULL;
