-- Add status and rejection_reason columns to user tables
-- Run this in phpMyAdmin SQL tab on 'helphup' database

-- Add status column to NGO table (if it doesn't exist)
ALTER TABLE `ngo` 
ADD COLUMN IF NOT EXISTS `status` VARCHAR(20) DEFAULT 'active' COMMENT 'active, rejected, inactive',
ADD COLUMN IF NOT EXISTS `rejection_reason` TEXT DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this user',
ADD COLUMN IF NOT EXISTS `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL;

-- Add status column to Volunteer table (if it doesn't exist)
ALTER TABLE `volunteer` 
ADD COLUMN IF NOT EXISTS `status` VARCHAR(20) DEFAULT 'active' COMMENT 'active, rejected, inactive',
ADD COLUMN IF NOT EXISTS `rejection_reason` TEXT DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this user',
ADD COLUMN IF NOT EXISTS `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL;

-- Add status column to Donor table (if it doesn't exist)
ALTER TABLE `donor` 
ADD COLUMN IF NOT EXISTS `status` VARCHAR(20) DEFAULT 'active' COMMENT 'active, rejected, inactive',
ADD COLUMN IF NOT EXISTS `rejection_reason` TEXT DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this user',
ADD COLUMN IF NOT EXISTS `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL;

-- Note: IF NOT EXISTS syntax may not work in all MySQL versions
-- If you get an error, run these commands one by one and skip if column already exists

