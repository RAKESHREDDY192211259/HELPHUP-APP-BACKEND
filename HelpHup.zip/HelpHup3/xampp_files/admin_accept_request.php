<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$request_type = $data['request_type'] ?? ''; // 'ngo', 'volunteer', 'donor'
$request_id = $data['request_id'] ?? 0;
$admin_id = $data['admin_id'] ?? 0;

if (empty($request_type) || empty($request_id) || empty($admin_id)) {
    sendResponse(false, "Request type, request ID, and admin ID are required");
}

// Determine table and column names based on actual table structure
$tableName = '';
$idColumn = '';
$statusColumn = '';

switch ($request_type) {
    case 'ngo':
        // Check which table exists
        $checkTable1 = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
        $checkTable2 = $conn->query("SHOW TABLES LIKE 'ngo_help_requests'");
        
        if ($checkTable1->num_rows > 0) {
            $tableName = 'ngoraisehelp';
            $idColumn = 'id';
            // Check if status column exists
            $checkStatus = $conn->query("SHOW COLUMNS FROM ngoraisehelp LIKE 'status'");
            $statusColumn = $checkStatus->num_rows > 0 ? 'status' : null;
        } else if ($checkTable2->num_rows > 0) {
            $tableName = 'ngo_help_requests';
            $idColumn = 'request_id';
            $statusColumn = 'status';
        } else {
            sendResponse(false, "NGO requests table not found");
            exit;
        }
        break;
    case 'volunteer':
        // Check which table exists
        $checkTable1 = $conn->query("SHOW TABLES LIKE 'volunteerraisehelp'");
        $checkTable2 = $conn->query("SHOW TABLES LIKE 'volunteer_requests'");
        
        if ($checkTable1->num_rows > 0) {
            $tableName = 'volunteerraisehelp';
            $idColumn = 'id';
            $checkStatus = $conn->query("SHOW COLUMNS FROM volunteerraisehelp LIKE 'status'");
            $statusColumn = $checkStatus->num_rows > 0 ? 'status' : null;
        } else if ($checkTable2->num_rows > 0) {
            $tableName = 'volunteer_requests';
            $idColumn = 'request_id';
            $statusColumn = 'status';
        } else {
            sendResponse(false, "Volunteer requests table not found");
            exit;
        }
        break;
    case 'donor':
        $tableName = 'donor_campaigns';
        $idColumn = 'campaign_id';
        $statusColumn = 'status';
        break;
    default:
        sendResponse(false, "Invalid request type");
        exit;
}

// Update admin_status to 'accepted' and status to 'approved' (so it's visible to other roles)
if ($statusColumn) {
    $stmt = $conn->prepare("UPDATE `$tableName` SET admin_status = 'accepted', `$statusColumn` = 'approved', admin_id = ?, admin_reviewed_at = NOW() WHERE `$idColumn` = ? AND (admin_status = 'pending' OR admin_status = 'verified')");
    $stmt->bind_param("ii", $admin_id, $request_id);
} else {
    // No status column, just update admin_status
    $stmt = $conn->prepare("UPDATE `$tableName` SET admin_status = 'accepted', admin_id = ?, admin_reviewed_at = NOW() WHERE `$idColumn` = ? AND (admin_status = 'pending' OR admin_status = 'verified')");
    $stmt->bind_param("ii", $admin_id, $request_id);
}

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        // Create notification for the user that their request was accepted
        $userId = 0;
        
        // Get user ID based on request type
        if ($request_type == 'ngo') {
            $getUser = $conn->query("SELECT ngo_id FROM `$tableName` WHERE `$idColumn` = $request_id");
            if ($getUser && $getUser->num_rows > 0) {
                $userRow = $getUser->fetch_assoc();
                $userId = $userRow['ngo_id'] ?? 0;
            }
        } else if ($request_type == 'volunteer') {
            $getUser = $conn->query("SELECT volunteer_id FROM `$tableName` WHERE `$idColumn` = $request_id");
            if ($getUser && $getUser->num_rows > 0) {
                $userRow = $getUser->fetch_assoc();
                $userId = $userRow['volunteer_id'] ?? 0;
            }
        } else if ($request_type == 'donor') {
            $getUser = $conn->query("SELECT donor_id FROM `$tableName` WHERE `$idColumn` = $request_id");
            if ($getUser && $getUser->num_rows > 0) {
                $userRow = $getUser->fetch_assoc();
                $userId = $userRow['donor_id'] ?? 0;
            }
        }
        
        // Get request title for notification
        $getRequest = $conn->query("SELECT request_title FROM `$tableName` WHERE `$idColumn` = $request_id");
        $requestTitle = 'Your Request';
        if ($getRequest && $getRequest->num_rows > 0) {
            $reqRow = $getRequest->fetch_assoc();
            $requestTitle = $reqRow['request_title'] ?? 'Your Request';
        }
        
        // Insert notification
        if ($userId > 0) {
            $notifStmt = $conn->prepare("INSERT INTO notifications (user_type, user_id, request_type, request_id, title, message) VALUES (?, ?, ?, ?, ?, ?)");
            $notifTitle = "Request Accepted: $requestTitle";
            $notifMessage = "Your help request has been accepted by the administrator. It is now visible to other users who can help.";
            $notifStmt->bind_param("siisss", $request_type, $userId, $request_type, $request_id, $notifTitle, $notifMessage);
            $notifStmt->execute();
            $notifStmt->close();
        }
        
        sendResponse(true, "Request accepted successfully. It is now visible to other users.");
    } else {
        sendResponse(false, "Request not found or already processed");
    }
} else {
    sendResponse(false, "Failed to accept request: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

