-- ============================================
-- Admin Approval Workflow - Complete Setup (Optimized)
-- Creates tables and adds admin approval fields
-- Run this in phpMyAdmin SQL tab on 'helphup' database
-- URL: http://localhost/phpmyadmin/db_sql.php?db=helphup
-- ============================================

-- ============================================
-- 1. CREATE/UPDATE NGO HELP REQUESTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `ngo_help_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ngo_id` INT(11) NOT NULL,
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `urgency_level` VARCHAR(20) NOT NULL,
  `required_amount` DECIMAL(10,2) NOT NULL,
  `date_needed` DATE NOT NULL,
  `contact_number` VARCHAR(20) NOT NULL,
  `description` TEXT NOT NULL,
  `status` VARCHAR(20) DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  FOREIGN KEY (`ngo_id`) REFERENCES `ngo`(`ngo_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add admin approval columns (only if they don't exist)
SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'ngo_help_requests' 
   AND COLUMN_NAME = 'admin_status') = 0,
  'ALTER TABLE `ngo_help_requests` ADD COLUMN `admin_status` VARCHAR(20) DEFAULT ''pending'' COMMENT ''pending, verified, accepted, rejected''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'ngo_help_requests' 
   AND COLUMN_NAME = 'admin_id') = 0,
  'ALTER TABLE `ngo_help_requests` ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT ''Admin who reviewed this request''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'ngo_help_requests' 
   AND COLUMN_NAME = 'admin_reviewed_at') = 0,
  'ALTER TABLE `ngo_help_requests` ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT ''When admin reviewed this request''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'ngo_help_requests' 
   AND COLUMN_NAME = 'rejection_reason') = 0,
  'ALTER TABLE `ngo_help_requests` ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT ''Reason if rejected by admin''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add indexes (only if they don't exist)
SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'ngo_help_requests' 
   AND INDEX_NAME = 'idx_admin_status') = 0,
  'ALTER TABLE `ngo_help_requests` ADD INDEX `idx_admin_status` (`admin_status`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'ngo_help_requests' 
   AND INDEX_NAME = 'idx_admin_id') = 0,
  'ALTER TABLE `ngo_help_requests` ADD INDEX `idx_admin_id` (`admin_id`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================
-- 2. CREATE/UPDATE VOLUNTEER REQUESTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `volunteer_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `volunteer_id` INT(11) NOT NULL,
  `request_title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `description` TEXT NOT NULL,
  `location` VARCHAR(200) NOT NULL,
  `help_date` DATE NOT NULL,
  `start_time` TIME NOT NULL,
  `volunteers_needed` INT(11) NOT NULL,
  `status` VARCHAR(20) DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  FOREIGN KEY (`volunteer_id`) REFERENCES `volunteer`(`volunteer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add admin approval columns
SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'volunteer_requests' 
   AND COLUMN_NAME = 'admin_status') = 0,
  'ALTER TABLE `volunteer_requests` ADD COLUMN `admin_status` VARCHAR(20) DEFAULT ''pending'' COMMENT ''pending, verified, accepted, rejected''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'volunteer_requests' 
   AND COLUMN_NAME = 'admin_id') = 0,
  'ALTER TABLE `volunteer_requests` ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT ''Admin who reviewed this request''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'volunteer_requests' 
   AND COLUMN_NAME = 'admin_reviewed_at') = 0,
  'ALTER TABLE `volunteer_requests` ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT ''When admin reviewed this request''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'volunteer_requests' 
   AND COLUMN_NAME = 'rejection_reason') = 0,
  'ALTER TABLE `volunteer_requests` ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT ''Reason if rejected by admin''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add indexes
SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'volunteer_requests' 
   AND INDEX_NAME = 'idx_admin_status') = 0,
  'ALTER TABLE `volunteer_requests` ADD INDEX `idx_admin_status` (`admin_status`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'volunteer_requests' 
   AND INDEX_NAME = 'idx_admin_id') = 0,
  'ALTER TABLE `volunteer_requests` ADD INDEX `idx_admin_id` (`admin_id`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================
-- 3. CREATE/UPDATE DONOR CAMPAIGNS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `donor_campaigns` (
  `campaign_id` INT(11) NOT NULL AUTO_INCREMENT,
  `donor_id` INT(11) NOT NULL,
  `campaign_title` VARCHAR(200) NOT NULL,
  `fundraising_goal` DECIMAL(10,2) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `cover_image_url` VARCHAR(255) DEFAULT NULL,
  `video_url` VARCHAR(255) DEFAULT NULL,
  `duration` VARCHAR(50) NOT NULL,
  `end_date` DATE NOT NULL,
  `beneficiary_name` VARCHAR(100) NOT NULL,
  `relationship` VARCHAR(50) NOT NULL,
  `contact_email` VARCHAR(100) NOT NULL,
  `status` VARCHAR(20) DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`campaign_id`),
  FOREIGN KEY (`donor_id`) REFERENCES `donor`(`donor_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add admin approval columns
SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'donor_campaigns' 
   AND COLUMN_NAME = 'admin_status') = 0,
  'ALTER TABLE `donor_campaigns` ADD COLUMN `admin_status` VARCHAR(20) DEFAULT ''pending'' COMMENT ''pending, verified, accepted, rejected''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'donor_campaigns' 
   AND COLUMN_NAME = 'admin_id') = 0,
  'ALTER TABLE `donor_campaigns` ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT ''Admin who reviewed this campaign''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'donor_campaigns' 
   AND COLUMN_NAME = 'admin_reviewed_at') = 0,
  'ALTER TABLE `donor_campaigns` ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT ''When admin reviewed this campaign''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'donor_campaigns' 
   AND COLUMN_NAME = 'rejection_reason') = 0,
  'ALTER TABLE `donor_campaigns` ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT ''Reason if rejected by admin''',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add indexes
SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'donor_campaigns' 
   AND INDEX_NAME = 'idx_admin_status') = 0,
  'ALTER TABLE `donor_campaigns` ADD INDEX `idx_admin_status` (`admin_status`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
   WHERE TABLE_SCHEMA = DATABASE() 
   AND TABLE_NAME = 'donor_campaigns' 
   AND INDEX_NAME = 'idx_admin_id') = 0,
  'ALTER TABLE `donor_campaigns` ADD INDEX `idx_admin_id` (`admin_id`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================
-- 4. UPDATE EXISTING RECORDS
-- ============================================
UPDATE `ngo_help_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

UPDATE `volunteer_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

UPDATE `donor_campaigns` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

-- ============================================
-- SUCCESS MESSAGE
-- ============================================
SELECT 'Admin approval workflow setup completed successfully!' AS message;

