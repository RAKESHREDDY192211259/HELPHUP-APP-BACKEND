-- Admin Approval Workflow Setup for HelpHup (Simple Version)
-- This file adds admin approval fields to existing help request tables
-- Run this in phpMyAdmin SQL tab on 'helphup' database
-- 
-- NOTE: If columns already exist, you'll get an error. That's okay - just ignore it.
-- Or run the "check" queries first to see what's missing.

-- ============================================
-- 1. UPDATE NGO HELP REQUESTS TABLE
-- Add admin approval fields
-- ============================================
ALTER TABLE `ngo_help_requests` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

ALTER TABLE `ngo_help_requests` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this request';

ALTER TABLE `ngo_help_requests` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this request';

ALTER TABLE `ngo_help_requests` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes
ALTER TABLE `ngo_help_requests` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `ngo_help_requests` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- ============================================
-- 2. UPDATE VOLUNTEER REQUESTS TABLE
-- Add admin approval fields
-- ============================================
ALTER TABLE `volunteer_requests` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

ALTER TABLE `volunteer_requests` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this request';

ALTER TABLE `volunteer_requests` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this request';

ALTER TABLE `volunteer_requests` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes
ALTER TABLE `volunteer_requests` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `volunteer_requests` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- ============================================
-- 3. UPDATE DONOR CAMPAIGNS TABLE
-- Add admin approval fields
-- ============================================
ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected';

ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_id` INT(11) DEFAULT NULL COMMENT 'Admin who reviewed this campaign';

ALTER TABLE `donor_campaigns` 
ADD COLUMN `admin_reviewed_at` TIMESTAMP NULL DEFAULT NULL COMMENT 'When admin reviewed this campaign';

ALTER TABLE `donor_campaigns` 
ADD COLUMN `rejection_reason` TEXT DEFAULT NULL COMMENT 'Reason if rejected by admin';

-- Add indexes
ALTER TABLE `donor_campaigns` 
ADD INDEX `idx_admin_status` (`admin_status`);

ALTER TABLE `donor_campaigns` 
ADD INDEX `idx_admin_id` (`admin_id`);

-- ============================================
-- 4. UPDATE EXISTING RECORDS
-- Set all existing requests to 'pending' status if they don't have admin_status
-- ============================================
UPDATE `ngo_help_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

UPDATE `volunteer_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

UPDATE `donor_campaigns` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

-- ============================================
-- Verification Queries (run these to check)
-- ============================================
-- Check NGO help requests table structure
-- DESCRIBE ngo_help_requests;

-- Check Volunteer requests table structure
-- DESCRIBE volunteer_requests;

-- Check Donor campaigns table structure
-- DESCRIBE donor_campaigns;

-- Count pending requests
-- SELECT 'NGO' as type, COUNT(*) as pending_count FROM ngo_help_requests WHERE admin_status = 'pending'
-- UNION ALL
-- SELECT 'Volunteer' as type, COUNT(*) as pending_count FROM volunteer_requests WHERE admin_status = 'pending'
-- UNION ALL
-- SELECT 'Donor' as type, COUNT(*) as pending_count FROM donor_campaigns WHERE admin_status = 'pending';

