-- Admin Approval Workflow Setup for HelpHup (Version 2 - Stored Procedure)
-- This file adds admin approval fields to existing help request tables
-- Run this in phpMyAdmin SQL tab on 'helphup' database
--
-- This version uses a stored procedure for cleaner syntax

DELIMITER $$

DROP PROCEDURE IF EXISTS AddColumnIfNotExists$$
CREATE PROCEDURE AddColumnIfNotExists(
    IN tableName VARCHAR(64),
    IN columnName VARCHAR(64),
    IN columnDefinition TEXT
)
BEGIN
    DECLARE columnExists INT DEFAULT 0;
    
    SELECT COUNT(*) INTO columnExists
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = tableName
      AND COLUMN_NAME = columnName;
    
    IF columnExists = 0 THEN
        SET @sql = CONCAT('ALTER TABLE `', tableName, '` ADD COLUMN `', columnName, '` ', columnDefinition);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DROP PROCEDURE IF EXISTS AddIndexIfNotExists$$
CREATE PROCEDURE AddIndexIfNotExists(
    IN tableName VARCHAR(64),
    IN indexName VARCHAR(64),
    IN indexDefinition TEXT
)
BEGIN
    DECLARE indexExists INT DEFAULT 0;
    
    SELECT COUNT(*) INTO indexExists
    FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = tableName
      AND INDEX_NAME = indexName;
    
    IF indexExists = 0 THEN
        SET @sql = CONCAT('ALTER TABLE `', tableName, '` ADD INDEX `', indexName, '` ', indexDefinition);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;

-- ============================================
-- 1. UPDATE NGO HELP REQUESTS TABLE
-- ============================================
CALL AddColumnIfNotExists('ngo_help_requests', 'admin_status', 'VARCHAR(20) DEFAULT ''pending'' COMMENT ''pending, verified, accepted, rejected''');
CALL AddColumnIfNotExists('ngo_help_requests', 'admin_id', 'INT(11) DEFAULT NULL COMMENT ''Admin who reviewed this request''');
CALL AddColumnIfNotExists('ngo_help_requests', 'admin_reviewed_at', 'TIMESTAMP NULL DEFAULT NULL COMMENT ''When admin reviewed this request''');
CALL AddColumnIfNotExists('ngo_help_requests', 'rejection_reason', 'TEXT DEFAULT NULL COMMENT ''Reason if rejected by admin''');

CALL AddIndexIfNotExists('ngo_help_requests', 'idx_admin_status', '(`admin_status`)');
CALL AddIndexIfNotExists('ngo_help_requests', 'idx_admin_id', '(`admin_id`)');

-- ============================================
-- 2. UPDATE VOLUNTEER REQUESTS TABLE
-- ============================================
CALL AddColumnIfNotExists('volunteer_requests', 'admin_status', 'VARCHAR(20) DEFAULT ''pending'' COMMENT ''pending, verified, accepted, rejected''');
CALL AddColumnIfNotExists('volunteer_requests', 'admin_id', 'INT(11) DEFAULT NULL COMMENT ''Admin who reviewed this request''');
CALL AddColumnIfNotExists('volunteer_requests', 'admin_reviewed_at', 'TIMESTAMP NULL DEFAULT NULL COMMENT ''When admin reviewed this request''');
CALL AddColumnIfNotExists('volunteer_requests', 'rejection_reason', 'TEXT DEFAULT NULL COMMENT ''Reason if rejected by admin''');

CALL AddIndexIfNotExists('volunteer_requests', 'idx_admin_status', '(`admin_status`)');
CALL AddIndexIfNotExists('volunteer_requests', 'idx_admin_id', '(`admin_id`)');

-- ============================================
-- 3. UPDATE DONOR CAMPAIGNS TABLE
-- ============================================
CALL AddColumnIfNotExists('donor_campaigns', 'admin_status', 'VARCHAR(20) DEFAULT ''pending'' COMMENT ''pending, verified, accepted, rejected''');
CALL AddColumnIfNotExists('donor_campaigns', 'admin_id', 'INT(11) DEFAULT NULL COMMENT ''Admin who reviewed this campaign''');
CALL AddColumnIfNotExists('donor_campaigns', 'admin_reviewed_at', 'TIMESTAMP NULL DEFAULT NULL COMMENT ''When admin reviewed this campaign''');
CALL AddColumnIfNotExists('donor_campaigns', 'rejection_reason', 'TEXT DEFAULT NULL COMMENT ''Reason if rejected by admin''');

CALL AddIndexIfNotExists('donor_campaigns', 'idx_admin_status', '(`admin_status`)');
CALL AddIndexIfNotExists('donor_campaigns', 'idx_admin_id', '(`admin_id`)');

-- ============================================
-- Clean up procedures
-- ============================================
DROP PROCEDURE IF EXISTS AddColumnIfNotExists;
DROP PROCEDURE IF EXISTS AddIndexIfNotExists;

-- ============================================
-- 4. UPDATE EXISTING RECORDS
-- ============================================
UPDATE `ngo_help_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

UPDATE `volunteer_requests` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

UPDATE `donor_campaigns` 
SET `admin_status` = 'pending' 
WHERE `admin_status` IS NULL OR `admin_status` = '';

-- ============================================
-- Verification Queries (optional - run to check)
-- ============================================
-- DESCRIBE ngo_help_requests;
-- DESCRIBE volunteer_requests;
-- DESCRIBE donor_campaigns;

