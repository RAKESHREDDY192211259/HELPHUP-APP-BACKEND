<?php
/**
 * Get all users by category (NGOs, Volunteers, Donors)
 * Returns all users with their details for admin management
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get user type from request
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    $user_type = $data['user_type'] ?? ($_GET['user_type'] ?? '');
    
    if (empty($user_type) || !in_array($user_type, ['ngo', 'volunteer', 'donor'])) {
        sendResponse(false, "Valid user_type is required (ngo, volunteer, or donor)");
    }
    
    $users = array();
    
    switch ($user_type) {
        case 'ngo':
            // Find NGO table
            $ngoTableName = null;
            $ngoIdColumn = 'ngo_id';
            $ngoTables = ['ngo', 'ngos'];
            foreach ($ngoTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $ngoTableName = $table;
                    // Check which column exists
                    $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
                    $checkNgoId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'ngo_id'");
                    if ($checkId && $checkId->num_rows > 0) {
                        $ngoIdColumn = 'id';
                    } elseif ($checkNgoId && $checkNgoId->num_rows > 0) {
                        $ngoIdColumn = 'ngo_id';
                    }
                    break;
                }
            }
            
            if (!$ngoTableName) {
                sendResponse(false, "NGO table not found");
            }
            
            // Check if status column exists
            $checkStatus = $conn->query("SHOW COLUMNS FROM `$ngoTableName` LIKE 'status'");
            $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
            
            $sql = "SELECT 
                $ngoIdColumn as user_id,
                full_name,
                phone,
                email,
                address,
                org_name,
                reg_number,
                reg_proof_file,
                " . ($hasStatus ? "COALESCE(status, 'active') as status" : "'active' as status") . ",
                created_at
            FROM `$ngoTableName`
            ORDER BY created_at DESC";
            
            $result = $conn->query($sql);
            if (!$result) {
                throw new Exception("Query failed: " . $conn->error);
            }
            
            while ($row = $result->fetch_assoc()) {
                $users[] = array(
                    'user_id' => (int)$row['user_id'],
                    'full_name' => $row['full_name'],
                    'phone' => $row['phone'],
                    'email' => $row['email'],
                    'address' => $row['address'],
                    'org_name' => $row['org_name'] ?? '',
                    'reg_number' => $row['reg_number'] ?? '',
                    'reg_proof_file' => $row['reg_proof_file'] ?? null,
                    'status' => $row['status'] ?? 'active',
                    'created_at' => $row['created_at'],
                    'user_type' => 'ngo'
                );
            }
            break;
            
        case 'volunteer':
            // Find Volunteer table
            $volunteerTableName = null;
            $volunteerIdColumn = 'volunteer_id';
            $volunteerTables = ['volunteer', 'volunteers'];
            foreach ($volunteerTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $volunteerTableName = $table;
                    // Check which column exists
                    $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
                    $checkVolunteerId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'volunteer_id'");
                    if ($checkId && $checkId->num_rows > 0) {
                        $volunteerIdColumn = 'id';
                    } elseif ($checkVolunteerId && $checkVolunteerId->num_rows > 0) {
                        $volunteerIdColumn = 'volunteer_id';
                    }
                    break;
                }
            }
            
            if (!$volunteerTableName) {
                sendResponse(false, "Volunteer table not found");
            }
            
            // Check if status column exists
            $checkStatus = $conn->query("SHOW COLUMNS FROM `$volunteerTableName` LIKE 'status'");
            $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
            
            $sql = "SELECT 
                $volunteerIdColumn as user_id,
                full_name,
                phone,
                email,
                skills,
                availability,
                " . ($hasStatus ? "COALESCE(status, 'active') as status" : "'active' as status") . ",
                created_at
            FROM `$volunteerTableName`
            ORDER BY created_at DESC";
            
            $result = $conn->query($sql);
            if (!$result) {
                throw new Exception("Query failed: " . $conn->error);
            }
            
            while ($row = $result->fetch_assoc()) {
                $users[] = array(
                    'user_id' => (int)$row['user_id'],
                    'full_name' => $row['full_name'],
                    'phone' => $row['phone'],
                    'email' => $row['email'],
                    'skills' => $row['skills'] ?? '',
                    'availability' => $row['availability'] ?? '',
                    'status' => $row['status'] ?? 'active',
                    'created_at' => $row['created_at'],
                    'user_type' => 'volunteer'
                );
            }
            break;
            
        case 'donor':
            // Find Donor table
            $donorTableName = null;
            $donorIdColumn = 'donor_id';
            $donorTables = ['donor', 'donors'];
            foreach ($donorTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $donorTableName = $table;
                    // Check which column exists
                    $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
                    $checkDonorId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'donor_id'");
                    if ($checkId && $checkId->num_rows > 0) {
                        $donorIdColumn = 'id';
                    } elseif ($checkDonorId && $checkDonorId->num_rows > 0) {
                        $donorIdColumn = 'donor_id';
                    }
                    break;
                }
            }
            
            if (!$donorTableName) {
                sendResponse(false, "Donor table not found");
            }
            
            // Check if status column exists
            $checkStatus = $conn->query("SHOW COLUMNS FROM `$donorTableName` LIKE 'status'");
            $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
            
            $sql = "SELECT 
                $donorIdColumn as user_id,
                full_name,
                phone,
                email,
                address,
                " . ($hasStatus ? "COALESCE(status, 'active') as status" : "'active' as status") . ",
                created_at
            FROM `$donorTableName`
            ORDER BY created_at DESC";
            
            $result = $conn->query($sql);
            if (!$result) {
                throw new Exception("Query failed: " . $conn->error);
            }
            
            while ($row = $result->fetch_assoc()) {
                $users[] = array(
                    'user_id' => (int)$row['user_id'],
                    'full_name' => $row['full_name'],
                    'phone' => $row['phone'],
                    'email' => $row['email'],
                    'address' => $row['address'],
                    'status' => $row['status'] ?? 'active',
                    'created_at' => $row['created_at'],
                    'user_type' => 'donor'
                );
            }
            break;
    }
    
    sendResponse(true, "Users fetched successfully", $users);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

