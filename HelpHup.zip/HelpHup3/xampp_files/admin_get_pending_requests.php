<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

// Get JSON input (optional - can also use GET)
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$request_type = $data['request_type'] ?? $_GET['request_type'] ?? 'all'; // 'ngo', 'volunteer', 'donor', 'all'

$allRequests = array();

// Get NGO Help Requests (pending admin approval)
if ($request_type == 'all' || $request_type == 'ngo') {
    try {
        // Check which table exists: ngoraisehelp or ngo_help_requests
        $checkTable1 = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
        $checkTable2 = $conn->query("SHOW TABLES LIKE 'ngo_help_requests'");
        
        if ($checkTable1->num_rows > 0) {
            // Use ngoraisehelp table (existing table)
            // Check if admin_status column exists
            $checkColumn = $conn->query("SHOW COLUMNS FROM ngoraisehelp LIKE 'admin_status'");
            $hasAdminStatus = $checkColumn->num_rows > 0;
            
            if ($hasAdminStatus) {
                // Column exists - show requests where admin_status is 'pending' or NULL
                // Check which parent table exists: ngos or ngo
                $checkNgos = $conn->query("SHOW TABLES LIKE 'ngos'");
                $checkNgo = $conn->query("SHOW TABLES LIKE 'ngo'");
                
                if ($checkNgos->num_rows > 0) {
                    // Use ngos table - check what the primary key column is called
                    $checkPK = $conn->query("SHOW COLUMNS FROM ngos WHERE `Key` = 'PRI'");
                    $pkInfo = $checkPK->fetch_assoc();
                    $ngoPKColumn = $pkInfo ? $pkInfo['Field'] : 'id'; // Default to 'id' if not found
                    
                    // Use ngos table
                    $stmt = $conn->prepare("
                        SELECT 
                            r.id as request_id,
                            'ngo' as request_type,
                            r.ngo_id,
                            r.request_title,
                            r.category,
                            r.urgency_level,
                            r.required_amount,
                            r.date_needed,
                            r.contact_number,
                            r.description,
                            COALESCE(r.admin_status, 'pending') as admin_status,
                            r.created_at,
                            n.full_name as submitter_name,
                            n.email as submitter_email,
                            n.org_name as submitter_org
                        FROM ngoraisehelp r
                        LEFT JOIN ngos n ON r.ngo_id = n.`$ngoPKColumn`
                        WHERE r.admin_status = 'pending' OR r.admin_status IS NULL
                        ORDER BY r.created_at DESC
                    ");
                } else if ($checkNgo->num_rows > 0) {
                    // Use ngo table - check what the primary key column is called
                    $checkPK = $conn->query("SHOW COLUMNS FROM ngo WHERE `Key` = 'PRI'");
                    $pkInfo = $checkPK->fetch_assoc();
                    $ngoPKColumn = $pkInfo ? $pkInfo['Field'] : 'ngo_id'; // Default to 'ngo_id' if not found
                    
                    // Use ngo table
                    $stmt = $conn->prepare("
                        SELECT 
                            r.id as request_id,
                            'ngo' as request_type,
                            r.ngo_id,
                            r.request_title,
                            r.category,
                            r.urgency_level,
                            r.required_amount,
                            r.date_needed,
                            r.contact_number,
                            r.description,
                            COALESCE(r.admin_status, 'pending') as admin_status,
                            r.created_at,
                            n.full_name as submitter_name,
                            n.email as submitter_email,
                            n.org_name as submitter_org
                        FROM ngoraisehelp r
                        LEFT JOIN ngo n ON r.ngo_id = n.`$ngoPKColumn`
                        WHERE r.admin_status = 'pending' OR r.admin_status IS NULL
                        ORDER BY r.created_at DESC
                    ");
                } else {
                    // No parent table, get requests without join
                    $stmt = $conn->prepare("
                        SELECT 
                            r.id as request_id,
                            'ngo' as request_type,
                            r.ngo_id,
                            r.request_title,
                            r.category,
                            r.urgency_level,
                            r.required_amount,
                            r.date_needed,
                            r.contact_number,
                            r.description,
                            COALESCE(r.admin_status, 'pending') as admin_status,
                            r.created_at,
                            'NGO User' as submitter_name,
                            'ngo@example.com' as submitter_email,
                            NULL as submitter_org
                        FROM ngoraisehelp r
                        WHERE r.admin_status = 'pending' OR r.admin_status IS NULL
                        ORDER BY r.created_at DESC
                    ");
                }
            } else {
                // admin_status column doesn't exist, show all requests as pending
                $stmt = $conn->prepare("
                    SELECT 
                        r.id as request_id,
                        'ngo' as request_type,
                        r.ngo_id,
                        r.request_title,
                        r.category,
                        r.urgency_level,
                        r.required_amount,
                        r.date_needed,
                        r.contact_number,
                        r.description,
                        'pending' as admin_status,
                        r.created_at,
                        n.full_name as submitter_name,
                        n.email as submitter_email,
                        n.org_name as submitter_org
                    FROM ngoraisehelp r
                    LEFT JOIN ngos n ON r.ngo_id = n.ngo_id
                    ORDER BY r.created_at DESC
                ");
            }
            
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }
        } else if ($checkTable2->num_rows > 0) {
            // Use ngo_help_requests table (new table)
            $stmt = $conn->prepare("
                SELECT 
                    r.request_id,
                    'ngo' as request_type,
                    r.ngo_id,
                    r.request_title,
                    r.category,
                    r.urgency_level,
                    r.required_amount,
                    r.date_needed,
                    r.contact_number,
                    r.description,
                    r.admin_status,
                    r.created_at,
                    n.full_name as submitter_name,
                    n.email as submitter_email,
                    n.org_name as submitter_org
                FROM ngo_help_requests r
                LEFT JOIN ngo n ON r.ngo_id = n.ngo_id
                WHERE r.admin_status = 'pending'
                ORDER BY r.created_at DESC
            ");
        } else {
            // No table exists
            $stmt = null;
        }
        
        if ($stmt) {
            if (!$stmt->execute()) {
                throw new Exception("Execute failed: " . $stmt->error);
            }
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $allRequests[] = $row;
            }
            $stmt->close();
        }
    } catch (Exception $e) {
        sendResponse(false, "Error fetching NGO requests: " . $e->getMessage());
    }
}

// Get Volunteer Requests (pending admin approval)
if ($request_type == 'all' || $request_type == 'volunteer') {
    try {
        // Check which table exists: volunteerraisehelp or volunteer_requests
        $checkTable1 = $conn->query("SHOW TABLES LIKE 'volunteerraisehelp'");
        $checkTable2 = $conn->query("SHOW TABLES LIKE 'volunteer_requests'");
        
        if ($checkTable1 && $checkTable1->num_rows > 0) {
            // Use volunteerraisehelp table (existing table)
            // Check if admin_status column exists
            $checkAdminStatus = $conn->query("SHOW COLUMNS FROM volunteerraisehelp LIKE 'admin_status'");
            $hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
            
            if ($hasAdminStatus) {
                $stmt = $conn->prepare("
                    SELECT 
                        r.id as request_id,
                        'volunteer' as request_type,
                        r.volunteer_id,
                        r.request_title,
                        r.category,
                        r.description,
                        r.location,
                        r.help_date,
                        r.start_time,
                        r.volunteers_needed,
                        COALESCE(r.admin_status, 'pending') as admin_status,
                        r.created_at,
                        v.full_name as submitter_name,
                        v.email as submitter_email,
                        NULL as submitter_org
                    FROM volunteerraisehelp r
                    LEFT JOIN volunteers v ON r.volunteer_id = v.volunteer_id
                    WHERE COALESCE(r.admin_status, 'pending') = 'pending'
                    ORDER BY r.created_at DESC
                ");
            } else {
                // Column doesn't exist - show all as pending
                $stmt = $conn->prepare("
                    SELECT 
                        r.id as request_id,
                        'volunteer' as request_type,
                        r.volunteer_id,
                        r.request_title,
                        r.category,
                        r.description,
                        r.location,
                        r.help_date,
                        r.start_time,
                        r.volunteers_needed,
                        'pending' as admin_status,
                        r.created_at,
                        v.full_name as submitter_name,
                        v.email as submitter_email,
                        NULL as submitter_org
                    FROM volunteerraisehelp r
                    LEFT JOIN volunteers v ON r.volunteer_id = v.volunteer_id
                    ORDER BY r.created_at DESC
                ");
            }
        } else if ($checkTable2 && $checkTable2->num_rows > 0) {
            // Use volunteer_requests table (new table)
            // Check if admin_status column exists
            $checkAdminStatus = $conn->query("SHOW COLUMNS FROM volunteer_requests LIKE 'admin_status'");
            $hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
            
            if ($hasAdminStatus) {
                $stmt = $conn->prepare("
                    SELECT 
                        r.request_id,
                        'volunteer' as request_type,
                        r.volunteer_id,
                        r.request_title,
                        r.category,
                        r.description,
                        r.location,
                        r.help_date,
                        r.start_time,
                        r.volunteers_needed,
                        COALESCE(r.admin_status, 'pending') as admin_status,
                        r.created_at,
                        v.full_name as submitter_name,
                        v.email as submitter_email,
                        NULL as submitter_org
                    FROM volunteer_requests r
                    LEFT JOIN volunteer v ON r.volunteer_id = v.volunteer_id
                    WHERE COALESCE(r.admin_status, 'pending') = 'pending'
                    ORDER BY r.created_at DESC
                ");
            } else {
                // Column doesn't exist - show all as pending and log warning
                error_log("WARNING: admin_status column missing in volunteer_requests table. Please run add_admin_status_to_tables.sql");
                $stmt = $conn->prepare("
                    SELECT 
                        r.request_id,
                        'volunteer' as request_type,
                        r.volunteer_id,
                        r.request_title,
                        r.category,
                        r.description,
                        r.location,
                        r.help_date,
                        r.start_time,
                        r.volunteers_needed,
                        'pending' as admin_status,
                        r.created_at,
                        v.full_name as submitter_name,
                        v.email as submitter_email,
                        NULL as submitter_org
                    FROM volunteer_requests r
                    LEFT JOIN volunteer v ON r.volunteer_id = v.volunteer_id
                    ORDER BY r.created_at DESC
                ");
            }
        } else {
            $stmt = null;
        }
        
        if ($stmt) {
            if (!$stmt->execute()) {
                throw new Exception("Execute failed: " . $stmt->error);
            }
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $allRequests[] = $row;
            }
            $stmt->close();
        }
    } catch (Exception $e) {
        error_log("Error fetching Volunteer requests: " . $e->getMessage());
        // Don't fail completely, just log and continue
    }
}

// Get Donor Campaigns (pending admin approval)
if ($request_type == 'all' || $request_type == 'donor') {
    try {
        // Check if table exists
        $checkTable = $conn->query("SHOW TABLES LIKE 'donor_campaigns'");
        if ($checkTable && $checkTable->num_rows > 0) {
            // Check if admin_status column exists
            $checkColumn = $conn->query("SHOW COLUMNS FROM donor_campaigns LIKE 'admin_status'");
            $hasAdminStatus = $checkColumn && $checkColumn->num_rows > 0;
            
            // Check primary key column name
            $checkPK = $conn->query("SHOW COLUMNS FROM donor_campaigns WHERE `Key` = 'PRI'");
            $pkInfo = $checkPK ? $checkPK->fetch_assoc() : null;
            $pkColumn = $pkInfo ? $pkInfo['Field'] : 'campaign_id';
            
            if ($hasAdminStatus) {
                // Column exists - filter by admin_status
                $stmt = $conn->prepare("
                    SELECT 
                        r.`$pkColumn` as request_id,
                        'donor' as request_type,
                        r.donor_id,
                        r.campaign_title as request_title,
                        r.category,
                        r.fundraising_goal as required_amount,
                        r.end_date as date_needed,
                        r.beneficiary_name,
                        r.relationship,
                        r.contact_email,
                        r.cover_image_url,
                        r.video_url,
                        r.duration,
                        COALESCE(r.admin_status, 'pending') as admin_status,
                        r.created_at,
                        d.full_name as submitter_name,
                        d.email as submitter_email,
                        NULL as submitter_org
                    FROM donor_campaigns r
                    LEFT JOIN donor d ON r.donor_id = d.donor_id
                    WHERE COALESCE(r.admin_status, 'pending') = 'pending'
                    ORDER BY r.created_at DESC
                ");
            } else {
                // Column doesn't exist - show all as pending and log warning
                error_log("WARNING: admin_status column missing in donor_campaigns table. Please run add_admin_status_to_tables.sql");
                $stmt = $conn->prepare("
                    SELECT 
                        r.`$pkColumn` as request_id,
                        'donor' as request_type,
                        r.donor_id,
                        r.campaign_title as request_title,
                        r.category,
                        r.fundraising_goal as required_amount,
                        r.end_date as date_needed,
                        r.beneficiary_name,
                        r.relationship,
                        r.contact_email,
                        r.cover_image_url,
                        r.video_url,
                        r.duration,
                        'pending' as admin_status,
                        r.created_at,
                        d.full_name as submitter_name,
                        d.email as submitter_email,
                        NULL as submitter_org
                    FROM donor_campaigns r
                    LEFT JOIN donor d ON r.donor_id = d.donor_id
                    ORDER BY r.created_at DESC
                ");
            }
            
            if ($stmt) {
                if (!$stmt->execute()) {
                    throw new Exception("Execute failed: " . $stmt->error);
                }
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    $allRequests[] = $row;
                }
                $stmt->close();
            }
        }
    } catch (Exception $e) {
        error_log("Error fetching Donor campaigns: " . $e->getMessage());
        // Don't fail completely, just log and continue
    }
}

sendResponse(true, "Pending requests retrieved successfully", $allRequests);

$conn->close();
?>

