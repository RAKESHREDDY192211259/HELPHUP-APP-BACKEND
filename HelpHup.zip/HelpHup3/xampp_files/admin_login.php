<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

if (empty($email) || empty($password)) {
    sendResponse(false, "Email and password are required");
}

// Query database
$stmt = $conn->prepare("SELECT admin_id, full_name, email, password FROM admin WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        sendResponse(true, "Login successful", array(
            'admin_id' => $row['admin_id'],
            'full_name' => $row['full_name'],
            'email' => $row['email']
        ));
    } else {
        sendResponse(false, "Invalid password");
    }
} else {
    sendResponse(false, "Email not found");
}

$stmt->close();
$conn->close();
?>










