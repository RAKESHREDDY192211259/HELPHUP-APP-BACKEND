<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$full_name = $data['full_name'] ?? '';
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

// Validate required fields
if (empty($full_name) || empty($email) || empty($password)) {
    sendResponse(false, "All fields are required");
}

// Check if email already exists
$check = $conn->prepare("SELECT admin_id FROM admin WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    sendResponse(false, "Email already registered");
}
$check->close();

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert into database
$stmt = $conn->prepare("INSERT INTO admin (full_name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $full_name, $email, $hashed_password);

if ($stmt->execute()) {
    sendResponse(true, "Registration successful");
} else {
    sendResponse(false, "Registration failed: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

