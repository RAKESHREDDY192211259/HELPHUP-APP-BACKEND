<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$request_type = $data['request_type'] ?? ''; // 'ngo', 'volunteer', 'donor'
$request_id = $data['request_id'] ?? 0;
$admin_id = $data['admin_id'] ?? 0;
$rejection_reason = $data['rejection_reason'] ?? '';

if (empty($request_type) || empty($request_id) || empty($admin_id)) {
    sendResponse(false, "Request type, request ID, and admin ID are required");
}

if (empty($rejection_reason)) {
    sendResponse(false, "Rejection reason is required");
}

// Determine table and column names based on actual table structure
$tableName = '';
$idColumn = '';
$statusColumn = '';

switch ($request_type) {
    case 'ngo':
        $checkTable1 = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
        $checkTable2 = $conn->query("SHOW TABLES LIKE 'ngo_help_requests'");
        
        if ($checkTable1->num_rows > 0) {
            $tableName = 'ngoraisehelp';
            $idColumn = 'id';
            $checkStatus = $conn->query("SHOW COLUMNS FROM ngoraisehelp LIKE 'status'");
            $statusColumn = $checkStatus->num_rows > 0 ? 'status' : null;
        } else if ($checkTable2->num_rows > 0) {
            $tableName = 'ngo_help_requests';
            $idColumn = 'request_id';
            $statusColumn = 'status';
        } else {
            sendResponse(false, "NGO requests table not found");
            exit;
        }
        break;
    case 'volunteer':
        $checkTable1 = $conn->query("SHOW TABLES LIKE 'volunteerraisehelp'");
        $checkTable2 = $conn->query("SHOW TABLES LIKE 'volunteer_requests'");
        
        if ($checkTable1->num_rows > 0) {
            $tableName = 'volunteerraisehelp';
            $idColumn = 'id';
            $checkStatus = $conn->query("SHOW COLUMNS FROM volunteerraisehelp LIKE 'status'");
            $statusColumn = $checkStatus->num_rows > 0 ? 'status' : null;
        } else if ($checkTable2->num_rows > 0) {
            $tableName = 'volunteer_requests';
            $idColumn = 'request_id';
            $statusColumn = 'status';
        } else {
            sendResponse(false, "Volunteer requests table not found");
            exit;
        }
        break;
    case 'donor':
        $tableName = 'donor_campaigns';
        $idColumn = 'campaign_id';
        $statusColumn = 'status';
        break;
    default:
        sendResponse(false, "Invalid request type");
        exit;
}

// Update admin_status to 'rejected' with rejection reason
if ($statusColumn) {
    $stmt = $conn->prepare("UPDATE `$tableName` SET admin_status = 'rejected', `$statusColumn` = 'rejected', admin_id = ?, admin_reviewed_at = NOW(), rejection_reason = ? WHERE `$idColumn` = ? AND (admin_status = 'pending' OR admin_status = 'verified')");
} else {
    $stmt = $conn->prepare("UPDATE `$tableName` SET admin_status = 'rejected', admin_id = ?, admin_reviewed_at = NOW(), rejection_reason = ? WHERE `$idColumn` = ? AND (admin_status = 'pending' OR admin_status = 'verified')");
}
$stmt->bind_param("isi", $admin_id, $rejection_reason, $request_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        // Create notification for the user
        // Get user details based on request type
        $userEmail = '';
        $userName = '';
        $userId = 0;
        
        if ($request_type == 'ngo') {
            // Get NGO email from ngoraisehelp table
            $getUser = $conn->query("SELECT r.ngo_id, n.email, n.full_name FROM `$tableName` r LEFT JOIN ngos n ON r.ngo_id = n.id WHERE r.$idColumn = $request_id");
            if ($getUser && $getUser->num_rows > 0) {
                $userRow = $getUser->fetch_assoc();
                $userId = $userRow['ngo_id'];
                $userEmail = $userRow['email'] ?? '';
                $userName = $userRow['full_name'] ?? 'NGO User';
            }
        } else if ($request_type == 'volunteer') {
            $getUser = $conn->query("SELECT r.volunteer_id, v.email, v.full_name FROM `$tableName` r LEFT JOIN volunteers v ON r.volunteer_id = v.id WHERE r.$idColumn = $request_id");
            if ($getUser && $getUser->num_rows > 0) {
                $userRow = $getUser->fetch_assoc();
                $userId = $userRow['volunteer_id'];
                $userEmail = $userRow['email'] ?? '';
                $userName = $userRow['full_name'] ?? 'Volunteer';
            }
        } else if ($request_type == 'donor') {
            $getUser = $conn->query("SELECT r.donor_id, d.email, d.full_name FROM `$tableName` r LEFT JOIN donors d ON r.donor_id = d.id WHERE r.$idColumn = $request_id");
            if ($getUser && $getUser->num_rows > 0) {
                $userRow = $getUser->fetch_assoc();
                $userId = $userRow['donor_id'];
                $userEmail = $userRow['email'] ?? '';
                $userName = $userRow['full_name'] ?? 'Donor';
            }
        }
        
        // Get request title for notification
        $getRequest = $conn->query("SELECT request_title FROM `$tableName` WHERE `$idColumn` = $request_id");
        $requestTitle = 'Your Request';
        if ($getRequest && $getRequest->num_rows > 0) {
            $reqRow = $getRequest->fetch_assoc();
            $requestTitle = $reqRow['request_title'] ?? 'Your Request';
        }
        
        // Insert notification
        if ($userId > 0) {
            $notifStmt = $conn->prepare("INSERT INTO notifications (user_type, user_id, request_type, request_id, title, message, rejection_reason) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $notifTitle = "Request Rejected: $requestTitle";
            $notifMessage = "Your help request has been rejected by the administrator.";
            $notifStmt->bind_param("siissss", $request_type, $userId, $request_type, $request_id, $notifTitle, $notifMessage, $rejection_reason);
            $notifStmt->execute();
            $notifStmt->close();
        }
        
        sendResponse(true, "Request rejected successfully. User has been notified.");
    } else {
        sendResponse(false, "Request not found or already processed");
    }
} else {
    sendResponse(false, "Failed to reject request: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

