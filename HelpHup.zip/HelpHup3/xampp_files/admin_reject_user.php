<?php
/**
 * Reject/Disable a user (NGO, Volunteer, or Donor)
 * Sets user status to 'rejected' or 'inactive'
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get JSON input
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    $user_type = $data['user_type'] ?? ''; // 'ngo', 'volunteer', 'donor'
    $user_id = $data['user_id'] ?? 0;
    $admin_id = $data['admin_id'] ?? 0;
    $rejection_reason = $data['rejection_reason'] ?? '';
    
    if (empty($user_type) || !in_array($user_type, ['ngo', 'volunteer', 'donor'])) {
        sendResponse(false, "Valid user_type is required (ngo, volunteer, or donor)");
    }
    
    if (empty($user_id) || $user_id <= 0) {
        sendResponse(false, "User ID is required");
    }
    
    if (empty($admin_id) || $admin_id <= 0) {
        sendResponse(false, "Admin ID is required");
    }
    
    if (empty($rejection_reason)) {
        sendResponse(false, "Rejection reason is required");
    }
    
    // Determine table and column names
    $tableName = '';
    $idColumn = '';
    
    switch ($user_type) {
        case 'ngo':
            $ngoTables = ['ngo', 'ngos'];
            foreach ($ngoTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $tableName = $table;
                    $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
                    $checkNgoId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'ngo_id'");
                    if ($checkId && $checkId->num_rows > 0) {
                        $idColumn = 'id';
                    } elseif ($checkNgoId && $checkNgoId->num_rows > 0) {
                        $idColumn = 'ngo_id';
                    } else {
                        $idColumn = 'ngo_id';
                    }
                    break;
                }
            }
            break;
            
        case 'volunteer':
            $volunteerTables = ['volunteer', 'volunteers'];
            foreach ($volunteerTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $tableName = $table;
                    $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
                    $checkVolunteerId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'volunteer_id'");
                    if ($checkId && $checkId->num_rows > 0) {
                        $idColumn = 'id';
                    } elseif ($checkVolunteerId && $checkVolunteerId->num_rows > 0) {
                        $idColumn = 'volunteer_id';
                    } else {
                        $idColumn = 'volunteer_id';
                    }
                    break;
                }
            }
            break;
            
        case 'donor':
            $donorTables = ['donor', 'donors'];
            foreach ($donorTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $tableName = $table;
                    $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
                    $checkDonorId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'donor_id'");
                    if ($checkId && $checkId->num_rows > 0) {
                        $idColumn = 'id';
                    } elseif ($checkDonorId && $checkDonorId->num_rows > 0) {
                        $idColumn = 'donor_id';
                    } else {
                        $idColumn = 'donor_id';
                    }
                    break;
                }
            }
            break;
    }
    
    if (empty($tableName) || empty($idColumn)) {
        sendResponse(false, "User table not found for type: $user_type");
    }
    
    // Check if status column exists
    $checkStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'status'");
    $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
    
    // Check if rejection_reason column exists
    $checkRejectionReason = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'rejection_reason'");
    $hasRejectionReason = $checkRejectionReason && $checkRejectionReason->num_rows > 0;
    
    // Update user status
    if ($hasStatus) {
        if ($hasRejectionReason) {
            $stmt = $conn->prepare("UPDATE `$tableName` SET status = 'rejected', rejection_reason = ?, admin_id = ?, admin_reviewed_at = NOW() WHERE `$idColumn` = ?");
            $stmt->bind_param("sii", $rejection_reason, $admin_id, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE `$tableName` SET status = 'rejected', admin_id = ?, admin_reviewed_at = NOW() WHERE `$idColumn` = ?");
            $stmt->bind_param("ii", $admin_id, $user_id);
        }
    } else {
        // If no status column, add it or use a different approach
        // For now, we'll try to add the column if it doesn't exist
        // But in production, you should add the column via migration
        sendResponse(false, "Status column does not exist. Please add a 'status' column to the $tableName table.");
    }
    
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            // Create notification for the user
            $getUser = $conn->query("SELECT email, full_name FROM `$tableName` WHERE `$idColumn` = $user_id");
            $userEmail = '';
            $userName = '';
            if ($getUser && $getUser->num_rows > 0) {
                $userRow = $getUser->fetch_assoc();
                $userEmail = $userRow['email'] ?? '';
                $userName = $userRow['full_name'] ?? 'User';
            }
            
            // Insert notification
            if (!empty($userEmail)) {
                $notifStmt = $conn->prepare("INSERT INTO notifications (user_type, user_id, request_type, request_id, title, message, rejection_reason) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $notifTitle = "Account Rejected";
                $notifMessage = "Your account has been rejected by the administrator.";
                $notifStmt->bind_param("siissss", $user_type, $user_id, $user_type, $user_id, $notifTitle, $notifMessage, $rejection_reason);
                $notifStmt->execute();
                $notifStmt->close();
            }
            
            sendResponse(true, "User rejected successfully. User has been notified.");
        } else {
            sendResponse(false, "User not found or already processed");
        }
    } else {
        sendResponse(false, "Failed to reject user: " . $conn->error);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

