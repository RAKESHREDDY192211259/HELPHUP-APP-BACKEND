<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$request_type = $data['request_type'] ?? ''; // 'ngo', 'volunteer', 'donor'
$request_id = $data['request_id'] ?? 0;
$admin_id = $data['admin_id'] ?? 0;

if (empty($request_type) || empty($request_id) || empty($admin_id)) {
    sendResponse(false, "Request type, request ID, and admin ID are required");
}

// Determine table and column names based on actual table structure
$tableName = '';
$idColumn = '';

switch ($request_type) {
    case 'ngo':
        $checkTable1 = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
        $checkTable2 = $conn->query("SHOW TABLES LIKE 'ngo_help_requests'");
        
        if ($checkTable1->num_rows > 0) {
            $tableName = 'ngoraisehelp';
            $idColumn = 'id';
        } else if ($checkTable2->num_rows > 0) {
            $tableName = 'ngo_help_requests';
            $idColumn = 'request_id';
        } else {
            sendResponse(false, "NGO requests table not found");
            exit;
        }
        break;
    case 'volunteer':
        $checkTable1 = $conn->query("SHOW TABLES LIKE 'volunteerraisehelp'");
        $checkTable2 = $conn->query("SHOW TABLES LIKE 'volunteer_requests'");
        
        if ($checkTable1->num_rows > 0) {
            $tableName = 'volunteerraisehelp';
            $idColumn = 'id';
        } else if ($checkTable2->num_rows > 0) {
            $tableName = 'volunteer_requests';
            $idColumn = 'request_id';
        } else {
            sendResponse(false, "Volunteer requests table not found");
            exit;
        }
        break;
    case 'donor':
        $tableName = 'donor_campaigns';
        $idColumn = 'campaign_id';
        break;
    default:
        sendResponse(false, "Invalid request type");
        exit;
}

// Update admin_status to 'verified'
$stmt = $conn->prepare("UPDATE `$tableName` SET admin_status = 'verified', admin_id = ?, admin_reviewed_at = NOW() WHERE `$idColumn` = ? AND admin_status = 'pending'");
$stmt->bind_param("ii", $admin_id, $request_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        sendResponse(true, "Request verified successfully");
    } else {
        sendResponse(false, "Request not found or already processed");
    }
} else {
    sendResponse(false, "Failed to verify request: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

