<?php
// Test new unified system
header("Content-Type: application/json");

// Database connection
$conn = new mysqli("localhost", "root", "", "helphup");

if ($conn->connect_error) {
    echo json_encode([
        "status" => false,
        "message" => "Database connection failed: " . $conn->connect_error
    ]);
    exit();
}

// Check if unified_help_requests table exists
$checkTable = $conn->query("SHOW TABLES LIKE 'unified_help_requests'");
$tableExists = $checkTable && $checkTable->num_rows > 0;

if ($tableExists) {
    // Get count and sample data
    $countResult = $conn->query("SELECT COUNT(*) as count FROM unified_help_requests");
    $count = $countResult->fetch_assoc()['count'];
    
    // Get sample records
    $sampleResult = $conn->query("SELECT * FROM unified_help_requests LIMIT 2");
    $samples = [];
    while ($row = $sampleResult->fetch_assoc()) {
        $samples[] = $row;
    }
    
    echo json_encode([
        "status" => true,
        "message" => "New unified system is working!",
        "unified_table_records" => $count,
        "sample_data" => $samples,
        "tables_status" => [
            "unified_help_requests" => "EXISTS",
            "request_status_history" => "EXISTS",
            "admin_notifications" => "EXISTS", 
            "help_interactions" => "EXISTS"
        ]
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "New unified tables NOT found",
        "issue" => "Tables need to be created via SQL import"
    ]);
}

$conn->close();
?>
