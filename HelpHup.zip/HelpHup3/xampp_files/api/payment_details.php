<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database configuration
$host = 'localhost';
$dbname = 'helphup_db';
$username = 'root';
$password = '';

try {
    $conn = new mysqli($host, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }
    
    // Get request method
    $method = $_SERVER['REQUEST_METHOD'];
    
    if ($method === 'GET') {
        // Get specific payment details
        handleGetPaymentDetails($conn);
    } elseif ($method === 'POST') {
        // Refund or update payment
        handlePaymentUpdate($conn);
    } else {
        http_response('error', 'Invalid request method', 405);
    }
    
} catch (Exception $e) {
    error_log("Payment Details API Error: " . $e->getMessage());
    http_response('error', 'Payment details retrieval failed: ' . $e->getMessage(), 500);
    }
}

function handleGetPaymentDetails($conn) {
    $payment_id = isset($_GET['payment_id']) ? (int)$_GET['payment_id'] : 0;
    
    if ($payment_id <= 0) {
        http_response('error', 'Payment ID is required', 400);
        return;
    }
    
    try {
        // Get payment details with method details
        $query = "SELECT pt.*, 
                         GROUP_CONCAT(pm.field_name, ': ', pm.field_value) as method_details
                  FROM payment_transactions pt
                  LEFT JOIN payment_method_details pm ON pt.payment_id = pm.payment_id
                  WHERE pt.payment_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $payment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            // Get all method details
            $method_details_query = "SELECT field_name, field_value FROM payment_method_details WHERE payment_id = ? ORDER BY field_name";
            $stmt2 = $conn->prepare($method_details_query);
            $stmt2->bind_param('i', $payment_id);
            $stmt2->execute();
            $result2 = $stmt2->get_result();
            
            $details = [];
            while ($detail_row = $result2->fetch_assoc()) {
                $details[] = [
                    'field_name' => $detail_row['field_name'],
                    'field_value' => $detail_row['field_value']
                ];
            }
            
            http_response('success', 'Payment details retrieved successfully', 200, [
                'payment' => [
                    'payment_id' => (int)$row['payment_id'],
                    'transaction_id' => $row['transaction_id'],
                    'payer_id' => (int)$row['payer_id'],
                    'payer_type' => $row['payer_type'],
                    'payer_name' => $row['payer_name'],
                    'payer_email' => $row['payer_email'],
                    'request_id' => (int)$row['request_id'],
                    'request_type' => $row['request_type'],
                    'payment_method' => $row['payment_method'],
                    'amount' => (float)$row['amount'],
                    'currency' => $row['currency'],
                    'status' => $row['status'],
                    'gateway_response' => json_decode($row['gateway_response'], true),
                    'created_at' => $row['created_at'],
                    'updated_at' => $row['updated_at'],
                    'completed_at' => $row['completed_at'],
                    'method_details' => $details
                ]
            ]);
        } else {
            http_response('error', 'Payment not found', 404);
        }
        
    } catch (Exception $e) {
        error_log("Get Payment Details Error: " . $e->getMessage());
        http_response('error', 'Failed to retrieve payment details: ' . $e->getMessage(), 500);
    }
}

function handlePaymentUpdate($conn) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    if (!$data || !isset($data['payment_id'])) {
        http_response('error', 'Payment ID is required', 400);
        return;
    }
    
    $payment_id = (int)$data['payment_id'];
    $action = isset($data['action']) ? $data['action'] : 'refund';
    
    try {
        if ($action === 'refund') {
            // Process refund
            $query = "UPDATE payment_transactions 
                        SET status = 'failed', 
                            failure_reason = ?,
                            updated_at = NOW()
                        WHERE payment_id = ? AND status = 'completed'";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('ss', $data['refund_reason'] ?? 'User requested refund', $payment_id);
            $stmt->execute();
            
            // Update help_interactions
            $query2 = "UPDATE help_interactions 
                        SET payment_status = 'failed',
                            interaction_status = 'refunded'
                        WHERE payment_id = ?";
            $stmt2 = $conn->prepare($query2);
            $stmt2->bind_param('i', $payment_id);
            $stmt2->execute();
            
            http_response('success', 'Payment refunded successfully', 200);
            
        } else {
            http_response('error', 'Invalid action', 400);
        }
        
    } catch (Exception $e) {
        error_log("Payment Update Error: " . $e->getMessage());
        http_response('error', 'Payment update failed: ' . $e->getMessage(), 500);
    }
}

function http_response($status, $message, $http_code = 200, $data = null) {
    header('Content-Type: application/json');
    http_response_code($http_code);
    
    $response = [
        'status' => $status,
        'message' => $message,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
}
?>
