<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database configuration
$host = 'localhost';
$dbname = 'helphup_db';
$username = 'root';
$password = '';

try {
    $conn = new mysqli($host, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }
    
    // Get request method
    $method = $_SERVER['REQUEST_METHOD'];
    
    if ($method === 'GET') {
        // Get payment history for a user
        handleGetPaymentHistory($conn);
    } elseif ($method === 'POST') {
        // Process payment
        handlePaymentProcessing($conn);
    } else {
        http_response('error', 'Invalid request method', 405);
    }
    
} catch (Exception $e) {
    error_log("Payment API Error: " . $e->getMessage());
    http_response('error', 'Payment processing failed: ' . $e->getMessage(), 500);
}

function handleGetPaymentHistory($conn) {
    $user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
    $request_type = isset($_GET['request_type']) ? $_GET['request_type'] : 'all';
    
    if ($user_id <= 0) {
        http_response('error', 'User ID is required', 400);
        return;
    }
    
    try {
        // Get payment history
        $query = "SELECT * FROM user_payment_history WHERE payer_id = ? ORDER BY created_at DESC";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $payments = [];
        while ($row = $result->fetch_assoc()) {
            $payments[] = [
                'payment_id' => (int)$row['payment_id'],
                'transaction_id' => $row['transaction_id'],
                'request_id' => (int)$row['request_id'],
                'request_title' => $row['request_title'],
                'request_type' => $row['request_type'],
                'helped_person' => $row['helper_name'],
                'amount' => (float)$row['amount'],
                'payment_method' => $row['payment_method'],
                'status' => $row['status'],
                'status_text' => $row['payment_status_text'],
                'created_at' => $row['created_at'],
                'completed_at' => $row['completed_at']
            ];
        }
        
        // Get help received history
        $query2 = "SELECT * FROM help_received_history WHERE helper_id = ? ORDER BY interaction_date DESC";
        $stmt2 = $conn->prepare($query2);
        $stmt2->bind_param('i', $user_id);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        
        $help_received = [];
        while ($row = $result2->fetch_assoc()) {
            $help_received[] = [
                'interaction_id' => (int)$row['interaction_id'],
                'request_id' => (int)$row['request_id'],
                'request_title' => $row['request_title'],
                'request_type' => $row['request_type'],
                'helper_name' => $row['receiver_name'],
                'receiver_name' => $row['receiver_name'],
                'receiver_email' => $row['receiver_email'],
                'payment_amount' => (float)$row['payment_amount'],
                'payment_method' => $row['payment_method'],
                'payment_status' => $row['payment_status'],
                'interaction_date' => $row['interaction_date'],
                'status_text' => $row['help_status_text']
            ];
        }
        
        // Get user totals
        $query3 = "SELECT total_help_received, total_payments_made, total_help_given, total_amount_given FROM users WHERE user_id = ?";
        $stmt3 = $conn->prepare($query3);
        $stmt3->bind_param('i', $user_id);
        $stmt3->execute();
        $result3 = $stmt3->get_result();
        $user_stats = $result3->fetch_assoc();
        
        http_response('success', 'History retrieved successfully', 200, [
            'payments' => $payments,
            'help_received' => $help_received,
            'user_stats' => [
                'total_help_received' => (float)$user_stats['total_help_received'],
                'total_payments_made' => (int)$user_stats['total_payments_made'],
                'total_help_given' => (float)$user_stats['total_help_given'],
                'total_amount_given' => (float)$user_stats['total_amount_given']
            ]
        ]);
        
    } catch (Exception $e) {
        error_log("Get Payment History Error: " . $e->getMessage());
        http_response('error', 'Failed to retrieve payment history: ' . $e->getMessage(), 500);
    }
}

function handlePaymentProcessing($conn) {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    if (!$data || !isset($data['payer_id']) || !isset($data['request_id']) || !isset($data['payment_method']) || !isset($data['amount'])) {
        http_response('error', 'Missing required payment fields', 400);
        return;
    }
    
    $payer_id = (int)$data['payer_id'];
    $request_id = (int)$data['request_id'];
    $payment_method = $data['payment_method'];
    $amount = (float)$data['amount'];
    $payment_details = isset($data['payment_details']) ? $data['payment_details'] : null;
    
    // Generate unique transaction ID
    $transaction_id = 'TXN' . strtoupper(uniqid()) . date('YmdHis');
    
    try {
        // Start transaction
        $conn->begin_transaction();
        
        // Insert payment transaction
        $query = "INSERT INTO payment_transactions 
                  (transaction_id, payer_id, payer_type, payer_name, payer_email, request_id, request_type, payment_method, amount, status, gateway_response) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', '{}')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sisss', $transaction_id, $payer_id, $data['payer_type'], $data['payer_name'], $data['payer_email'], $request_id, $data['request_type'], $payment_method, $amount);
        $stmt->execute();
        
        $payment_id = $conn->insert_id;
        
        // Insert payment method details if provided
        if ($payment_details && is_array($payment_details)) {
            foreach ($payment_details as $field => $value) {
                $query2 = "INSERT INTO payment_method_details 
                           (payment_id, payment_method, field_name, field_value) 
                           VALUES (?, ?, ?, ?)";
                $stmt2 = $conn->prepare($query2);
                $stmt2->bind_param('iss', $payment_id, $payment_method, $field, $value);
                $stmt2->execute();
            }
        }
        
        // Simulate payment processing (in real app, this would be async)
        $status = 'completed';
        $gateway_response = json_encode([
            'status' => 'success',
            'transaction_id' => $transaction_id,
            'amount' => $amount,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
        
        $completed_at = date('Y-m-d H:i:s');
        
        // Update payment status
        $query3 = "UPDATE payment_transactions 
                    SET status = ?, gateway_response = ?, completed_at = ? 
                    WHERE payment_id = ?";
        $stmt3 = $conn->prepare($query3);
        $stmt3->bind_param('sss', $status, $gateway_response, $completed_at, $payment_id);
        $stmt3->execute();
        
        // Update help_interactions table
        $query4 = "INSERT INTO help_interactions 
                    (request_id, helper_id, interaction_type, interaction_status, payment_id, payment_amount, payment_method, payment_status, payment_date, interaction_date) 
                    VALUES (?, ?, 'help', 'completed', ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                    SET payment_id = VALUES(payment_id), 
                        payment_amount = VALUES(payment_amount), 
                        payment_method = VALUES(payment_method), 
                        payment_status = VALUES(payment_status), 
                        payment_date = VALUES(payment_date), 
                        interaction_status = VALUES(interaction_status)";
        $stmt4 = $conn->prepare($query4);
        $stmt4->bind_param('isss', $request_id, $payer_id, $payment_id, $amount, $payment_method, $status, $completed_at);
        $stmt4->execute();
        
        // Update user totals (helper)
        $query5 = "UPDATE users 
                    SET total_help_given = IFNULL(total_help_given, 0) + 1, 
                        total_amount_given = IFNULL(total_amount_given, 0) + ?, 
                        last_help_given_date = ? 
                    WHERE user_id = ?";
        $stmt5 = $conn->prepare($query5);
        $stmt5->bind_param('ds', $amount, $completed_at, $payer_id);
        $stmt5->execute();
        
        // Update request status to mark as funded/completed
        $query6 = "UPDATE unified_help_requests 
                    SET status = 'completed' 
                    WHERE request_id = ? AND status = 'approved'";
        $stmt6 = $conn->prepare($query6);
        $stmt6->bind_param('i', $request_id);
        $stmt6->execute();
        
        // Update user totals (receiver - if different from helper)
        $query7 = "SELECT requester_id FROM unified_help_requests WHERE request_id = ?";
        $stmt7 = $conn->prepare($query7);
        $stmt7->bind_param('i', $request_id);
        $stmt7->execute();
        $result7 = $stmt7->get_result();
        $requester_data = $result7->fetch_assoc();
        
        if ($requester_data && $requester_data['requester_id'] != $payer_id) {
            $query8 = "UPDATE users 
                        SET total_help_received = IFNULL(total_help_received, 0) + ?, 
                            total_payments_made = IFNULL(total_payments_made, 0) + 1, 
                            last_help_received_date = ? 
                        WHERE user_id = ?";
            $stmt8 = $conn->prepare($query8);
            $stmt8->bind_param('ds', $amount, $completed_at, $requester_data['requester_id']);
            $stmt8->execute();
        }
        
        $conn->commit();
        
        http_response('success', 'Payment processed successfully', 200, [
            'payment_id' => $payment_id,
            'transaction_id' => $transaction_id,
            'status' => $status,
            'amount' => $amount,
            'message' => 'Payment completed successfully'
        ]);
        
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Payment Processing Error: " . $e->getMessage());
        http_response('error', 'Payment processing failed: ' . $e->getMessage(), 500);
    }
}

function http_response($status, $message, $http_code = 200, $data = null) {
    header('Content-Type: application/json');
    http_response_code($http_code);
    
    $response = [
        'status' => $status,
        'message' => $message,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
}
?>
