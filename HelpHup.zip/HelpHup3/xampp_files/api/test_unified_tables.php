<?php
// Test if unified database tables exist
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "helphup");

if ($conn->connect_error) {
    echo json_encode([
        "status" => false,
        "message" => "Database connection failed: " . $conn->connect_error
    ]);
    exit();
}

// Check if unified_help_requests table exists
$checkTable = $conn->query("SHOW TABLES LIKE 'unified_help_requests'");
$tableExists = $checkTable && $checkTable->num_rows > 0;

if ($tableExists) {
    // Count records in unified table
    $countResult = $conn->query("SELECT COUNT(*) as count FROM unified_help_requests");
    $count = $countResult->fetch_assoc()['count'];
    
    echo json_encode([
        "status" => true,
        "message" => "Unified tables exist successfully!",
        "tables" => [
            "unified_help_requests" => "EXISTS",
            "request_status_history" => "EXISTS", 
            "admin_notifications" => "EXISTS",
            "help_interactions" => "EXISTS"
        ],
        "record_count" => $count
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Unified tables NOT found. Please import NEW_UNIFIED_HELP_SYSTEM.sql",
        "missing_tables" => [
            "unified_help_requests",
            "request_status_history", 
            "admin_notifications",
            "help_interactions"
        ]
    ]);
}

$conn->close();
?>
