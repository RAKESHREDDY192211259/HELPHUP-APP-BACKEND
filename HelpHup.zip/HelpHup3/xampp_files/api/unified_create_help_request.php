<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Only POST requests allowed'
    ]);
    exit();
}

try {
    // Include database configuration
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get JSON input
    $jsonInput = file_get_contents('php://input');
    $data = json_decode($jsonInput, true);
    
    if (!$data) {
        throw new Exception("Invalid JSON input");
    }
    
    // Validate required fields
    $requiredFields = ['requester_type', 'requester_id', 'requester_name', 'requester_email', 'requester_phone', 
                      'request_title', 'category', 'description', 'urgency_level'];
    
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }
    
    // Validate requester type
    $validRequesterTypes = ['ngo', 'donor', 'volunteer'];
    if (!in_array($data['requester_type'], $validRequesterTypes)) {
        throw new Exception("Invalid requester type. Must be: ngo, donor, or volunteer");
    }
    
    // Validate urgency level
    $validUrgencyLevels = ['Low', 'Medium', 'High', 'Critical'];
    if (!in_array($data['urgency_level'], $validUrgencyLevels)) {
        throw new Exception("Invalid urgency level. Must be: Low, Medium, High, or Critical");
    }
    
    // Prepare base fields
    $fields = [
        'requester_type' => $data['requester_type'],
        'requester_id' => (int)$data['requester_id'],
        'requester_name' => $data['requester_name'],
        'requester_email' => $data['requester_email'],
        'requester_phone' => $data['requester_phone'],
        'request_title' => $data['request_title'],
        'category' => $data['category'],
        'description' => $data['description'],
        'urgency_level' => $data['urgency_level']
    ];
    
    // Add type-specific fields
    switch ($data['requester_type']) {
        case 'ngo':
            // NGO specific fields
            $optionalFields = ['required_amount', 'date_needed', 'contact_number'];
            break;
            
        case 'volunteer':
            // Volunteer specific fields
            $optionalFields = ['location', 'help_date', 'start_time', 'volunteers_needed'];
            break;
            
        case 'donor':
            // Donor specific fields
            $optionalFields = ['fundraising_goal', 'duration', 'end_date', 'beneficiary_name', 
                              'relationship', 'contact_email', 'cover_image_url', 'video_url'];
            break;
    }
    
    // Add optional fields if present
    foreach ($optionalFields as $field) {
        if (isset($data[$field]) && !empty($data[$field])) {
            $fields[$field] = $data[$field];
        }
    }
    
    // Build INSERT query
    $columnNames = array_keys($fields);
    $columnList = implode(', ', array_map(function($col) { return "`$col`"; }, $columnNames));
    $valuePlaceholders = implode(', ', array_fill(0, count($fields), '?'));
    
    $sql = "INSERT INTO unified_help_requests ($columnList, status, created_at) 
            VALUES ($valuePlaceholders, 'pending', NOW())";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    
    // Bind parameters
    $types = str_repeat('s', count($fields));
    $values = array_values($fields);
    
    $stmt->bind_param($types, ...$values);
    
    // Execute the statement
    if (!$stmt->execute()) {
        throw new Exception("Failed to create help request: " . $stmt->error);
    }
    
    $requestId = $conn->insert_id;
    
    // Create status history entry
    $historySql = "INSERT INTO request_status_history 
                   (request_id, old_status, new_status, changed_by, created_at) 
                   VALUES (?, NULL, 'pending', 'system', NOW())";
    
    $historyStmt = $conn->prepare($historySql);
    $historyStmt->bind_param('i', $requestId);
    $historyStmt->execute();
    
    // Create admin notification
    $notificationMessage = "New {$data['requester_type']} help request: {$data['request_title']}";
    $notificationSql = "INSERT INTO admin_notifications 
                       (request_id, notification_type, message, created_at) 
                       VALUES (?, 'new_request', ?, NOW())";
    
    $notificationStmt = $conn->prepare($notificationSql);
    $notificationStmt->bind_param('is', $requestId, $notificationMessage);
    $notificationStmt->execute();
    
    // Return success response
    echo json_encode([
        'status' => true,
        'message' => 'Help request created successfully',
        'data' => [
            'request_id' => $requestId,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => false,
        'message' => $e->getMessage()
    ]);
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>
