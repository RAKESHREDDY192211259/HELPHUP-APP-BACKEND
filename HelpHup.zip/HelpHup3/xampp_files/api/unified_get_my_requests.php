<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Only GET requests allowed'
    ]);
    exit();
}

try {
    // Include database configuration
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) && !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get required parameters
    if (!isset($_GET['requester_type']) || !isset($_GET['requester_id'])) {
        throw new Exception("Missing required parameters: requester_type and requester_id");
    }
    
    $requesterType = $_GET['requester_type'];
    $requesterId = (int)$_GET['requester_id'];
    
    // Validate requester type
    $validRequesterTypes = ['ngo', 'donor', 'volunteer'];
    if (!in_array($requesterType, $validRequesterTypes)) {
        throw new Exception("Invalid requester type. Must be: ngo, donor, or volunteer");
    }
    
    // Get optional status filter
    $statusFilter = isset($_GET['status']) ? $_GET['status'] : null;
    if ($statusFilter) {
        $validStatuses = ['pending', 'approved', 'rejected'];
        if (!in_array($statusFilter, $validStatuses)) {
            throw new Exception("Invalid status filter. Must be: pending, approved, or rejected");
        }
    }
    
    // Build query
    $sql = "SELECT 
                r.request_id,
                r.requester_type,
                r.requester_id,
                r.requester_name,
                r.requester_email,
                r.requester_phone,
                r.request_title,
                r.category,
                r.description,
                r.urgency_level,
                r.required_amount,
                r.date_needed,
                r.contact_number,
                r.location,
                r.help_date,
                r.start_time,
                r.volunteers_needed,
                r.fundraising_goal,
                r.duration,
                r.end_date,
                r.beneficiary_name,
                r.relationship,
                r.contact_email,
                r.cover_image_url,
                r.video_url,
                r.status,
                r.admin_id,
                r.admin_reviewed_at,
                r.rejection_reason,
                r.created_at,
                r.updated_at
            FROM unified_help_requests r
            WHERE r.requester_type = ? AND r.requester_id = ?";
    
    $params = [$requesterType, $requesterId];
    $types = "si";
    
    // Add status filter if specified
    if ($statusFilter) {
        $sql .= " AND r.status = ?";
        $params[] = $statusFilter;
        $types .= "s";
    }
    
    $sql .= " ORDER BY r.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    
    $stmt->bind_param($types, ...$params);
    
    if (!$stmt->execute()) {
        throw new Exception("Failed to execute query: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    $requests = [];
    
    while ($row = $result->fetch_assoc()) {
        // Convert numeric fields to proper types
        $row['request_id'] = (int)$row['request_id'];
        $row['requester_id'] = (int)$row['requester_id'];
        $row['required_amount'] = $row['required_amount'] ? (float)$row['required_amount'] : null;
        $row['fundraising_goal'] = $row['fundraising_goal'] ? (float)$row['fundraising_goal'] : null;
        $row['volunteers_needed'] = $row['volunteers_needed'] ? (int)$row['volunteers_needed'] : null;
        $row['admin_id'] = $row['admin_id'] ? (int)$row['admin_id'] : null;
        
        // Format dates for better display
        $row['created_at_formatted'] = date('M j, Y g:i A', strtotime($row['created_at']));
        if ($row['admin_reviewed_at']) {
            $row['admin_reviewed_at_formatted'] = date('M j, Y g:i A', strtotime($row['admin_reviewed_at']));
        }
        
        // Add status display text
        $statusDisplay = [
            'pending' => 'Pending Review',
            'approved' => 'Approved - Public',
            'rejected' => 'Rejected'
        ];
        $row['status_display'] = $statusDisplay[$row['status']] ?? $row['status'];
        
        // Add next action hint
        $nextActions = [
            'pending' => 'Waiting for admin review',
            'approved' => 'Your request is now public and visible to others',
            'rejected' => 'Request was rejected. You can create a new request.'
        ];
        $row['next_action'] = $nextActions[$row['status']] ?? '';
        
        $requests[] = $row;
    }
    
    // Get status counts for dashboard
    $countSql = "SELECT 
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
                    COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_count,
                    COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected_count,
                    COUNT(*) as total_count
                 FROM unified_help_requests 
                 WHERE requester_type = ? AND requester_id = ?";
    
    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param('si', $requesterType, $requesterId);
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $counts = $countResult->fetch_assoc();
    
    echo json_encode([
        'status' => true,
        'message' => 'My requests fetched successfully',
        'data' => $requests,
        'counts' => [
            'pending' => (int)$counts['pending_count'],
            'approved' => (int)$counts['approved_count'],
            'rejected' => (int)$counts['rejected_count'],
            'total' => (int)$counts['total_count']
        ],
        'requester_info' => [
            'type' => $requesterType,
            'id' => $requesterId
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => false,
        'message' => $e->getMessage()
    ]);
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>
