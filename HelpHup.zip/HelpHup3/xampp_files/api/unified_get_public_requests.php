<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Only GET requests allowed'
    ]);
    exit();
}

try {
    // Include database configuration
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) && !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get filter parameters (optional)
    $categoryFilter = isset($_GET['category']) ? $_GET['category'] : null;
    $urgencyFilter = isset($_GET['urgency']) ? $_GET['urgency'] : null;
    $excludeRequesterType = isset($_GET['exclude_requester_type']) ? $_GET['exclude_requester_type'] : null;
    $searchQuery = isset($_GET['search']) ? trim($_GET['search']) : null;
    
    // Build base query for approved requests only
    $sql = "SELECT 
                r.request_id,
                r.requester_type,
                r.requester_id,
                r.requester_name,
                r.requester_email,
                r.requester_phone,
                r.request_title,
                r.category,
                r.description,
                r.urgency_level,
                r.required_amount,
                r.date_needed,
                r.contact_number,
                r.location,
                r.help_date,
                r.start_time,
                r.volunteers_needed,
                r.fundraising_goal,
                r.duration,
                r.end_date,
                r.beneficiary_name,
                r.relationship,
                r.contact_email,
                r.cover_image_url,
                r.video_url,
                r.status,
                r.created_at,
                r.updated_at,
                CASE 
                    WHEN r.requester_type = 'ngo' THEN CONCAT('NGO: ', r.requester_name)
                    WHEN r.requester_type = 'volunteer' THEN CONCAT('Volunteer: ', r.requester_name)
                    WHEN r.requester_type = 'donor' THEN CONCAT('Donor: ', r.requester_name)
                END as requester_display
            FROM unified_help_requests r
            WHERE r.status = 'approved'";
    
    $params = [];
    $types = "";
    
    // Add category filter
    if ($categoryFilter) {
        $sql .= " AND r.category = ?";
        $params[] = $categoryFilter;
        $types .= "s";
    }
    
    // Add urgency filter
    if ($urgencyFilter) {
        $validUrgencyLevels = ['Low', 'Medium', 'High', 'Critical'];
        if (!in_array($urgencyFilter, $validUrgencyLevels)) {
            throw new Exception("Invalid urgency level. Must be: Low, Medium, High, or Critical");
        }
        $sql .= " AND r.urgency_level = ?";
        $params[] = $urgencyFilter;
        $types .= "s";
    }
    
    // Exclude requester type (for Help Others pages)
    if ($excludeRequesterType) {
        $validRequesterTypes = ['ngo', 'donor', 'volunteer'];
        if (!in_array($excludeRequesterType, $validRequesterTypes)) {
            throw new Exception("Invalid requester type to exclude. Must be: ngo, donor, or volunteer");
        }
        $sql .= " AND r.requester_type != ?";
        $params[] = $excludeRequesterType;
        $types .= "s";
    }
    
    // Add search query
    if ($searchQuery) {
        $sql .= " AND (r.request_title LIKE ? OR r.description LIKE ? OR r.requester_name LIKE ?)";
        $searchParam = "%$searchQuery%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $types .= "sss";
    }
    
    $sql .= " ORDER BY r.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    if (!$stmt->execute()) {
        throw new Exception("Failed to execute query: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    $requests = [];
    
    while ($row = $result->fetch_assoc()) {
        // Convert numeric fields to proper types
        $row['request_id'] = (int)$row['request_id'];
        $row['requester_id'] = (int)$row['requester_id'];
        $row['required_amount'] = $row['required_amount'] ? (float)$row['required_amount'] : null;
        $row['fundraising_goal'] = $row['fundraising_goal'] ? (float)$row['fundraising_goal'] : null;
        $row['volunteers_needed'] = $row['volunteers_needed'] ? (int)$row['volunteers_needed'] : null;
        
        // Format dates for better display
        $row['created_at_formatted'] = date('M j, Y', strtotime($row['created_at']));
        if ($row['date_needed']) {
            $row['date_needed_formatted'] = date('M j, Y', strtotime($row['date_needed']));
        }
        if ($row['help_date']) {
            $row['help_date_formatted'] = date('M j, Y', strtotime($row['help_date']));
        }
        if ($row['end_date']) {
            $row['end_date_formatted'] = date('M j, Y', strtotime($row['end_date']));
        }
        
        $requests[] = $row;
    }
    
    // Get available categories for filtering
    $categorySql = "SELECT DISTINCT category FROM unified_help_requests WHERE status = 'approved' ORDER BY category";
    $categoryResult = $conn->query($categorySql);
    $categories = [];
    while ($cat = $categoryResult->fetch_assoc()) {
        $categories[] = $cat['category'];
    }
    
    // Get statistics
    $statsSql = "SELECT 
                    COUNT(*) as total_approved,
                    COUNT(CASE WHEN requester_type = 'ngo' THEN 1 END) as ngo_count,
                    COUNT(CASE WHEN requester_type = 'volunteer' THEN 1 END) as volunteer_count,
                    COUNT(CASE WHEN requester_type = 'donor' THEN 1 END) as donor_count
                 FROM unified_help_requests 
                 WHERE status = 'approved'";
    
    $statsResult = $conn->query($statsSql);
    $stats = $statsResult->fetch_assoc();
    
    echo json_encode([
        'status' => true,
        'message' => 'Public requests fetched successfully',
        'data' => $requests,
        'filters' => [
            'categories' => $categories,
            'urgency_levels' => ['Low', 'Medium', 'High', 'Critical']
        ],
        'statistics' => [
            'total_approved' => (int)$stats['total_approved'],
            'by_type' => [
                'ngo' => (int)$stats['ngo_count'],
                'volunteer' => (int)$stats['volunteer_count'],
                'donor' => (int)$stats['donor_count']
            ]
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => false,
        'message' => $e->getMessage()
    ]);
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>
