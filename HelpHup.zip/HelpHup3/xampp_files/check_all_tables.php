<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h2>Database Tables Check</h2>";

// Get all tables in the database
$tables = $conn->query("SHOW TABLES");

if ($tables && $tables->num_rows > 0) {
    echo "<h3>All Tables in 'helphup' Database:</h3>";
    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr><th>Table Name</th><th>Row Count</th><th>Columns</th></tr>";
    
    while ($row = $tables->fetch_row()) {
        $tableName = $row[0];
        
        // Count rows
        $countResult = $conn->query("SELECT COUNT(*) FROM `$tableName`");
        $count = $countResult ? $countResult->fetch_row()[0] : 0;
        
        // Get columns
        $columns = $conn->query("SHOW COLUMNS FROM `$tableName`");
        $columnList = array();
        if ($columns && $columns->num_rows > 0) {
            while ($col = $columns->fetch_assoc()) {
                $columnList[] = $col['Field'];
            }
        }
        
        echo "<tr>";
        echo "<td><strong>$tableName</strong></td>";
        echo "<td>$count</td>";
        echo "<td>" . implode(", ", $columnList) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No tables found";
}

// Check specific table structures
echo "<hr><h3>NGO Help Request Tables Structure:</h3>";

$ngoTables = ['ngoraisehelp', 'ngo_help_requests', 'ngohelprequests'];
foreach ($ngoTables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        echo "<h4>Table: $table</h4>";
        $columns = $conn->query("SHOW COLUMNS FROM `$table`");
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Column Name</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        while ($col = $columns->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $col['Field'] . "</td>";
            echo "<td>" . $col['Type'] . "</td>";
            echo "<td>" . $col['Null'] . "</td>";
            echo "<td>" . $col['Key'] . "</td>";
            echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Show sample data
        $sample = $conn->query("SELECT * FROM `$table` LIMIT 3");
        if ($sample && $sample->num_rows > 0) {
            echo "<h5>Sample Data:</h5>";
            echo "<table border='1' cellpadding='5'>";
            $row = $sample->fetch_assoc();
            echo "<tr>";
            foreach (array_keys($row) as $key) {
                echo "<th>$key</th>";
            }
            echo "</tr>";
            $sample->data_seek(0);
            while ($row = $sample->fetch_assoc()) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        }
        echo "<br>";
    }
}

$conn->close();
?>

