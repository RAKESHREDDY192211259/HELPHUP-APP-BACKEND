<?php
/**
 * Check and fix admin_status columns in volunteer_requests and donor_campaigns tables
 * Run this script once to ensure columns exist
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

header('Content-Type: application/json');

$results = array();
$errors = array();

// Function to check if column exists
function columnExists($conn, $table, $column) {
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = ? 
        AND COLUMN_NAME = ?
    ");
    $stmt->bind_param("ss", $table, $column);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['count'] > 0;
}

// Function to add column if it doesn't exist
function addColumnIfNotExists($conn, $table, $column, $definition) {
    if (!columnExists($conn, $table, $column)) {
        $sql = "ALTER TABLE `$table` ADD COLUMN `$column` $definition";
        if ($conn->query($sql)) {
            return array('success' => true, 'message' => "Added $column to $table");
        } else {
            return array('success' => false, 'message' => "Failed to add $column to $table: " . $conn->error);
        }
    } else {
        return array('success' => true, 'message' => "$column already exists in $table");
    }
}

try {
    // Fix volunteer_requests table
    $results[] = addColumnIfNotExists($conn, 'volunteer_requests', 'admin_status', "VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected'");
    $results[] = addColumnIfNotExists($conn, 'volunteer_requests', 'admin_id', 'INT(11) DEFAULT NULL');
    $results[] = addColumnIfNotExists($conn, 'volunteer_requests', 'admin_reviewed_at', 'TIMESTAMP NULL DEFAULT NULL');
    $results[] = addColumnIfNotExists($conn, 'volunteer_requests', 'rejection_reason', 'TEXT DEFAULT NULL');
    
    // Update existing records
    $updateVolunteer = $conn->query("UPDATE volunteer_requests SET admin_status = 'pending' WHERE admin_status IS NULL");
    $results[] = array('success' => true, 'message' => "Updated existing volunteer_requests records");
    
    // Fix donor_campaigns table
    $results[] = addColumnIfNotExists($conn, 'donor_campaigns', 'admin_status', "VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, verified, accepted, rejected'");
    $results[] = addColumnIfNotExists($conn, 'donor_campaigns', 'admin_id', 'INT(11) DEFAULT NULL');
    $results[] = addColumnIfNotExists($conn, 'donor_campaigns', 'admin_reviewed_at', 'TIMESTAMP NULL DEFAULT NULL');
    $results[] = addColumnIfNotExists($conn, 'donor_campaigns', 'rejection_reason', 'TEXT DEFAULT NULL');
    
    // Update existing records
    $updateDonor = $conn->query("UPDATE donor_campaigns SET admin_status = 'pending' WHERE admin_status IS NULL");
    $results[] = array('success' => true, 'message' => "Updated existing donor_campaigns records");
    
    // Check pending counts
    $volunteerPending = $conn->query("SELECT COUNT(*) as count FROM volunteer_requests WHERE admin_status = 'pending' OR admin_status IS NULL");
    $donorPending = $conn->query("SELECT COUNT(*) as count FROM donor_campaigns WHERE admin_status = 'pending' OR admin_status IS NULL");
    
    $volunteerCount = $volunteerPending->fetch_assoc()['count'];
    $donorCount = $donorPending->fetch_assoc()['count'];
    
    sendResponse(true, "Tables updated successfully", array(
        'results' => $results,
        'pending_counts' => array(
            'volunteer_requests' => $volunteerCount,
            'donor_campaigns' => $donorCount
        )
    ));
    
} catch (Exception $e) {
    sendResponse(false, "Error: " . $e->getMessage());
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

