<?php
// Check donor_campaigns table structure
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

header('Content-Type: application/json');

$result = array();

// Check if table exists
$check = $conn->query("SHOW TABLES LIKE 'donor_campaigns'");
$result['table_exists'] = $check->num_rows > 0;

if ($result['table_exists']) {
    // Get all columns
    $columns = $conn->query("SHOW COLUMNS FROM donor_campaigns");
    $result['columns'] = array();
    while ($row = $columns->fetch_assoc()) {
        $result['columns'][] = $row['Field'];
    }
    
    // Check for primary key
    $pk = $conn->query("SHOW KEYS FROM donor_campaigns WHERE Key_name = 'PRIMARY'");
    $result['primary_key'] = array();
    while ($row = $pk->fetch_assoc()) {
        $result['primary_key'][] = $row['Column_name'];
    }
}

echo json_encode($result, JSON_PRETTY_PRINT);

$conn->close();
?>

