<?php
/**
 * Error Diagnostic Script
 * Run this in your browser to see what's causing the 500 error
 * URL: http://localhost/helphup/api/check_errors.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Error Diagnostic</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
        pre { background: #f5f5f5; padding: 10px; border: 1px solid #ddd; }
    </style>
</head>
<body>
    <h1>Error Diagnostic Report</h1>
    
    <h2>1. File Existence Check</h2>
    <ul>
        <li>config.php: <?php echo file_exists('config.php') ? '<span class="success">✓ EXISTS</span>' : '<span class="error">✗ NOT FOUND</span>'; ?></li>
        <li>email_config.php: <?php echo file_exists('email_config.php') ? '<span class="success">✓ EXISTS</span>' : '<span class="warning">⚠ NOT FOUND (optional)</span>'; ?></li>
        <li>ngoforgot.php: <?php echo file_exists('ngoforgot.php') ? '<span class="success">✓ EXISTS</span>' : '<span class="error">✗ NOT FOUND</span>'; ?></li>
    </ul>
    
    <h2>2. Config.php Test</h2>
    <?php
    try {
        if (file_exists('config.php')) {
            require_once 'config.php';
            echo '<p class="success">✓ config.php loaded successfully</p>';
            
            if (isset($conn)) {
                if ($conn->connect_error) {
                    echo '<p class="error">✗ Database connection failed: ' . htmlspecialchars($conn->connect_error) . '</p>';
                } else {
                    echo '<p class="success">✓ Database connected</p>';
                }
            } else {
                echo '<p class="error">✗ $conn variable not set</p>';
            }
            
            if (function_exists('sendResponse')) {
                echo '<p class="success">✓ sendResponse function exists</p>';
            } else {
                echo '<p class="error">✗ sendResponse function NOT FOUND</p>';
            }
        } else {
            echo '<p class="error">✗ config.php file not found</p>';
        }
    } catch (Exception $e) {
        echo '<p class="error">✗ Exception: ' . htmlspecialchars($e->getMessage()) . '</p>';
    } catch (Error $e) {
        echo '<p class="error">✗ Fatal Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
    }
    ?>
    
    <h2>3. Email Config Test</h2>
    <?php
    try {
        if (file_exists('email_config.php')) {
            $emailConfigExists = @include_once 'email_config.php';
            if ($emailConfigExists) {
                echo '<p class="success">✓ email_config.php loaded</p>';
            } else {
                echo '<p class="warning">⚠ email_config.php exists but failed to load</p>';
            }
            
            if (function_exists('sendOTPEmail')) {
                echo '<p class="success">✓ sendOTPEmail function exists</p>';
            } else {
                echo '<p class="warning">⚠ sendOTPEmail function NOT found (will use fallback)</p>';
            }
        } else {
            echo '<p class="warning">⚠ email_config.php not found (will use fallback)</p>';
        }
    } catch (Exception $e) {
        echo '<p class="error">✗ Exception: ' . htmlspecialchars($e->getMessage()) . '</p>';
    }
    ?>
    
    <h2>4. Database Tables Check</h2>
    <?php
    if (isset($conn) && !$conn->connect_error) {
        $tables = ['ngo', 'donor', 'volunteer', 'ngo_password_reset_tokens', 'donor_password_reset_tokens', 'volunteer_password_reset_tokens'];
        foreach ($tables as $table) {
            $result = $conn->query("SHOW TABLES LIKE '$table'");
            if ($result && $result->num_rows > 0) {
                echo '<p class="success">✓ Table "' . htmlspecialchars($table) . '" exists</p>';
            } else {
                echo '<p class="error">✗ Table "' . htmlspecialchars($table) . '" NOT FOUND</p>';
            }
        }
    } else {
        echo '<p class="error">Cannot check tables - database not connected</p>';
    }
    ?>
    
    <h2>5. PHP Syntax Check</h2>
    <?php
    $files = ['ngoforgot.php', 'donor_forgot.php', 'volunteer_forgot.php'];
    foreach ($files as $file) {
        if (file_exists($file)) {
            $output = [];
            $return = 0;
            exec("php -l \"$file\" 2>&1", $output, $return);
            if ($return === 0) {
                echo '<p class="success">✓ ' . htmlspecialchars($file) . ' - No syntax errors</p>';
            } else {
                echo '<p class="error">✗ ' . htmlspecialchars($file) . ' - Syntax errors:</p>';
                echo '<pre>' . htmlspecialchars(implode("\n", $output)) . '</pre>';
            }
        } else {
            echo '<p class="error">✗ ' . htmlspecialchars($file) . ' - File not found</p>';
        }
    }
    ?>
    
    <h2>6. Test ngoforgot.php Directly</h2>
    <p>Click the button below to test ngoforgot.php with a test email:</p>
    <form method="POST" action="ngoforgot.php" style="margin: 20px 0;">
        <input type="hidden" name="test" value="1">
        <button type="submit">Test ngoforgot.php</button>
    </form>
    
    <h2>7. PHP Error Log Location</h2>
    <p>Check your PHP error log at:</p>
    <pre><?php echo ini_get('error_log') ?: 'C:\xampp\php\logs\php_error_log'; ?></pre>
    
    <?php
    if (isset($conn)) {
        $conn->close();
    }
    ?>
</body>
</html>

