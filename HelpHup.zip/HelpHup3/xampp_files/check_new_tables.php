<?php
// Check if new unified tables exist and have data
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "helphup");

if ($conn->connect_error) {
    echo json_encode([
        "status" => false,
        "message" => "Database connection failed: " . $conn->connect_error
    ]);
    exit();
}

// Check if unified_help_requests table exists
$checkTable = $conn->query("SHOW TABLES LIKE 'unified_help_requests'");
$tableExists = $checkTable && $checkTable->num_rows > 0;

if ($tableExists) {
    // Get table structure
    $structureResult = $conn->query("DESCRIBE unified_help_requests");
    $structure = [];
    while ($row = $structureResult->fetch_assoc()) {
        $structure[] = $row;
    }
    
    // Count records
    $countResult = $conn->query("SELECT COUNT(*) as count FROM unified_help_requests");
    $count = $countResult->fetch_assoc()['count'];
    
    // Get sample records if any
    $sampleData = [];
    if ($count > 0) {
        $dataResult = $conn->query("SELECT * FROM unified_help_requests LIMIT 3");
        while ($row = $dataResult->fetch_assoc()) {
            $sampleData[] = $row;
        }
    }
    
    echo json_encode([
        "status" => true,
        "message" => "Unified tables exist!",
        "table_structure" => $structure,
        "record_count" => $count,
        "sample_data" => $sampleData
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Unified tables NOT found",
        "existing_tables" => []
    ]);
}

$conn->close();
?>
