<?php
// Check ngoraisehelp table structure
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

header('Content-Type: application/json');

$result = array();

// Check if table exists
$check = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
$result['table_exists'] = $check->num_rows > 0;

if ($result['table_exists']) {
    // Get all columns
    $columns = $conn->query("SHOW COLUMNS FROM ngoraisehelp");
    $result['columns'] = array();
    while ($row = $columns->fetch_assoc()) {
        $result['columns'][] = $row['Field'];
    }
    
    // Check if admin_status exists
    $checkAdminStatus = $conn->query("SHOW COLUMNS FROM ngoraisehelp LIKE 'admin_status'");
    $result['admin_status_exists'] = $checkAdminStatus->num_rows > 0;
    
    // Count total requests
    $count = $conn->query("SELECT COUNT(*) as count FROM ngoraisehelp");
    $row = $count->fetch_assoc();
    $result['total_requests'] = $row['count'];
    
    // Count requests with admin_status = 'pending' or NULL
    if ($result['admin_status_exists']) {
        $pending = $conn->query("SELECT COUNT(*) as count FROM ngoraisehelp WHERE admin_status = 'pending' OR admin_status IS NULL");
        $row = $pending->fetch_assoc();
        $result['pending_requests'] = $row['count'];
        
        // Get latest 3 requests
        $latest = $conn->query("SELECT id, request_title, admin_status, created_at FROM ngoraisehelp ORDER BY created_at DESC LIMIT 3");
        $result['latest_requests'] = array();
        while ($row = $latest->fetch_assoc()) {
            $result['latest_requests'][] = $row;
        }
    } else {
        $result['pending_requests'] = "Column doesn't exist";
        $result['latest_requests'] = "Cannot check - column missing";
    }
}

echo json_encode($result, JSON_PRETTY_PRINT);

$conn->close();
?>

