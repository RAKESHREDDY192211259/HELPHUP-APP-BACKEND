<?php
// Check ngos table structure
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

header('Content-Type: application/json');

$result = array();

// Check if table exists
$check = $conn->query("SHOW TABLES LIKE 'ngos'");
$result['ngos_table_exists'] = $check->num_rows > 0;

if ($result['ngos_table_exists']) {
    // Get all columns
    $columns = $conn->query("SHOW COLUMNS FROM ngos");
    $result['columns'] = array();
    while ($row = $columns->fetch_assoc()) {
        $result['columns'][] = $row['Field'];
    }
    
    // Check for primary key
    $pk = $conn->query("SHOW KEYS FROM ngos WHERE Key_name = 'PRIMARY'");
    $result['primary_key'] = array();
    while ($row = $pk->fetch_assoc()) {
        $result['primary_key'][] = $row['Column_name'];
    }
    
    // Get sample data
    $sample = $conn->query("SELECT * FROM ngos LIMIT 1");
    if ($sample->num_rows > 0) {
        $result['sample_row'] = $sample->fetch_assoc();
    }
}

// Check ngoraisehelp table structure
$check2 = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
$result['ngoraisehelp_exists'] = $check2->num_rows > 0;

if ($result['ngoraisehelp_exists']) {
    // Get columns from ngoraisehelp
    $columns2 = $conn->query("SHOW COLUMNS FROM ngoraisehelp");
    $result['ngoraisehelp_columns'] = array();
    while ($row = $columns2->fetch_assoc()) {
        $result['ngoraisehelp_columns'][] = $row['Field'];
    }
    
    // Get sample data
    $sample2 = $conn->query("SELECT * FROM ngoraisehelp LIMIT 1");
    if ($sample2->num_rows > 0) {
        $result['ngoraisehelp_sample'] = $sample2->fetch_assoc();
    }
}

echo json_encode($result, JSON_PRETTY_PRINT);

$conn->close();
?>

