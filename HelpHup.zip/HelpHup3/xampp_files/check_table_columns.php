<?php
/**
 * Check actual column names in tables
 * Run: http://localhost/helphup/api/check_table_columns.php
 */

require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Table Columns Check</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #22C55E; color: white; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <h1>Table Columns Check</h1>
    
    <?php
    $tables = ['ngos', 'donors', 'volunteers'];
    
    foreach ($tables as $table) {
        echo "<h2>Table: $table</h2>";
        
        // Check if table exists
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            echo "<p class='success'>✓ Table exists</p>";
            
            // Get all columns
            $result = $conn->query("SHOW COLUMNS FROM `$table`");
            if ($result) {
                echo "<table><tr><th>Column Name</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td><strong>" . htmlspecialchars($row['Field']) . "</strong></td>";
                    echo "<td>" . htmlspecialchars($row['Type']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Null']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Key']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Default'] ?? 'NULL') . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        } else {
            echo "<p class='error'>✗ Table does not exist</p>";
        }
        echo "<hr>";
    }
    
    $conn->close();
    ?>
</body>
</html>

