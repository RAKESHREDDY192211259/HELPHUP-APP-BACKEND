<?php
/**
 * Check actual table names in database
 * Run: http://localhost/helphup/api/check_table_names.php
 */

require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Table Names Check</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { color: green; }
        .error { color: red; }
        table { border-collapse: collapse; width: 100%; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #22C55E; color: white; }
    </style>
</head>
<body>
    <h1>Database Table Names Check</h1>
    
    <h2>All Tables in Database: <?php echo $database; ?></h2>
    <?php
    $result = $conn->query("SHOW TABLES");
    if ($result) {
        echo "<table><tr><th>Table Name</th><th>Rows</th></tr>";
        while ($row = $result->fetch_array()) {
            $tableName = $row[0];
            $countResult = $conn->query("SELECT COUNT(*) as count FROM `$tableName`");
            $count = $countResult ? $countResult->fetch_assoc()['count'] : 0;
            echo "<tr><td>$tableName</td><td>$count</td></tr>";
        }
        echo "</table>";
    }
    ?>
    
    <h2>Checking User Tables</h2>
    <?php
    $tablesToCheck = ['ngo', 'ngos', 'donor', 'donors', 'volunteer', 'volunteers'];
    foreach ($tablesToCheck as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result && $result->num_rows > 0) {
            echo "<p class='success'>✓ Table '$table' EXISTS</p>";
            // Check if it has email column
            $cols = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'email'");
            if ($cols && $cols->num_rows > 0) {
                echo "<p class='success'>  → Has 'email' column</p>";
            } else {
                echo "<p class='error'>  → Missing 'email' column</p>";
            }
        } else {
            echo "<p class='error'>✗ Table '$table' NOT FOUND</p>";
        }
    }
    ?>
    
    <h2>Checking Password Reset Tables</h2>
    <?php
    $resetTables = [
        'ngo_password_reset_tokens',
        'donor_password_reset_tokens', 
        'volunteer_password_reset_tokens',
        'password_reset_tokens'
    ];
    foreach ($resetTables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result && $result->num_rows > 0) {
            echo "<p class='success'>✓ Table '$table' EXISTS</p>";
            $countResult = $conn->query("SELECT COUNT(*) as count FROM `$table`");
            $count = $countResult ? $countResult->fetch_assoc()['count'] : 0;
            echo "<p>  → Rows: $count</p>";
        } else {
            echo "<p class='error'>✗ Table '$table' NOT FOUND</p>";
        }
    }
    ?>
    
    <h2>Test Email Lookup</h2>
    <?php
    $testEmail = 'gassensor23@gmail.com';
    echo "<p>Testing email: <strong>$testEmail</strong></p>";
    
    // Try different table names
    $tableNames = ['ngo', 'ngos'];
    foreach ($tableNames as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result && $result->num_rows > 0) {
            $stmt = $conn->prepare("SELECT * FROM `$table` WHERE LOWER(email) = LOWER(?)");
            if ($stmt) {
                $stmt->bind_param("s", $testEmail);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    echo "<p class='success'>✓ Found in table '$table': " . json_encode($row) . "</p>";
                } else {
                    echo "<p class='error'>✗ Email not found in table '$table'</p>";
                }
                $stmt->close();
            }
        }
    }
    ?>
    
    <?php $conn->close(); ?>
</body>
</html>

