<?php
// Database Configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "helphup";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die(json_encode(array(
        'status' => false,
        'message' => "Connection failed: " . $conn->connect_error
    )));
}

// Set charset to utf8mb4
$conn->set_charset("utf8mb4");

// Function to send JSON response
function sendResponse($status, $message, $data = null) {
    header('Content-Type: application/json');
    $response = array(
        'status' => $status,
        'message' => $message
    );
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response);
    exit();
}
?>

