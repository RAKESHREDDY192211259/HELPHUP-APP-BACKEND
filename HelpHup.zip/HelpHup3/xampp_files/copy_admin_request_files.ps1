# PowerShell Script to Copy Admin Request Management PHP Files to XAMPP
# Run this script as Administrator

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Copying Admin Request Management Files" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDir = $scriptDir
$targetDir = "C:\xampp\htdocs\helphup\api"

Write-Host "Source: $sourceDir" -ForegroundColor Yellow
Write-Host "Target: $targetDir" -ForegroundColor Yellow
Write-Host ""

# Check if source directory exists
if (-not (Test-Path $sourceDir)) {
    Write-Host "ERROR: Source directory not found: $sourceDir" -ForegroundColor Red
    exit 1
}

# Check if target directory exists, create if not
if (-not (Test-Path $targetDir)) {
    Write-Host "Target directory does not exist. Creating: $targetDir" -ForegroundColor Yellow
    try {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        Write-Host "✓ Directory created successfully" -ForegroundColor Green
    } catch {
        Write-Host "ERROR: Failed to create target directory: $_" -ForegroundColor Red
        exit 1
    }
}

# Files to copy
$files = @(
    "admin_get_pending_requests.php",
    "admin_verify_request.php",
    "admin_accept_request.php",
    "admin_reject_request.php"
)

Write-Host "Files to copy:" -ForegroundColor Cyan
foreach ($file in $files) {
    Write-Host "  - $file" -ForegroundColor Gray
}
Write-Host ""

$successCount = 0
$failCount = 0

foreach ($file in $files) {
    $sourceFile = Join-Path $sourceDir $file
    $targetFile = Join-Path $targetDir $file
    
    if (Test-Path $sourceFile) {
        try {
            Copy-Item -Path $sourceFile -Destination $targetFile -Force
            Write-Host "✓ Copied: $file" -ForegroundColor Green
            $successCount++
        } catch {
            Write-Host "✗ Failed to copy: $file - $_" -ForegroundColor Red
            $failCount++
        }
    } else {
        Write-Host "✗ Not found: $file" -ForegroundColor Red
        $failCount++
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Successfully copied: $successCount files" -ForegroundColor Green
if ($failCount -gt 0) {
    Write-Host "Failed/Missing: $failCount files" -ForegroundColor Red
}
Write-Host ""

# Verify files
Write-Host "Verifying files in target directory..." -ForegroundColor Cyan
$allExist = $true
foreach ($file in $files) {
    $targetFile = Join-Path $targetDir $file
    if (Test-Path $targetFile) {
        Write-Host "  ✓ $file" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $file (NOT FOUND)" -ForegroundColor Red
        $allExist = $false
    }
}

Write-Host ""
if ($allExist) {
    Write-Host "✓ All files copied successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Test URLs:" -ForegroundColor Cyan
    Write-Host "  http://localhost/helphup/api/admin_get_pending_requests.php?request_type=all" -ForegroundColor Gray
    Write-Host "  http://localhost/helphup/api/admin_verify_request.php" -ForegroundColor Gray
    Write-Host "  http://localhost/helphup/api/admin_accept_request.php" -ForegroundColor Gray
    Write-Host "  http://localhost/helphup/api/admin_reject_request.php" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor Cyan
    Write-Host "  1. Make sure XAMPP Apache is running" -ForegroundColor Yellow
    Write-Host "  2. Test the endpoint in browser (should return JSON, not 404)" -ForegroundColor Yellow
    Write-Host "  3. Open Admin app → Manage Requests" -ForegroundColor Yellow
} else {
    Write-Host "⚠ Some files are missing. Please check the errors above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Green

