# PowerShell script to copy API files to XAMPP web server directory
# Run this script in PowerShell (right-click -> Run with PowerShell)

$sourceDir = "D:\Android\Projects\HelpHup3\xampp_files"
$targetDir = "C:\xampp\htdocs\helphup\api"

# Files to copy
$files = @(
    "get_all_ngo_requests.php",
    "get_all_volunteer_requests.php",
    "get_all_donor_campaigns.php"
)

Write-Host "Copying API files to web server directory..." -ForegroundColor Yellow
Write-Host "Source: $sourceDir" -ForegroundColor Cyan
Write-Host "Target: $targetDir" -ForegroundColor Cyan
Write-Host ""

# Check if target directory exists
if (-not (Test-Path $targetDir)) {
    Write-Host "Creating target directory: $targetDir" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
}

# Copy each file
foreach ($file in $files) {
    $sourcePath = Join-Path $sourceDir $file
    $targetPath = Join-Path $targetDir $file
    
    if (Test-Path $sourcePath) {
        Copy-Item -Path $sourcePath -Destination $targetPath -Force
        Write-Host "✓ Copied: $file" -ForegroundColor Green
    } else {
        Write-Host "✗ Not found: $file" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Done! Please verify the files are accessible at:" -ForegroundColor Yellow
Write-Host "http://10.26.77.227/helphup/api/get_all_ngo_requests.php" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

