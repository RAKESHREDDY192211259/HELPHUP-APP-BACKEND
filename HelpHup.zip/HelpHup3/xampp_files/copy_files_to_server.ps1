# PowerShell script to copy fixed PHP files to XAMPP server
# Run this script from the xampp_files folder

$sourceDir = $PSScriptRoot
$targetDir = "C:\xampp\htdocs\helphup\api\"

Write-Host "========================================"
Write-Host "Copying Fixed PHP Files to Server"
Write-Host "========================================"
Write-Host ""

# Check if target directory exists
if (-not (Test-Path $targetDir)) {
    Write-Host "ERROR: Target directory does not exist!" -ForegroundColor Red
    Write-Host "Expected: $targetDir" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Please ensure XAMPP is installed and the directory exists." -ForegroundColor Yellow
    exit 1
}

# Files to copy
$filesToCopy = @(
    "get_all_ngo_requests.php",
    "get_all_volunteer_requests.php",
    "get_all_donor_campaigns.php"
)

Write-Host "Source Directory: $sourceDir" -ForegroundColor Cyan
Write-Host "Target Directory: $targetDir" -ForegroundColor Cyan
Write-Host ""

$successCount = 0
$errorCount = 0

foreach ($file in $filesToCopy) {
    $sourceFile = Join-Path $sourceDir $file
    $targetFile = Join-Path $targetDir $file
    
    if (Test-Path $sourceFile) {
        try {
            Copy-Item -Path $sourceFile -Destination $targetFile -Force
            Write-Host "✅ Copied: $file" -ForegroundColor Green
            $successCount++
        }
        catch {
            Write-Host "❌ Error copying $file : $_" -ForegroundColor Red
            $errorCount++
        }
    }
    else {
        Write-Host "❌ Source file not found: $file" -ForegroundColor Red
        $errorCount++
    }
}

Write-Host ""
Write-Host "========================================"
Write-Host "Copy Summary"
Write-Host "========================================"
Write-Host "Successfully copied: $successCount files" -ForegroundColor Green
Write-Host "Errors: $errorCount files" -ForegroundColor $(if ($errorCount -gt 0) { "Red" } else { "Green" })
Write-Host ""

if ($successCount -eq $filesToCopy.Count) {
    Write-Host "✅ All files copied successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor Cyan
    Write-Host "1. Test in browser: http://localhost/helphup/api/get_all_ngo_requests.php" -ForegroundColor Yellow
    Write-Host "2. Should see JSON response (not HTTP 500 error)" -ForegroundColor Yellow
    Write-Host "3. Test in Android app - NGO requests should now appear!" -ForegroundColor Yellow
}
else {
    Write-Host "⚠️ Some files failed to copy. Please check errors above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

