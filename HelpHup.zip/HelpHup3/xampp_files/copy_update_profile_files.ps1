# PowerShell script to copy update profile PHP files to XAMPP server
# Run this script from PowerShell (as Administrator if needed)

$sourceDir = "D:\Android\Projects\HelpHup3\xampp_files"
$targetDir = "C:\xampp\htdocs\helphup\api\"

Write-Host "========================================"
Write-Host "Copying Update Profile Files to Server"
Write-Host "========================================"
Write-Host ""

# Check if source directory exists
if (-not (Test-Path $sourceDir)) {
    Write-Host "ERROR: Source directory does not exist!" -ForegroundColor Red
    Write-Host "Expected: $sourceDir" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Please update the sourceDir path in this script." -ForegroundColor Yellow
    exit 1
}

# Check if target directory exists
if (-not (Test-Path $targetDir)) {
    Write-Host "ERROR: Target directory does not exist!" -ForegroundColor Red
    Write-Host "Expected: $targetDir" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Creating target directory..." -ForegroundColor Yellow
    try {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        Write-Host "✅ Created target directory" -ForegroundColor Green
    }
    catch {
        Write-Host "❌ Failed to create directory: $_" -ForegroundColor Red
        Write-Host ""
        Write-Host "Please ensure XAMPP is installed and create the directory manually." -ForegroundColor Yellow
        exit 1
    }
}

# Files to copy
$filesToCopy = @(
    "update_ngo_profile.php",
    "update_donor_profile.php",
    "update_volunteer_profile.php"
)

Write-Host "Source Directory: $sourceDir" -ForegroundColor Cyan
Write-Host "Target Directory: $targetDir" -ForegroundColor Cyan
Write-Host ""

$successCount = 0
$errorCount = 0

foreach ($file in $filesToCopy) {
    $sourceFile = Join-Path $sourceDir $file
    $targetFile = Join-Path $targetDir $file
    
    if (Test-Path $sourceFile) {
        try {
            Copy-Item -Path $sourceFile -Destination $targetFile -Force
            Write-Host "✅ Copied: $file" -ForegroundColor Green
            $successCount++
        }
        catch {
            Write-Host "❌ Error copying $file : $_" -ForegroundColor Red
            $errorCount++
        }
    }
    else {
        Write-Host "❌ Source file not found: $file" -ForegroundColor Red
        Write-Host "   Expected at: $sourceFile" -ForegroundColor Yellow
        $errorCount++
    }
}

Write-Host ""
Write-Host "========================================"
Write-Host "Copy Summary"
Write-Host "========================================"
Write-Host "Successfully copied: $successCount files" -ForegroundColor Green
Write-Host "Errors: $errorCount files" -ForegroundColor $(if ($errorCount -gt 0) { "Red" } else { "Green" })
Write-Host ""

if ($successCount -eq $filesToCopy.Count) {
    Write-Host "✅ All files copied successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor Cyan
    Write-Host "1. Make sure Apache is running in XAMPP" -ForegroundColor Yellow
    Write-Host "2. Test in browser:" -ForegroundColor Yellow
    Write-Host "   http://10.26.77.227/helphup/api/update_ngo_profile.php" -ForegroundColor White
    Write-Host "   http://10.26.77.227/helphup/api/update_donor_profile.php" -ForegroundColor White
    Write-Host "   http://10.26.77.227/helphup/api/update_volunteer_profile.php" -ForegroundColor White
    Write-Host "3. Should see error about missing data (not 404) - this means files exist!" -ForegroundColor Yellow
    Write-Host "4. Test profile update in Android app" -ForegroundColor Yellow
}
else {
    Write-Host "⚠️ Some files failed to copy. Please check errors above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

