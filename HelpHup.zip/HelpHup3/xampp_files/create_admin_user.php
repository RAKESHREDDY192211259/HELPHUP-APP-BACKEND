<?php
// Script to create admin user with proper password hash
// Run this once to set up the admin account
// Usage: Open in browser: http://localhost/helphup/api/create_admin_user.php

require_once 'config.php';

// Default admin credentials
$adminEmail = 'admin@helphup.com';
$adminPassword = 'admin123'; // Change this to your desired password
$adminName = 'Admin User';

// Hash the password
$hashedPassword = password_hash($adminPassword, PASSWORD_DEFAULT);

// Check if admin already exists
$checkStmt = $conn->prepare("SELECT admin_id FROM admin WHERE email = ?");
$checkStmt->bind_param("s", $adminEmail);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
    // Update existing admin
    $updateStmt = $conn->prepare("UPDATE admin SET password = ?, full_name = ? WHERE email = ?");
    $updateStmt->bind_param("sss", $hashedPassword, $adminName, $adminEmail);
    
    if ($updateStmt->execute()) {
        echo json_encode(array(
            'status' => true,
            'message' => "Admin password updated successfully!",
            'email' => $adminEmail,
            'password' => $adminPassword
        ));
    } else {
        echo json_encode(array(
            'status' => false,
            'message' => "Error updating admin: " . $updateStmt->error
        ));
    }
    $updateStmt->close();
} else {
    // Insert new admin
    $insertStmt = $conn->prepare("INSERT INTO admin (full_name, email, password) VALUES (?, ?, ?)");
    $insertStmt->bind_param("sss", $adminName, $adminEmail, $hashedPassword);
    
    if ($insertStmt->execute()) {
        echo json_encode(array(
            'status' => true,
            'message' => "Admin user created successfully!",
            'email' => $adminEmail,
            'password' => $adminPassword
        ));
    } else {
        echo json_encode(array(
            'status' => false,
            'message' => "Error creating admin: " . $insertStmt->error
        ));
    }
    $insertStmt->close();
}

$checkStmt->close();
$conn->close();
?>










