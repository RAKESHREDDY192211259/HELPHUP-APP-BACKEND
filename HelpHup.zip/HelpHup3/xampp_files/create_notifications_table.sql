-- ============================================
-- Create Notifications Table for Rejection Notifications
-- Run this in phpMyAdmin SQL tab on 'helphup' database
-- ============================================

CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_type` VARCHAR(20) NOT NULL COMMENT 'ngo, volunteer, donor',
  `user_id` INT(11) NOT NULL COMMENT 'ID of the user (ngo_id, volunteer_id, or donor_id)',
  `request_type` VARCHAR(20) NOT NULL COMMENT 'ngo, volunteer, donor',
  `request_id` INT(11) NOT NULL COMMENT 'ID of the rejected request',
  `title` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `rejection_reason` TEXT DEFAULT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`),
  INDEX `idx_user` (`user_type`, `user_id`),
  INDEX `idx_is_read` (`is_read`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

