<?php
/**
 * Debug script to check approved requests
 * Use this to verify which requests should be visible to volunteers/donors/other NGOs
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

echo "<h2>Debug: Approved Requests Check</h2>";

// Check table
$tableName = null;
$possibleTables = ['ngoraisehelp', 'ngo_help_requests'];
foreach ($possibleTables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        echo "<p>✓ Found table: <strong>$table</strong></p>";
        break;
    }
}

if (!$tableName) {
    echo "<p style='color:red;'>✗ No NGO table found!</p>";
    exit;
}

$idColumn = ($tableName == 'ngoraisehelp') ? 'id' : 'request_id';

// Check columns
echo "<h3>Column Check:</h3>";
$checkAdminStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'admin_status'");
$hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
echo "<p>admin_status column: " . ($hasAdminStatus ? "✓ EXISTS" : "✗ NOT FOUND") . "</p>";

$checkStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'status'");
$hasStatus = $checkStatus && $checkStatus->num_rows > 0;
echo "<p>status column: " . ($hasStatus ? "✓ EXISTS" : "✗ NOT FOUND") . "</p>";

// Count by admin_status
echo "<h3>Requests by admin_status:</h3>";
$counts = $conn->query("SELECT admin_status, COUNT(*) as count FROM `$tableName` GROUP BY admin_status");
echo "<table border='1'><tr><th>admin_status</th><th>Count</th></tr>";
while ($row = $counts->fetch_assoc()) {
    echo "<tr><td>" . ($row['admin_status'] ?? 'NULL') . "</td><td>" . $row['count'] . "</td></tr>";
}
echo "</table>";

// Show what get_all_ngo_requests.php would return
echo "<h3>What Volunteers/Donors/Other NGOs Should See:</h3>";

if ($hasAdminStatus && $hasStatus) {
    $sql = "SELECT $idColumn, request_title, admin_status, status 
            FROM `$tableName` 
            WHERE admin_status = 'accepted' AND (status = 'approved' OR status = 'active')
            ORDER BY created_at DESC";
} elseif ($hasAdminStatus) {
    $sql = "SELECT $idColumn, request_title, admin_status 
            FROM `$tableName` 
            WHERE admin_status = 'accepted'
            ORDER BY created_at DESC";
} else {
    $sql = "SELECT $idColumn, request_title FROM `$tableName` ORDER BY created_at DESC";
}

echo "<p>SQL Query: <code>$sql</code></p>";

$result = $conn->query($sql);
if ($result) {
    echo "<p>✓ Query successful. Found <strong>" . $result->num_rows . "</strong> approved requests.</p>";
    echo "<table border='1'><tr><th>ID</th><th>Title</th><th>admin_status</th>" . ($hasStatus ? "<th>status</th>" : "") . "</tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row[$idColumn] . "</td>";
        echo "<td>" . substr($row['request_title'], 0, 50) . "</td>";
        echo "<td>" . ($row['admin_status'] ?? 'NULL') . "</td>";
        if ($hasStatus) {
            echo "<td>" . ($row['status'] ?? 'NULL') . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color:red;'>✗ Query failed: " . $conn->error . "</p>";
}

// Show all requests for comparison
echo "<h3>All Requests (for comparison):</h3>";
$all = $conn->query("SELECT $idColumn, request_title, admin_status" . ($hasStatus ? ", status" : "") . " FROM `$tableName` ORDER BY created_at DESC LIMIT 10");
echo "<table border='1'><tr><th>ID</th><th>Title</th><th>admin_status</th>" . ($hasStatus ? "<th>status</th>" : "") . "</tr>";
while ($row = $all->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row[$idColumn] . "</td>";
    echo "<td>" . substr($row['request_title'], 0, 50) . "</td>";
    echo "<td>" . ($row['admin_status'] ?? 'NULL') . "</td>";
    if ($hasStatus) {
        echo "<td>" . ($row['status'] ?? 'NULL') . "</td>";
    }
    echo "</tr>";
}
echo "</table>";

$conn->close();
?>

