<?php
header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Check which donor campaigns table exists
    $tableName = null;
    $possibleTables = ['donor_campaigns', 'donorraisehelp', 'donor_campaign'];
    foreach ($possibleTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $tableName = $table;
            break;
        }
    }
    
    if (!$tableName) {
        echo json_encode(['status' => false, 'message' => 'No donor campaigns table found']);
        exit;
    }
    
    // Get all columns from the table
    $columns = $conn->query("SHOW COLUMNS FROM `$tableName`");
    $columnList = array();
    while ($col = $columns->fetch_assoc()) {
        $columnList[] = $col['Field'];
    }
    
    // Get sample data
    $sample = $conn->query("SELECT * FROM `$tableName` LIMIT 1");
    $sampleData = null;
    if ($sample && $sample->num_rows > 0) {
        $sampleData = $sample->fetch_assoc();
    }
    
    echo json_encode([
        'status' => true,
        'table_name' => $tableName,
        'columns' => $columnList,
        'sample_data' => $sampleData
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => false,
        'message' => $e->getMessage()
    ]);
}
?>
