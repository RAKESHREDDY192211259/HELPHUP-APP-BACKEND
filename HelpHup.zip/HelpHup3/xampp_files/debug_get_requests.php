<?php
/**
 * Debug script for get_all_ngo_requests.php
 * Use this to check what's causing the 500 error
 * 
 * Access: http://localhost/helphup/api/debug_get_requests.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

echo "<h1>Debug: Get NGO Requests API</h1>";
echo "<hr>";

// Step 1: Check config.php
echo "<h2>Step 1: Checking config.php</h2>";
if (!file_exists('config.php')) {
    echo "<p style='color:red;'>❌ config.php file NOT FOUND!</p>";
    echo "<p>Location: " . __DIR__ . "/config.php</p>";
    exit;
} else {
    echo "<p style='color:green;'>✅ config.php file exists</p>";
}

require_once 'config.php';

// Step 2: Check database connection
echo "<h2>Step 2: Checking Database Connection</h2>";
if (!isset($conn) || !$conn) {
    echo "<p style='color:red;'>❌ Database connection not established</p>";
    exit;
} else {
    echo "<p style='color:green;'>✅ Database connection established</p>";
}

// Step 3: Check if database exists
echo "<h2>Step 3: Checking Database</h2>";
$result = $conn->query("SELECT DATABASE()");
if ($result) {
    $row = $result->fetch_row();
    $currentDb = $row[0];
    echo "<p>Current database: <strong>$currentDb</strong></p>";
} else {
    echo "<p style='color:red;'>❌ Could not get database name</p>";
}

// Step 4: Check if tables exist
echo "<h2>Step 4: Checking Tables</h2>";

$tablesToCheck = [
    'ngo_help_requests',
    'ngoraisehelp',
    'ngohelprequests',
    'ngo',
    'ngos'
];

foreach ($tablesToCheck as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "<p style='color:green;'>✅ Table '$table' EXISTS</p>";
        
        // Show columns
        $columns = $conn->query("SHOW COLUMNS FROM `$table`");
        if ($columns) {
            echo "<ul>";
            while ($col = $columns->fetch_assoc()) {
                echo "<li>{$col['Field']} ({$col['Type']})</li>";
            }
            echo "</ul>";
        }
    } else {
        echo "<p style='color:orange;'>⚠️ Table '$table' NOT FOUND</p>";
    }
}

// Step 5: Try the actual query
echo "<h2>Step 5: Testing Query</h2>";

$tableName = null;
$possibleTables = ['ngoraisehelp', 'ngo_help_requests', 'ngohelprequests'];
foreach ($possibleTables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    echo "<p style='color:red;'>❌ No NGO help request table found!</p>";
    echo "<p>Checked tables: " . implode(", ", $possibleTables) . "</p>";
    exit;
}

echo "<p style='color:green;'>✅ Using table: <strong>$tableName</strong></p>";

// Check NGO table
$ngoTableName = null;
$ngoTables = ['ngo', 'ngos'];
foreach ($ngoTables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $ngoTableName = $table;
        break;
    }
}

if (!$ngoTableName) {
    echo "<p style='color:orange;'>⚠️ No NGO table found (will use 'Unknown' for names)</p>";
} else {
    echo "<p style='color:green;'>✅ Using NGO table: <strong>$ngoTableName</strong></p>";
}

// Build and test query
$idColumn = ($tableName == 'ngoraisehelp') ? 'id' : 'request_id';
$statusColumnCheck = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'status'");
$hasStatusColumn = $statusColumnCheck && $statusColumnCheck->num_rows > 0;

echo "<p>Has status column: " . ($hasStatusColumn ? "✅ Yes" : "⚠️ No") . "</p>";

$statusField = $hasStatusColumn ? "COALESCE(nhr.status, 'pending') as status" : "'pending' as status";

if ($ngoTableName) {
    $sql = "SELECT 
        nhr.$idColumn as request_id,
        nhr.ngo_id,
        COALESCE(n.full_name, 'Unknown') as ngo_name,
        COALESCE(n.org_name, 'Unknown') as org_name,
        nhr.request_title,
        nhr.category,
        nhr.urgency_level,
        nhr.required_amount,
        nhr.date_needed,
        nhr.contact_number,
        nhr.description,
        $statusField,
        nhr.created_at
    FROM `$tableName` nhr
    LEFT JOIN `$ngoTableName` n ON nhr.ngo_id = n.ngo_id
    ORDER BY nhr.created_at DESC
    LIMIT 5";
} else {
    $sql = "SELECT 
        nhr.$idColumn as request_id,
        nhr.ngo_id,
        'Unknown' as ngo_name,
        'Unknown' as org_name,
        nhr.request_title,
        nhr.category,
        nhr.urgency_level,
        nhr.required_amount,
        nhr.date_needed,
        nhr.contact_number,
        nhr.description,
        $statusField,
        nhr.created_at
    FROM `$tableName` nhr
    ORDER BY nhr.created_at DESC
    LIMIT 5";
}

echo "<h3>SQL Query:</h3>";
echo "<pre style='background:#f5f5f5;padding:10px;border:1px solid #ddd;'>";
echo htmlspecialchars($sql);
echo "</pre>";

$result = $conn->query($sql);

if (!$result) {
    echo "<p style='color:red;'>❌ Query FAILED!</p>";
    echo "<p>Error: <strong>" . $conn->error . "</strong></p>";
} else {
    echo "<p style='color:green;'>✅ Query SUCCESS!</p>";
    echo "<p>Rows returned: <strong>" . $result->num_rows . "</strong></p>";
    
    if ($result->num_rows > 0) {
        echo "<h3>Sample Data:</h3>";
        echo "<table border='1' cellpadding='5' style='border-collapse:collapse;'>";
        $first = true;
        while ($row = $result->fetch_assoc()) {
            if ($first) {
                echo "<tr>";
                foreach (array_keys($row) as $key) {
                    echo "<th>$key</th>";
                }
                echo "</tr>";
                $first = false;
            }
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . htmlspecialchars(substr($value, 0, 50)) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color:orange;'>⚠️ No data found in table</p>";
    }
}

echo "<hr>";
echo "<h2>Summary</h2>";
echo "<p>✅ If all checks passed, the API should work.</p>";
echo "<p>❌ Check the errors above to fix any issues.</p>";

$conn->close();
?>

