<?php
/**
 * Debug Login Queries - Find why emails aren't being found
 * Access: http://localhost/helphup/api/debug_login_queries.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

require_once 'config.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug Login Queries</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        h1 { color: #333; }
        h2 { color: #4CAF50; border-bottom: 2px solid #4CAF50; padding-bottom: 5px; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .warning { color: orange; font-weight: bold; }
        .info { background: #e3f2fd; padding: 10px; border-left: 4px solid #2196F3; margin: 10px 0; }
        .code { background: #f5f5f5; padding: 10px; border-left: 3px solid #4CAF50; margin: 10px 0; font-family: monospace; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
        input { padding: 8px; width: 300px; margin: 5px 0; }
        button { padding: 10px 20px; background: #4CAF50; color: white; border: none; cursor: pointer; }
        .test-result { margin: 15px 0; padding: 10px; border-radius: 5px; }
        .pass { background: #d4edda; border-left: 4px solid #28a745; }
        .fail { background: #f8d7da; border-left: 4px solid #dc3545; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Debug Login Queries</h1>
        
        <form method="POST">
            <h2>Test Login Query</h2>
            <p>
                <label>Email to test:</label><br>
                <input type="email" name="test_email" placeholder="Enter email address" value="<?php echo $_POST['test_email'] ?? ''; ?>" required>
            </p>
            <p>
                <label>Password to test:</label><br>
                <input type="password" name="test_password" placeholder="Enter password" value="<?php echo $_POST['test_password'] ?? ''; ?>">
            </p>
            <button type="submit">Test Login Query</button>
        </form>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_email'])) {
            $testEmail = trim($_POST['test_email']);
            $testPassword = $_POST['test_password'] ?? '';
            
            echo "<h2>Testing: $testEmail</h2>";
            
            // ========== NGO TEST ==========
            echo "<h2>1. NGO Login Test</h2>";
            
            $ngoTables = ['ngo', 'ngos'];
            $ngoTable = null;
            
            foreach ($ngoTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $ngoTable = $table;
                    break;
                }
            }
            
            if ($ngoTable) {
                echo "<div class='info'><strong>Table found:</strong> $ngoTable</div>";
                
                // Get primary key
                $pkResult = $conn->query("SHOW COLUMNS FROM `$ngoTable` WHERE `Key` = 'PRI'");
                $ngoIdColumn = 'id';
                if ($pkResult && $pkResult->num_rows > 0) {
                    $pkRow = $pkResult->fetch_assoc();
                    $ngoIdColumn = $pkRow['Field'];
                }
                echo "<div class='info'><strong>Primary Key Column:</strong> $ngoIdColumn</div>";
                
                // Get all columns
                $columns = $conn->query("SHOW COLUMNS FROM `$ngoTable`");
                $columnNames = [];
                while ($col = $columns->fetch_assoc()) {
                    $columnNames[] = $col['Field'];
                }
                echo "<div class='info'><strong>All Columns:</strong> " . implode(', ', $columnNames) . "</div>";
                
                // Test 1: Check if email column exists
                if (!in_array('email', $columnNames)) {
                    echo "<div class='fail'><strong>❌ ERROR:</strong> 'email' column not found! Available columns: " . implode(', ', $columnNames) . "</div>";
                } else {
                    echo "<div class='pass'><strong>✅ 'email' column exists</strong></div>";
                }
                
                // Test 2: Count all records
                $countResult = $conn->query("SELECT COUNT(*) as count FROM `$ngoTable`");
                $totalRecords = $countResult->fetch_assoc()['count'];
                echo "<div class='info'><strong>Total records in table:</strong> $totalRecords</div>";
                
                // Test 3: Show all emails in database
                echo "<h3>All Emails in NGO Table:</h3>";
                $allEmails = $conn->query("SELECT `$ngoIdColumn`, email, full_name FROM `$ngoTable` LIMIT 20");
                if ($allEmails->num_rows > 0) {
                    echo "<table>";
                    echo "<tr><th>ID</th><th>Email</th><th>Name</th><th>Matches Test?</th></tr>";
                    while ($row = $allEmails->fetch_assoc()) {
                        $matches = (strtolower(trim($row['email'])) === strtolower(trim($testEmail))) ? "✅ YES" : "❌ NO";
                        echo "<tr><td>{$row[$ngoIdColumn]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td><td>$matches</td></tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<div class='warning'>⚠️ No records found in table</div>";
                }
                
                // Test 4: Try exact match
                echo "<h3>Test 4: Exact Match Query</h3>";
                $stmt1 = $conn->prepare("SELECT `$ngoIdColumn`, email, full_name, password FROM `$ngoTable` WHERE email = ?");
                $stmt1->bind_param("s", $testEmail);
                $stmt1->execute();
                $result1 = $stmt1->get_result();
                if ($result1->num_rows > 0) {
                    $row1 = $result1->fetch_assoc();
                    echo "<div class='pass'><strong>✅ Exact match found!</strong></div>";
                    echo "<div class='code'>ID: {$row1[$ngoIdColumn]}<br>Email: {$row1['email']}<br>Name: {$row1['full_name']}</div>";
                } else {
                    echo "<div class='fail'><strong>❌ Exact match NOT found</strong></div>";
                }
                $stmt1->close();
                
                // Test 5: Try case-insensitive match
                echo "<h3>Test 5: Case-Insensitive Match Query</h3>";
                $stmt2 = $conn->prepare("SELECT `$ngoIdColumn`, email, full_name, password FROM `$ngoTable` WHERE LOWER(email) = LOWER(?)");
                $stmt2->bind_param("s", $testEmail);
                $stmt2->execute();
                $result2 = $stmt2->get_result();
                if ($result2->num_rows > 0) {
                    $row2 = $result2->fetch_assoc();
                    echo "<div class='pass'><strong>✅ Case-insensitive match found!</strong></div>";
                    echo "<div class='code'>ID: {$row2[$ngoIdColumn]}<br>Email in DB: {$row2['email']}<br>Name: {$row2['full_name']}</div>";
                    
                    // Test password if provided
                    if (!empty($testPassword)) {
                        if (password_verify($testPassword, $row2['password'])) {
                            echo "<div class='pass'><strong>✅ Password is CORRECT!</strong></div>";
                        } else {
                            echo "<div class='fail'><strong>❌ Password is INCORRECT</strong></div>";
                            echo "<div class='code'>Password hash in DB: " . substr($row2['password'], 0, 30) . "...</div>";
                        }
                    }
                } else {
                    echo "<div class='fail'><strong>❌ Case-insensitive match NOT found</strong></div>";
                }
                $stmt2->close();
                
                // Test 6: Try with TRIM
                echo "<h3>Test 6: Match with TRIM</h3>";
                $trimmedEmail = trim($testEmail);
                $stmt3 = $conn->prepare("SELECT `$ngoIdColumn`, email, full_name FROM `$ngoTable` WHERE TRIM(LOWER(email)) = TRIM(LOWER(?))");
                $stmt3->bind_param("s", $trimmedEmail);
                $stmt3->execute();
                $result3 = $stmt3->get_result();
                if ($result3->num_rows > 0) {
                    $row3 = $result3->fetch_assoc();
                    echo "<div class='pass'><strong>✅ TRIM match found!</strong></div>";
                } else {
                    echo "<div class='fail'><strong>❌ TRIM match NOT found</strong></div>";
                }
                $stmt3->close();
                
            } else {
                echo "<div class='fail'><strong>❌ NGO table not found (checked: ngo, ngos)</strong></div>";
            }
            
            // ========== VOLUNTEER TEST ==========
            echo "<h2>2. Volunteer Login Test</h2>";
            
            $volTables = ['volunteer', 'volunteers'];
            $volTable = null;
            
            foreach ($volTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $volTable = $table;
                    break;
                }
            }
            
            if ($volTable) {
                echo "<div class='info'><strong>Table found:</strong> $volTable</div>";
                
                $pkResult = $conn->query("SHOW COLUMNS FROM `$volTable` WHERE `Key` = 'PRI'");
                $volIdColumn = 'id';
                if ($pkResult && $pkResult->num_rows > 0) {
                    $pkRow = $pkResult->fetch_assoc();
                    $volIdColumn = $pkRow['Field'];
                }
                echo "<div class='info'><strong>Primary Key Column:</strong> $volIdColumn</div>";
                
                // Show all emails
                echo "<h3>All Emails in Volunteer Table:</h3>";
                $allEmails = $conn->query("SELECT `$volIdColumn`, email, full_name FROM `$volTable` LIMIT 20");
                if ($allEmails->num_rows > 0) {
                    echo "<table>";
                    echo "<tr><th>ID</th><th>Email</th><th>Name</th><th>Matches Test?</th></tr>";
                    while ($row = $allEmails->fetch_assoc()) {
                        $matches = (strtolower(trim($row['email'])) === strtolower(trim($testEmail))) ? "✅ YES" : "❌ NO";
                        echo "<tr><td>{$row[$volIdColumn]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td><td>$matches</td></tr>";
                    }
                    echo "</table>";
                }
                
                // Test case-insensitive match
                $stmt = $conn->prepare("SELECT `$volIdColumn`, email, full_name, password FROM `$volTable` WHERE LOWER(email) = LOWER(?)");
                $stmt->bind_param("s", $testEmail);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    echo "<div class='pass'><strong>✅ Volunteer match found!</strong></div>";
                    echo "<div class='code'>ID: {$row[$volIdColumn]}<br>Email: {$row['email']}<br>Name: {$row['full_name']}</div>";
                } else {
                    echo "<div class='fail'><strong>❌ Volunteer match NOT found</strong></div>";
                }
                $stmt->close();
            } else {
                echo "<div class='fail'><strong>❌ Volunteer table not found</strong></div>";
            }
            
            // ========== DONOR TEST ==========
            echo "<h2>3. Donor Login Test</h2>";
            
            $donorTables = ['donor', 'donors'];
            $donorTable = null;
            
            foreach ($donorTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $donorTable = $table;
                    break;
                }
            }
            
            if ($donorTable) {
                echo "<div class='info'><strong>Table found:</strong> $donorTable</div>";
                
                $pkResult = $conn->query("SHOW COLUMNS FROM `$donorTable` WHERE `Key` = 'PRI'");
                $donorIdColumn = 'id';
                if ($pkResult && $pkResult->num_rows > 0) {
                    $pkRow = $pkResult->fetch_assoc();
                    $donorIdColumn = $pkRow['Field'];
                }
                echo "<div class='info'><strong>Primary Key Column:</strong> $donorIdColumn</div>";
                
                // Show all emails
                echo "<h3>All Emails in Donor Table:</h3>";
                $allEmails = $conn->query("SELECT `$donorIdColumn`, email, full_name FROM `$donorTable` LIMIT 20");
                if ($allEmails->num_rows > 0) {
                    echo "<table>";
                    echo "<tr><th>ID</th><th>Email</th><th>Name</th><th>Matches Test?</th></tr>";
                    while ($row = $allEmails->fetch_assoc()) {
                        $matches = (strtolower(trim($row['email'])) === strtolower(trim($testEmail))) ? "✅ YES" : "❌ NO";
                        echo "<tr><td>{$row[$donorIdColumn]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td><td>$matches</td></tr>";
                    }
                    echo "</table>";
                }
                
                // Test case-insensitive match
                $stmt = $conn->prepare("SELECT `$donorIdColumn`, email, full_name, password FROM `$donorTable` WHERE LOWER(email) = LOWER(?)");
                $stmt->bind_param("s", $testEmail);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    echo "<div class='pass'><strong>✅ Donor match found!</strong></div>";
                    echo "<div class='code'>ID: {$row[$donorIdColumn]}<br>Email: {$row['email']}<br>Name: {$row['full_name']}</div>";
                } else {
                    echo "<div class='fail'><strong>❌ Donor match NOT found</strong></div>";
                }
                $stmt->close();
            } else {
                echo "<div class='fail'><strong>❌ Donor table not found</strong></div>";
            }
        } else {
            // Show all emails in all tables
            echo "<h2>All Emails in Database</h2>";
            echo "<p>Enter an email above to test, or review all emails below:</p>";
            
            // NGO
            $ngoTables = ['ngo', 'ngos'];
            foreach ($ngoTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $idCol = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $idCol = $pkResult->fetch_assoc()['Field'];
                    }
                    echo "<h3>NGO Table ($table)</h3>";
                    $result = $conn->query("SELECT `$idCol`, email, full_name FROM `$table` LIMIT 50");
                    if ($result->num_rows > 0) {
                        echo "<table>";
                        echo "<tr><th>ID</th><th>Email</th><th>Name</th></tr>";
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row[$idCol]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td></tr>";
                        }
                        echo "</table>";
                    }
                    break;
                }
            }
            
            // Volunteer
            $volTables = ['volunteer', 'volunteers'];
            foreach ($volTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $idCol = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $idCol = $pkResult->fetch_assoc()['Field'];
                    }
                    echo "<h3>Volunteer Table ($table)</h3>";
                    $result = $conn->query("SELECT `$idCol`, email, full_name FROM `$table` LIMIT 50");
                    if ($result->num_rows > 0) {
                        echo "<table>";
                        echo "<tr><th>ID</th><th>Email</th><th>Name</th></tr>";
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row[$idCol]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td></tr>";
                        }
                        echo "</table>";
                    }
                    break;
                }
            }
            
            // Donor
            $donorTables = ['donor', 'donors'];
            foreach ($donorTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $idCol = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $idCol = $pkResult->fetch_assoc()['Field'];
                    }
                    echo "<h3>Donor Table ($table)</h3>";
                    $result = $conn->query("SELECT `$idCol`, email, full_name FROM `$table` LIMIT 50");
                    if ($result->num_rows > 0) {
                        echo "<table>";
                        echo "<tr><th>ID</th><th>Email</th><th>Name</th></tr>";
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row[$idCol]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td></tr>";
                        }
                        echo "</table>";
                    }
                    break;
                }
            }
        }
        
        $conn->close();
        ?>
    </div>
</body>
</html>

