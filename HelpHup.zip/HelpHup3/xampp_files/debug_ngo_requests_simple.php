<?php
/**
 * SIMPLE DEBUG VERSION - No JOIN, just get data from ngoraisehelp table
 * Copy this to: C:\xampp\htdocs\helphup\api\
 * Then open: http://localhost/helphup/api/debug_ngo_requests_simple.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection failed");
    }
    
    // Find table
    $tableName = null;
    $possibleTables = ['ngoraisehelp', 'ngo_help_requests', 'ngohelprequests'];
    foreach ($possibleTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $tableName = $table;
            break;
        }
    }
    
    if (!$tableName) {
        throw new Exception("No NGO request table found");
    }
    
    // Use correct ID column
    $idColumn = ($tableName == 'ngoraisehelp') ? 'id' : 'request_id';
    
    // SIMPLE QUERY - NO JOIN, NO STATUS COLUMN CHECK
    $sql = "SELECT 
        $idColumn as request_id,
        ngo_id,
        request_title,
        category,
        urgency_level,
        required_amount,
        date_needed,
        contact_number,
        description,
        created_at
    FROM `$tableName`
    ORDER BY created_at DESC
    LIMIT 20";
    
    $result = $conn->query($sql);
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $requests = array();
    while ($row = $result->fetch_assoc()) {
        $requests[] = array(
            'request_id' => (int)$row['request_id'],
            'ngo_id' => (int)$row['ngo_id'],
            'ngo_name' => 'NGO',
            'org_name' => 'Organization',
            'request_title' => $row['request_title'],
            'category' => $row['category'],
            'urgency_level' => $row['urgency_level'],
            'required_amount' => (string)$row['required_amount'],
            'date_needed' => $row['date_needed'],
            'contact_number' => $row['contact_number'],
            'description' => $row['description'],
            'status' => 'pending',
            'created_at' => $row['created_at'],
            'request_type' => 'ngo'
        );
    }
    
    echo json_encode(array(
        'status' => true,
        'message' => 'Requests fetched successfully',
        'data' => $requests
    ), JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ), JSON_PRETTY_PRINT);
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

