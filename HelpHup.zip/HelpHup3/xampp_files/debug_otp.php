<?php
/**
 * Debug OTP Endpoint
 * Use this to check what OTPs are in the database
 * 
 * Usage: http://localhost/helphup/api/debug_otp.php?email=your@email.com
 */

require_once 'config.php';

header('Content-Type: application/json');

$email = $_GET['email'] ?? '';

if (empty($email)) {
    echo json_encode([
        'error' => 'Please provide email parameter: ?email=your@email.com'
    ], JSON_PRETTY_PRINT);
    exit();
}

$results = [];

// Normalize email to lowercase
$email = trim(strtolower($email));

// Check NGO tokens
$stmt = $conn->prepare("SELECT * FROM ngo_password_reset_tokens WHERE LOWER(email) = LOWER(?) ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$results['ngo_tokens'] = [];
while ($row = $result->fetch_assoc()) {
    $results['ngo_tokens'][] = [
        'otp' => $row['otp'],
        'expires_at' => $row['expires_at'],
        'used' => $row['used'],
        'created_at' => $row['created_at'],
        'is_expired' => strtotime($row['expires_at']) < time(),
        'is_valid' => strtotime($row['expires_at']) > time() && $row['used'] == 0
    ];
}
$stmt->close();

// Check Donor tokens
$stmt = $conn->prepare("SELECT * FROM donor_password_reset_tokens WHERE LOWER(email) = LOWER(?) ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$results['donor_tokens'] = [];
while ($row = $result->fetch_assoc()) {
    $results['donor_tokens'][] = [
        'otp' => $row['otp'],
        'expires_at' => $row['expires_at'],
        'used' => $row['used'],
        'created_at' => $row['created_at'],
        'is_expired' => strtotime($row['expires_at']) < time(),
        'is_valid' => strtotime($row['expires_at']) > time() && $row['used'] == 0
    ];
}
$stmt->close();

// Check Volunteer tokens
$stmt = $conn->prepare("SELECT * FROM volunteer_password_reset_tokens WHERE LOWER(email) = LOWER(?) ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$results['volunteer_tokens'] = [];
while ($row = $result->fetch_assoc()) {
    $results['volunteer_tokens'][] = [
        'otp' => $row['otp'],
        'expires_at' => $row['expires_at'],
        'used' => $row['used'],
        'created_at' => $row['created_at'],
        'is_expired' => strtotime($row['expires_at']) < time(),
        'is_valid' => strtotime($row['expires_at']) > time() && $row['used'] == 0
    ];
}
$stmt->close();

echo json_encode($results, JSON_PRETTY_PRINT);

$conn->close();
?>

