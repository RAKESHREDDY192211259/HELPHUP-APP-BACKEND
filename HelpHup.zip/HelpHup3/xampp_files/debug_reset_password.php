<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

$email = $_GET['email'] ?? 'rakeshreddyk1259.sse@saveetha.com';
$testPassword = $_GET['oldpassword'] ?? '123';
$newPassword = $_GET['newpassword'] ?? 'NewPass123';

echo "<h2>Password Reset Debug</h2>";
echo "<p>Email: $email</p>";

// Check current password
$tableNames = ['volunteer', 'volunteers'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    echo "<p style='color: red;'>Table not found</p>";
    exit;
}

echo "<p>Using table: <strong>$tableName</strong></p>";

// Get current password hash
$stmt = $conn->prepare("SELECT id, email, password, CHAR_LENGTH(password) as pwd_len FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $actualEmail = $row['email'];
    $currentHash = $row['password'];
    
    echo "<h3>Current State:</h3>";
    echo "<p>Actual email in DB: <strong>$actualEmail</strong></p>";
    echo "<p>Password hash length: <strong>" . $row['pwd_len'] . "</strong></p>";
    echo "<p>Password hash preview: <strong>" . substr($currentHash, 0, 30) . "...</strong></p>";
    
    $oldWorks = password_verify($testPassword, $currentHash);
    $newWorks = password_verify($newPassword, $currentHash);
    
    echo "<p>Old password '$testPassword' verifies: <strong style='color: " . ($oldWorks ? 'green' : 'red') . ";'>" . ($oldWorks ? 'YES' : 'NO') . "</strong></p>";
    echo "<p>New password '$newPassword' verifies: <strong style='color: " . ($newWorks ? 'green' : 'red') . ";'>" . ($newWorks ? 'YES' : 'NO') . "</strong></p>";
    
    // Simulate the update
    echo "<h3>Simulating Password Update:</h3>";
    $hashedNew = password_hash($newPassword, PASSWORD_DEFAULT);
    echo "<p>New hash length: <strong>" . strlen($hashedNew) . "</strong></p>";
    echo "<p>New hash preview: <strong>" . substr($hashedNew, 0, 30) . "...</strong></p>";
    
    // Test the UPDATE query
    $update = $conn->prepare("UPDATE `$tableName` SET password = ? WHERE LOWER(email) = LOWER(?)");
    $update->bind_param("ss", $hashedNew, $actualEmail);
    
    if ($update->execute()) {
        $affected = $update->affected_rows;
        echo "<p style='color: green;'>✓ UPDATE executed successfully!</p>";
        echo "<p>Affected rows: <strong>$affected</strong></p>";
        
        // Verify the update
        $verify = $conn->prepare("SELECT password FROM `$tableName` WHERE email = ?");
        $verify->bind_param("s", $actualEmail);
        $verify->execute();
        $verifyResult = $verify->get_result();
        $verifyRow = $verifyResult->fetch_assoc();
        $verify->close();
        
        $updatedHash = $verifyRow['password'];
        echo "<p>Updated hash preview: <strong>" . substr($updatedHash, 0, 30) . "...</strong></p>";
        
        $newWorksAfter = password_verify($newPassword, $updatedHash);
        $oldWorksAfter = password_verify($testPassword, $updatedHash);
        
        echo "<p>After update - New password '$newPassword' verifies: <strong style='color: " . ($newWorksAfter ? 'green' : 'red') . ";'>" . ($newWorksAfter ? 'YES' : 'NO') . "</strong></p>";
        echo "<p>After update - Old password '$testPassword' verifies: <strong style='color: " . ($oldWorksAfter ? 'green' : 'red') . ";'>" . ($oldWorksAfter ? 'YES' : 'NO') . "</strong></p>";
        
        if ($oldWorksAfter) {
            echo "<p style='color: red; font-weight: bold;'>⚠ WARNING: Old password still works! The update may not have worked correctly.</p>";
        }
        
    } else {
        echo "<p style='color: red;'>✗ UPDATE failed: " . $update->error . "</p>";
    }
    $update->close();
    
} else {
    echo "<p style='color: red;'>Email not found</p>";
}

$stmt->close();
$conn->close();
?>

