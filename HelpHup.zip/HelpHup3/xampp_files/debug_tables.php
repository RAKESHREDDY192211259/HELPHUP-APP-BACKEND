<?php
header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get all tables
    $tables = $conn->query("SHOW TABLES");
    $tableList = array();
    while ($table = $tables->fetch_array()) {
        $tableList[] = $table[0];
    }
    
    // Check specific tables and their columns
    $tableInfo = array();
    
    foreach (['ngo_help_requests', 'volunteer_requests', 'donor_campaigns', 'ngoraisehelp', 'volunteerraisehelp', 'donorraisehelp'] as $tableName) {
        $check = $conn->query("SHOW TABLES LIKE '$tableName'");
        if ($check && $check->num_rows > 0) {
            $columns = $conn->query("SHOW COLUMNS FROM `$tableName`");
            $columnList = array();
            while ($col = $columns->fetch_assoc()) {
                $columnList[] = $col['Field'];
            }
            $tableInfo[$tableName] = $columnList;
        }
    }
    
    echo json_encode([
        'status' => true,
        'all_tables' => $tableList,
        'table_details' => $tableInfo
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => false,
        'message' => $e->getMessage()
    ]);
}
?>
