<?php
// Quick debug script to test verification
// Usage: php debug_verify_issue.php email otp
// Example: php debug_verify_issue.php rakeshreddyk1259.sse@saveetha.com 071756

require_once 'config.php';

$email = isset($argv[1]) ? $argv[1] : 'rakeshreddyk1259.sse@saveetha.com';
$inputOtp = isset($argv[2]) ? $argv[2] : '071756';

echo "=== OTP Verification Debug ===\n\n";
echo "Email: $email\n";
echo "Input OTP: $inputOtp\n\n";

// Normalize (same as verification script)
$normalizedEmail = trim(strtolower($email));
$normalizedOtp = preg_replace('/[^0-9]/', '', $inputOtp);
$normalizedOtp = str_pad($normalizedOtp, 6, '0', STR_PAD_LEFT);

echo "Normalized Email: '$normalizedEmail'\n";
echo "Normalized OTP: '$normalizedOtp' (length: " . strlen($normalizedOtp) . ")\n\n";

// Check database
$stmt = $conn->prepare("SELECT id, email, otp, expires_at, used, created_at, 
                        TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry,
                        LENGTH(otp) as otp_len,
                        HEX(otp) as otp_hex
                        FROM ngo_password_reset_tokens 
                        WHERE email = ? 
                        ORDER BY created_at DESC LIMIT 1");
$stmt->bind_param("s", $normalizedEmail);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "❌ No OTP found for this email\n";
    exit(1);
}

$row = $result->fetch_assoc();
echo "=== Database Record ===\n";
echo "ID: {$row['id']}\n";
echo "Email (DB): '{$row['email']}'\n";
echo "Email match: " . ($row['email'] === $normalizedEmail ? "✅ YES" : "❌ NO") . "\n\n";

echo "OTP (DB): '{$row['otp']}'\n";
echo "OTP (DB length): {$row['otp_len']}\n";
echo "OTP (DB hex): {$row['otp_hex']}\n";
echo "OTP (input normalized): '$normalizedOtp'\n";
echo "OTP (input hex): " . bin2hex($normalizedOtp) . "\n";
echo "OTP match: " . ($row['otp'] === $normalizedOtp ? "✅ YES" : "❌ NO") . "\n";
echo "OTP match (trim): " . (trim($row['otp']) === trim($normalizedOtp) ? "✅ YES" : "❌ NO") . "\n\n";

echo "Created: {$row['created_at']}\n";
echo "Expires: {$row['expires_at']}\n";
echo "Used: {$row['used']}\n";
echo "Seconds until expiry: {$row['seconds_until_expiry']}\n\n";

// Test verification query
echo "=== Testing Verification Query ===\n";
$verifyStmt = $conn->prepare("SELECT *, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry 
                               FROM ngo_password_reset_tokens 
                               WHERE email = ? AND otp = ? AND used = 0");
$verifyStmt->bind_param("ss", $normalizedEmail, $normalizedOtp);
$verifyStmt->execute();
$verifyResult = $verifyStmt->get_result();

if ($verifyResult->num_rows > 0) {
    $verifyRow = $verifyResult->fetch_assoc();
    echo "✅ Query found record\n";
    echo "Seconds until expiry: {$verifyRow['seconds_until_expiry']}\n";
    if ($verifyRow['seconds_until_expiry'] > 0) {
        echo "✅✅✅ OTP is VALID and NOT EXPIRED\n";
    } else {
        echo "❌ OTP is EXPIRED (expired " . abs($verifyRow['seconds_until_expiry']) . " seconds ago)\n";
    }
} else {
    echo "❌ Query did NOT find record\n\n";
    
    // Test each condition
    echo "Testing conditions:\n";
    $t1 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ?");
    $t1->bind_param("s", $normalizedEmail);
    $t1->execute();
    $r1 = $t1->get_result()->fetch_assoc();
    echo "  Email match: {$r1['cnt']} records " . ($r1['cnt'] > 0 ? "✅" : "❌") . "\n";
    
    $t2 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ?");
    $t2->bind_param("ss", $normalizedEmail, $normalizedOtp);
    $t2->execute();
    $r2 = $t2->get_result()->fetch_assoc();
    echo "  Email + OTP match: {$r2['cnt']} records " . ($r2['cnt'] > 0 ? "✅" : "❌") . "\n";
    
    $t3 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ? AND used = 0");
    $t3->bind_param("ss", $normalizedEmail, $normalizedOtp);
    $t3->execute();
    $r3 = $t3->get_result()->fetch_assoc();
    echo "  Email + OTP + not used: {$r3['cnt']} records " . ($r3['cnt'] > 0 ? "✅" : "❌") . "\n";
    
    // Try with exact stored OTP
    $t4 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ?");
    $t4->bind_param("ss", $normalizedEmail, $row['otp']);
    $t4->execute();
    $r4 = $t4->get_result()->fetch_assoc();
    echo "  Email + stored OTP: {$r4['cnt']} records " . ($r4['cnt'] > 0 ? "✅" : "❌") . "\n";
}

$stmt->close();
$conn->close();
?>

