<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h2>Password Reset Diagnosis</h2>";

// Get test email from URL or use default
$testEmail = $_GET['email'] ?? 'rakeshreddyk1259.sse@saveetha.com';

echo "<h3>Checking email: $testEmail</h3>";

// Check volunteers table
echo "<h4>1. Volunteers Table:</h4>";
$stmt = $conn->prepare("SELECT id, email, LEFT(password, 30) as pwd_preview FROM volunteers WHERE LOWER(email) = LOWER(?)");
$stmt->bind_param("s", $testEmail);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<p>✓ Found in volunteers table</p>";
    echo "<p>ID: {$row['id']}</p>";
    echo "<p>Email in DB: <strong>" . htmlspecialchars($row['email']) . "</strong></p>";
    echo "<p>Password hash: " . htmlspecialchars($row['pwd_preview']) . "...</p>";
    $volunteerEmail = $row['email'];
    $volunteerId = $row['id'];
} else {
    echo "<p style='color: red;'>✗ Not found in volunteers table</p>";
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// Check password_reset_tokens table
echo "<h4>2. Password Reset Tokens Table:</h4>";
$stmt = $conn->prepare("SELECT email, otp, used, expires_at, created_at FROM volunteer_password_reset_tokens WHERE email = ? ORDER BY created_at DESC LIMIT 3");
// Use lowercase email for tokens table
$lowerEmail = strtolower($testEmail);
$stmt->bind_param("s", $lowerEmail);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<p>✓ Found " . $result->num_rows . " token(s)</p>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Email</th><th>OTP</th><th>Used</th><th>Created</th><th>Expires</th></tr>";
    while ($tokenRow = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($tokenRow['email']) . "</td>";
        echo "<td>" . htmlspecialchars($tokenRow['otp']) . "</td>";
        echo "<td>" . ($tokenRow['used'] ? 'Yes' : 'No') . "</td>";
        echo "<td>" . htmlspecialchars($tokenRow['created_at']) . "</td>";
        echo "<td>" . htmlspecialchars($tokenRow['expires_at']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    $tokenEmail = $tokenRow['email'];
} else {
    echo "<p style='color: orange;'>⚠ No tokens found for this email</p>";
}
$stmt->close();

// Test UPDATE query
echo "<h4>3. Testing UPDATE Query:</h4>";
echo "<p>Volunteer email (from DB): <strong>$volunteerEmail</strong></p>";
echo "<p>Token email (lowercase): <strong>$lowerEmail</strong></p>";

if ($volunteerEmail !== $lowerEmail) {
    echo "<p style='color: red; font-weight: bold;'>⚠ CASE MISMATCH DETECTED!</p>";
    echo "<p>This is the problem! The UPDATE query needs to use the exact email from the volunteers table.</p>";
}

// Simulate the UPDATE
$testHash = password_hash('TestPassword123', PASSWORD_DEFAULT);
echo "<p>Testing UPDATE with volunteer email (correct):</p>";
$testUpdate = $conn->prepare("UPDATE volunteers SET password = ? WHERE email = ?");
$testUpdate->bind_param("ss", $testHash, $volunteerEmail);
$testUpdate->execute();
$affected1 = $testUpdate->affected_rows;
$testUpdate->close();
echo "<p>Using email '$volunteerEmail': Affected rows = <strong>$affected1</strong></p>";

echo "<p>Testing UPDATE with lowercase email (wrong):</p>";
$testUpdate2 = $conn->prepare("UPDATE volunteers SET password = ? WHERE email = ?");
$testUpdate2->bind_param("ss", $testHash, $lowerEmail);
$testUpdate2->execute();
$affected2 = $testUpdate2->affected_rows;
$testUpdate2->close();
echo "<p>Using email '$lowerEmail': Affected rows = <strong>$affected2</strong></p>";

if ($affected1 > 0 && $affected2 == 0) {
    echo "<p style='color: green;'>✓ This confirms the issue - we MUST use the exact email from the volunteers table!</p>";
}

// Restore original password (you'll need to do this manually)
echo "<hr>";
echo "<p><strong>Note:</strong> The test UPDATE changed the password. You may need to reset it again.</p>";

$conn->close();
?>

