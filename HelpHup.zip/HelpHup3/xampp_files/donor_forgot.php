<?php
// Set error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Start output buffering to catch any errors
ob_start();

// Wrap everything in try-catch to prevent 500 errors
try {
    // Load config
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    // Check if database connection exists
    if (!isset($conn) || $conn->connect_error) {
        throw new Exception("Database connection failed: " . ($conn->connect_error ?? "Connection not established"));
    }
    
    // Check if sendResponse function exists
    if (!function_exists('sendResponse')) {
        throw new Exception("sendResponse function not found in config.php");
    }
    
    // Try to include email_config.php, but don't fail if it doesn't exist
    $emailConfigExists = @include_once 'email_config.php';
    if (!$emailConfigExists || !function_exists('sendOTPEmail')) {
        if (!function_exists('sendOTPEmail')) {
            function sendOTPEmail($to, $otp, $userType = 'User') {
                return array(
                    'success' => false,
                    'message' => 'Email configuration not available. OTP shown in response.'
                );
            }
        }
    }
    
    // Get JSON input
    $json = file_get_contents('php://input');
    if ($json === false) {
        throw new Exception("Failed to read input data");
    }
    $data = json_decode($json, true);
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("Invalid JSON input: " . json_last_error_msg());
    }

    $email = trim(strtolower($data['email'] ?? ''));

    if (empty($email)) {
        sendResponse(false, "Email is required");
    }

    // Check if email exists (case-insensitive)
    // The donors table uses 'id' as the primary key column (not 'donor_id')
    $tableName = 'donors'; // Based on phpMyAdmin, the table is 'donors' (plural)
    $stmt = $conn->prepare("SELECT id FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
    if ($stmt === false) {
        throw new Exception("Database prepare error: " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    if (!$stmt->execute()) {
        throw new Exception("Database execute error: " . $stmt->error);
    }
    $result = $stmt->get_result();
    if ($result === false) {
        throw new Exception("Database result error: " . $conn->error);
    }

    if ($result->num_rows == 0) {
        $stmt->close();
        sendResponse(false, "Email not found");
    }

    // Check if table exists first
    $tableCheck = $conn->query("SHOW TABLES LIKE 'donor_password_reset_tokens'");
    if ($tableCheck === false) {
        $stmt->close();
        throw new Exception("Database query error: " . $conn->error);
    }
    if ($tableCheck->num_rows == 0) {
        $stmt->close();
        sendResponse(false, "Database error: Table 'donor_password_reset_tokens' does not exist. Please run setup_password_reset_table.php first.");
    }

    // Generate 6-digit OTP
    $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    
    // Use database time to calculate expiration (to avoid timezone issues)
    // Get current database time and expiration time in one query
    $timeResult = $conn->query("SELECT NOW() as db_time, DATE_ADD(NOW(), INTERVAL 15 MINUTE) as expires_time");
    if ($timeResult && $timeResult->num_rows > 0) {
        $timeRow = $timeResult->fetch_assoc();
        $created_at = $timeRow['db_time'];  // Use database time for created_at too
        $expires_at = $timeRow['expires_time'];
        error_log("Database time: $created_at, Expires at: $expires_at");
    } else {
        // Fallback to PHP time calculation (should not happen)
        $created_at = date('Y-m-d H:i:s');
        $expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        error_log("WARNING: Using PHP time calculation - Created: $created_at, Expires: $expires_at");
    }

    // Delete old tokens for this email (email is already lowercased)
    $delete = $conn->prepare("DELETE FROM donor_password_reset_tokens WHERE email = ?");
    if ($delete === false) {
        $stmt->close();
        throw new Exception("Database prepare error (delete): " . $conn->error);
    }
    $delete->bind_param("s", $email);
    $delete->execute();
    $delete->close();

    // Insert new token - explicitly set both created_at and expires_at using database time
    $insert = $conn->prepare("INSERT INTO donor_password_reset_tokens (email, otp, expires_at, created_at) VALUES (?, ?, ?, ?)");
    if ($insert === false) {
        $stmt->close();
        sendResponse(false, "Database error: " . $conn->error . ". Please check if donor_password_reset_tokens table exists.");
    }
    $insert->bind_param("ssss", $email, $otp, $expires_at, $created_at);
    if (!$insert->execute()) {
        $stmt->close();
        $insert->close();
        sendResponse(false, "Failed to save OTP: " . $insert->error);
    }

    // Verify the OTP was actually saved
    $verifyInsert = $conn->prepare("SELECT otp, expires_at FROM donor_password_reset_tokens WHERE email = ? AND otp = ?");
    if ($verifyInsert === false) {
        $stmt->close();
        $insert->close();
        throw new Exception("Database prepare error (verify): " . $conn->error);
    }
    $verifyInsert->bind_param("ss", $email, $otp);
    $verifyInsert->execute();
    $verifyResult = $verifyInsert->get_result();
    if ($verifyResult === false) {
        $stmt->close();
        $insert->close();
        $verifyInsert->close();
        throw new Exception("Database result error (verify): " . $conn->error);
    }
    if ($verifyResult->num_rows == 0) {
        error_log("WARNING: OTP was not saved correctly!");
        $stmt->close();
        $insert->close();
        $verifyInsert->close();
        sendResponse(false, "Failed to save OTP. Please try again.");
    }
    $verifyInsert->close();

    error_log("OTP saved successfully - Email: $email, OTP: $otp");
    $insert->close();

    // Send OTP via email
    try {
        error_log("Attempting to send OTP email to: $email, OTP: $otp");
        $emailResult = sendOTPEmail($email, $otp, 'Donor');
        
        if ($emailResult && isset($emailResult['success']) && $emailResult['success']) {
            error_log("Email sent successfully to: $email");
            $stmt->close();
            sendResponse(true, "OTP sent successfully to your email. Please check your inbox.");
        } else {
            // Email failed, but OTP is generated - return success (OTP is in database)
            $emailMsg = $emailResult['message'] ?? 'Email sending failed';
            error_log("Email sending failed for: $email. Error: $emailMsg");
            error_log("IMPORTANT: OTP is saved in database: $otp for email: $email");
            $stmt->close();
            // Don't show OTP in response - user should check email or configure SMTP
            sendResponse(true, "OTP generated successfully. Please check your email. If you don't receive it, please configure SMTP in email_config.php");
        }
    } catch (Exception $e) {
        // Email function error - but OTP is saved, so return success
        error_log("Email error: " . $e->getMessage());
        error_log("IMPORTANT: OTP is saved in database: $otp for email: $email");
        $stmt->close();
        sendResponse(true, "OTP generated successfully. Please check your email. If you don't receive it, please configure SMTP in email_config.php");
    }

} catch (Exception $e) {
    ob_end_clean();
    error_log("Fatal error in donor_forgot.php: " . $e->getMessage() . " at " . $e->getFile() . ":" . $e->getLine());
    
    // Try to send error response if sendResponse exists
    if (function_exists('sendResponse')) {
        sendResponse(false, "Server error: " . $e->getMessage());
    } else {
        // Last resort - output JSON directly
        header('Content-Type: application/json');
        echo json_encode(array(
            'status' => false,
            'message' => "Server error: " . $e->getMessage()
        ));
        exit();
    }
} catch (Error $e) {
    ob_end_clean();
    error_log("Fatal PHP error in donor_forgot.php: " . $e->getMessage() . " at " . $e->getFile() . ":" . $e->getLine());
    
    // Try to send error response if sendResponse exists
    if (function_exists('sendResponse')) {
        sendResponse(false, "Server error: " . $e->getMessage());
    } else {
        // Last resort - output JSON directly
        header('Content-Type: application/json');
        echo json_encode(array(
            'status' => false,
            'message' => "Server error: " . $e->getMessage()
        ));
        exit();
    }
}

ob_end_flush();
?>
