<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Debug: Log received data (remove in production)
error_log("Donor Login - Raw JSON: " . $json);
error_log("Donor Login - Decoded data: " . print_r($data, true));

$email = isset($data['email']) ? trim($data['email']) : '';
$password = isset($data['password']) ? trim($data['password']) : '';

error_log("Donor Login - Email: '$email', Password length: " . strlen($password));

if (empty($email) || empty($password)) {
    sendResponse(false, "Email and password are required");
    exit;
}

// Try donors first (where data usually is), then donor
$tableNames = ['donors', 'donor'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break; // Use first table found
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Donor table not found.");
    exit;
}

// Detect primary key column name (id or donor_id)
$idColumn = 'id'; // default
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` WHERE `Key` = 'PRI'");
if ($checkId && $checkId->num_rows > 0) {
    $pkRow = $checkId->fetch_assoc();
    $idColumn = $pkRow['Field']; // Will be 'id' or 'donor_id'
}

// Query database - use case-insensitive email matching
$stmt = $conn->prepare("SELECT `$idColumn`, full_name, email, password FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
if (!$stmt) {
    sendResponse(false, "Database error: " . $conn->error);
    exit;
}
$stmt->bind_param("s", $email);
if (!$stmt->execute()) {
    sendResponse(false, "Database error: " . $stmt->error);
    $stmt->close();
    exit;
}
$result = $stmt->get_result();

error_log("Donor Login - Query executed, rows found: " . $result->num_rows);
error_log("Donor Login - Searching for email: '$email'");

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        // Return response in format expected by Android app (donor_id and full_name at root level)
        header('Content-Type: application/json');
        echo json_encode(array(
            'status' => true,
            'message' => 'Login successful',
            'donor_id' => (int)$row[$idColumn],
            'full_name' => $row['full_name']
        ));
        exit();
    } else {
        sendResponse(false, "Invalid password");
    }
} else {
    sendResponse(false, "Email not found");
}

$stmt->close();
$conn->close();
?>
