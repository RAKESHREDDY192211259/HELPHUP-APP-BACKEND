<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$full_name = $data['full_name'] ?? '';
$phone = $data['phone'] ?? '';
$email = $data['email'] ?? '';
$address = $data['address'] ?? '';
$password = $data['password'] ?? '';

// Validate required fields
if (empty($full_name) || empty($phone) || empty($email) || empty($address) || empty($password)) {
    sendResponse(false, "All fields are required");
}

// Check if email already exists
$check = $conn->prepare("SELECT donor_id FROM donor WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    sendResponse(false, "Email already registered");
}
$check->close();

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert into database
$stmt = $conn->prepare("INSERT INTO donor (full_name, phone, email, address, password) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $full_name, $phone, $email, $address, $hashed_password);

if ($stmt->execute()) {
    sendResponse(true, "Registration successful");
} else {
    sendResponse(false, "Registration failed: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

