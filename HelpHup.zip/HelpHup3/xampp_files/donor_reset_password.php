<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$email = $data['email'] ?? '';
$otp = $data['otp'] ?? '';
$newPassword = $data['new_password'] ?? '';

if (empty($email) || empty($otp) || empty($newPassword)) {
    sendResponse(false, "Email, OTP, and new password are required");
}

// Validate password length
if (strlen($newPassword) < 6) {
    sendResponse(false, "Password must be at least 6 characters long");
}

// Lowercase email for tokens table (tokens table stores lowercase from forgot.php)
$emailLower = strtolower(trim($email));

// Verify OTP first - use same logic as verify_otp.php
// Use lowercase email to match tokens table
$stmt = $conn->prepare("SELECT *, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry FROM donor_password_reset_tokens WHERE email = ? AND CAST(otp AS CHAR) = ? AND used = 0");
$stmt->bind_param("ss", $emailLower, $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    // Check if OTP exists but was used
    $checkUsed = $conn->prepare("SELECT used FROM donor_password_reset_tokens WHERE email = ? AND CAST(otp AS CHAR) = ?");
    $checkUsed->bind_param("ss", $emailLower, $otp);
    $checkUsed->execute();
    $usedResult = $checkUsed->get_result();
    
    if ($usedResult->num_rows > 0) {
        $usedRow = $usedResult->fetch_assoc();
        if ($usedRow['used'] == 1) {
            sendResponse(false, "This OTP has already been used. Please request a new OTP.");
        }
    }
    
    // Check if expired
    $checkExpired = $conn->prepare("SELECT expires_at, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry FROM donor_password_reset_tokens WHERE email = ? AND CAST(otp AS CHAR) = ?");
    $checkExpired->bind_param("ss", $emailLower, $otp);
    $checkExpired->execute();
    $expiredResult = $checkExpired->get_result();
    
    if ($expiredResult->num_rows > 0) {
        $expiredRow = $expiredResult->fetch_assoc();
        if ($expiredRow['seconds_until_expiry'] <= 0) {
            sendResponse(false, "OTP has expired. Please request a new OTP.");
        }
    }
    
    sendResponse(false, "Invalid OTP. Please check and try again.");
}

$otpData = $result->fetch_assoc();

// Check if OTP is expired
if ($otpData['seconds_until_expiry'] <= 0) {
    sendResponse(false, "OTP has expired. Please request a new OTP.");
}

// OTP is valid - update password
// Try different possible table names
$tableNames = ['donor', 'donors'];
$tableName = null;

foreach ($tableNames as $table) {
    $checkTable = $conn->query("SHOW TABLES LIKE '$table'");
    if ($checkTable && $checkTable->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Donor table not found.");
}

$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
// Use case-insensitive email matching for UPDATE (same as login)
$update = $conn->prepare("UPDATE `$tableName` SET password = ? WHERE LOWER(email) = LOWER(?)");
$update->bind_param("ss", $hashedPassword, $email);
$update->execute();

if ($update->affected_rows > 0) {
    // Mark OTP as used instead of deleting (use lowercase for tokens table)
    $markUsed = $conn->prepare("UPDATE donor_password_reset_tokens SET used = 1 WHERE email = ? AND CAST(otp AS CHAR) = ?");
    $markUsed->bind_param("ss", $emailLower, $otp);
    $markUsed->execute();
    $markUsed->close();
    
    sendResponse(true, "Password reset successfully");
} else {
    // Check if email exists (case-insensitive)
    $checkEmail = $conn->prepare("SELECT id FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $emailResult = $checkEmail->get_result();
    
    if ($emailResult->num_rows == 0) {
        sendResponse(false, "Failed to update password. Email not found in database.");
    } else {
        sendResponse(false, "Failed to update password. Please try again or contact support.");
    }
    $checkEmail->close();
}

$update->close();
$stmt->close();
$conn->close();
?>
