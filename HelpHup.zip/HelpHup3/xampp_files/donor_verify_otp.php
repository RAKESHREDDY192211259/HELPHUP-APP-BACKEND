<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$email = trim(strtolower($data['email'] ?? ''));
$otp = trim($data['otp'] ?? '');

if (empty($email) || empty($otp)) {
    sendResponse(false, "Email and OTP are required");
}

// Normalize OTP - ensure it's exactly 6 digits (pad with zeros if needed)
// Remove any non-numeric characters first
$otp = preg_replace('/[^0-9]/', '', $otp);
$otp = str_pad($otp, 6, '0', STR_PAD_LEFT);

// Log what we're searching for
error_log("Donor OTP Verification - Email: '$email', OTP: '$otp' (normalized)");

// First, let's check what OTPs exist for this email (for debugging)
$debugStmt = $conn->prepare("SELECT otp, expires_at, used, created_at, email FROM donor_password_reset_tokens WHERE email = ? ORDER BY created_at DESC LIMIT 3");
$debugStmt->bind_param("s", $email);
$debugStmt->execute();
$debugResult = $debugStmt->get_result();
error_log("Debug: Found " . $debugResult->num_rows . " OTP records for email: $email");
while ($row = $debugResult->fetch_assoc()) {
    error_log("Debug: OTP in DB: '" . $row['otp'] . "' (length: " . strlen($row['otp']) . "), Email: '" . $row['email'] . "', Expires: " . $row['expires_at'] . ", Used: " . $row['used']);
}
$debugStmt->close();

// Verify OTP - check if exists, not expired, and not used
// Note: Email is already lowercased, so we compare directly without LOWER()
// Cast OTP to string in SQL to ensure proper comparison (handles INT columns)
// Use database time for expiration comparison to avoid timezone issues
$stmt = $conn->prepare("SELECT *, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry FROM donor_password_reset_tokens WHERE email = ? AND CAST(otp AS CHAR) = ? AND used = 0");

if ($stmt === false) {
    sendResponse(false, "Database error: " . $conn->error . ". Please check if donor_password_reset_tokens table exists.");
}

$stmt->bind_param("ss", $email, $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $secondsUntilExpiry = $row['seconds_until_expiry'];
    $storedOtp = $row['otp'];
    error_log("Donor OTP found - Stored OTP: '$storedOtp', Received OTP: '$otp', Seconds until expiry: $secondsUntilExpiry, Expires at: " . $row['expires_at']);
    
    if ($secondsUntilExpiry > 0) {
        // OTP is valid - return success
        error_log("Donor OTP verified successfully for email: $email");
        sendResponse(true, "OTP verified successfully");
        $stmt->close();
        $conn->close();
        exit();
    } else {
        error_log("Donor OTP found but expired - $secondsUntilExpiry seconds until expiry");
        sendResponse(false, "OTP has expired. Please request a new OTP.");
        $stmt->close();
        $conn->close();
        exit();
    }
}

if ($result->num_rows == 0) {
    // Check if OTP exists but expired or used
    $checkExpired = $conn->prepare("SELECT * FROM donor_password_reset_tokens WHERE email = ? AND CAST(otp AS CHAR) = ?");
    $checkExpired->bind_param("ss", $email, $otp);
    $checkExpired->execute();
    $expiredResult = $checkExpired->get_result();
    
    if ($expiredResult->num_rows > 0) {
        $row = $expiredResult->fetch_assoc();
        if ($row['used'] == 1) {
            sendResponse(false, "OTP has already been used. Please request a new OTP.");
        } else {
            // Check if expired using database time calculation
            $expiryCheck = $conn->query("SELECT TIMESTAMPDIFF(SECOND, NOW(), '" . $row['expires_at'] . "') as seconds_until_expiry");
            if ($expiryCheck && $expiryCheck->num_rows > 0) {
                $expiryRow = $expiryCheck->fetch_assoc();
                $secondsUntilExpiry = $expiryRow['seconds_until_expiry'];
                
                if ($secondsUntilExpiry <= 0) {
                    $minutesExpired = round(abs($secondsUntilExpiry) / 60);
                    sendResponse(false, "OTP has expired ($minutesExpired minutes ago). Please request a new OTP.");
                } else {
                    error_log("ERROR: Donor OTP exists, not expired, not used, but verification query failed.");
                    sendResponse(false, "OTP verification failed. Please request a new OTP and try again.");
                }
            } else {
                // Fallback to PHP time calculation
                $expiresAt = strtotime($row['expires_at']);
                $now = time();
                if ($expiresAt < $now) {
                    sendResponse(false, "OTP has expired. Please request a new OTP.");
                } else {
                    sendResponse(false, "OTP verification failed. Please request a new OTP and try again.");
                }
            }
        }
    } else {
        // Check if email exists but OTP doesn't match
        $checkEmail = $conn->prepare("SELECT otp, expires_at, used, created_at FROM donor_password_reset_tokens WHERE email = ? ORDER BY created_at DESC LIMIT 1");
        $checkEmail->bind_param("s", $email);
        $checkEmail->execute();
        $emailResult = $checkEmail->get_result();
        
        if ($emailResult->num_rows > 0) {
            $row = $emailResult->fetch_assoc();
            $storedOtp = $row['otp'];
            error_log("Donor OTP mismatch - Stored: '$storedOtp' (length: " . strlen($storedOtp) . "), Received: '$otp' (length: " . strlen($otp) . ")");
            sendResponse(false, "Invalid OTP. The OTP you entered does not match. Please check and try again.");
        } else {
            sendResponse(false, "No OTP found for this email. Please request a new OTP.");
        }
        $checkEmail->close();
    }
    $checkExpired->close();
    $stmt->close();
    $conn->close();
    exit();
}

// OTP is valid - return success
sendResponse(true, "OTP verified successfully");

$stmt->close();
$conn->close();
?>

