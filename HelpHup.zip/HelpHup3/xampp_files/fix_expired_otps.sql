-- Fix OTP records where expires_at is before created_at
-- This script updates the expires_at to be 15 minutes after created_at

-- Fix NGO password reset tokens
UPDATE ngo_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) < 0 
   OR expires_at IS NULL;

-- Fix Donor password reset tokens
UPDATE donor_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) < 0 
   OR expires_at IS NULL;

-- Fix Volunteer password reset tokens
UPDATE volunteer_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) < 0 
   OR expires_at IS NULL;

-- Fix Admin password reset tokens
UPDATE admin_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) < 0 
   OR expires_at IS NULL;

-- Show affected records (for verification)
SELECT 'NGO' as table_name, id, email, created_at, expires_at, 
       TIMESTAMPDIFF(SECOND, created_at, expires_at) as seconds_difference
FROM ngo_password_reset_tokens
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) < 0
UNION ALL
SELECT 'Donor' as table_name, id, email, created_at, expires_at,
       TIMESTAMPDIFF(SECOND, created_at, expires_at) as seconds_difference
FROM donor_password_reset_tokens
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) < 0
UNION ALL
SELECT 'Volunteer' as table_name, id, email, created_at, expires_at,
       TIMESTAMPDIFF(SECOND, created_at, expires_at) as seconds_difference
FROM volunteer_password_reset_tokens
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) < 0
UNION ALL
SELECT 'Admin' as table_name, id, email, created_at, expires_at,
       TIMESTAMPDIFF(SECOND, created_at, expires_at) as seconds_difference
FROM admin_password_reset_tokens
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) < 0;

