<?php
require_once 'config.php';

echo "=== Fixing expires_at timestamps in password reset tables ===\n\n";

// Function to fix a table
function fixTable($conn, $tableName) {
    echo "Processing table: $tableName\n";
    
    // Get all records where expires_at is before or equal to created_at
    $checkQuery = "SELECT id, email, created_at, expires_at, TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds 
                   FROM $tableName 
                   WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) <= 0 OR expires_at IS NULL";
    
    $result = $conn->query($checkQuery);
    
    if (!$result) {
        echo "  Error checking table: " . $conn->error . "\n";
        return;
    }
    
    $count = $result->num_rows;
    echo "  Found $count records with invalid expires_at\n";
    
    if ($count == 0) {
        echo "  No records need fixing.\n\n";
        return;
    }
    
    // Update each record: set expires_at = created_at + 15 minutes
    $updateQuery = "UPDATE $tableName 
                    SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
                    WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) <= 0 OR expires_at IS NULL";
    
    if ($conn->query($updateQuery)) {
        $affected = $conn->affected_rows;
        echo "  ✅ Fixed $affected records\n";
        
        // Show the fixed records
        $showQuery = "SELECT id, email, created_at, expires_at, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry
                      FROM $tableName 
                      WHERE id IN (SELECT id FROM ($checkQuery) as temp)";
        
        $showResult = $conn->query($showQuery);
        if ($showResult && $showResult->num_rows > 0) {
            echo "  Updated records:\n";
            while ($row = $showResult->fetch_assoc()) {
                echo "    ID: {$row['id']}, Email: {$row['email']}\n";
                echo "      Created: {$row['created_at']}, Expires: {$row['expires_at']}\n";
                echo "      Seconds until expiry: {$row['seconds_until_expiry']}\n";
            }
        }
    } else {
        echo "  ❌ Error updating table: " . $conn->error . "\n";
    }
    
    echo "\n";
}

// Fix all three tables
fixTable($conn, 'ngo_password_reset_tokens');
fixTable($conn, 'donor_password_reset_tokens');
fixTable($conn, 'volunteer_password_reset_tokens');

echo "=== Done ===\n";
$conn->close();
?>

