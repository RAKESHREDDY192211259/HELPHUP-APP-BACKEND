-- Fix expires_at timestamps in password reset tables
-- This script updates all records where expires_at is before or equal to created_at
-- Sets expires_at = created_at + 15 minutes

-- Fix NGO password reset tokens
UPDATE ngo_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) <= 0 OR expires_at IS NULL;

-- Fix Donor password reset tokens
UPDATE donor_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) <= 0 OR expires_at IS NULL;

-- Fix Volunteer password reset tokens
UPDATE volunteer_password_reset_tokens 
SET expires_at = DATE_ADD(created_at, INTERVAL 15 MINUTE)
WHERE TIMESTAMPDIFF(SECOND, created_at, expires_at) <= 0 OR expires_at IS NULL;

-- Verify the fix (check all records)
SELECT 'ngo_password_reset_tokens' as table_name, id, email, created_at, expires_at, 
       TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds,
       TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry
FROM ngo_password_reset_tokens
UNION ALL
SELECT 'donor_password_reset_tokens', id, email, created_at, expires_at,
       TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds,
       TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry
FROM donor_password_reset_tokens
UNION ALL
SELECT 'volunteer_password_reset_tokens', id, email, created_at, expires_at,
       TIMESTAMPDIFF(SECOND, created_at, expires_at) as diff_seconds,
       TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry
FROM volunteer_password_reset_tokens
ORDER BY table_name, id;

