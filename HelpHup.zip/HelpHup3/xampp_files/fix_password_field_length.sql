-- Fix password field length to ensure it can store bcrypt hashes (60+ characters)
-- Run this in phpMyAdmin if passwords are being truncated

-- Check current password column length
-- SELECT COLUMN_NAME, CHARACTER_MAXIMUM_LENGTH 
-- FROM INFORMATION_SCHEMA.COLUMNS 
-- WHERE TABLE_SCHEMA = 'helphup' 
-- AND COLUMN_NAME = 'password';

-- Update volunteer table password column
ALTER TABLE `volunteer` MODIFY COLUMN `password` VARCHAR(255) NOT NULL;

-- Update volunteers table password column (if it exists)
ALTER TABLE `volunteers` MODIFY COLUMN `password` VARCHAR(255) NOT NULL;

-- Update donor table password column
ALTER TABLE `donor` MODIFY COLUMN `password` VARCHAR(255) NOT NULL;

-- Update donors table password column (if it exists)
ALTER TABLE `donors` MODIFY COLUMN `password` VARCHAR(255) NOT NULL;

-- Update ngo table password column
ALTER TABLE `ngo` MODIFY COLUMN `password` VARCHAR(255) NOT NULL;

-- Update ngos table password column (if it exists)
ALTER TABLE `ngos` MODIFY COLUMN `password` VARCHAR(255) NOT NULL;

