<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Check which donor campaigns table exists
    $tableName = null;
    $possibleTables = ['donorraisehelp', 'donor_campaigns', 'donor_campaign'];
    foreach ($possibleTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $tableName = $table;
            break;
        }
    }
    
    if (!$tableName) {
        sendResponse(false, "Donor campaigns table not found");
    }
    
    // Find donor table and detect column name
    $donorTableName = null;
    $donorIdColumn = 'donor_id'; // default
    $donorTables = ['donor', 'donors'];
    foreach ($donorTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $donorTableName = $table;
            // Check which column exists - id or donor_id
            $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
            $checkDonorId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'donor_id'");
            if ($checkId && $checkId->num_rows > 0) {
                $donorIdColumn = 'id';
            } elseif ($checkDonorId && $checkDonorId->num_rows > 0) {
                $donorIdColumn = 'donor_id';
            }
            break;
        }
    }
    
    // Determine ID column based on table name and check actual columns
    $idColumn = 'campaign_id'; // default
    if ($tableName == 'donorraisehelp') {
        // Check which ID column exists in donorraisehelp
        $checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");
        $checkCampaignId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'campaign_id'");
        if ($checkId && $checkId->num_rows > 0) {
            $idColumn = 'id';
        } elseif ($checkCampaignId && $checkCampaignId->num_rows > 0) {
            $idColumn = 'campaign_id';
        }
    }
    $checkAdminStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'admin_status'");
    $hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
    
    $checkStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'status'");
    $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
    
    // Build WHERE clause - only show APPROVED campaigns (visible to all roles)
    // Single status system: only check status='approved'
    $whereClause = "";
    if ($hasStatus) {
        $whereClause = "WHERE dc.status = 'approved'";
    }
    
    // Build status field selection
    $statusField = "COALESCE(dc.status, 'pending') as status";
    if (!$hasStatus && $hasAdminStatus) {
        // If no status column but has admin_status, use admin_status as fallback
        $statusField = "COALESCE(dc.admin_status, 'pending') as status";
    }
    
    // Build query
    if ($donorTableName) {
        // Query WITH JOIN
        // Query WITH JOIN - handle different column names
        $sql = "SELECT 
            dc.`$idColumn` as campaign_id,
            dc.donor_id,
            COALESCE(d.full_name, 'Unknown') as donor_name,
            dc.campaign_title,
            dc.fundraising_goal,
            dc.category,
            dc.cover_image_url,
            dc.video_url,
            dc.duration,
            dc.end_date,
            dc.beneficiary_name,
            dc.relationship,
            dc.contact_email,
            $statusField,
            dc.created_at
        FROM `$tableName` dc
        LEFT JOIN `$donorTableName` d ON dc.donor_id = d.$donorIdColumn
        $whereClause
        ORDER BY dc.created_at DESC";
    } else {
        // Query WITHOUT JOIN
        $sql = "SELECT 
            dc.`$idColumn` as campaign_id,
            dc.donor_id,
            'Unknown' as donor_name,
            dc.campaign_title,
            dc.fundraising_goal,
            dc.category,
            dc.cover_image_url,
            dc.video_url,
            dc.duration,
            dc.end_date,
            dc.beneficiary_name,
            dc.relationship,
            dc.contact_email,
            $statusField,
            dc.created_at
        FROM `$tableName` dc
        $whereClause
        ORDER BY dc.created_at DESC";
    }
    
    $result = $conn->query($sql);
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $campaigns = array();
    while ($row = $result->fetch_assoc()) {
        $campaigns[] = array(
            'campaign_id' => (int)$row['campaign_id'],
            'donor_id' => (int)$row['donor_id'],
            'donor_name' => $row['donor_name'],
            'campaign_title' => $row['campaign_title'],
            'fundraising_goal' => (string)$row['fundraising_goal'],
            'category' => $row['category'],
            'cover_image_url' => $row['cover_image_url'],
            'video_url' => $row['video_url'],
            'duration' => $row['duration'],
            'end_date' => $row['end_date'],
            'beneficiary_name' => $row['beneficiary_name'],
            'relationship' => $row['relationship'],
            'contact_email' => $row['contact_email'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'request_type' => 'donor'
        );
    }
    
    sendResponse(true, "Campaigns fetched successfully", $campaigns);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>
