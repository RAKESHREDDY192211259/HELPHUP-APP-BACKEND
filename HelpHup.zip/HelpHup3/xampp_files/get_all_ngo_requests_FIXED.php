<?php
/**
 * FIXED VERSION - Copy this over get_all_ngo_requests.php
 * This version has better error handling and column detection
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Find request table
    $tableName = null;
    $possibleTables = ['ngo_help_requests', 'ngoraisehelp', 'ngohelprequests'];
    foreach ($possibleTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $tableName = $table;
            break;
        }
    }
    
    if (!$tableName) {
        sendResponse(false, "NGO help request table not found");
    }
    
    // Find NGO table and detect column name
    $ngoTableName = null;
    $ngoIdColumn = 'ngo_id'; // default
    $ngoTables = ['ngo', 'ngos'];
    foreach ($ngoTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $ngoTableName = $table;
            
            // Check which column exists
            $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
            $checkNgoId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'ngo_id'");
            
            if ($checkId && $checkId->num_rows > 0) {
                $ngoIdColumn = 'id';
            } elseif ($checkNgoId && $checkNgoId->num_rows > 0) {
                $ngoIdColumn = 'ngo_id';
            }
            break;
        }
    }
    
    // Build query - start simple, no JOIN if NGO table not found
    $idColumn = ($tableName == 'ngoraisehelp') ? 'id' : 'request_id';
    
    if ($ngoTableName) {
        // Query WITH JOIN
        $sql = "SELECT 
            nhr.$idColumn as request_id,
            nhr.ngo_id,
            COALESCE(n.full_name, 'Unknown') as ngo_name,
            COALESCE(n.org_name, 'Unknown') as org_name,
            nhr.request_title,
            nhr.category,
            nhr.urgency_level,
            nhr.required_amount,
            nhr.date_needed,
            nhr.contact_number,
            nhr.description,
            COALESCE(nhr.status, 'pending') as status,
            nhr.created_at
        FROM `$tableName` nhr
        LEFT JOIN `$ngoTableName` n ON nhr.ngo_id = n.$ngoIdColumn
        ORDER BY nhr.created_at DESC";
    } else {
        // Query WITHOUT JOIN
        $sql = "SELECT 
            nhr.$idColumn as request_id,
            nhr.ngo_id,
            'Unknown' as ngo_name,
            'Unknown' as org_name,
            nhr.request_title,
            nhr.category,
            nhr.urgency_level,
            nhr.required_amount,
            nhr.date_needed,
            nhr.contact_number,
            nhr.description,
            COALESCE(nhr.status, 'pending') as status,
            nhr.created_at
        FROM `$tableName` nhr
        ORDER BY nhr.created_at DESC";
    }
    
    $result = $conn->query($sql);
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $requests = array();
    while ($row = $result->fetch_assoc()) {
        $requests[] = array(
            'request_id' => (int)$row['request_id'],
            'ngo_id' => (int)$row['ngo_id'],
            'ngo_name' => $row['ngo_name'],
            'org_name' => $row['org_name'],
            'request_title' => $row['request_title'],
            'category' => $row['category'],
            'urgency_level' => $row['urgency_level'],
            'required_amount' => (string)$row['required_amount'],
            'date_needed' => $row['date_needed'],
            'contact_number' => $row['contact_number'],
            'description' => $row['description'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'request_type' => 'ngo'
        );
    }
    
    sendResponse(true, "Requests fetched successfully", $requests);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

