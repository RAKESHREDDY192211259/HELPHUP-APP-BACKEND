<?php
/**
 * SIMPLIFIED VERSION - Direct query for ngoraisehelp table
 * This version is simpler and easier to debug
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Check which table exists
    $tableName = null;
    $idColumn = null;
    
    $check1 = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
    if ($check1 && $check1->num_rows > 0) {
        $tableName = 'ngoraisehelp';
        $idColumn = 'id';
    } else {
        $check2 = $conn->query("SHOW TABLES LIKE 'ngo_help_requests'");
        if ($check2 && $check2->num_rows > 0) {
            $tableName = 'ngo_help_requests';
            $idColumn = 'request_id';
        }
    }
    
    if (!$tableName) {
        sendResponse(false, "NGO help request table not found");
    }
    
    // Check if admin_status column exists
    $checkAdminStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'admin_status'");
    $hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
    
    // Build WHERE clause
    if ($hasAdminStatus) {
        $whereClause = "WHERE admin_status = 'accepted'";
    } else {
        $whereClause = "";
    }
    
    // Simple query without JOIN first (to avoid JOIN issues)
    $sql = "SELECT 
        $idColumn as request_id,
        ngo_id,
        request_title,
        category,
        urgency_level,
        required_amount,
        date_needed,
        contact_number,
        description,
        created_at
    FROM `$tableName`
    $whereClause
    ORDER BY created_at DESC";
    
    error_log("Simple NGO Requests SQL: " . $sql);
    
    $result = $conn->query($sql);
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $requests = array();
    while ($row = $result->fetch_assoc()) {
        // Try to get NGO name from ngo/ngos table
        $ngoName = 'Unknown';
        $orgName = 'Unknown';
        
        if (isset($row['ngo_id'])) {
            $ngoId = $row['ngo_id'];
            // Try ngo table
            $ngoCheck = $conn->query("SELECT full_name, org_name FROM ngo WHERE ngo_id = $ngoId LIMIT 1");
            if (!$ngoCheck || $ngoCheck->num_rows == 0) {
                // Try ngos table
                $ngoCheck = $conn->query("SELECT full_name, org_name FROM ngos WHERE id = $ngoId LIMIT 1");
            }
            if ($ngoCheck && $ngoCheck->num_rows > 0) {
                $ngoRow = $ngoCheck->fetch_assoc();
                $ngoName = $ngoRow['full_name'] ?? 'Unknown';
                $orgName = $ngoRow['org_name'] ?? 'Unknown';
            }
        }
        
        $requests[] = array(
            'request_id' => (int)$row['request_id'],
            'ngo_id' => (int)$row['ngo_id'],
            'ngo_name' => $ngoName,
            'org_name' => $orgName,
            'request_title' => $row['request_title'],
            'category' => $row['category'],
            'urgency_level' => $row['urgency_level'],
            'required_amount' => (string)$row['required_amount'],
            'date_needed' => $row['date_needed'],
            'contact_number' => $row['contact_number'],
            'description' => $row['description'],
            'status' => $hasAdminStatus ? 'approved' : 'pending',
            'created_at' => $row['created_at'],
            'request_type' => 'ngo'
        );
    }
    
    sendResponse(true, "Requests fetched successfully", $requests);
    
} catch (Exception $e) {
    error_log("Simple NGO Requests Error: " . $e->getMessage());
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage(),
        'data' => null
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>
