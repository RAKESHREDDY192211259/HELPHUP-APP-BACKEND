<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Find request table
    $tableName = null;
    $possibleTables = ['volunteer_requests', 'volunteerraisehelp', 'volunteerrequests'];
    foreach ($possibleTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $tableName = $table;
            break;
        }
    }
    
    if (!$tableName) {
        sendResponse(false, "Volunteer help request table not found");
    }
    
    // Find volunteer table and detect column name
    $volunteerTableName = null;
    $volunteerIdColumn = 'volunteer_id'; // default
    $volunteerTables = ['volunteer', 'volunteers'];
    foreach ($volunteerTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $volunteerTableName = $table;
            // Check which column exists - id or volunteer_id
            $checkId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'id'");
            $checkVolunteerId = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'volunteer_id'");
            if ($checkId && $checkId->num_rows > 0) {
                $volunteerIdColumn = 'id';
            } elseif ($checkVolunteerId && $checkVolunteerId->num_rows > 0) {
                $volunteerIdColumn = 'volunteer_id';
            }
            break;
        }
    }
    
    // Build query
    $idColumn = ($tableName == 'volunteerraisehelp') ? 'id' : 'request_id';
    
    // Check if admin_status and status columns exist
    $checkAdminStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'admin_status'");
    $hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
    
    $checkStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'status'");
    $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
    
    // Build WHERE clause - only show APPROVED requests (visible to all roles)
    // Single status system: only check status='approved'
    $whereClause = "";
    if ($hasStatus) {
        $whereClause = "WHERE vr.status = 'approved'";
    }
    
    // Build status field selection
    $statusField = "COALESCE(vr.status, 'pending') as status";
    if (!$hasStatus && $hasAdminStatus) {
        // If no status column but has admin_status, use admin_status as fallback
        $statusField = "COALESCE(vr.admin_status, 'pending') as status";
    }
    
    if ($volunteerTableName) {
        // Query WITH JOIN
        $sql = "SELECT 
            vr.$idColumn as request_id,
            vr.volunteer_id,
            COALESCE(v.full_name, 'Unknown') as volunteer_name,
            vr.request_title,
            vr.category,
            vr.description,
            vr.location,
            vr.help_date,
            vr.start_time,
            vr.volunteers_needed,
            $statusField,
            vr.created_at
        FROM `$tableName` vr
        LEFT JOIN `$volunteerTableName` v ON vr.volunteer_id = v.$volunteerIdColumn
        $whereClause
        ORDER BY vr.created_at DESC";
    } else {
        // Query WITHOUT JOIN
        $sql = "SELECT 
            vr.$idColumn as request_id,
            vr.volunteer_id,
            'Unknown' as volunteer_name,
            vr.request_title,
            vr.category,
            vr.description,
            vr.location,
            vr.help_date,
            vr.start_time,
            vr.volunteers_needed,
            $statusField,
            vr.created_at
        FROM `$tableName` vr
        $whereClause
        ORDER BY vr.created_at DESC";
    }
    
    $result = $conn->query($sql);
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $requests = array();
    while ($row = $result->fetch_assoc()) {
        $requests[] = array(
            'request_id' => (int)$row['request_id'],
            'volunteer_id' => (int)$row['volunteer_id'],
            'volunteer_name' => $row['volunteer_name'],
            'request_title' => $row['request_title'],
            'category' => $row['category'],
            'description' => $row['description'],
            'location' => $row['location'],
            'help_date' => $row['help_date'],
            'start_time' => $row['start_time'],
            'volunteers_needed' => (int)$row['volunteers_needed'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'request_type' => 'volunteer'
        );
    }
    
    sendResponse(true, "Requests fetched successfully", $requests);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>
