<?php
/**
 * Get Donations Received for Donor
 * GET parameters: donor_id
 * Returns: List of donations received for their requests (not donations they made)
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config.php';

$donor_id = $_GET['donor_id'] ?? 0;

if (empty($donor_id)) {
    sendResponse(false, "Donor ID is required");
    exit();
}

try {
    // Get donations received for donor's requests
    // This gets payments made to requests created by this donor
    $sql = "SELECT 
                pt.payment_id,
                pt.transaction_id,
                pt.request_id,
                uhr.request_title,
                uhr.request_type,
                pt.payer_name,
                pt.payer_email,
                pt.payer_type,
                pt.amount,
                pt.payment_method,
                pt.status as payment_status,
                pt.created_at,
                pt.completed_at
            FROM payment_transactions pt
            JOIN unified_help_requests uhr ON pt.request_id = uhr.request_id
            WHERE uhr.requester_type = 'donor'
            AND uhr.requester_id = ?
            ORDER BY pt.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $donations = array();
    while ($row = $result->fetch_assoc()) {
        $donations[] = array(
            'payment_id' => (int)$row['payment_id'],
            'transaction_id' => $row['transaction_id'],
            'request_id' => (int)$row['request_id'],
            'request_title' => $row['request_title'],
            'payer_name' => $row['payer_name'],
            'payer_email' => $row['payer_email'],
            'payer_type' => $row['payer_type'],
            'amount' => (float)$row['amount'],
            'payment_method' => $row['payment_method'],
            'payment_status' => $row['payment_status'],
            'created_at' => $row['created_at'],
            'completed_at' => $row['completed_at']
        );
    }
    
    $stmt->close();
    
    // Get total amount received
    $totalSql = "SELECT 
                    COALESCE(SUM(pt.amount), 0) as total_received,
                    COUNT(*) as total_donations
                 FROM payment_transactions pt
                 JOIN unified_help_requests uhr ON pt.request_id = uhr.request_id
                 WHERE uhr.requester_type = 'donor'
                 AND uhr.requester_id = ?
                 AND pt.status = 'completed'";
    
    $totalStmt = $conn->prepare($totalSql);
    $totalStmt->bind_param("i", $donor_id);
    $totalStmt->execute();
    $totalResult = $totalStmt->get_result();
    $totalData = $totalResult->fetch_assoc();
    $totalReceived = (float)$totalData['total_received'];
    $totalDonations = (int)$totalData['total_donations'];
    $totalStmt->close();
    
    sendResponse(true, "Donations received retrieved successfully", array(
        'donations' => $donations,
        'total_received' => $totalReceived,
        'total_donations' => $totalDonations
    ));
    
} catch (Exception $e) {
    sendResponse(false, "Error: " . $e->getMessage());
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>
