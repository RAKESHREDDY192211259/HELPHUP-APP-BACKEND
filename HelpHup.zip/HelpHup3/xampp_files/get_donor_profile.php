<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$donor_id = $data['donor_id'] ?? '';

if (empty($donor_id)) {
    sendResponse(false, "Donor ID is required");
}

// Try different possible table names
$tableNames = ['donor', 'donors'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Donor table not found.");
}

// Check which column exists - id or donor_id
$checkDonorId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'donor_id'");
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");

$donorIdColumn = 'id'; // default
if ($checkDonorId && $checkDonorId->num_rows > 0) {
    $donorIdColumn = 'donor_id';
} elseif ($checkId && $checkId->num_rows > 0) {
    $donorIdColumn = 'id';
}

// Query database to get full profile
$stmt = $conn->prepare("SELECT $donorIdColumn, full_name, phone, email, address FROM `$tableName` WHERE $donorIdColumn = ?");
$stmt->bind_param("i", $donor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Ensure all fields have values (use empty string if NULL or not set)
    sendResponse(true, "Profile data retrieved successfully", array(
        'donor_id' => $row[$donorIdColumn] ?? 0,
        'full_name' => isset($row['full_name']) && $row['full_name'] !== null ? $row['full_name'] : '',
        'phone' => isset($row['phone']) && $row['phone'] !== null ? $row['phone'] : '',
        'email' => isset($row['email']) && $row['email'] !== null ? $row['email'] : '',
        'address' => isset($row['address']) && $row['address'] !== null ? $row['address'] : ''
    ));
} else {
    sendResponse(false, "Donor not found");
}

$stmt->close();
$conn->close();
?>

