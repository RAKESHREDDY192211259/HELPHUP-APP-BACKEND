<?php
/**
 * Get Help Received for User
 * GET parameters: user_type (ngo/volunteer/donor), user_id
 * Returns: List of help received (donations/payments) for their requests
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config.php';

$user_type = $_GET['user_type'] ?? '';
$user_id = $_GET['user_id'] ?? 0;

if (empty($user_type) || empty($user_id)) {
    sendResponse(false, "User type and user ID are required");
    exit();
}

// Validate user_type
if (!in_array($user_type, ['ngo', 'volunteer', 'donor'])) {
    sendResponse(false, "Invalid user type. Must be: ngo, volunteer, or donor");
    exit();
}

try {
    // Get help received for user's requests
    // This gets payments/help received for requests created by this user
    $sql = "SELECT 
                hi.interaction_id,
                hi.request_id,
                uhr.request_title,
                uhr.request_type,
                uhr.requester_type,
                uhr.requester_id,
                helper.user_name as helper_name,
                helper.user_email as helper_email,
                hi.payment_amount,
                hi.payment_method,
                hi.payment_status,
                hi.interaction_status,
                hi.interaction_date,
                pt.transaction_id,
                pt.status as payment_transaction_status
            FROM help_interactions hi
            JOIN unified_help_requests uhr ON hi.request_id = uhr.request_id
            JOIN users helper ON hi.helper_id = helper.user_id
            LEFT JOIN payment_transactions pt ON hi.payment_id = pt.payment_id
            WHERE uhr.requester_type = ? 
            AND uhr.requester_id = ?
            ORDER BY hi.interaction_date DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $user_type, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $help_received = array();
    while ($row = $result->fetch_assoc()) {
        $help_received[] = array(
            'interaction_id' => (int)$row['interaction_id'],
            'request_id' => (int)$row['request_id'],
            'request_title' => $row['request_title'],
            'request_type' => $row['request_type'],
            'helper_name' => $row['helper_name'],
            'helper_email' => $row['helper_email'],
            'payment_amount' => $row['payment_amount'] ? (float)$row['payment_amount'] : null,
            'payment_method' => $row['payment_method'],
            'payment_status' => $row['payment_status'],
            'interaction_status' => $row['interaction_status'],
            'interaction_date' => $row['interaction_date'],
            'transaction_id' => $row['transaction_id']
        );
    }
    
    $stmt->close();
    
    // Get total amount received
    $totalSql = "SELECT 
                    COALESCE(SUM(hi.payment_amount), 0) as total_received,
                    COUNT(*) as total_help_count
                 FROM help_interactions hi
                 JOIN unified_help_requests uhr ON hi.request_id = uhr.request_id
                 WHERE uhr.requester_type = ? 
                 AND uhr.requester_id = ?
                 AND hi.payment_status = 'completed'";
    
    $totalStmt = $conn->prepare($totalSql);
    $totalStmt->bind_param("si", $user_type, $user_id);
    $totalStmt->execute();
    $totalResult = $totalStmt->get_result();
    $totalData = $totalResult->fetch_assoc();
    $totalReceived = (float)$totalData['total_received'];
    $totalHelpCount = (int)$totalData['total_help_count'];
    $totalStmt->close();
    
    sendResponse(true, "Help received retrieved successfully", array(
        'help_received' => $help_received,
        'total_received' => $totalReceived,
        'total_help_count' => $totalHelpCount
    ));
    
} catch (Exception $e) {
    sendResponse(false, "Error: " . $e->getMessage());
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>
