<?php
/**
 * Get all campaigns for a specific donor (shows all statuses: pending, accepted, rejected)
 * This allows donors to see the status of their own campaigns
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get JSON input
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Also support GET request with query parameter
    $donor_id = $data['donor_id'] ?? ($_GET['donor_id'] ?? 0);
    
    if (empty($donor_id) || $donor_id <= 0) {
        sendResponse(false, "Donor ID is required");
    }
    
    // Check if table exists
    $tableCheck = $conn->query("SHOW TABLES LIKE 'donor_campaigns'");
    if (!$tableCheck || $tableCheck->num_rows == 0) {
        sendResponse(false, "Table 'donor_campaigns' does not exist");
    }
    
    // Check if admin_status and rejection_reason columns exist
    $checkAdminStatus = $conn->query("SHOW COLUMNS FROM donor_campaigns LIKE 'admin_status'");
    $hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
    
    $checkRejectionReason = $conn->query("SHOW COLUMNS FROM donor_campaigns LIKE 'rejection_reason'");
    $hasRejectionReason = $checkRejectionReason && $checkRejectionReason->num_rows > 0;
    
    $checkStatus = $conn->query("SHOW COLUMNS FROM donor_campaigns LIKE 'status'");
    $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
    
    // Build SELECT fields
    $selectFields = "
        dc.campaign_id,
        dc.donor_id,
        dc.campaign_title,
        dc.fundraising_goal,
        dc.category,
        dc.cover_image_url,
        dc.video_url,
        dc.duration,
        dc.end_date,
        dc.beneficiary_name,
        dc.relationship,
        dc.contact_email,
        dc.created_at";
    
    if ($hasAdminStatus) {
        $selectFields .= ", dc.admin_status";
    } else {
        $selectFields .= ", 'accepted' as admin_status";
    }
    
    if ($hasStatus) {
        $selectFields .= ", dc.status";
    } else {
        $selectFields .= ", COALESCE(dc.admin_status, 'pending') as status";
    }
    
    if ($hasRejectionReason) {
        $selectFields .= ", dc.rejection_reason";
    } else {
        $selectFields .= ", NULL as rejection_reason";
    }
    
    // Build query - show ALL campaigns for this donor (no status filter)
    $sql = "SELECT 
        $selectFields
    FROM donor_campaigns dc
    WHERE dc.donor_id = ?
    ORDER BY dc.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $campaigns = array();
    while ($row = $result->fetch_assoc()) {
        $campaignData = array(
            'campaign_id' => (int)$row['campaign_id'],
            'donor_id' => (int)$row['donor_id'],
            'campaign_title' => $row['campaign_title'],
            'fundraising_goal' => (string)$row['fundraising_goal'],
            'category' => $row['category'],
            'cover_image_url' => $row['cover_image_url'],
            'video_url' => $row['video_url'],
            'duration' => $row['duration'],
            'end_date' => $row['end_date'],
            'beneficiary_name' => $row['beneficiary_name'],
            'relationship' => $row['relationship'],
            'contact_email' => $row['contact_email'],
            'admin_status' => $row['admin_status'] ?? 'pending',
            'status' => $row['status'] ?? 'pending',
            'created_at' => $row['created_at'],
            'request_type' => 'donor'
        );
        
        // Add rejection_reason if available
        if (isset($row['rejection_reason']) && !empty($row['rejection_reason'])) {
            $campaignData['rejection_reason'] = $row['rejection_reason'];
        }
        
        $campaigns[] = $campaignData;
    }
    
    $stmt->close();
    sendResponse(true, "Campaigns fetched successfully", $campaigns);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

