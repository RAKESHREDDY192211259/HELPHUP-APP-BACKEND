<?php
/**
 * Get all help requests for a specific NGO (shows all statuses: pending, accepted, rejected)
 * This allows NGOs to see the status of their own requests
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get JSON input
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Also support GET request with query parameter
    $ngo_id = $data['ngo_id'] ?? ($_GET['ngo_id'] ?? 0);
    
    if (empty($ngo_id) || $ngo_id <= 0) {
        sendResponse(false, "NGO ID is required");
    }
    
    // Find request table
    $tableName = null;
    $possibleTables = ['ngoraisehelp', 'ngo_help_requests', 'ngohelprequests'];
    foreach ($possibleTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $tableName = $table;
            break;
        }
    }
    
    if (!$tableName) {
        sendResponse(false, "NGO help request table not found");
    }
    
    // Determine ID column based on table name
    $idColumn = ($tableName == 'ngoraisehelp') ? 'id' : 'request_id';
    
    // Check if admin_status and rejection_reason columns exist
    $checkAdminStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'admin_status'");
    $hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
    
    $checkRejectionReason = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'rejection_reason'");
    $hasRejectionReason = $checkRejectionReason && $checkRejectionReason->num_rows > 0;
    
    $checkStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'status'");
    $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
    
    // Build SELECT fields
    $selectFields = "
        nhr.$idColumn as request_id,
        nhr.ngo_id,
        nhr.request_title,
        nhr.category,
        nhr.urgency_level,
        nhr.required_amount,
        nhr.date_needed,
        nhr.contact_number,
        nhr.description,
        nhr.created_at";
    
    if ($hasAdminStatus) {
        $selectFields .= ", nhr.admin_status";
    } else {
        $selectFields .= ", 'accepted' as admin_status";
    }
    
    if ($hasStatus) {
        $selectFields .= ", nhr.status";
    } else {
        $selectFields .= ", COALESCE(nhr.admin_status, 'pending') as status";
    }
    
    if ($hasRejectionReason) {
        $selectFields .= ", nhr.rejection_reason";
    } else {
        $selectFields .= ", NULL as rejection_reason";
    }
    
    // Build query - show ALL requests for this NGO (no status filter)
    $sql = "SELECT 
        $selectFields
    FROM `$tableName` nhr
    WHERE nhr.ngo_id = ?
    ORDER BY nhr.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $ngo_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $requests = array();
    while ($row = $result->fetch_assoc()) {
        $requestData = array(
            'request_id' => (int)$row['request_id'],
            'ngo_id' => (int)$row['ngo_id'],
            'request_title' => $row['request_title'],
            'category' => $row['category'],
            'urgency_level' => $row['urgency_level'],
            'required_amount' => (string)$row['required_amount'],
            'date_needed' => $row['date_needed'],
            'contact_number' => $row['contact_number'],
            'description' => $row['description'],
            'admin_status' => $row['admin_status'] ?? 'pending',
            'status' => $row['status'] ?? 'pending',
            'created_at' => $row['created_at'],
            'request_type' => 'ngo'
        );
        
        // Add rejection_reason if available
        if (isset($row['rejection_reason']) && !empty($row['rejection_reason'])) {
            $requestData['rejection_reason'] = $row['rejection_reason'];
        }
        
        $requests[] = $requestData;
    }
    
    $stmt->close();
    sendResponse(true, "Requests fetched successfully", $requests);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

