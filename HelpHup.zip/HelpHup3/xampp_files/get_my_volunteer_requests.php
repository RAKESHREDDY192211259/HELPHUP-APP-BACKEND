<?php
/**
 * Get all help requests for a specific volunteer (shows all statuses: pending, accepted, rejected)
 * This allows volunteers to see the status of their own requests
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

try {
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get JSON input
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Also support GET request with query parameter
    $volunteer_id = $data['volunteer_id'] ?? ($_GET['volunteer_id'] ?? 0);
    
    if (empty($volunteer_id) || $volunteer_id <= 0) {
        sendResponse(false, "Volunteer ID is required");
    }
    
    // Find request table
    $tableName = null;
    $possibleTables = ['volunteer_requests', 'volunteerraisehelp', 'volunteerrequests'];
    foreach ($possibleTables as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check && $check->num_rows > 0) {
            $tableName = $table;
            break;
        }
    }
    
    if (!$tableName) {
        sendResponse(false, "Volunteer help request table not found");
    }
    
    // Determine ID column based on table name
    $idColumn = ($tableName == 'volunteerraisehelp') ? 'id' : 'request_id';
    
    // Check if admin_status and rejection_reason columns exist
    $checkAdminStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'admin_status'");
    $hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
    
    $checkRejectionReason = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'rejection_reason'");
    $hasRejectionReason = $checkRejectionReason && $checkRejectionReason->num_rows > 0;
    
    $checkStatus = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'status'");
    $hasStatus = $checkStatus && $checkStatus->num_rows > 0;
    
    // Build SELECT fields
    $selectFields = "
        vr.$idColumn as request_id,
        vr.volunteer_id,
        vr.request_title,
        vr.category,
        vr.description,
        vr.location,
        vr.help_date,
        vr.start_time,
        vr.volunteers_needed,
        vr.created_at";
    
    if ($hasAdminStatus) {
        $selectFields .= ", vr.admin_status";
    } else {
        $selectFields .= ", 'accepted' as admin_status";
    }
    
    if ($hasStatus) {
        $selectFields .= ", vr.status";
    } else {
        $selectFields .= ", COALESCE(vr.admin_status, 'pending') as status";
    }
    
    if ($hasRejectionReason) {
        $selectFields .= ", vr.rejection_reason";
    } else {
        $selectFields .= ", NULL as rejection_reason";
    }
    
    // Build query - show ALL requests for this volunteer (no status filter)
    $sql = "SELECT 
        $selectFields
    FROM `$tableName` vr
    WHERE vr.volunteer_id = ?
    ORDER BY vr.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $volunteer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $requests = array();
    while ($row = $result->fetch_assoc()) {
        $requestData = array(
            'request_id' => (int)$row['request_id'],
            'volunteer_id' => (int)$row['volunteer_id'],
            'request_title' => $row['request_title'],
            'category' => $row['category'],
            'description' => $row['description'],
            'location' => $row['location'],
            'help_date' => $row['help_date'],
            'start_time' => $row['start_time'],
            'volunteers_needed' => (int)$row['volunteers_needed'],
            'admin_status' => $row['admin_status'] ?? 'pending',
            'status' => $row['status'] ?? 'pending',
            'created_at' => $row['created_at'],
            'request_type' => 'volunteer'
        );
        
        // Add rejection_reason if available
        if (isset($row['rejection_reason']) && !empty($row['rejection_reason'])) {
            $requestData['rejection_reason'] = $row['rejection_reason'];
        }
        
        $requests[] = $requestData;
    }
    
    $stmt->close();
    sendResponse(true, "Requests fetched successfully", $requests);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

