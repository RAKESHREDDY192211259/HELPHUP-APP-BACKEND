<?php
/**
 * Get Notifications for User
 * GET parameters: user_type (ngo/volunteer/donor), user_id
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

require_once 'config.php';

$user_type = $_GET['user_type'] ?? '';
$user_id = $_GET['user_id'] ?? 0;

if (empty($user_type) || empty($user_id)) {
    sendResponse(false, "User type and user ID are required");
    exit;
}

// Validate user_type
if (!in_array($user_type, ['ngo', 'volunteer', 'donor'])) {
    sendResponse(false, "Invalid user type. Must be: ngo, volunteer, or donor");
    exit;
}

// Get notifications for the user
$stmt = $conn->prepare("SELECT notification_id, user_type, user_id, request_type, request_id, title, message, rejection_reason, is_read, created_at FROM notifications WHERE user_type = ? AND user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("si", $user_type, $user_id);
$stmt->execute();
$result = $stmt->get_result();

$notifications = array();
while ($row = $result->fetch_assoc()) {
    $notifications[] = array(
        'notification_id' => (int)$row['notification_id'],
        'title' => $row['title'],
        'message' => $row['message'],
        'rejection_reason' => $row['rejection_reason'],
        'is_read' => (bool)$row['is_read'],
        'created_at' => $row['created_at'],
        'request_type' => $row['request_type'],
        'request_id' => (int)$row['request_id']
    );
}

$stmt->close();

// Get unread count
$countStmt = $conn->prepare("SELECT COUNT(*) as unread_count FROM notifications WHERE user_type = ? AND user_id = ? AND is_read = 0");
$countStmt->bind_param("si", $user_type, $user_id);
$countStmt->execute();
$countResult = $countStmt->get_result();
$unreadCount = 0;
if ($countResult && $countRow = $countResult->fetch_assoc()) {
    $unreadCount = (int)$countRow['unread_count'];
}
$countStmt->close();

sendResponse(true, "Notifications retrieved successfully", array(
    'notifications' => $notifications,
    'unread_count' => $unreadCount
));

$conn->close();
?>

