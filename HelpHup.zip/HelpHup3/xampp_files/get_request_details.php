<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Only GET requests allowed'
    ]);
    exit();
}

try {
    // Include database configuration
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) && !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get request ID from URL
    $requestId = isset($_GET['request_id']) ? intval($_GET['request_id']) : 0;
    
    if ($requestId <= 0) {
        throw new Exception("Invalid request ID");
    }
    
    // Prepare SQL to get request details
    $sql = "SELECT 
                r.request_id,
                r.requester_type,
                r.requester_id,
                r.requester_name,
                r.requester_email,
                r.requester_phone,
                r.request_title,
                r.category,
                r.description,
                r.urgency_level,
                r.required_amount,
                r.date_needed,
                r.contact_number,
                r.location,
                r.help_date,
                r.start_time,
                r.volunteers_needed,
                r.fundraising_goal,
                r.duration,
                r.end_date,
                r.beneficiary_name,
                r.relationship,
                r.contact_email,
                r.cover_image_url,
                r.video_url,
                r.status,
                r.created_at,
                r.updated_at
            FROM unified_help_requests r
            WHERE r.request_id = ?";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    
    $stmt->bind_param("i", $requestId);
    
    if (!$stmt->execute()) {
        throw new Exception("Failed to execute query: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode([
            'status' => false,
            'message' => 'Request not found'
        ]);
        exit();
    }
    
    $request = $result->fetch_assoc();
    
    // Convert numeric fields to proper types
    $request['request_id'] = (int)$request['request_id'];
    $request['requester_id'] = (int)$request['requester_id'];
    $request['required_amount'] = $request['required_amount'] ? (float)$request['required_amount'] : null;
    $request['fundraising_goal'] = $request['fundraising_goal'] ? (float)$request['fundraising_goal'] : null;
    $request['volunteers_needed'] = $request['volunteers_needed'] ? (int)$request['volunteers_needed'] : null;
    
    // Format dates for better display
    $request['created_at_formatted'] = date('M j, Y h:i A', strtotime($request['created_at']));
    if ($request['updated_at']) {
        $request['updated_at_formatted'] = date('M j, Y h:i A', strtotime($request['updated_at']));
    }
    if ($request['date_needed']) {
        $request['date_needed_formatted'] = date('M j, Y', strtotime($request['date_needed']));
    }
    if ($request['help_date']) {
        $request['help_date_formatted'] = date('M j, Y', strtotime($request['help_date']));
    }
    if ($request['end_date']) {
        $request['end_date_formatted'] = date('M j, Y', strtotime($request['end_date']));
    }
    
    echo json_encode([
        'status' => true,
        'message' => 'Request details retrieved successfully',
        'data' => $request
    ], JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    error_log("Error in get_request_details.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => false,
        'message' => 'Internal server error: ' . $e->getMessage()
    ]);
}

if (isset($stmt)) {
    $stmt->close();
}
if (isset($conn)) {
    $conn->close();
}
?>
