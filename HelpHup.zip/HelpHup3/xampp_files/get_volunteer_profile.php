<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$volunteer_id = $data['volunteer_id'] ?? '';

if (empty($volunteer_id)) {
    sendResponse(false, "Volunteer ID is required");
}

// Try different possible table names
$tableNames = ['volunteer', 'volunteers'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Volunteer table not found.");
}

// Check which column exists - id or volunteer_id
$checkVolunteerId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'volunteer_id'");
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");

$volunteerIdColumn = 'id'; // default
if ($checkVolunteerId && $checkVolunteerId->num_rows > 0) {
    $volunteerIdColumn = 'volunteer_id';
} elseif ($checkId && $checkId->num_rows > 0) {
    $volunteerIdColumn = 'id';
}

// Query database to get full profile
$stmt = $conn->prepare("SELECT $volunteerIdColumn, full_name, phone, email, skills, availability FROM `$tableName` WHERE $volunteerIdColumn = ?");
$stmt->bind_param("i", $volunteer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Ensure all fields have values (use empty string if NULL or not set)
    sendResponse(true, "Profile data retrieved successfully", array(
        'volunteer_id' => $row[$volunteerIdColumn] ?? 0,
        'full_name' => isset($row['full_name']) && $row['full_name'] !== null ? $row['full_name'] : '',
        'phone' => isset($row['phone']) && $row['phone'] !== null ? $row['phone'] : '',
        'email' => isset($row['email']) && $row['email'] !== null ? $row['email'] : '',
        'skills' => isset($row['skills']) && $row['skills'] !== null ? $row['skills'] : '',
        'availability' => isset($row['availability']) && $row['availability'] !== null ? $row['availability'] : ''
    ));
} else {
    sendResponse(false, "Volunteer not found");
}

$stmt->close();
$conn->close();
?>

