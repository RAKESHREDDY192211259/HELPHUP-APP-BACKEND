<?php
require_once 'config.php';

header('Content-Type: application/json');

// This is a utility script to manually fix corrupted passwords
// Should only be used in development/testing

$email = $_GET['email'] ?? '';
$newPassword = $_GET['password'] ?? '';
$userType = $_GET['type'] ?? 'volunteer'; // volunteer, donor, ngo

if (empty($email) || empty($newPassword)) {
    echo json_encode([
        'status' => false,
        'message' => 'Email and password required. Usage: ?email=user@email.com&password=newpass&type=volunteer'
    ]);
    exit;
}

// Determine table name
$tables = [
    'volunteer' => ['volunteer', 'volunteers'],
    'donor' => ['donor', 'donors'],
    'ngo' => ['ngo', 'ngos']
];

$tableNames = $tables[$userType] ?? $tables['volunteer'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    echo json_encode([
        'status' => false,
        'message' => "Table for $userType not found"
    ]);
    exit;
}

// Get actual email from database
$checkEmail = $conn->prepare("SELECT email FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
$checkEmail->bind_param("s", $email);
$checkEmail->execute();
$emailResult = $checkEmail->get_result();

if ($emailResult->num_rows == 0) {
    $checkEmail->close();
    echo json_encode([
        'status' => false,
        'message' => 'Email not found in database'
    ]);
    exit;
}

$emailRow = $emailResult->fetch_assoc();
$actualEmail = $emailRow['email'];
$checkEmail->close();

// Hash the new password
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

// Update password
$update = $conn->prepare("UPDATE `$tableName` SET password = ? WHERE email = ?");
$update->bind_param("ss", $hashedPassword, $actualEmail);

if (!$update->execute()) {
    echo json_encode([
        'status' => false,
        'message' => 'Update failed: ' . $update->error
    ]);
    $update->close();
    exit;
}

$affectedRows = $update->affected_rows;
$update->close();

// Verify the update
$verify = $conn->prepare("SELECT password FROM `$tableName` WHERE email = ?");
$verify->bind_param("s", $actualEmail);
$verify->execute();
$verifyResult = $verify->get_result();
$verifyRow = $verifyResult->fetch_assoc();
$verify->close();

$passwordVerified = false;
if ($verifyRow && password_verify($newPassword, $verifyRow['password'])) {
    $passwordVerified = true;
}

echo json_encode([
    'status' => $affectedRows > 0,
    'message' => $affectedRows > 0 
        ? ($passwordVerified ? 'Password updated and verified successfully' : 'Password updated but verification failed')
        : 'No rows affected',
    'affected_rows' => $affectedRows,
    'password_verified' => $passwordVerified,
    'table' => $tableName,
    'email' => $actualEmail
]);

$conn->close();
?>

