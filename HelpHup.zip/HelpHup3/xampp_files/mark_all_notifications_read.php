<?php
/**
 * Mark All Notifications as Read for User
 * POST: user_type, user_id
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

require_once 'config.php';

$json = file_get_contents('php://input');
$data = json_decode($json, true);

$user_type = $data['user_type'] ?? '';
$user_id = $data['user_id'] ?? 0;

if (empty($user_type) || empty($user_id)) {
    sendResponse(false, "User type and user ID are required");
    exit;
}

$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_type = ? AND user_id = ? AND is_read = 0");
$stmt->bind_param("si", $user_type, $user_id);

if ($stmt->execute()) {
    sendResponse(true, "All notifications marked as read", array('updated_count' => $stmt->affected_rows));
} else {
    sendResponse(false, "Failed to update notifications: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

