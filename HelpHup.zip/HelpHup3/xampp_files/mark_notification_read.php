<?php
/**
 * Mark Notification as Read
 * POST: notification_id
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

require_once 'config.php';

$json = file_get_contents('php://input');
$data = json_decode($json, true);

$notification_id = $data['notification_id'] ?? 0;
$user_type = $data['user_type'] ?? '';
$user_id = $data['user_id'] ?? 0;

if (empty($notification_id)) {
    sendResponse(false, "Notification ID is required");
    exit;
}

// If user_type and user_id provided, verify ownership
if (!empty($user_type) && !empty($user_id)) {
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_type = ? AND user_id = ?");
    $stmt->bind_param("isi", $notification_id, $user_type, $user_id);
} else {
    // Just mark as read without verification (less secure but simpler)
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE notification_id = ?");
    $stmt->bind_param("i", $notification_id);
}

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        sendResponse(true, "Notification marked as read");
    } else {
        sendResponse(false, "Notification not found or already read");
    }
} else {
    sendResponse(false, "Failed to update notification: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

