<?php
/**
 * Migration Script: Separate Password Reset Tables
 * 
 * This script:
 * 1. Creates the three new separate tables (ngo, donor, volunteer)
 * 2. Migrates data from old password_reset_tokens table if it exists
 * 3. Optionally drops the old table
 * 
 * Usage: Run this once via browser or command line
 */

require_once 'config.php';

// Set header for JSON response
header('Content-Type: application/json');

// Function to send JSON response
function sendResponse($status, $message, $data = null) {
    $response = array(
        'status' => $status,
        'message' => $message
    );
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit();
}

$results = array();
$errors = array();

// Step 1: Create the three new tables
$tables = array(
    'ngo_password_reset_tokens',
    'donor_password_reset_tokens',
    'volunteer_password_reset_tokens'
);

foreach ($tables as $tableName) {
    // Check if table exists
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    
    if ($checkTable && $checkTable->num_rows > 0) {
        $results[$tableName] = "Table already exists";
    } else {
        // Create table
        $sql = "";
        if ($tableName === 'ngo_password_reset_tokens') {
            $sql = "CREATE TABLE IF NOT EXISTS `ngo_password_reset_tokens` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `email` VARCHAR(100) NOT NULL,
              `otp` VARCHAR(6) NOT NULL,
              `expires_at` TIMESTAMP NOT NULL,
              `used` TINYINT(1) DEFAULT 0,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              INDEX `idx_email` (`email`),
              INDEX `idx_email_otp` (`email`, `otp`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        } elseif ($tableName === 'donor_password_reset_tokens') {
            $sql = "CREATE TABLE IF NOT EXISTS `donor_password_reset_tokens` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `email` VARCHAR(100) NOT NULL,
              `otp` VARCHAR(6) NOT NULL,
              `expires_at` TIMESTAMP NOT NULL,
              `used` TINYINT(1) DEFAULT 0,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              INDEX `idx_email` (`email`),
              INDEX `idx_email_otp` (`email`, `otp`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        } elseif ($tableName === 'volunteer_password_reset_tokens') {
            $sql = "CREATE TABLE IF NOT EXISTS `volunteer_password_reset_tokens` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `email` VARCHAR(100) NOT NULL,
              `otp` VARCHAR(6) NOT NULL,
              `expires_at` TIMESTAMP NOT NULL,
              `used` TINYINT(1) DEFAULT 0,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              INDEX `idx_email` (`email`),
              INDEX `idx_email_otp` (`email`, `otp`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        }
        
        if ($conn->query($sql) === TRUE) {
            $results[$tableName] = "Created successfully";
        } else {
            $errors[] = "Error creating $tableName: " . $conn->error;
            $results[$tableName] = "Error: " . $conn->error;
        }
    }
}

// Step 2: Check if old table exists and migrate data
$oldTableExists = $conn->query("SHOW TABLES LIKE 'password_reset_tokens'");
$migratedCount = 0;

if ($oldTableExists && $oldTableExists->num_rows > 0) {
    // Check if old table has user_type column
    $describeResult = $conn->query("DESCRIBE password_reset_tokens");
    $hasUserType = false;
    while ($row = $describeResult->fetch_assoc()) {
        if ($row['Field'] === 'user_type') {
            $hasUserType = true;
            break;
        }
    }
    
    if ($hasUserType) {
        // Migrate data from old table to new tables
        $migrationQueries = array(
            "INSERT INTO ngo_password_reset_tokens (email, otp, expires_at, used, created_at) 
             SELECT email, otp, expires_at, used, created_at FROM password_reset_tokens WHERE user_type = 'ngo'",
            "INSERT INTO donor_password_reset_tokens (email, otp, expires_at, used, created_at) 
             SELECT email, otp, expires_at, used, created_at FROM password_reset_tokens WHERE user_type = 'donor'",
            "INSERT INTO volunteer_password_reset_tokens (email, otp, expires_at, used, created_at) 
             SELECT email, otp, expires_at, used, created_at FROM password_reset_tokens WHERE user_type = 'volunteer'"
        );
        
        foreach ($migrationQueries as $query) {
            if ($conn->query($query) === TRUE) {
                $migratedCount += $conn->affected_rows;
            }
        }
        
        $results['migration'] = "Migrated $migratedCount records from old table";
        
        // Step 3: Drop old table (optional - uncomment to enable)
        // $dropResult = $conn->query("DROP TABLE IF EXISTS password_reset_tokens");
        // if ($dropResult) {
        //     $results['old_table'] = "Old password_reset_tokens table dropped";
        // } else {
        //     $results['old_table'] = "Old table still exists (not dropped)";
        // }
        $results['old_table'] = "Old password_reset_tokens table still exists. You can drop it manually if migration was successful.";
    } else {
        $results['migration'] = "Old table exists but doesn't have user_type column. Cannot migrate automatically.";
    }
} else {
    $results['migration'] = "Old password_reset_tokens table does not exist. No migration needed.";
}

if (count($errors) > 0) {
    sendResponse(false, "Migration completed with errors", array('results' => $results, 'errors' => $errors));
} else {
    sendResponse(true, "Migration completed successfully!", array('results' => $results));
}

$conn->close();
?>

