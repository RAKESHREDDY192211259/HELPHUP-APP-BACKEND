<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Debug: Log received data (remove in production)
error_log("NGO Login - Raw JSON: " . $json);
error_log("NGO Login - Decoded data: " . print_r($data, true));

$email = isset($data['email']) ? trim($data['email']) : '';
$password = isset($data['password']) ? trim($data['password']) : '';

error_log("NGO Login - Email: '$email', Password length: " . strlen($password));

if (empty($email) || empty($password)) {
    sendResponse(false, "Email and password are required");
    exit;
}

// Try ngos first (where data actually is), then ngo
$tableNames = ['ngos', 'ngo'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break; // Use first table found (ngos has priority)
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: NGO table not found.");
    exit;
}

error_log("NGO Login - Using table: $tableName");

// Detect primary key column name (id or ngo_id)
$idColumn = 'id'; // default
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` WHERE `Key` = 'PRI'");
if ($checkId && $checkId->num_rows > 0) {
    $pkRow = $checkId->fetch_assoc();
    $idColumn = $pkRow['Field']; // Will be 'id' or 'ngo_id'
}

// Clean email - remove any hidden characters
$email = trim($email);
$email = preg_replace('/\s+/', '', $email); // Remove all whitespace
$email = filter_var($email, FILTER_SANITIZE_EMAIL);

error_log("NGO Login - Cleaned email: '$email' (length: " . strlen($email) . ")");
error_log("NGO Login - Table: $tableName, ID Column: $idColumn");

// Query database - use case-insensitive email matching with TRIM to handle whitespace
$query = "SELECT `$idColumn`, full_name, email, password FROM `$tableName` WHERE LOWER(TRIM(email)) = LOWER(TRIM(?))";
error_log("NGO Login - Query: $query");

$stmt = $conn->prepare($query);
if (!$stmt) {
    error_log("NGO Login - Prepare failed: " . $conn->error);
    sendResponse(false, "Database error: " . $conn->error);
    exit;
}
$stmt->bind_param("s", $email);
if (!$stmt->execute()) {
    error_log("NGO Login - Execute failed: " . $stmt->error);
    sendResponse(false, "Database error: " . $stmt->error);
    $stmt->close();
    exit;
}
$result = $stmt->get_result();

error_log("NGO Login - Query executed, rows found: " . $result->num_rows);

// If no results, try without TRIM as fallback
if ($result->num_rows == 0) {
    error_log("NGO Login - Trying fallback query without TRIM");
    $fallbackQuery = "SELECT `$idColumn`, full_name, email, password FROM `$tableName` WHERE LOWER(email) = LOWER(?)";
    $stmt2 = $conn->prepare($fallbackQuery);
    if ($stmt2) {
        $stmt2->bind_param("s", $email);
        $stmt2->execute();
        $result = $stmt2->get_result();
        error_log("NGO Login - Fallback query rows found: " . $result->num_rows);
        if ($result->num_rows > 0) {
            $stmt->close();
            $stmt = $stmt2; // Use fallback statement
        } else {
            $stmt2->close();
        }
    }
}

// Debug: Show all emails in table for comparison
$debugQuery = "SELECT email FROM `$tableName` LIMIT 10";
$debugResult = $conn->query($debugQuery);
if ($debugResult) {
    $emails = [];
    while ($row = $debugResult->fetch_assoc()) {
        $emails[] = $row['email'];
    }
    error_log("NGO Login - Sample emails in table: " . implode(', ', $emails));
}

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        sendResponse(true, "Login successful", array(
            'ngo_id' => (int)$row[$idColumn],
            'full_name' => $row['full_name'],
            'email' => $row['email']
        ));
    } else {
        sendResponse(false, "Invalid password");
    }
} else {
    sendResponse(false, "Email not found");
}

$stmt->close();
$conn->close();
?>

