<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$ngo_id = $data['ngo_id'] ?? 0;
$request_title = $data['request_title'] ?? '';
$category = $data['category'] ?? '';
$urgency_level = $data['urgency_level'] ?? '';
$required_amount = $data['required_amount'] ?? '';
$date_needed = $data['date_needed'] ?? '';
$contact_number = $data['contact_number'] ?? '';
$description = $data['description'] ?? '';

// Validate required fields
if (empty($ngo_id) || empty($request_title) || empty($category) || 
    empty($urgency_level) || empty($required_amount) || empty($date_needed) || 
    empty($contact_number) || empty($description)) {
    sendResponse(false, "All fields are required");
}

// Check which table exists and insert accordingly
$checkTable1 = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
$checkTable2 = $conn->query("SHOW TABLES LIKE 'ngo_help_requests'");

if ($checkTable1->num_rows > 0) {
    // Use existing ngoraisehelp table
    // Check if admin_status column exists
    $checkColumn = $conn->query("SHOW COLUMNS FROM ngoraisehelp LIKE 'admin_status'");
    if ($checkColumn->num_rows > 0) {
        // Column exists, include it in INSERT
        $stmt = $conn->prepare("INSERT INTO ngoraisehelp (ngo_id, request_title, category, urgency_level, required_amount, date_needed, contact_number, description, admin_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
    } else {
        // Column doesn't exist yet, insert without it
        $stmt = $conn->prepare("INSERT INTO ngoraisehelp (ngo_id, request_title, category, urgency_level, required_amount, date_needed, contact_number, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    }
} else if ($checkTable2->num_rows > 0) {
    // Use new ngo_help_requests table
    $stmt = $conn->prepare("INSERT INTO ngo_help_requests (ngo_id, request_title, category, urgency_level, required_amount, date_needed, contact_number, description, admin_status, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending')");
} else {
    sendResponse(false, "Database table not found. Please contact administrator.");
    exit;
}

$stmt->bind_param("isssdsss", $ngo_id, $request_title, $category, $urgency_level, $required_amount, $date_needed, $contact_number, $description);

if ($stmt->execute()) {
    sendResponse(true, "Help request submitted successfully. It will be reviewed by admin before being published.");
} else {
    sendResponse(false, "Failed to create help request: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

