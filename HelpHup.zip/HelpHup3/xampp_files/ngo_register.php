<?php
require_once 'config.php';

// Handle multipart form data
$full_name = $_POST['full_name'] ?? '';
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';
$address = $_POST['address'] ?? '';
$org_name = $_POST['org_name'] ?? '';
$reg_number = $_POST['reg_number'] ?? '';
$password = $_POST['password'] ?? '';

// Validate required fields
if (empty($full_name) || empty($phone) || empty($email) || 
    empty($address) || empty($org_name) || empty($reg_number) || empty($password)) {
    sendResponse(false, "All fields are required");
}

// Check if email already exists
$check = $conn->prepare("SELECT ngo_id FROM ngo WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    sendResponse(false, "Email already registered");
}
$check->close();

// Handle file upload
$reg_proof_file = null;
if (isset($_FILES['reg_proof']) && $_FILES['reg_proof']['error'] == 0) {
    $upload_dir = '../uploads/registration_proofs/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $file_name = time() . '_' . basename($_FILES['reg_proof']['name']);
    $target_file = $upload_dir . $file_name;
    if (move_uploaded_file($_FILES['reg_proof']['tmp_name'], $target_file)) {
        $reg_proof_file = 'uploads/registration_proofs/' . $file_name;
    }
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert into database
$stmt = $conn->prepare("INSERT INTO ngo (full_name, phone, email, address, org_name, reg_number, password, reg_proof_file) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $full_name, $phone, $email, $address, $org_name, $reg_number, $hashed_password, $reg_proof_file);

if ($stmt->execute()) {
    sendResponse(true, "Registration successful");
} else {
    sendResponse(false, "Registration failed: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

