<?php
require_once 'config.php';

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display, but log
ini_set('log_errors', 1);

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Log the received data
error_log("OTP Verification Request: " . json_encode($data));

$email = trim(strtolower($data['email'] ?? ''));
$otp = trim($data['otp'] ?? '');

if (empty($email) || empty($otp)) {
    sendResponse(false, "Email and OTP are required");
}

// Normalize OTP - ensure it's exactly 6 digits (pad with zeros if needed)
// Remove any non-numeric characters first
$otp = preg_replace('/[^0-9]/', '', $otp);
$otp = str_pad($otp, 6, '0', STR_PAD_LEFT);

// Log what we're searching for
error_log("Searching for - Email: '$email', OTP: '$otp' (normalized)");

// First, check if table exists
$tableCheck = $conn->query("SHOW TABLES LIKE 'ngo_password_reset_tokens'");
if (!$tableCheck || $tableCheck->num_rows == 0) {
    sendResponse(false, "Database error: Table 'ngo_password_reset_tokens' does not exist. Please run setup_password_reset_table.php first.");
}

// First, let's check what OTPs exist for this email (for debugging)
$debugStmt = $conn->prepare("SELECT otp, expires_at, used, created_at, email FROM ngo_password_reset_tokens WHERE email = ? ORDER BY created_at DESC LIMIT 3");
$debugStmt->bind_param("s", $email);
$debugStmt->execute();
$debugResult = $debugStmt->get_result();
error_log("Debug: Found " . $debugResult->num_rows . " OTP records for email: $email");
while ($row = $debugResult->fetch_assoc()) {
    error_log("Debug: OTP in DB: '" . $row['otp'] . "' (length: " . strlen($row['otp']) . "), Email: '" . $row['email'] . "', Expires: " . $row['expires_at'] . ", Used: " . $row['used']);
}
$debugStmt->close();

// Verify OTP - check if exists, not expired, and not used
// Note: Email is already lowercased, so we compare directly without LOWER()
// Cast OTP to string in SQL to ensure proper comparison (handles INT columns)
// Use database time (NOW()) for expiration comparison to avoid timezone issues
$stmt = $conn->prepare("SELECT *, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry FROM ngo_password_reset_tokens WHERE email = ? AND CAST(otp AS CHAR) = ? AND used = 0");

if ($stmt === false) {
    sendResponse(false, "Database error: " . $conn->error . ". Please check if ngo_password_reset_tokens table exists.");
}

$stmt->bind_param("ss", $email, $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $secondsUntilExpiry = $row['seconds_until_expiry'];
    $storedOtp = $row['otp'];
    error_log("OTP found - Stored OTP: '$storedOtp', Received OTP: '$otp', Seconds until expiry: $secondsUntilExpiry, Expires at: " . $row['expires_at'] . ", Now (DB): " . date('Y-m-d H:i:s'));
    
    if ($secondsUntilExpiry > 0) {
        // OTP is valid - return success
        error_log("OTP verified successfully for email: $email");
        sendResponse(true, "OTP verified successfully");
        $stmt->close();
        $conn->close();
        exit();
    } else {
        error_log("OTP found but expired - $secondsUntilExpiry seconds until expiry (negative = expired)");
        sendResponse(false, "OTP has expired. Please request a new OTP.");
        $stmt->close();
        $conn->close();
        exit();
    }
}

// If we get here, OTP was not found in valid state
// Let's check what's in the database for debugging
error_log("OTP not found in valid state. Checking database...");

// Check if OTP exists but expired or used
$checkExpired = $conn->prepare("SELECT * FROM ngo_password_reset_tokens WHERE email = ? AND CAST(otp AS CHAR) = ?");
$checkExpired->bind_param("ss", $email, $otp);
$checkExpired->execute();
$expiredResult = $checkExpired->get_result();

if ($expiredResult->num_rows > 0) {
    $row = $expiredResult->fetch_assoc();
    error_log("Found OTP in database - Used: " . $row['used'] . ", Expires: " . $row['expires_at'] . ", Now: " . date('Y-m-d H:i:s'));
    
    if ($row['used'] == 1) {
        sendResponse(false, "OTP has already been used. Please request a new OTP.");
    } else {
        // Check if expired using database time calculation
        $expiryCheck = $conn->query("SELECT TIMESTAMPDIFF(SECOND, NOW(), '" . $row['expires_at'] . "') as seconds_until_expiry");
        if ($expiryCheck && $expiryCheck->num_rows > 0) {
            $expiryRow = $expiryCheck->fetch_assoc();
            $secondsUntilExpiry = $expiryRow['seconds_until_expiry'];
            
            if ($secondsUntilExpiry <= 0) {
                $minutesExpired = round(abs($secondsUntilExpiry) / 60);
                sendResponse(false, "OTP has expired ($minutesExpired minutes ago). Please request a new OTP.");
            } else {
                // OTP exists and is not expired/used, but query failed - this shouldn't happen
                error_log("ERROR: OTP exists, not expired, not used, but verification query failed. This is a bug!");
                error_log("Expires: " . $row['expires_at'] . ", Seconds until expiry: $secondsUntilExpiry");
                sendResponse(false, "OTP verification failed. Please request a new OTP and try again.");
            }
        } else {
            // Fallback to PHP time calculation
            $expiresAt = strtotime($row['expires_at']);
            $now = time();
            if ($expiresAt < $now) {
                $minutesExpired = round(($now - $expiresAt) / 60);
                sendResponse(false, "OTP has expired ($minutesExpired minutes ago). Please request a new OTP.");
            } else {
                error_log("OTP exists and valid, but query failed. Expires: " . $row['expires_at'] . ", Now: " . date('Y-m-d H:i:s'));
                sendResponse(false, "OTP verification failed. Please request a new OTP and try again.");
            }
        }
    }
    $checkExpired->close();
} else {
    // Check if email exists but OTP doesn't match
    $checkEmail = $conn->prepare("SELECT otp, expires_at, used, created_at FROM ngo_password_reset_tokens WHERE email = ? ORDER BY created_at DESC LIMIT 1");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $emailResult = $checkEmail->get_result();
    
    if ($emailResult->num_rows > 0) {
        $row = $emailResult->fetch_assoc();
        $storedOtp = $row['otp'];
        error_log("Email found but OTP mismatch - Stored OTP: '$storedOtp' (length: " . strlen($storedOtp) . "), Received OTP: '$otp' (length: " . strlen($otp) . ")");
        error_log("Stored OTP bytes: " . bin2hex($storedOtp) . ", Received OTP bytes: " . bin2hex($otp));
        sendResponse(false, "Invalid OTP. The code you entered does not match. Please check and try again.");
    } else {
        error_log("No OTP found for email: $email");
        sendResponse(false, "No OTP found for this email. Please request a new OTP by clicking 'Resend Code'.");
    }
    $checkEmail->close();
}

$stmt->close();
$conn->close();
?>
