-- Payment/Donation Tables for HelpHup
-- Run this in phpMyAdmin SQL tab on 'helphup' database
-- Location: C:\xampp\htdocs\helphup\api\

-- ============================================
-- 1. DONATIONS TABLE (Main payment/donation records)
-- Stores donations FROM donors TO causes/campaigns
-- ============================================
CREATE TABLE IF NOT EXISTS `donations` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `donor_id` INT(11) NOT NULL COMMENT 'References donors.id',
  `campaign_id` INT(11) DEFAULT NULL COMMENT 'References donor_campaigns.id (if donating to campaign)',
  `ngo_id` INT(11) DEFAULT NULL COMMENT 'References ngos.id (if donating to NGO cause)',
  `volunteer_id` INT(11) DEFAULT NULL COMMENT 'References volunteers.id (if donating to volunteer cause)',
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_method` VARCHAR(50) NOT NULL COMMENT 'CARD, UPI, NET_BANKING, etc.',
  `transaction_id` VARCHAR(100) DEFAULT NULL COMMENT 'Payment gateway transaction ID',
  `payment_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, completed, failed, refunded',
  `description` TEXT DEFAULT NULL COMMENT 'Optional note/message from donor',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_donor_id` (`donor_id`),
  INDEX `idx_campaign_id` (`campaign_id`),
  INDEX `idx_ngo_id` (`ngo_id`),
  INDEX `idx_volunteer_id` (`volunteer_id`),
  INDEX `idx_payment_status` (`payment_status`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 2. NGO PAYMENTS TABLE (For NGO community support payments)
-- Stores payments FROM NGOs (for community support/contributions)
-- ============================================
CREATE TABLE IF NOT EXISTS `ngo_payments` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `ngo_id` INT(11) NOT NULL COMMENT 'References ngos.id',
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_method` VARCHAR(50) NOT NULL COMMENT 'CARD, UPI, NET_BANKING, etc.',
  `transaction_id` VARCHAR(100) DEFAULT NULL COMMENT 'Payment gateway transaction ID',
  `payment_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, completed, failed, refunded',
  `description` TEXT DEFAULT NULL COMMENT 'Optional note',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_ngo_id` (`ngo_id`),
  INDEX `idx_payment_status` (`payment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 3. VOLUNTEER PAYMENTS TABLE (For Volunteer community support payments)
-- Stores payments FROM volunteers (for community support/contributions)
-- ============================================
CREATE TABLE IF NOT EXISTS `volunteer_payments` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `volunteer_id` INT(11) NOT NULL COMMENT 'References volunteers.id',
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_method` VARCHAR(50) NOT NULL COMMENT 'CARD, UPI, NET_BANKING, etc.',
  `transaction_id` VARCHAR(100) DEFAULT NULL COMMENT 'Payment gateway transaction ID',
  `payment_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'pending, completed, failed, refunded',
  `description` TEXT DEFAULT NULL COMMENT 'Optional note',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_volunteer_id` (`volunteer_id`),
  INDEX `idx_payment_status` (`payment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- NOTES:
-- ============================================
-- 1. The 'donations' table handles donations FROM donors TO causes/campaigns
-- 2. The 'ngo_payments' table handles payments FROM NGOs (for community support)
-- 3. The 'volunteer_payments' table handles payments FROM volunteers (for community support)
-- 4. All amounts are stored as DECIMAL(10,2) to handle currency properly
-- 5. Payment status: pending → completed/failed
-- 6. Transaction IDs can be used to link with payment gateway records
-- 7. All tables have created_at and updated_at timestamps


