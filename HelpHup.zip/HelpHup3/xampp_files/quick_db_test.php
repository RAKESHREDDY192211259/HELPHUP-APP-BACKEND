<?php
/**
 * Quick Database Connection Test
 * Access: http://localhost/helphup/api/quick_db_test.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

?>
<!DOCTYPE html>
<html>
<head>
    <title>Database Connection Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        h1 { color: #333; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .warning { color: orange; font-weight: bold; }
        .info { background: #e3f2fd; padding: 10px; border-left: 4px solid #2196F3; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Database Connection Test</h1>
        
        <?php
        // Test 1: Config file
        echo "<h2>1. Configuration File</h2>";
        if (file_exists('config.php')) {
            echo "<p class='success'>✅ config.php found</p>";
            require_once 'config.php';
        } else {
            echo "<p class='error'>❌ config.php NOT FOUND</p>";
            echo "<p>Current directory: " . __DIR__ . "</p>";
            exit;
        }
        
        // Test 2: Connection
        echo "<h2>2. Database Connection</h2>";
        if (isset($conn) && $conn) {
            if ($conn->connect_error) {
                echo "<p class='error'>❌ Connection Error: " . $conn->connect_error . "</p>";
                exit;
            }
            echo "<p class='success'>✅ Database connection successful</p>";
            echo "<div class='info'>";
            echo "<strong>Database:</strong> helphup<br>";
            echo "<strong>Host:</strong> localhost<br>";
            echo "<strong>Server Info:</strong> " . $conn->server_info . "<br>";
            echo "<strong>Host Info:</strong> " . $conn->host_info . "<br>";
            echo "</div>";
        } else {
            echo "<p class='error'>❌ Connection variable not set</p>";
            exit;
        }
        
        // Test 3: Check Tables
        echo "<h2>3. Required Tables</h2>";
        $tables = [
            'volunteer' => ['volunteer', 'volunteers'],
            'donor' => ['donor', 'donors'],
            'ngo' => ['ngo', 'ngos'],
            'admin' => ['admin', 'admins']
        ];
        
        echo "<table>";
        echo "<tr><th>Type</th><th>Status</th><th>Table Name</th><th>Primary Key</th><th>Records</th></tr>";
        
        foreach ($tables as $type => $possibleNames) {
            $found = false;
            $actualName = null;
            $pkColumn = null;
            $recordCount = 0;
            
            foreach ($possibleNames as $tableName) {
                $check = $conn->query("SHOW TABLES LIKE '$tableName'");
                if ($check && $check->num_rows > 0) {
                    $found = true;
                    $actualName = $tableName;
                    
                    // Get primary key
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$tableName` WHERE `Key` = 'PRI'");
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $pkRow = $pkResult->fetch_assoc();
                        $pkColumn = $pkRow['Field'];
                    }
                    
                    // Get record count
                    $countResult = $conn->query("SELECT COUNT(*) as count FROM `$tableName`");
                    if ($countResult) {
                        $countRow = $countResult->fetch_assoc();
                        $recordCount = $countRow['count'];
                    }
                    
                    break;
                }
            }
            
            if ($found) {
                echo "<tr>";
                echo "<td><strong>$type</strong></td>";
                echo "<td class='success'>✅ Found</td>";
                echo "<td>$actualName</td>";
                echo "<td>$pkColumn</td>";
                echo "<td>$recordCount</td>";
                echo "</tr>";
            } else {
                echo "<tr>";
                echo "<td><strong>$type</strong></td>";
                echo "<td class='error'>❌ Not Found</td>";
                echo "<td>-</td>";
                echo "<td>-</td>";
                echo "<td>-</td>";
                echo "</tr>";
            }
        }
        echo "</table>";
        
        // Test 4: Column Check
        echo "<h2>4. Column Verification</h2>";
        
        // Check Volunteer Table
        $volTables = ['volunteer', 'volunteers'];
        $volTable = null;
        foreach ($volTables as $t) {
            $check = $conn->query("SHOW TABLES LIKE '$t'");
            if ($check && $check->num_rows > 0) {
                $volTable = $t;
                break;
            }
        }
        
        if ($volTable) {
            echo "<h3>Volunteer Table ($volTable)</h3>";
            $columns = $conn->query("SHOW COLUMNS FROM `$volTable`");
            $required = ['email', 'password', 'full_name'];
            $foundCols = [];
            
            if ($columns) {
                while ($col = $columns->fetch_assoc()) {
                    $foundCols[] = $col['Field'];
                }
                
                echo "<table>";
                echo "<tr><th>Column</th><th>Status</th><th>Type</th></tr>";
                foreach ($required as $req) {
                    if (in_array($req, $foundCols)) {
                        $colInfo = $conn->query("SHOW COLUMNS FROM `$volTable` LIKE '$req'")->fetch_assoc();
                        echo "<tr><td>$req</td><td class='success'>✅</td><td>{$colInfo['Type']}</td></tr>";
                    } else {
                        echo "<tr><td>$req</td><td class='error'>❌ Missing</td><td>-</td></tr>";
                    }
                }
                echo "</table>";
            }
        }
        
        // Check Donor Table
        $donorTables = ['donor', 'donors'];
        $donorTable = null;
        foreach ($donorTables as $t) {
            $check = $conn->query("SHOW TABLES LIKE '$t'");
            if ($check && $check->num_rows > 0) {
                $donorTable = $t;
                break;
            }
        }
        
        if ($donorTable) {
            echo "<h3>Donor Table ($donorTable)</h3>";
            $columns = $conn->query("SHOW COLUMNS FROM `$donorTable`");
            $required = ['email', 'password', 'full_name'];
            $foundCols = [];
            
            if ($columns) {
                while ($col = $columns->fetch_assoc()) {
                    $foundCols[] = $col['Field'];
                }
                
                echo "<table>";
                echo "<tr><th>Column</th><th>Status</th><th>Type</th></tr>";
                foreach ($required as $req) {
                    if (in_array($req, $foundCols)) {
                        $colInfo = $conn->query("SHOW COLUMNS FROM `$donorTable` LIKE '$req'")->fetch_assoc();
                        echo "<tr><td>$req</td><td class='success'>✅</td><td>{$colInfo['Type']}</td></tr>";
                    } else {
                        echo "<tr><td>$req</td><td class='error'>❌ Missing</td><td>-</td></tr>";
                    }
                }
                echo "</table>";
            }
        }
        
        // Test 5: Query Test
        echo "<h2>5. Query Test</h2>";
        
        if ($volTable) {
            $pkResult = $conn->query("SHOW COLUMNS FROM `$volTable` WHERE `Key` = 'PRI'");
            $volIdColumn = 'id';
            if ($pkResult && $pkResult->num_rows > 0) {
                $pkRow = $pkResult->fetch_assoc();
                $volIdColumn = $pkRow['Field'];
            }
            
            $testQuery = "SELECT `$volIdColumn`, full_name, email, password FROM `$volTable` WHERE email = ?";
            $stmt = $conn->prepare($testQuery);
            if ($stmt) {
                echo "<p class='success'>✅ Volunteer login query works</p>";
                echo "<div class='info'><strong>Query:</strong> $testQuery</div>";
                $stmt->close();
            } else {
                echo "<p class='error'>❌ Volunteer login query FAILED: " . $conn->error . "</p>";
            }
        }
        
        if ($donorTable) {
            $pkResult = $conn->query("SHOW COLUMNS FROM `$donorTable` WHERE `Key` = 'PRI'");
            $donorIdColumn = 'id';
            if ($pkResult && $pkResult->num_rows > 0) {
                $pkRow = $pkResult->fetch_assoc();
                $donorIdColumn = $pkRow['Field'];
            }
            
            $testQuery = "SELECT `$donorIdColumn`, full_name, email, password FROM `$donorTable` WHERE email = ?";
            $stmt = $conn->prepare($testQuery);
            if ($stmt) {
                echo "<p class='success'>✅ Donor login query works</p>";
                echo "<div class='info'><strong>Query:</strong> $testQuery</div>";
                $stmt->close();
            } else {
                echo "<p class='error'>❌ Donor login query FAILED: " . $conn->error . "</p>";
            }
        }
        
        echo "<h2>✅ Test Complete</h2>";
        echo "<p>If all tests pass, your database connection is working correctly!</p>";
        
        $conn->close();
        ?>
    </div>
</body>
</html>

