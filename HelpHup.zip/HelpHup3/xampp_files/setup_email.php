<?php
/**
 * Email Setup Helper Script
 * 
 * This script helps you set up email sending for OTP.
 * Run this in your browser: http://localhost/helphup/api/setup_email.php
 */

$baseDir = __DIR__;
$phpmailerPath = $baseDir . '/PHPMailer/src/Exception.php';
$emailConfigPath = $baseDir . '/email_config.php';

// Check current status
$phpmailerExists = file_exists($phpmailerPath);
$emailConfigExists = file_exists($emailConfigPath);

// Read current config
$usePhpMail = true;
$smtpUsername = '';
$smtpPassword = '';

if ($emailConfigExists) {
    $configContent = file_get_contents($emailConfigPath);
    preg_match("/define\s*\(\s*['\"]USE_PHP_MAIL['\"]\s*,\s*(true|false)\s*\)/", $configContent, $matches);
    if (!empty($matches[1])) {
        $usePhpMail = $matches[1] === 'true';
    }
    
    preg_match("/define\s*\(\s*['\"]SMTP_USERNAME['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)/", $configContent, $matches);
    if (!empty($matches[1]) && $matches[1] !== 'your-email@gmail.com') {
        $smtpUsername = $matches[1];
    }
    
    preg_match("/define\s*\(\s*['\"]SMTP_PASSWORD['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)/", $configContent, $matches);
    if (!empty($matches[1]) && $matches[1] !== 'your-app-password') {
        $smtpPassword = $matches[1];
    }
}

// Handle form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_config') {
        $usePhpMailNew = ($_POST['use_php_mail'] ?? 'false') === 'true';
        $smtpUsernameNew = trim($_POST['smtp_username'] ?? '');
        $smtpPasswordNew = trim($_POST['smtp_password'] ?? '');
        $smtpFromEmailNew = trim($_POST['smtp_from_email'] ?? '');
        
        if ($emailConfigExists) {
            $configContent = file_get_contents($emailConfigPath);
            
            // Update USE_PHP_MAIL
            $configContent = preg_replace(
                "/define\s*\(\s*['\"]USE_PHP_MAIL['\"]\s*,\s*(true|false)\s*\)/",
                "define('USE_PHP_MAIL', " . ($usePhpMailNew ? 'true' : 'false') . ")",
                $configContent
            );
            
            // Update SMTP_USERNAME
            if (!empty($smtpUsernameNew)) {
                $configContent = preg_replace(
                    "/define\s*\(\s*['\"]SMTP_USERNAME['\"]\s*,\s*['\"][^'\"]+['\"]\s*\)/",
                    "define('SMTP_USERNAME', '" . addslashes($smtpUsernameNew) . "')",
                    $configContent
                );
            }
            
            // Update SMTP_PASSWORD
            if (!empty($smtpPasswordNew)) {
                $configContent = preg_replace(
                    "/define\s*\(\s*['\"]SMTP_PASSWORD['\"]\s*,\s*['\"][^'\"]+['\"]\s*\)/",
                    "define('SMTP_PASSWORD', '" . addslashes($smtpPasswordNew) . "')",
                    $configContent
                );
            }
            
            // Update SMTP_FROM_EMAIL
            if (!empty($smtpFromEmailNew)) {
                $configContent = preg_replace(
                    "/define\s*\(\s*['\"]SMTP_FROM_EMAIL['\"]\s*,\s*['\"][^'\"]+['\"]\s*\)/",
                    "define('SMTP_FROM_EMAIL', '" . addslashes($smtpFromEmailNew) . "')",
                    $configContent
                );
            }
            
            if (file_put_contents($emailConfigPath, $configContent)) {
                $message = 'Configuration updated successfully!';
                $messageType = 'success';
                $usePhpMail = $usePhpMailNew;
                $smtpUsername = $smtpUsernameNew;
                $smtpPassword = $smtpPasswordNew;
            } else {
                $message = 'Failed to update configuration. Check file permissions.';
                $messageType = 'error';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Email Setup - HelpHup</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        .container { 
            max-width: 900px; 
            margin: 0 auto; 
            background: white; 
            padding: 40px; 
            border-radius: 15px; 
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 { 
            color: #22C55E; 
            margin-bottom: 10px;
            font-size: 32px;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 16px;
        }
        .status-box {
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            border-left: 5px solid;
        }
        .status-success {
            background: #e8f5e9;
            border-color: #22C55E;
            color: #2e7d32;
        }
        .status-warning {
            background: #fff3cd;
            border-color: #ffc107;
            color: #856404;
        }
        .status-error {
            background: #ffebee;
            border-color: #f44336;
            color: #c62828;
        }
        .status-info {
            background: #e3f2fd;
            border-color: #2196f3;
            color: #1565c0;
        }
        .check-item {
            display: flex;
            align-items: center;
            padding: 15px;
            margin: 10px 0;
            background: #f5f5f5;
            border-radius: 8px;
        }
        .check-item .icon {
            font-size: 24px;
            margin-right: 15px;
            width: 30px;
            text-align: center;
        }
        .check-item .text {
            flex: 1;
        }
        .form-group {
            margin: 20px 0;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        input:focus {
            outline: none;
            border-color: #22C55E;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            margin: 20px 0;
        }
        .checkbox-group input[type="checkbox"] {
            width: 20px;
            height: 20px;
            margin-right: 10px;
        }
        button {
            background: #22C55E;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background: #16a34a;
        }
        .steps {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .steps ol {
            margin-left: 20px;
        }
        .steps li {
            margin: 10px 0;
            line-height: 1.6;
        }
        .link-button {
            display: inline-block;
            background: #2196f3;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 8px;
            margin: 5px;
        }
        .link-button:hover {
            background: #1976d2;
        }
        code {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📧 Email Setup Helper</h1>
        <p class="subtitle">Configure email sending for OTP in HelpHup</p>
        
        <?php if ($message): ?>
            <div class="status-box status-<?php echo $messageType; ?>">
                <strong><?php echo $messageType === 'success' ? '✅' : '⚠️'; ?></strong> <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <!-- Status Check -->
        <div class="status-box status-info">
            <h3>📊 Current Status</h3>
            <div class="check-item">
                <span class="icon"><?php echo $phpmailerExists ? '✅' : '❌'; ?></span>
                <div class="text">
                    <strong>PHPMailer Library:</strong> 
                    <?php if ($phpmailerExists): ?>
                        Installed at <code>PHPMailer/</code>
                    <?php else: ?>
                        Not found. Need to install.
                    <?php endif; ?>
                </div>
            </div>
            <div class="check-item">
                <span class="icon"><?php echo $emailConfigExists ? '✅' : '❌'; ?></span>
                <div class="text">
                    <strong>Email Config File:</strong> 
                    <?php echo $emailConfigExists ? 'Found' : 'Not found'; ?>
                </div>
            </div>
            <div class="check-item">
                <span class="icon"><?php echo !$usePhpMail ? '✅' : '⚠️'; ?></span>
                <div class="text">
                    <strong>Email Method:</strong> 
                    <?php echo $usePhpMail ? 'PHP mail() (won\'t work on XAMPP)' : 'SMTP (Gmail)'; ?>
                </div>
            </div>
            <div class="check-item">
                <span class="icon"><?php echo !empty($smtpUsername) && $smtpUsername !== 'your-email@gmail.com' ? '✅' : '❌'; ?></span>
                <div class="text">
                    <strong>Gmail Credentials:</strong> 
                    <?php echo !empty($smtpUsername) && $smtpUsername !== 'your-email@gmail.com' ? 'Configured' : 'Not configured'; ?>
                </div>
            </div>
        </div>
        
        <?php if (!$phpmailerExists): ?>
            <div class="status-box status-warning">
                <h3>📥 Step 1: Install PHPMailer</h3>
                <p><strong>PHPMailer is required for email sending.</strong></p>
                <div class="steps">
                    <ol>
                        <li>Download PHPMailer: <a href="https://github.com/PHPMailer/PHPMailer/archive/refs/heads/master.zip" target="_blank" class="link-button">Download ZIP</a></li>
                        <li>Extract the ZIP file</li>
                        <li>Copy the <code>PHPMailer</code> folder to: <code><?php echo htmlspecialchars($baseDir); ?>\PHPMailer\</code></li>
                        <li>Refresh this page to continue</li>
                    </ol>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if ($phpmailerExists): ?>
            <!-- Configuration Form -->
            <div class="status-box status-info">
                <h3>⚙️ Step 2: Configure Email Settings</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="update_config">
                    
                    <div class="checkbox-group">
                        <input type="checkbox" name="use_php_mail" value="true" id="use_php_mail" <?php echo $usePhpMail ? 'checked' : ''; ?>>
                        <label for="use_php_mail">Use PHP mail() (not recommended - won't work on XAMPP)</label>
                    </div>
                    
                    <div class="form-group">
                        <label>Gmail Address:</label>
                        <input type="email" name="smtp_username" value="<?php echo htmlspecialchars($smtpUsername); ?>" placeholder="your-email@gmail.com" required>
                        <small style="color: #666;">The Gmail account to send emails from</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Gmail App Password:</label>
                        <input type="password" name="smtp_password" value="<?php echo htmlspecialchars($smtpPassword); ?>" placeholder="16-character app password" required>
                        <small style="color: #666;">
                            Get this from: <a href="https://myaccount.google.com/apppasswords" target="_blank">Google App Passwords</a>
                            <br>(Enable 2-Step Verification first, then generate App Password)
                        </small>
                    </div>
                    
                    <div class="form-group">
                        <label>From Email (usually same as Gmail):</label>
                        <input type="email" name="smtp_from_email" value="<?php echo htmlspecialchars($smtpUsername); ?>" placeholder="your-email@gmail.com" required>
                    </div>
                    
                    <button type="submit">💾 Save Configuration</button>
                </form>
            </div>
            
            <!-- Test Email -->
            <div class="status-box status-success">
                <h3>🧪 Step 3: Test Email</h3>
                <p>After saving configuration, test email sending:</p>
                <a href="test_email.php" class="link-button">Test Email Sending</a>
            </div>
        <?php endif; ?>
        
        <!-- Instructions -->
        <div class="steps">
            <h3>📖 Quick Instructions</h3>
            <ol>
                <li><strong>Enable 2-Step Verification</strong> on your Gmail account</strong>
                    <br>Go to: <a href="https://myaccount.google.com/security" target="_blank">Google Account Security</a></li>
                <li><strong>Generate App Password</strong>
                    <br>Go to: <a href="https://myaccount.google.com/apppasswords" target="_blank">App Passwords</a>
                    <br>Select "Mail" → "Other" → Type "HelpHup" → Generate
                    <br>Copy the 16-character password</li>
                <li><strong>Install PHPMailer</strong> (if not done)
                    <br>Download from link above and extract to <code>PHPMailer/</code> folder</li>
                <li><strong>Configure above</strong> with your Gmail and App Password</li>
                <li><strong>Test</strong> using the test email link</li>
            </ol>
        </div>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 2px solid #eee; text-align: center;">
            <a href="test_email.php" class="link-button">Test Email</a>
            <a href="EMAIL_SETUP_INSTRUCTIONS.md" target="_blank" class="link-button" style="background: #666;">View Full Guide</a>
        </div>
    </div>
</body>
</html>

