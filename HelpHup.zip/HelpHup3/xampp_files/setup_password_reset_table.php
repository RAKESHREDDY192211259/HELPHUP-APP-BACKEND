<?php
require_once 'config.php';

// Set header for JSON response
header('Content-Type: application/json');

// Function to send JSON response
function sendResponse($status, $message, $data = null) {
    $response = array(
        'status' => $status,
        'message' => $message
    );
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit();
}

$tables = array(
    'ngo_password_reset_tokens',
    'donor_password_reset_tokens',
    'volunteer_password_reset_tokens'
);

$results = array();
$allCreated = true;
$allExist = true;

foreach ($tables as $tableName) {
    // Check if table exists
    $checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
    
    if ($checkTable && $checkTable->num_rows > 0) {
        // Table exists, show structure
        $result = $conn->query("DESCRIBE $tableName");
        $columns = array();
        while ($row = $result->fetch_assoc()) {
            $columns[] = $row;
        }
        $results[$tableName] = array('status' => 'exists', 'columns' => $columns);
        $allCreated = false;
    } else {
        // Table doesn't exist, create it
        $allExist = false;
        
        // Determine table structure based on name
        $sql = "";
        if ($tableName === 'ngo_password_reset_tokens') {
            $sql = "CREATE TABLE IF NOT EXISTS `ngo_password_reset_tokens` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `email` VARCHAR(100) NOT NULL,
              `otp` VARCHAR(6) NOT NULL,
              `expires_at` TIMESTAMP NOT NULL,
              `used` TINYINT(1) DEFAULT 0,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              INDEX `idx_email` (`email`),
              INDEX `idx_email_otp` (`email`, `otp`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        } elseif ($tableName === 'donor_password_reset_tokens') {
            $sql = "CREATE TABLE IF NOT EXISTS `donor_password_reset_tokens` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `email` VARCHAR(100) NOT NULL,
              `otp` VARCHAR(6) NOT NULL,
              `expires_at` TIMESTAMP NOT NULL,
              `used` TINYINT(1) DEFAULT 0,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              INDEX `idx_email` (`email`),
              INDEX `idx_email_otp` (`email`, `otp`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        } elseif ($tableName === 'volunteer_password_reset_tokens') {
            $sql = "CREATE TABLE IF NOT EXISTS `volunteer_password_reset_tokens` (
              `id` INT(11) NOT NULL AUTO_INCREMENT,
              `email` VARCHAR(100) NOT NULL,
              `otp` VARCHAR(6) NOT NULL,
              `expires_at` TIMESTAMP NOT NULL,
              `used` TINYINT(1) DEFAULT 0,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              INDEX `idx_email` (`email`),
              INDEX `idx_email_otp` (`email`, `otp`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        }
        
        if ($conn->query($sql) === TRUE) {
            // Get table structure to return
            $result = $conn->query("DESCRIBE $tableName");
            $columns = array();
            while ($row = $result->fetch_assoc()) {
                $columns[] = $row;
            }
            $results[$tableName] = array('status' => 'created', 'columns' => $columns);
        } else {
            $results[$tableName] = array('status' => 'error', 'message' => $conn->error);
            $allCreated = false;
        }
    }
}

if ($allExist) {
    sendResponse(true, "All password reset token tables already exist!", array('tables' => $results));
} elseif ($allCreated) {
    sendResponse(true, "All password reset token tables created successfully!", array('tables' => $results));
} else {
    sendResponse(true, "Password reset token tables setup completed (some already existed, some were created)", array('tables' => $results));
}

$conn->close();
?>

