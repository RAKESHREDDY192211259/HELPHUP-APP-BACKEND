<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

$email = $_GET['email'] ?? 'rakeshreddyk1259.sse@saveetha.com';
$newPassword = $_GET['password'] ?? 'TestPass123';

echo "<h2>Simple Password Update Test</h2>";
echo "<p>Email: $email</p>";
echo "<p>New Password: $newPassword</p><hr>";

// Find table
$tableNames = ['volunteer', 'volunteers'];
$tableName = null;
foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    die("Table not found");
}

echo "<p><strong>Using table: $tableName</strong></p>";

// Step 1: Get current password
$stmt = $conn->prepare("SELECT id, email, password FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Email not found");
}

$row = $result->fetch_assoc();
$actualEmail = $row['email'];
$oldHash = $row['password'];

echo "<h3>Step 1: Current State</h3>";
echo "<p>ID: {$row['id']}</p>";
echo "<p>Email in DB: <strong>$actualEmail</strong></p>";
echo "<p>Old hash: " . substr($oldHash, 0, 30) . "...</p>";

// Step 2: Hash new password
$newHash = password_hash($newPassword, PASSWORD_DEFAULT);
echo "<h3>Step 2: New Hash</h3>";
echo "<p>New hash: " . substr($newHash, 0, 30) . "...</p>";

// Step 3: UPDATE
echo "<h3>Step 3: UPDATE Query</h3>";
echo "<p>UPDATE `$tableName` SET password = ? WHERE email = ?</p>";
echo "<p>Using email: <strong>$actualEmail</strong></p>";

$update = $conn->prepare("UPDATE `$tableName` SET password = ? WHERE email = ?");
$update->bind_param("ss", $newHash, $actualEmail);

if ($update->execute()) {
    $affected = $update->affected_rows;
    echo "<p style='color: green;'>✓ Execute: SUCCESS</p>";
    echo "<p>Affected rows: <strong>$affected</strong></p>";
    
    if ($affected == 0) {
        echo "<p style='color: red; font-weight: bold;'>⚠ PROBLEM: No rows affected!</p>";
        echo "<p>This means the UPDATE didn't match any rows.</p>";
    } else {
        echo "<p style='color: green;'>✓ Rows affected: $affected</p>";
        
        // Step 4: Verify
        echo "<h3>Step 4: Verification</h3>";
        $verify = $conn->prepare("SELECT password FROM `$tableName` WHERE email = ?");
        $verify->bind_param("s", $actualEmail);
        $verify->execute();
        $verifyResult = $verify->get_result();
        $verifyRow = $verifyResult->fetch_assoc();
        $verify->close();
        
        $dbHash = $verifyRow['password'];
        echo "<p>Hash in DB now: " . substr($dbHash, 0, 30) . "...</p>";
        
        if ($dbHash === $newHash) {
            echo "<p style='color: green;'>✓ Hash matches new password!</p>";
        } else {
            echo "<p style='color: red;'>✗ Hash does NOT match!</p>";
        }
        
        $newWorks = password_verify($newPassword, $dbHash);
        $oldWorks = password_verify('123', $dbHash); // assuming old password is '123'
        
        echo "<p>New password '$newPassword' verifies: <strong style='color: " . ($newWorks ? 'green' : 'red') . ";'>" . ($newWorks ? 'YES' : 'NO') . "</strong></p>";
        echo "<p>Old password '123' verifies: <strong style='color: " . ($oldWorks ? 'green' : 'red') . ";'>" . ($oldWorks ? 'YES' : 'NO') . "</strong></p>";
    }
} else {
    echo "<p style='color: red;'>✗ Execute: FAILED</p>";
    echo "<p>Error: " . $update->error . "</p>";
}

$update->close();
$stmt->close();
$conn->close();
?>

