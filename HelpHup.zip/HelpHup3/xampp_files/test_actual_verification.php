<?php
// Test the actual verification endpoint
// This simulates what the Android app sends

require_once 'config.php';

// Simulate the JSON request from Android
$testEmail = 'rakeshreddyk1259.sse@saveetha.com';
$testOtp = '071756'; // Replace with actual OTP from database

echo "=== Testing OTP Verification (Simulating Android Request) ===\n\n";

// Prepare JSON data (like Android sends)
$jsonData = json_encode([
    'email' => $testEmail,
    'otp' => $testOtp
]);

echo "JSON Request: $jsonData\n\n";

// Parse it like the verification script does
$data = json_decode($jsonData, true);
$email = trim(strtolower($data['email'] ?? ''));
$otp = trim($data['otp'] ?? '');

echo "Parsed Email: '$email'\n";
echo "Parsed OTP: '$otp'\n\n";

// Normalize OTP (same as verification script)
$otp = preg_replace('/[^0-9]/', '', $otp);
$otp = str_pad($otp, 6, '0', STR_PAD_LEFT);

echo "Normalized OTP: '$otp' (length: " . strlen($otp) . ")\n\n";

// Check database
$stmt = $conn->prepare("SELECT id, email, otp, expires_at, used, created_at, 
                        TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry,
                        LENGTH(otp) as otp_len,
                        HEX(otp) as otp_hex
                        FROM ngo_password_reset_tokens 
                        WHERE email = ? 
                        ORDER BY created_at DESC LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "❌ No OTP found for email: $email\n";
    echo "\nAll OTPs in database:\n";
    $allStmt = $conn->prepare("SELECT id, email, otp, created_at, expires_at FROM ngo_password_reset_tokens ORDER BY created_at DESC LIMIT 10");
    $allStmt->execute();
    $allResult = $allStmt->get_result();
    while ($r = $allResult->fetch_assoc()) {
        echo "  ID: {$r['id']}, Email: {$r['email']}, OTP: {$r['otp']}, Created: {$r['created_at']}, Expires: {$r['expires_at']}\n";
    }
    exit(1);
}

$row = $result->fetch_assoc();
echo "=== Latest Database Record ===\n";
echo "ID: {$row['id']}\n";
echo "Email (DB): '{$row['email']}'\n";
echo "Email (search): '$email'\n";
echo "Email match: " . ($row['email'] === $email ? "✅ YES" : "❌ NO") . "\n";
if ($row['email'] !== $email) {
    echo "  DB email length: " . strlen($row['email']) . "\n";
    echo "  Search email length: " . strlen($email) . "\n";
    echo "  DB email hex: " . bin2hex($row['email']) . "\n";
    echo "  Search email hex: " . bin2hex($email) . "\n";
}
echo "\n";

echo "OTP (DB): '{$row['otp']}'\n";
echo "OTP (DB length): {$row['otp_len']}\n";
echo "OTP (DB hex): {$row['otp_hex']}\n";
echo "OTP (input normalized): '$otp'\n";
echo "OTP (input length): " . strlen($otp) . "\n";
echo "OTP (input hex): " . bin2hex($otp) . "\n";
echo "OTP match (===): " . ($row['otp'] === $otp ? "✅ YES" : "❌ NO") . "\n";
echo "OTP match (==): " . ($row['otp'] == $otp ? "✅ YES" : "❌ NO") . "\n";
echo "OTP match (trim): " . (trim($row['otp']) === trim($otp) ? "✅ YES" : "❌ NO") . "\n";
echo "\n";

echo "Created: {$row['created_at']}\n";
echo "Expires: {$row['expires_at']}\n";
echo "Used: {$row['used']}\n";
echo "Seconds until expiry: {$row['seconds_until_expiry']}\n";
echo "Status: " . ($row['seconds_until_expiry'] > 0 && $row['used'] == 0 ? "✅ VALID" : "❌ INVALID") . "\n\n";

// Test the actual verification query
echo "=== Testing Verification Query ===\n";
$verifyStmt = $conn->prepare("SELECT *, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry 
                               FROM ngo_password_reset_tokens 
                               WHERE email = ? AND otp = ? AND used = 0");
$verifyStmt->bind_param("ss", $email, $otp);
$verifyStmt->execute();
$verifyResult = $verifyStmt->get_result();

echo "Query: SELECT * FROM ngo_password_reset_tokens WHERE email = '$email' AND otp = '$otp' AND used = 0\n";
echo "Rows found: {$verifyResult->num_rows}\n\n";

if ($verifyResult->num_rows > 0) {
    $verifyRow = $verifyResult->fetch_assoc();
    echo "✅ Query found record\n";
    echo "Seconds until expiry: {$verifyRow['seconds_until_expiry']}\n";
    if ($verifyRow['seconds_until_expiry'] > 0) {
        echo "✅✅✅ OTP is VALID and NOT EXPIRED\n";
        echo "\nThis OTP should verify successfully!\n";
    } else {
        echo "❌ OTP is EXPIRED (expired " . abs($verifyRow['seconds_until_expiry']) . " seconds ago)\n";
        echo "You need to request a new OTP.\n";
    }
} else {
    echo "❌ Query did NOT find record\n\n";
    
    // Test each condition separately
    echo "Testing conditions individually:\n";
    
    $t1 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ?");
    $t1->bind_param("s", $email);
    $t1->execute();
    $r1 = $t1->get_result()->fetch_assoc();
    echo "  1. Email match: {$r1['cnt']} records " . ($r1['cnt'] > 0 ? "✅" : "❌") . "\n";
    
    $t2 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ?");
    $t2->bind_param("ss", $email, $otp);
    $t2->execute();
    $r2 = $t2->get_result()->fetch_assoc();
    echo "  2. Email + OTP match: {$r2['cnt']} records " . ($r2['cnt'] > 0 ? "✅" : "❌") . "\n";
    
    if ($r2['cnt'] == 0) {
        // Try with stored OTP directly
        $t3 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ?");
        $t3->bind_param("ss", $email, $row['otp']);
        $t3->execute();
        $r3 = $t3->get_result()->fetch_assoc();
        echo "  3. Email + stored OTP: {$r3['cnt']} records " . ($r3['cnt'] > 0 ? "✅" : "❌") . "\n";
        
        if ($r3['cnt'] > 0) {
            echo "\n⚠️  ISSUE FOUND: OTP mismatch!\n";
            echo "  The stored OTP doesn't match the normalized input OTP.\n";
            echo "  This could be due to:\n";
            echo "    - OTP format/storage issue\n";
            echo "    - Normalization issue\n";
            echo "    - Encoding issue\n";
        }
    }
    
    $t4 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ? AND used = 0");
    $t4->bind_param("ss", $email, $otp);
    $t4->execute();
    $r4 = $t4->get_result()->fetch_assoc();
    echo "  4. Email + OTP + not used: {$r4['cnt']} records " . ($r4['cnt'] > 0 ? "✅" : "❌") . "\n";
    
    if ($r4['cnt'] == 0 && $r2['cnt'] > 0) {
        echo "\n⚠️  OTP exists but is marked as USED\n";
    }
}

$stmt->close();
$conn->close();
?>

