<?php
// Test the actual query that admin uses
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

header('Content-Type: application/json');

$result = array();
$allRequests = array();

// Test NGO query exactly as admin_get_pending_requests.php does
try {
    // Check if admin_status column exists
    $checkColumn = $conn->query("SHOW COLUMNS FROM ngoraisehelp LIKE 'admin_status'");
    $hasAdminStatus = $checkColumn->num_rows > 0;
    
    if ($hasAdminStatus) {
        // Try with ngos table first
        $checkNgos = $conn->query("SHOW TABLES LIKE 'ngos'");
        $checkNgo = $conn->query("SHOW TABLES LIKE 'ngo'");
        
        if ($checkNgos->num_rows > 0) {
            // Use ngos table
            $stmt = $conn->prepare("
                SELECT 
                    r.id as request_id,
                    'ngo' as request_type,
                    r.ngo_id,
                    r.request_title,
                    r.category,
                    r.urgency_level,
                    r.required_amount,
                    r.date_needed,
                    r.contact_number,
                    r.description,
                    COALESCE(r.admin_status, 'pending') as admin_status,
                    r.created_at,
                    n.full_name as submitter_name,
                    n.email as submitter_email,
                    n.org_name as submitter_org
                FROM ngoraisehelp r
                LEFT JOIN ngos n ON r.ngo_id = n.ngo_id
                WHERE r.admin_status = 'pending' OR r.admin_status IS NULL
                ORDER BY r.created_at DESC
                LIMIT 5
            ");
        } else if ($checkNgo->num_rows > 0) {
            // Use ngo table
            $stmt = $conn->prepare("
                SELECT 
                    r.id as request_id,
                    'ngo' as request_type,
                    r.ngo_id,
                    r.request_title,
                    r.category,
                    r.urgency_level,
                    r.required_amount,
                    r.date_needed,
                    r.contact_number,
                    r.description,
                    COALESCE(r.admin_status, 'pending') as admin_status,
                    r.created_at,
                    n.full_name as submitter_name,
                    n.email as submitter_email,
                    n.org_name as submitter_org
                FROM ngoraisehelp r
                LEFT JOIN ngo n ON r.ngo_id = n.ngo_id
                WHERE r.admin_status = 'pending' OR r.admin_status IS NULL
                ORDER BY r.created_at DESC
                LIMIT 5
            ");
        } else {
            // No parent table, just get requests without join
            $stmt = $conn->prepare("
                SELECT 
                    r.id as request_id,
                    'ngo' as request_type,
                    r.ngo_id,
                    r.request_title,
                    r.category,
                    r.urgency_level,
                    r.required_amount,
                    r.date_needed,
                    r.contact_number,
                    r.description,
                    COALESCE(r.admin_status, 'pending') as admin_status,
                    r.created_at,
                    'Unknown' as submitter_name,
                    'unknown@email.com' as submitter_email,
                    NULL as submitter_org
                FROM ngoraisehelp r
                WHERE r.admin_status = 'pending' OR r.admin_status IS NULL
                ORDER BY r.created_at DESC
                LIMIT 5
            ");
        }
        
        if ($stmt) {
            if ($stmt->execute()) {
                $queryResult = $stmt->get_result();
                while ($row = $queryResult->fetch_assoc()) {
                    $allRequests[] = $row;
                }
                $result['success'] = true;
                $result['requests'] = $allRequests;
                $result['count'] = count($allRequests);
            } else {
                $result['error'] = "Execute failed: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $result['error'] = "Prepare failed: " . $conn->error;
        }
    } else {
        $result['error'] = "admin_status column does not exist";
    }
} catch (Exception $e) {
    $result['error'] = "Exception: " . $e->getMessage();
}

// Check which parent table exists
$checkNgos = $conn->query("SHOW TABLES LIKE 'ngos'");
$checkNgo = $conn->query("SHOW TABLES LIKE 'ngo'");
$result['ngos_table_exists'] = $checkNgos->num_rows > 0;
$result['ngo_table_exists'] = $checkNgo->num_rows > 0;

echo json_encode($result, JSON_PRETTY_PRINT);

$conn->close();
?>

