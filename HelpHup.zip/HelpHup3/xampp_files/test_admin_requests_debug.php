<?php
// Debug script to test admin_get_pending_requests
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

header('Content-Type: application/json');

$errors = array();
$results = array();

// Test NGO requests
try {
    $stmt = $conn->prepare("
        SELECT 
            r.request_id,
            r.ngo_id,
            r.request_title,
            r.admin_status,
            n.full_name as submitter_name
        FROM ngo_help_requests r
        LEFT JOIN ngo n ON r.ngo_id = n.ngo_id
        WHERE r.admin_status = 'pending'
        LIMIT 5
    ");
    if (!$stmt) {
        $errors[] = "NGO Prepare Error: " . $conn->error;
    } else {
        if (!$stmt->execute()) {
            $errors[] = "NGO Execute Error: " . $stmt->error;
        } else {
            $result = $stmt->get_result();
            $results['ngo'] = array();
            while ($row = $result->fetch_assoc()) {
                $results['ngo'][] = $row;
            }
        }
        $stmt->close();
    }
} catch (Exception $e) {
    $errors[] = "NGO Exception: " . $e->getMessage();
}

// Check if ngo table exists
$check = $conn->query("SHOW TABLES LIKE 'ngo'");
$results['ngo_table_exists'] = $check->num_rows > 0;

// Check if ngo_help_requests has data
$check = $conn->query("SELECT COUNT(*) as count FROM ngo_help_requests");
$row = $check->fetch_assoc();
$results['ngo_requests_count'] = $row['count'];

// Check if any have admin_status = 'pending'
$check = $conn->query("SELECT COUNT(*) as count FROM ngo_help_requests WHERE admin_status = 'pending'");
$row = $check->fetch_assoc();
$results['ngo_pending_count'] = $row['count'];

echo json_encode(array(
    'errors' => $errors,
    'results' => $results
), JSON_PRETTY_PRINT);

$conn->close();
?>

