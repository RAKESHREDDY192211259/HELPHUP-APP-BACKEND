<?php
// Test if admin_status column exists
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

header('Content-Type: application/json');

$result = array();

// Check NGO table
$check = $conn->query("SHOW COLUMNS FROM ngo_help_requests LIKE 'admin_status'");
$result['ngo_help_requests'] = $check->num_rows > 0 ? "Column EXISTS" : "Column MISSING";

// Check Volunteer table
$check = $conn->query("SHOW COLUMNS FROM volunteer_requests LIKE 'admin_status'");
$result['volunteer_requests'] = $check->num_rows > 0 ? "Column EXISTS" : "Column MISSING";

// Check Donor table
$check = $conn->query("SHOW COLUMNS FROM donor_campaigns LIKE 'admin_status'");
$result['donor_campaigns'] = $check->num_rows > 0 ? "Column EXISTS" : "Column MISSING";

echo json_encode($result, JSON_PRETTY_PRINT);

$conn->close();
?>

