<?php
// Test script to check API endpoints
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h2>API Endpoints Test</h2>";

// Test 1: Check database connection
echo "<h3>1. Database Connection Test</h3>";
if (isset($conn) && $conn) {
    echo "✓ Database connection successful<br>";
    echo "Database: " . $conn->query("SELECT DATABASE()")->fetch_row()[0] . "<br>";
} else {
    echo "✗ Database connection failed<br>";
    exit;
}

// Test 2: Check if tables exist
echo "<h3>2. Tables Existence Check</h3>";
$tables = ['ngo_help_requests', 'volunteer_requests', 'donor_campaigns', 'ngo', 'volunteer', 'donor'];
foreach ($tables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        echo "✓ Table '$table' exists<br>";
        
        // Count records
        $count = $conn->query("SELECT COUNT(*) FROM $table")->fetch_row()[0];
        echo "&nbsp;&nbsp;Records: $count<br>";
        
        // Check status values if status column exists
        $statusCheck = $conn->query("SHOW COLUMNS FROM $table LIKE 'status'");
        if ($statusCheck && $statusCheck->num_rows > 0) {
            $statuses = $conn->query("SELECT DISTINCT status FROM $table WHERE status IS NOT NULL");
            if ($statuses && $statuses->num_rows > 0) {
                $statusValues = [];
                while ($row = $statuses->fetch_row()) {
                    $statusValues[] = $row[0];
                }
                echo "&nbsp;&nbsp;Status values: " . implode(", ", $statusValues) . "<br>";
            }
        }
    } else {
        echo "✗ Table '$table' does NOT exist<br>";
    }
}

// Test 3: Test NGO requests query
echo "<h3>3. NGO Requests Query Test</h3>";
try {
    $sql = "SELECT COUNT(*) as total FROM ngo_help_requests";
    $result = $conn->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        echo "✓ Total NGO requests: " . $row['total'] . "<br>";
        
        // Show recent requests
        $recent = $conn->query("SELECT request_id, request_title, status, created_at FROM ngo_help_requests ORDER BY created_at DESC LIMIT 5");
        if ($recent && $recent->num_rows > 0) {
            echo "<br>Recent requests:<br>";
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>ID</th><th>Title</th><th>Status</th><th>Created</th></tr>";
            while ($r = $recent->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $r['request_id'] . "</td>";
                echo "<td>" . htmlspecialchars($r['request_title']) . "</td>";
                echo "<td>" . $r['status'] . "</td>";
                echo "<td>" . $r['created_at'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    }
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "<br>";
}

// Test 4: Test JOIN query
echo "<h3>4. JOIN Query Test (NGO + ngo table)</h3>";
try {
    $sql = "SELECT 
        nhr.request_id,
        nhr.request_title,
        n.full_name as ngo_name,
        n.org_name,
        nhr.status
    FROM ngo_help_requests nhr
    LEFT JOIN ngo n ON nhr.ngo_id = n.ngo_id
    LIMIT 5";
    
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        echo "✓ JOIN query works. Sample results:<br>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Request ID</th><th>Title</th><th>NGO Name</th><th>Org Name</th><th>Status</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['request_id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['request_title']) . "</td>";
            echo "<td>" . htmlspecialchars($row['ngo_name'] ?? 'NULL') . "</td>";
            echo "<td>" . htmlspecialchars($row['org_name'] ?? 'NULL') . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "⚠ No results found (this is OK if table is empty)<br>";
    }
} catch (Exception $e) {
    echo "✗ JOIN query failed: " . $e->getMessage() . "<br>";
}

echo "<hr>";
echo "<p><a href='get_all_ngo_requests.php'>Test API: get_all_ngo_requests.php</a></p>";
echo "<p><a href='get_all_volunteer_requests.php'>Test API: get_all_volunteer_requests.php</a></p>";
echo "<p><a href='get_all_donor_campaigns.php'>Test API: get_all_donor_campaigns.php</a></p>";

$conn->close();
?>

