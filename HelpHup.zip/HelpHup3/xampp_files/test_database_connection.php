<?php
/**
 * Comprehensive Database Connection Test
 * Access: http://localhost/helphup/api/test_database_connection.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/plain; charset=utf-8');

echo "========================================\n";
echo "DATABASE CONNECTION TEST\n";
echo "========================================\n\n";

// Test 1: Check if config.php exists
echo "1. Checking config.php...\n";
if (!file_exists('config.php')) {
    echo "   ❌ ERROR: config.php not found in current directory\n";
    echo "   Current directory: " . __DIR__ . "\n";
    exit;
}
echo "   ✅ config.php found\n\n";

// Test 2: Include config.php
echo "2. Loading config.php...\n";
try {
    require_once 'config.php';
    echo "   ✅ config.php loaded successfully\n\n";
} catch (Exception $e) {
    echo "   ❌ ERROR loading config.php: " . $e->getMessage() . "\n";
    exit;
}

// Test 3: Check if $conn variable exists
echo "3. Checking database connection variable...\n";
if (!isset($conn)) {
    echo "   ❌ ERROR: \$conn variable not set in config.php\n";
    exit;
}
echo "   ✅ \$conn variable exists\n\n";

// Test 4: Check if connection is active
echo "4. Testing database connection...\n";
if (!$conn) {
    echo "   ❌ ERROR: Database connection is NULL\n";
    exit;
}

// Test connection by pinging
if ($conn->ping()) {
    echo "   ✅ Database connection is active\n\n";
} else {
    echo "   ❌ ERROR: Database connection ping failed\n";
    exit;
}

// Test 5: Get database name
echo "5. Getting database information...\n";
$dbName = $conn->query("SELECT DATABASE()")->fetch_row()[0];
echo "   ✅ Connected to database: $dbName\n\n";

// Test 6: Check all required tables
echo "6. Checking required tables...\n";
$requiredTables = [
    'volunteer' => ['volunteer', 'volunteers'],
    'donor' => ['donor', 'donors'],
    'ngo' => ['ngo', 'ngos'],
    'admin' => ['admin', 'admins']
];

$foundTables = [];

foreach ($requiredTables as $type => $possibleNames) {
    $found = false;
    $actualName = null;
    
    foreach ($possibleNames as $tableName) {
        $check = $conn->query("SHOW TABLES LIKE '$tableName'");
        if ($check && $check->num_rows > 0) {
            $found = true;
            $actualName = $tableName;
            break;
        }
    }
    
    if ($found) {
        echo "   ✅ $type table found: $actualName\n";
        $foundTables[$type] = $actualName;
    } else {
        echo "   ❌ $type table NOT FOUND (checked: " . implode(', ', $possibleNames) . ")\n";
    }
}

echo "\n";

// Test 7: Check table structures
echo "7. Checking table structures...\n";
foreach ($foundTables as $type => $tableName) {
    echo "   --- $type ($tableName) ---\n";
    
    // Get primary key
    $pkResult = $conn->query("SHOW COLUMNS FROM `$tableName` WHERE `Key` = 'PRI'");
    if ($pkResult && $pkResult->num_rows > 0) {
        $pkRow = $pkResult->fetch_assoc();
        $pkColumn = $pkRow['Field'];
        echo "      Primary Key: $pkColumn\n";
    } else {
        echo "      ⚠️  No primary key found!\n";
    }
    
    // Get all columns
    $columns = $conn->query("SHOW COLUMNS FROM `$tableName`");
    $requiredColumns = ['email', 'password', 'full_name'];
    $foundColumns = [];
    
    if ($columns) {
        while ($col = $columns->fetch_assoc()) {
            $foundColumns[] = $col['Field'];
        }
        
        foreach ($requiredColumns as $reqCol) {
            if (in_array($reqCol, $foundColumns)) {
                echo "      ✅ $reqCol\n";
            } else {
                echo "      ❌ $reqCol MISSING\n";
            }
        }
    }
    
    // Count records
    $countResult = $conn->query("SELECT COUNT(*) as count FROM `$tableName`");
    if ($countResult) {
        $countRow = $countResult->fetch_assoc();
        echo "      Records: {$countRow['count']}\n";
    }
    
    echo "\n";
}

// Test 8: Test actual queries
echo "8. Testing actual login queries...\n";

// Test Volunteer Login Query
if (isset($foundTables['volunteer'])) {
    $volTable = $foundTables['volunteer'];
    $pkResult = $conn->query("SHOW COLUMNS FROM `$volTable` WHERE `Key` = 'PRI'");
    if ($pkResult && $pkResult->num_rows > 0) {
        $pkRow = $pkResult->fetch_assoc();
        $volIdColumn = $pkRow['Field'];
        
        $testQuery = "SELECT `$volIdColumn`, full_name, email, password FROM `$volTable` WHERE email = ?";
        $stmt = $conn->prepare($testQuery);
        if ($stmt) {
            echo "   ✅ Volunteer login query works\n";
            echo "      Query: $testQuery\n";
            $stmt->close();
        } else {
            echo "   ❌ Volunteer login query FAILED: " . $conn->error . "\n";
        }
    }
}

// Test Donor Login Query
if (isset($foundTables['donor'])) {
    $donorTable = $foundTables['donor'];
    $pkResult = $conn->query("SHOW COLUMNS FROM `$donorTable` WHERE `Key` = 'PRI'");
    if ($pkResult && $pkResult->num_rows > 0) {
        $pkRow = $pkResult->fetch_assoc();
        $donorIdColumn = $pkRow['Field'];
        
        $testQuery = "SELECT `$donorIdColumn`, full_name, email, password FROM `$donorTable` WHERE email = ?";
        $stmt = $conn->prepare($testQuery);
        if ($stmt) {
            echo "   ✅ Donor login query works\n";
            echo "      Query: $testQuery\n";
            $stmt->close();
        } else {
            echo "   ❌ Donor login query FAILED: " . $conn->error . "\n";
        }
    }
}

echo "\n";

// Test 9: Check config.php database settings
echo "9. Database configuration (from config.php)...\n";
if (defined('DB_HOST')) {
    echo "   Host: " . DB_HOST . "\n";
}
if (defined('DB_USER')) {
    echo "   User: " . DB_USER . "\n";
}
if (defined('DB_NAME')) {
    echo "   Database: " . DB_NAME . "\n";
}
echo "   Server Info: " . $conn->server_info . "\n";
echo "   Host Info: " . $conn->host_info . "\n";

echo "\n";

// Test 10: Test with sample data
echo "10. Testing with sample email...\n";
$testEmail = "test@example.com";

if (isset($foundTables['volunteer'])) {
    $volTable = $foundTables['volunteer'];
    $pkResult = $conn->query("SHOW COLUMNS FROM `$volTable` WHERE `Key` = 'PRI'");
    $volIdColumn = 'id';
    if ($pkResult && $pkResult->num_rows > 0) {
        $pkRow = $pkResult->fetch_assoc();
        $volIdColumn = $pkRow['Field'];
    }
    
    $stmt = $conn->prepare("SELECT `$volIdColumn`, email FROM `$volTable` WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $testEmail);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "   ✅ Volunteer: Found email in database (ID: {$row[$volIdColumn]})\n";
        } else {
            echo "   ⚠️  Volunteer: Email not found (this is OK if user doesn't exist)\n";
        }
        $stmt->close();
    }
}

if (isset($foundTables['donor'])) {
    $donorTable = $foundTables['donor'];
    $pkResult = $conn->query("SHOW COLUMNS FROM `$donorTable` WHERE `Key` = 'PRI'");
    $donorIdColumn = 'id';
    if ($pkResult && $pkResult->num_rows > 0) {
        $pkRow = $pkResult->fetch_assoc();
        $donorIdColumn = $pkRow['Field'];
    }
    
    $stmt = $conn->prepare("SELECT `$donorIdColumn`, email FROM `$donorTable` WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $testEmail);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "   ✅ Donor: Found email in database (ID: {$row[$donorIdColumn]})\n";
        } else {
            echo "   ⚠️  Donor: Email not found (this is OK if user doesn't exist)\n";
        }
        $stmt->close();
    }
}

echo "\n";
echo "========================================\n";
echo "TEST COMPLETE\n";
echo "========================================\n";

$conn->close();
?>

