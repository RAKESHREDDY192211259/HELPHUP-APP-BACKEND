<?php
/**
 * Test Donor Login Endpoint
 * Access: http://localhost/helphup/api/test_donor_login.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

require_once 'config.php';

echo "=== Donor Login Test ===\n\n";

// Test 1: Check if config.php exists
if (!file_exists('config.php')) {
    echo "❌ ERROR: config.php not found\n";
    exit;
}
echo "✅ config.php found\n";

// Test 2: Check database connection
if (!isset($conn) || !$conn) {
    echo "❌ ERROR: Database connection not established\n";
    exit;
}
echo "✅ Database connection established\n";

// Test 3: Check if donor table exists
$tableNames = ['donor', 'donors'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    echo "❌ ERROR: Donor table not found (checked: donor, donors)\n";
    exit;
}
echo "✅ Table found: $tableName\n";

// Test 4: Check table structure
$result = $conn->query("SHOW COLUMNS FROM `$tableName`");
if ($result) {
    echo "✅ Table columns:\n";
    while ($row = $result->fetch_assoc()) {
        echo "   - {$row['Field']} ({$row['Type']})\n";
    }
} else {
    echo "❌ ERROR: Could not get table structure\n";
}

// Test 5: Check if any donors exist
$result = $conn->query("SELECT COUNT(*) as count FROM `$tableName`");
if ($result) {
    $row = $result->fetch_assoc();
    echo "✅ Total donors: {$row['count']}\n";
} else {
    echo "❌ ERROR: Could not count donors\n";
}

// Test 6: Detect primary key column
$idColumn = 'id'; // default
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` WHERE `Key` = 'PRI'");
if ($checkId && $checkId->num_rows > 0) {
    $pkRow = $checkId->fetch_assoc();
    $idColumn = $pkRow['Field'];
    echo "✅ Primary key column detected: $idColumn\n";
} else {
    echo "⚠️  Could not detect primary key, using default: $idColumn\n";
}

// Test 7: Test query with sample email
$testEmail = "test@example.com";
$stmt = $conn->prepare("SELECT `$idColumn`, full_name, email FROM `$tableName` WHERE email = ?");
if ($stmt) {
    $stmt->bind_param("s", $testEmail);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo "✅ Query test successful (found test email)\n";
    } else {
        echo "⚠️  Query test successful (test email not found - this is OK)\n";
    }
    $stmt->close();
} else {
    echo "❌ ERROR: Could not prepare query: " . $conn->error . "\n";
}

// Test 7: Check donor_login.php file
if (file_exists('donor_login.php')) {
    echo "✅ donor_login.php file exists\n";
} else {
    echo "❌ ERROR: donor_login.php file not found\n";
}

echo "\n=== Test Complete ===\n";

$conn->close();
?>

