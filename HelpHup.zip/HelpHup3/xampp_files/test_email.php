<?php
/**
 * Test Email Sending
 * 
 * Usage: http://localhost/helphup/api/test_email.php?email=your-email@gmail.com
 */

require_once 'email_config.php';

// Get email from URL parameter or use default
$testEmail = $_GET['email'] ?? '';

if (empty($testEmail)) {
    die('
    <html>
    <head>
        <title>Email Test - HelpHup</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 40px; background: #f5f5f5; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #22C55E; }
            .form-group { margin: 20px 0; }
            label { display: block; margin-bottom: 5px; font-weight: bold; }
            input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
            button { background: #22C55E; color: white; padding: 12px 30px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; }
            button:hover { background: #16a34a; }
            .info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
            .error { background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px 0; color: #c62828; }
            .success { background: #e8f5e9; padding: 15px; border-radius: 5px; margin: 20px 0; color: #2e7d32; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📧 Test Email Sending</h1>
            <div class="info">
                <strong>Instructions:</strong><br>
                1. Enter your email address below<br>
                2. Click "Send Test Email"<br>
                3. Check your inbox for the OTP email
            </div>
            <form method="GET">
                <div class="form-group">
                    <label>Your Email Address:</label>
                    <input type="email" name="email" placeholder="your-email@gmail.com" required>
                </div>
                <button type="submit">Send Test Email</button>
            </form>
            <div class="info">
                <strong>Current Configuration:</strong><br>
                USE_PHP_MAIL: ' . (USE_PHP_MAIL ? 'true (PHP mail())' : 'false (SMTP)') . '<br>
                SMTP_HOST: ' . SMTP_HOST . '<br>
                SMTP_USERNAME: ' . (empty(SMTP_USERNAME) || SMTP_USERNAME === 'your-email@gmail.com' ? '<span style="color: red;">NOT CONFIGURED</span>' : SMTP_USERNAME) . '
            </div>
        </div>
    </body>
    </html>
    ');
}

// Generate test OTP
$testOTP = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Email Test Result - HelpHup</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 40px; background: #f5f5f5; }
        .container { max-width: 700px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #22C55E; }
        .info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .success { background: #e8f5e9; padding: 20px; border-radius: 5px; margin: 20px 0; color: #2e7d32; border-left: 4px solid #22C55E; }
        .error { background: #ffebee; padding: 20px; border-radius: 5px; margin: 20px 0; color: #c62828; border-left: 4px solid #f44336; }
        .otp-box { background: #22C55E; color: white; padding: 20px; text-align: center; font-size: 32px; font-weight: bold; margin: 20px 0; border-radius: 5px; }
        .config-info { background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; font-size: 14px; }
        code { background: #f5f5f5; padding: 2px 6px; border-radius: 3px; }
        a { color: #22C55E; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📧 Email Test Result</h1>
        
        <div class="info">
            <strong>Test Details:</strong><br>
            Email: <strong><?php echo htmlspecialchars($testEmail); ?></strong><br>
            OTP: <strong><?php echo $testOTP; ?></strong><br>
            Time: <?php echo date('Y-m-d H:i:s'); ?>
        </div>

        <?php
        // Try to send email
        echo "<h2>Sending Email...</h2>";
        $result = sendOTPEmail($testEmail, $testOTP, 'Test User');
        
        if ($result['success']) {
            echo '<div class="success">';
            echo '<h2>✅ SUCCESS! Email Sent Successfully</h2>';
            echo '<p>' . htmlspecialchars($result['message']) . '</p>';
            echo '<div class="otp-box">OTP: ' . $testOTP . '</div>';
            echo '<p><strong>Next Steps:</strong></p>';
            echo '<ol>';
            echo '<li>Check your inbox: <strong>' . htmlspecialchars($testEmail) . '</strong></li>';
            echo '<li>Check your <strong>Spam/Junk</strong> folder if not in inbox</li>';
            echo '<li>Look for email with subject: "Your Password Reset OTP - HelpHup"</li>';
            echo '</ol>';
            echo '</div>';
        } else {
            echo '<div class="error">';
            echo '<h2>❌ FAILED - Email Not Sent</h2>';
            echo '<p><strong>Error:</strong> ' . htmlspecialchars($result['message']) . '</p>';
            echo '</div>';
            
            echo '<div class="config-info">';
            echo '<h3>🔧 Troubleshooting Steps:</h3>';
            
            if (USE_PHP_MAIL) {
                echo '<p><strong>Issue:</strong> Using PHP mail() which doesn\'t work on XAMPP.</p>';
                echo '<p><strong>Solution:</strong></p>';
                echo '<ol>';
                echo '<li>Open <code>email_config.php</code></li>';
                echo '<li>Change <code>USE_PHP_MAIL</code> to <code>false</code></li>';
                echo '<li>Configure Gmail SMTP credentials</li>';
                echo '<li>Install PHPMailer library</li>';
                echo '<li>See <code>EMAIL_SETUP_INSTRUCTIONS.md</code> for detailed steps</li>';
                echo '</ol>';
            } else {
                $phpmailerPath = __DIR__ . '/PHPMailer/src/Exception.php';
                if (!file_exists($phpmailerPath)) {
                    echo '<p><strong>Issue:</strong> PHPMailer not found.</p>';
                    echo '<p><strong>Solution:</strong></p>';
                    echo '<ol>';
                    echo '<li>Download PHPMailer from: <a href="https://github.com/PHPMailer/PHPMailer/archive/refs/heads/master.zip" target="_blank">GitHub</a></li>';
                    echo '<li>Extract and copy <code>PHPMailer</code> folder to: <code>C:\\xampp\\htdocs\\helphup\\api\\PHPMailer\\</code></li>';
                    echo '</ol>';
                } else {
                    echo '<p><strong>Issue:</strong> SMTP authentication failed.</p>';
                    echo '<p><strong>Solution:</strong></p>';
                    echo '<ol>';
                    echo '<li>Check Gmail credentials in <code>email_config.php</code></li>';
                    echo '<li>Make sure you\'re using Gmail App Password (not regular password)</li>';
                    echo '<li>Verify 2-Step Verification is enabled on your Gmail account</li>';
                    echo '<li>Generate a new App Password if needed</li>';
                    echo '</ol>';
                }
            }
            echo '</div>';
        }
        ?>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <a href="test_email.php">← Test Another Email</a> | 
            <a href="EMAIL_SETUP_INSTRUCTIONS.md" target="_blank">View Setup Instructions</a>
        </div>
    </div>
</body>
</html>

