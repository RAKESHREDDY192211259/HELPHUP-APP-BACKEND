<?php
/**
 * Simple test script to check get_all_ngo_requests.php
 * This will show the actual error
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

echo "<h2>Testing get_all_ngo_requests.php</h2>";

// Include the actual file but capture output
ob_start();
try {
    include 'get_all_ngo_requests.php';
    $output = ob_get_clean();
    echo "<p style='color:green;'>✓ Script executed successfully</p>";
    echo "<h3>Output:</h3>";
    echo "<pre>" . htmlspecialchars($output) . "</pre>";
} catch (Exception $e) {
    ob_end_clean();
    echo "<p style='color:red;'>✗ Error: " . $e->getMessage() . "</p>";
    echo "<p>File: " . $e->getFile() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
    echo "<h3>Stack Trace:</h3>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
} catch (Error $e) {
    ob_end_clean();
    echo "<p style='color:red;'>✗ Fatal Error: " . $e->getMessage() . "</p>";
    echo "<p>File: " . $e->getFile() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
}
?>

