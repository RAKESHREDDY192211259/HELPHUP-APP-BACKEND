<?php
require_once 'config.php';

// Test script to check if get_ngo_profile.php works
// Usage: Call this from browser or Postman with ngo_id parameter

$ngo_id = $_GET['ngo_id'] ?? $_POST['ngo_id'] ?? '';

if (empty($ngo_id)) {
    echo json_encode(array(
        'status' => false,
        'message' => 'Please provide ngo_id as parameter',
        'example' => 'test_get_ngo_profile.php?ngo_id=1'
    ));
    exit;
}

// Detect which column name the NGO table uses (id or ngo_id)
$ngoIdColumn = 'ngo_id'; // default
$tableNames = ['ngo', 'ngos'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    echo json_encode(array(
        'status' => false,
        'message' => 'Database error: NGO table not found.'
    ));
    exit;
}

// Check which column exists - id or ngo_id
$checkNgoId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'ngo_id'");
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");

if ($checkId && $checkId->num_rows > 0) {
    $ngoIdColumn = 'id';
} elseif ($checkNgoId && $checkNgoId->num_rows > 0) {
    $ngoIdColumn = 'ngo_id';
}

// Query database to get full profile
$stmt = $conn->prepare("SELECT $ngoIdColumn, full_name, phone, email, address, org_name, reg_number, reg_proof_file FROM `$tableName` WHERE $ngoIdColumn = ?");
$stmt->bind_param("i", $ngo_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(array(
        'status' => true,
        'message' => 'Profile data retrieved successfully',
        'data' => array(
            'ngo_id' => $row[$ngoIdColumn] ?? 0,
            'full_name' => isset($row['full_name']) && $row['full_name'] !== null ? $row['full_name'] : '',
            'phone' => isset($row['phone']) && $row['phone'] !== null ? $row['phone'] : '',
            'email' => isset($row['email']) && $row['email'] !== null ? $row['email'] : '',
            'address' => isset($row['address']) && $row['address'] !== null ? $row['address'] : '',
            'org_name' => isset($row['org_name']) && $row['org_name'] !== null ? $row['org_name'] : '',
            'reg_number' => isset($row['reg_number']) && $row['reg_number'] !== null ? $row['reg_number'] : '',
            'reg_proof_file' => isset($row['reg_proof_file']) && $row['reg_proof_file'] !== null ? $row['reg_proof_file'] : null
        ),
        'debug' => array(
            'table_name' => $tableName,
            'id_column' => $ngoIdColumn,
            'raw_data' => $row
        )
    ), JSON_PRETTY_PRINT);
} else {
    echo json_encode(array(
        'status' => false,
        'message' => 'NGO not found',
        'debug' => array(
            'table_name' => $tableName,
            'id_column' => $ngoIdColumn,
            'ngo_id_searched' => $ngo_id
        )
    ), JSON_PRETTY_PRINT);
}

$stmt->close();
$conn->close();
?>

