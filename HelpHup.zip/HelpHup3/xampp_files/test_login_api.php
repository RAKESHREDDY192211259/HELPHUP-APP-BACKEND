<?php
// Test script to verify login API response format
header('Content-Type: text/html; charset=utf-8');

echo "<h2>Login API Response Format Test</h2>";
echo "<p>This script tests the login API endpoints to verify they return the correct JSON format.</p>";

// Test Volunteer Login
echo "<h3>1. Volunteer Login Response Format:</h3>";
echo "<p>Expected: <code>{ status: true, message: '...', volunteer: { id, name, email } }</code></p>";

$testData = json_encode([
    'email' => 'test@example.com',
    'password' => 'test123'
]);

// Simulate the response format
echo "<p>Current format (after fix):</p>";
$response = [
    'status' => true,
    'message' => 'Login successful',
    'volunteer' => [
        'id' => 1,
        'name' => 'Test User',
        'email' => 'test@example.com'
    ]
];
echo "<pre>" . json_encode($response, JSON_PRETTY_PRINT) . "</pre>";

// Test Donor Login
echo "<h3>2. Donor Login Response Format:</h3>";
echo "<p>Expected: <code>{ status: true, message: '...', donor_id: 1, full_name: '...' }</code></p>";

$donorResponse = [
    'status' => true,
    'message' => 'Login successful',
    'donor_id' => 1,
    'full_name' => 'Test Donor'
];
echo "<p>Current format (after fix):</p>";
echo "<pre>" . json_encode($donorResponse, JSON_PRETTY_PRINT) . "</pre>";

echo "<hr>";
echo "<p><strong>Note:</strong> The key fix was changing from nested data structure to root-level fields.</p>";
echo "<p><strong>Before:</strong> <code>{ status, message, data: { volunteer: {...} } }</code></p>";
echo "<p><strong>After:</strong> <code>{ status, message, volunteer: {...} }</code></p>";
?>

