<?php
// Direct test of login API to verify it works
require_once 'config.php';

header('Content-Type: application/json');

// Test data
$testEmail = 'rakeshreddyk1259.sse@saveetha.com';
$testPassword = '123';

// Simulate the login process
$tableNames = ['volunteer', 'volunteers'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    echo json_encode(['error' => 'Table not found']);
    exit;
}

$stmt = $conn->prepare("SELECT id, full_name, email, password, CHAR_LENGTH(password) as password_length FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
$stmt->bind_param("s", $testEmail);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    $response = [
        'found' => true,
        'table' => $tableName,
        'email_in_db' => $row['email'],
        'password_length' => $row['password_length'],
        'password_verify' => password_verify($testPassword, $row['password']) ? 'YES' : 'NO',
        'test_response' => null
    ];
    
    if (password_verify($testPassword, $row['password'])) {
        $response['test_response'] = [
            'status' => true,
            'message' => 'Login successful',
            'volunteer' => [
                'id' => (int)$row['id'],
                'name' => $row['full_name'],
                'email' => $row['email']
            ]
        ];
    }
    
    echo json_encode($response, JSON_PRETTY_PRINT);
} else {
    echo json_encode(['error' => 'Email not found']);
}

$stmt->close();
$conn->close();
?>

