<?php
/**
 * Test Login Email Matching
 * Access: http://localhost/helphup/api/test_login_emails.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

require_once 'config.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Email Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        h1 { color: #333; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .info { background: #e3f2fd; padding: 10px; border-left: 4px solid #2196F3; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
        input { padding: 8px; width: 300px; margin: 5px 0; }
        button { padding: 10px 20px; background: #4CAF50; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Test Login Email Matching</h1>
        
        <form method="POST">
            <h2>Test Email Lookup</h2>
            <p>
                <label>Email to test:</label><br>
                <input type="email" name="test_email" placeholder="Enter email address" required>
            </p>
            <button type="submit">Test Email</button>
        </form>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_email'])) {
            $testEmail = trim($_POST['test_email']);
            
            echo "<h2>Results for: $testEmail</h2>";
            
            // Test NGO
            echo "<h3>NGO Login</h3>";
            $ngoTables = ['ngo', 'ngos'];
            $ngoFound = false;
            
            foreach ($ngoTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $ngoTable = $table;
                    $ngoFound = true;
                    
                    // Get primary key
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $ngoIdColumn = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $pkRow = $pkResult->fetch_assoc();
                        $ngoIdColumn = $pkRow['Field'];
                    }
                    
                    // Test case-sensitive
                    $stmt1 = $conn->prepare("SELECT `$ngoIdColumn`, email, full_name FROM `$table` WHERE email = ?");
                    $stmt1->bind_param("s", $testEmail);
                    $stmt1->execute();
                    $result1 = $stmt1->get_result();
                    $caseSensitive = $result1->num_rows > 0;
                    $stmt1->close();
                    
                    // Test case-insensitive
                    $stmt2 = $conn->prepare("SELECT `$ngoIdColumn`, email, full_name FROM `$table` WHERE LOWER(email) = LOWER(?)");
                    $stmt2->bind_param("s", $testEmail);
                    $stmt2->execute();
                    $result2 = $stmt2->get_result();
                    $caseInsensitive = $result2->num_rows > 0;
                    
                    if ($caseInsensitive) {
                        $row = $result2->fetch_assoc();
                        echo "<p class='success'>✅ Found in $table</p>";
                        echo "<div class='info'>";
                        echo "<strong>ID:</strong> {$row[$ngoIdColumn]}<br>";
                        echo "<strong>Email in DB:</strong> {$row['email']}<br>";
                        echo "<strong>Name:</strong> {$row['full_name']}<br>";
                        echo "<strong>Case-sensitive match:</strong> " . ($caseSensitive ? "✅ Yes" : "❌ No") . "<br>";
                        echo "<strong>Case-insensitive match:</strong> ✅ Yes<br>";
                        echo "</div>";
                    } else {
                        echo "<p class='error'>❌ Email not found in $table</p>";
                    }
                    $stmt2->close();
                    break;
                }
            }
            
            if (!$ngoFound) {
                echo "<p class='error'>❌ NGO table not found</p>";
            }
            
            // Test Volunteer
            echo "<h3>Volunteer Login</h3>";
            $volTables = ['volunteer', 'volunteers'];
            $volFound = false;
            
            foreach ($volTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $volTable = $table;
                    $volFound = true;
                    
                    // Get primary key
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $volIdColumn = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $pkRow = $pkResult->fetch_assoc();
                        $volIdColumn = $pkRow['Field'];
                    }
                    
                    // Test case-insensitive
                    $stmt = $conn->prepare("SELECT `$volIdColumn`, email, full_name FROM `$table` WHERE LOWER(email) = LOWER(?)");
                    $stmt->bind_param("s", $testEmail);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        echo "<p class='success'>✅ Found in $table</p>";
                        echo "<div class='info'>";
                        echo "<strong>ID:</strong> {$row[$volIdColumn]}<br>";
                        echo "<strong>Email in DB:</strong> {$row['email']}<br>";
                        echo "<strong>Name:</strong> {$row['full_name']}<br>";
                        echo "</div>";
                    } else {
                        echo "<p class='error'>❌ Email not found in $table</p>";
                    }
                    $stmt->close();
                    break;
                }
            }
            
            if (!$volFound) {
                echo "<p class='error'>❌ Volunteer table not found</p>";
            }
            
            // Test Donor
            echo "<h3>Donor Login</h3>";
            $donorTables = ['donor', 'donors'];
            $donorFound = false;
            
            foreach ($donorTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $donorTable = $table;
                    $donorFound = true;
                    
                    // Get primary key
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $donorIdColumn = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $pkRow = $pkResult->fetch_assoc();
                        $donorIdColumn = $pkRow['Field'];
                    }
                    
                    // Test case-insensitive
                    $stmt = $conn->prepare("SELECT `$donorIdColumn`, email, full_name FROM `$table` WHERE LOWER(email) = LOWER(?)");
                    $stmt->bind_param("s", $testEmail);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        echo "<p class='success'>✅ Found in $table</p>";
                        echo "<div class='info'>";
                        echo "<strong>ID:</strong> {$row[$donorIdColumn]}<br>";
                        echo "<strong>Email in DB:</strong> {$row['email']}<br>";
                        echo "<strong>Name:</strong> {$row['full_name']}<br>";
                        echo "</div>";
                    } else {
                        echo "<p class='error'>❌ Email not found in $table</p>";
                    }
                    $stmt->close();
                    break;
                }
            }
            
            if (!$donorFound) {
                echo "<p class='error'>❌ Donor table not found</p>";
            }
            
            // Show all emails in database for reference
            echo "<h3>All Emails in Database (for reference)</h3>";
            echo "<table>";
            echo "<tr><th>Type</th><th>Table</th><th>ID</th><th>Email</th><th>Name</th></tr>";
            
            // NGO emails
            foreach ($ngoTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $idCol = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $idCol = $pkResult->fetch_assoc()['Field'];
                    }
                    $result = $conn->query("SELECT `$idCol`, email, full_name FROM `$table` LIMIT 10");
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>NGO</td><td>$table</td><td>{$row[$idCol]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td></tr>";
                    }
                    break;
                }
            }
            
            // Volunteer emails
            foreach ($volTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $idCol = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $idCol = $pkResult->fetch_assoc()['Field'];
                    }
                    $result = $conn->query("SELECT `$idCol`, email, full_name FROM `$table` LIMIT 10");
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>Volunteer</td><td>$table</td><td>{$row[$idCol]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td></tr>";
                    }
                    break;
                }
            }
            
            // Donor emails
            foreach ($donorTables as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    $idCol = 'id';
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $idCol = $pkResult->fetch_assoc()['Field'];
                    }
                    $result = $conn->query("SELECT `$idCol`, email, full_name FROM `$table` LIMIT 10");
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>Donor</td><td>$table</td><td>{$row[$idCol]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td></tr>";
                    }
                    break;
                }
            }
            
            echo "</table>";
        }
        
        $conn->close();
        ?>
    </div>
</body>
</html>

