<?php
// Test the get_ngo_profile.php endpoint
require_once 'config.php';

// First, get a sample NGO ID
$ngoQuery = $conn->query("SELECT ngo_id FROM ngo LIMIT 1");
if ($ngoQuery && $ngoQuery->num_rows > 0) {
    $ngoId = $ngoQuery->fetch_assoc()['ngo_id'];
    echo "Testing with NGO ID: $ngoId\n";
    
    // Simulate the API request
    $_SERVER['REQUEST_METHOD'] = 'POST';
    $testData = ['ngo_id' => $ngoId];
    
    // Create a temporary file to simulate POST data
    $tempFile = tempnam(sys_get_temp_dir(), 'php_input');
    file_put_contents($tempFile, json_encode($testData));
    
    // Backup original php://input
    $originalInput = 'php://input';
    
    // Override php://input for testing
    $_POST['ngo_id'] = $ngoId;
    
    // Call the get_ngo_profile logic
    $json = json_encode($testData);
    $data = json_decode($json, true);
    
    $ngo_id = $data['ngo_id'] ?? '';
    
    if (empty($ngo_id)) {
        echo "ERROR: NGO ID is required\n";
    } else {
        echo "NGO ID received: $ngo_id\n";
        
        // Detect which column name the NGO table uses (id or ngo_id)
        $ngoIdColumn = 'ngo_id'; // default
        $tableNames = ['ngo', 'ngos'];
        $tableName = null;
        
        foreach ($tableNames as $table) {
            $check = $conn->query("SHOW TABLES LIKE '$table'");
            if ($check && $check->num_rows > 0) {
                $tableName = $table;
                echo "Found table: $tableName\n";
                break;
            }
        }
        
        if (!$tableName) {
            echo "ERROR: Database error: NGO table not found.\n";
        } else {
            // Check which column exists - id or ngo_id
            $checkNgoId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'ngo_id'");
            $checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");
            
            if ($checkId && $checkId->num_rows > 0) {
                $ngoIdColumn = 'id';
                echo "Using column: $ngoIdColumn\n";
            } elseif ($checkNgoId && $checkNgoId->num_rows > 0) {
                $ngoIdColumn = 'ngo_id';
                echo "Using column: $ngoIdColumn\n";
            }
            
            // Query database to get full profile
            $sql = "SELECT $ngoIdColumn, full_name, phone, email, address, org_name, reg_number, reg_proof_file FROM `$tableName` WHERE $ngoIdColumn = ?";
            echo "SQL Query: $sql\n";
            echo "Parameter: $ngo_id\n";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $ngo_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "SUCCESS: NGO found\n";
                echo "Data: " . json_encode($row, JSON_PRETTY_PRINT) . "\n";
                
                // Format response like the API would
                $response = array(
                    'ngo_id' => $row[$ngoIdColumn] ?? 0,
                    'full_name' => isset($row['full_name']) && $row['full_name'] !== null ? $row['full_name'] : '',
                    'phone' => isset($row['phone']) && $row['phone'] !== null ? $row['phone'] : '',
                    'email' => isset($row['email']) && $row['email'] !== null ? $row['email'] : '',
                    'address' => isset($row['address']) && $row['address'] !== null ? $row['address'] : '',
                    'org_name' => isset($row['org_name']) && $row['org_name'] !== null ? $row['org_name'] : '',
                    'reg_number' => isset($row['reg_number']) && $row['reg_number'] !== null ? $row['reg_number'] : '',
                    'reg_proof_file' => isset($row['reg_proof_file']) && $row['reg_proof_file'] !== null ? $row['reg_proof_file'] : null
                );
                
                echo "API Response format:\n";
                echo json_encode(array(
                    'status' => true,
                    'message' => 'Profile data retrieved successfully',
                    'data' => $response
                ), JSON_PRETTY_PRINT) . "\n";
                
            } else {
                echo "ERROR: NGO not found with ID $ngo_id\n";
            }
            
            $stmt->close();
        }
    }
    
    unlink($tempFile);
} else {
    echo "ERROR: No NGO records found in database\n";
}

$conn->close();
?>
