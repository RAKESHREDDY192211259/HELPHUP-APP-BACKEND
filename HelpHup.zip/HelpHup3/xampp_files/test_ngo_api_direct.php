<?php
/**
 * DIRECT TEST - Copy this to: C:\xampp\htdocs\helphup\api\
 * Then open: http://localhost/helphup/api/test_ngo_api_direct.php
 * 
 * This tests the exact same logic as get_all_ngo_requests.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

echo "<h1>Direct NGO API Test</h1>";
echo "<hr>";

require_once 'config.php';

if (!isset($conn) || !$conn) {
    die("❌ Database connection failed");
}

echo "✅ Connected to database<br><br>";

// Find table
$tableName = null;
$possibleTables = ['ngoraisehelp', 'ngo_help_requests', 'ngohelprequests'];
foreach ($possibleTables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        echo "✅ Found table: <strong>$table</strong><br>";
        break;
    }
}

if (!$tableName) {
    die("❌ No table found!");
}

// Check column
$idColumn = ($tableName == 'ngoraisehelp') ? 'id' : 'request_id';
echo "Using ID column: <strong>$idColumn</strong><br><br>";

// Simple query WITHOUT JOIN first
$sql = "SELECT 
    $idColumn as request_id,
    ngo_id,
    request_title,
    category,
    urgency_level,
    required_amount,
    date_needed,
    contact_number,
    description,
    created_at
FROM `$tableName`
ORDER BY created_at DESC
LIMIT 10";

echo "<h2>SQL Query:</h2>";
echo "<pre>" . htmlspecialchars($sql) . "</pre>";

$result = $conn->query($sql);

if (!$result) {
    echo "<p style='color:red;'>❌ Query failed: " . $conn->error . "</p>";
} else {
    echo "<p style='color:green;'>✅ Query successful! Found " . $result->num_rows . " rows</p>";
    
    echo "<h2>Data:</h2>";
    echo "<table border='1' cellpadding='5' style='border-collapse:collapse;'>";
    $first = true;
    while ($row = $result->fetch_assoc()) {
        if ($first) {
            echo "<tr>";
            foreach (array_keys($row) as $key) {
                echo "<th>$key</th>";
            }
            echo "</tr>";
            $first = false;
        }
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>" . htmlspecialchars(substr($value, 0, 50)) . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<hr>";
    echo "<h2>JSON Output (Same as API):</h2>";
    
    // Reset result
    $result = $conn->query($sql);
    $requests = array();
    while ($row = $result->fetch_assoc()) {
        $requests[] = array(
            'request_id' => (int)$row['request_id'],
            'ngo_id' => (int)$row['ngo_id'],
            'ngo_name' => 'NGO',
            'org_name' => 'Organization',
            'request_title' => $row['request_title'],
            'category' => $row['category'],
            'urgency_level' => $row['urgency_level'],
            'required_amount' => (string)$row['required_amount'],
            'date_needed' => $row['date_needed'],
            'contact_number' => $row['contact_number'],
            'description' => $row['description'],
            'status' => 'pending',
            'created_at' => $row['created_at'],
            'request_type' => 'ngo'
        );
    }
    
    $response = array(
        'status' => true,
        'message' => 'Requests fetched successfully',
        'data' => $requests
    );
    
    echo "<pre>" . json_encode($response, JSON_PRETTY_PRINT) . "</pre>";
    
    echo "<hr>";
    echo "<h2>Test API Endpoint:</h2>";
    echo "<p><a href='get_all_ngo_requests.php' target='_blank'>Open get_all_ngo_requests.php</a></p>";
    echo "<p>Should show JSON like above (but without HTML formatting)</p>";
}

$conn->close();
?>

