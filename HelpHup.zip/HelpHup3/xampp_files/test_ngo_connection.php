<?php
require_once 'config.php';

// Test database connection
echo "Testing database connection...\n";

if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
    exit();
}
echo "Database connection: SUCCESS\n";

// Check if NGO table exists
echo "Checking if NGO table exists...\n";
$checkTable = $conn->query("SHOW TABLES LIKE 'ngo'");
if ($checkTable && $checkTable->num_rows > 0) {
    echo "NGO table: EXISTS\n";
} else {
    echo "NGO table: NOT FOUND\n";
    exit();
}

// Check table structure
echo "Checking NGO table structure...\n";
$structure = $conn->query("DESCRIBE ngo");
if ($structure) {
    while ($row = $structure->fetch_assoc()) {
        echo "- " . $row['Field'] . " (" . $row['Type'] . ")\n";
    }
}

// Check if there are any NGO records
echo "Checking NGO records...\n";
$count = $conn->query("SELECT COUNT(*) as count FROM ngo");
if ($count) {
    $result = $count->fetch_assoc();
    echo "Total NGO records: " . $result['count'] . "\n";
    
    if ($result['count'] > 0) {
        echo "Sample NGO records:\n";
        $ngos = $conn->query("SELECT ngo_id, full_name, email, org_name FROM ngo LIMIT 3");
        while ($ngo = $ngos->fetch_assoc()) {
            echo "- ID: " . $ngo['ngo_id'] . ", Name: " . $ngo['full_name'] . ", Email: " . $ngo['email'] . ", Org: " . $ngo['org_name'] . "\n";
        }
    } else {
        echo "No NGO records found. Creating sample NGO...\n";
        
        // Create a sample NGO record
        $password = password_hash('password123', PASSWORD_DEFAULT);
        $insert = $conn->prepare("INSERT INTO ngo (full_name, phone, email, address, org_name, reg_number, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $insert->bind_param("sssssss", 
            $fullName, $phone, $email, $address, $orgName, $regNumber, $password
        );
        
        $fullName = "Test NGO Organization";
        $phone = "9876543210";
        $email = "test@ngo.com";
        $address = "123 NGO Street, Test City";
        $orgName = "Test NGO Foundation";
        $regNumber = "NGO-TEST-001";
        
        if ($insert->execute()) {
            echo "Sample NGO created successfully with ID: " . $conn->insert_id . "\n";
        } else {
            echo "Error creating sample NGO: " . $conn->error . "\n";
        }
        $insert->close();
    }
}

$conn->close();
?>
