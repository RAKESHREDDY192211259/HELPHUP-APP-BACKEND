<?php
/**
 * Direct NGO Login Test
 * Tests the exact query that login uses
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

require_once 'config.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Direct NGO Login Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .code { background: #f5f5f5; padding: 10px; border-left: 3px solid #4CAF50; margin: 10px 0; font-family: monospace; }
        input { padding: 8px; width: 300px; margin: 5px 0; }
        button { padding: 10px 20px; background: #4CAF50; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Direct NGO Login Test</h1>
        
        <form method="POST">
            <p>
                <label>Email:</label><br>
                <input type="email" name="email" placeholder="Enter email" value="<?php echo $_POST['email'] ?? 'jayanthreddi135@gmail.com'; ?>" required>
            </p>
            <button type="submit">Test Login Query</button>
        </form>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
            $testEmail = trim($_POST['email']);
            
            echo "<h2>Testing: $testEmail</h2>";
            
            // Check which table exists
            $tableNames = ['ngos', 'ngo'];
            $tableName = null;
            $idColumn = 'id';
            
            foreach ($tableNames as $table) {
                $check = $conn->query("SHOW TABLES LIKE '$table'");
                if ($check && $check->num_rows > 0) {
                    echo "<div class='success'>✅ Table found: $table</div>";
                    
                    // Get primary key
                    $pkResult = $conn->query("SHOW COLUMNS FROM `$table` WHERE `Key` = 'PRI'");
                    if ($pkResult && $pkResult->num_rows > 0) {
                        $pkRow = $pkResult->fetch_assoc();
                        $idColumn = $pkRow['Field'];
                        echo "<div class='success'>✅ Primary Key: $idColumn</div>";
                    }
                    
                    // Show all emails first
                    echo "<h3>All Emails in $table:</h3>";
                    $allEmails = $conn->query("SELECT `$idColumn`, email, full_name FROM `$table` LIMIT 20");
                    echo "<table border='1' cellpadding='5'>";
                    echo "<tr><th>ID</th><th>Email</th><th>Name</th><th>Matches?</th></tr>";
                    while ($row = $allEmails->fetch_assoc()) {
                        $matches = (strtolower(trim($row['email'])) === strtolower(trim($testEmail))) ? "✅ YES" : "❌ NO";
                        echo "<tr><td>{$row[$idColumn]}</td><td>{$row['email']}</td><td>{$row['full_name']}</td><td>$matches</td></tr>";
                    }
                    echo "</table>";
                    
                    // Test the exact query from login
                    echo "<h3>Testing Login Query:</h3>";
                    $query = "SELECT `$idColumn`, full_name, email, password FROM `$table` WHERE LOWER(TRIM(email)) = LOWER(TRIM(?))";
                    echo "<div class='code'>Query: $query</div>";
                    echo "<div class='code'>Email: '$testEmail'</div>";
                    
                    $stmt = $conn->prepare($query);
                    if ($stmt) {
                        $stmt->bind_param("s", $testEmail);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            echo "<div class='success'>✅ EMAIL FOUND!</div>";
                            echo "<div class='code'>";
                            echo "ID: {$row[$idColumn]}<br>";
                            echo "Email: {$row['email']}<br>";
                            echo "Name: {$row['full_name']}<br>";
                            echo "Password Hash: " . substr($row['password'], 0, 30) . "...<br>";
                            echo "</div>";
                        } else {
                            echo "<div class='error'>❌ EMAIL NOT FOUND</div>";
                            
                            // Try alternative queries
                            echo "<h3>Trying Alternative Queries:</h3>";
                            
                            // Test 1: Without TRIM
                            $stmt2 = $conn->prepare("SELECT `$idColumn`, email FROM `$table` WHERE LOWER(email) = LOWER(?)");
                            $stmt2->bind_param("s", $testEmail);
                            $stmt2->execute();
                            $result2 = $stmt2->get_result();
                            echo "<div>Without TRIM: " . ($result2->num_rows > 0 ? "✅ Found" : "❌ Not Found") . "</div>";
                            $stmt2->close();
                            
                            // Test 2: Exact match
                            $stmt3 = $conn->prepare("SELECT `$idColumn`, email FROM `$table` WHERE email = ?");
                            $stmt3->bind_param("s", $testEmail);
                            $stmt3->execute();
                            $result3 = $stmt3->get_result();
                            echo "<div>Exact match: " . ($result3->num_rows > 0 ? "✅ Found" : "❌ Not Found") . "</div>";
                            $stmt3->close();
                            
                            // Test 3: LIKE
                            $likeEmail = "%" . $testEmail . "%";
                            $stmt4 = $conn->prepare("SELECT `$idColumn`, email FROM `$table` WHERE email LIKE ?");
                            $stmt4->bind_param("s", $likeEmail);
                            $stmt4->execute();
                            $result4 = $stmt4->get_result();
                            echo "<div>LIKE match: " . ($result4->num_rows > 0 ? "✅ Found" : "❌ Not Found") . "</div>";
                            if ($result4->num_rows > 0) {
                                while ($r = $result4->fetch_assoc()) {
                                    echo "<div class='code'>Found: {$r['email']}</div>";
                                }
                            }
                            $stmt4->close();
                        }
                        $stmt->close();
                    } else {
                        echo "<div class='error'>❌ Query prepare failed: " . $conn->error . "</div>";
                    }
                    
                    $tableName = $table;
                    break;
                }
            }
            
            if (!$tableName) {
                echo "<div class='error'>❌ No NGO table found</div>";
            }
        }
        
        $conn->close();
        ?>
    </div>
</body>
</html>

