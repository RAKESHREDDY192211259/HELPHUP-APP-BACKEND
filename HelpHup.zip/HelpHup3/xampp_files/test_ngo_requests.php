<?php
/**
 * Test script to check NGO requests endpoint
 * Use this to debug the get_all_ngo_requests.php endpoint
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

echo "<h2>Testing NGO Requests Endpoint</h2>";

// Check table existence
$tables = ['ngoraisehelp', 'ngo_help_requests'];
$foundTable = null;

foreach ($tables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $foundTable = $table;
        echo "<p>✓ Found table: <strong>$table</strong></p>";
        break;
    }
}

if (!$foundTable) {
    echo "<p style='color:red;'>✗ No NGO table found!</p>";
    exit;
}

// Check columns
echo "<h3>Table Structure:</h3>";
$columns = $conn->query("SHOW COLUMNS FROM `$foundTable`");
echo "<table border='1'><tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
while ($col = $columns->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $col['Field'] . "</td>";
    echo "<td>" . $col['Type'] . "</td>";
    echo "<td>" . $col['Null'] . "</td>";
    echo "<td>" . $col['Key'] . "</td>";
    echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
    echo "</tr>";
}
echo "</table>";

// Check admin_status column
$checkAdminStatus = $conn->query("SHOW COLUMNS FROM `$foundTable` LIKE 'admin_status'");
$hasAdminStatus = $checkAdminStatus && $checkAdminStatus->num_rows > 0;
echo "<p>admin_status column exists: " . ($hasAdminStatus ? "✓ YES" : "✗ NO") . "</p>";

// Check status column
$checkStatus = $conn->query("SHOW COLUMNS FROM `$foundTable` LIKE 'status'");
$hasStatus = $checkStatus && $checkStatus->num_rows > 0;
echo "<p>status column exists: " . ($hasStatus ? "✓ YES" : "✗ NO") . "</p>";

// Count requests by status
echo "<h3>Request Counts:</h3>";
$idColumn = ($foundTable == 'ngoraisehelp') ? 'id' : 'request_id';

if ($hasAdminStatus && $hasStatus) {
    $counts = $conn->query("SELECT admin_status, status, COUNT(*) as count FROM `$foundTable` GROUP BY admin_status, status");
    echo "<table border='1'><tr><th>admin_status</th><th>status</th><th>Count</th></tr>";
    while ($row = $counts->fetch_assoc()) {
        echo "<tr><td>" . $row['admin_status'] . "</td><td>" . $row['status'] . "</td><td>" . $row['count'] . "</td></tr>";
    }
    echo "</table>";
    
    // Test the WHERE clause
    echo "<h3>Testing WHERE Clause:</h3>";
    $testSql = "SELECT COUNT(*) as count FROM `$foundTable` WHERE admin_status = 'accepted' AND (status = 'approved' OR status = 'active')";
    echo "<p>SQL: <code>$testSql</code></p>";
    $result = $conn->query($testSql);
    if ($result) {
        $row = $result->fetch_assoc();
        echo "<p>✓ Approved requests count: <strong>" . $row['count'] . "</strong></p>";
    } else {
        echo "<p style='color:red;'>✗ SQL Error: " . $conn->error . "</p>";
    }
} elseif ($hasAdminStatus) {
    $counts = $conn->query("SELECT admin_status, COUNT(*) as count FROM `$foundTable` GROUP BY admin_status");
    echo "<table border='1'><tr><th>admin_status</th><th>Count</th></tr>";
    while ($row = $counts->fetch_assoc()) {
        echo "<tr><td>" . $row['admin_status'] . "</td><td>" . $row['count'] . "</td></tr>";
    }
    echo "</table>";
}

// Show sample requests
echo "<h3>Sample Requests (First 5):</h3>";
$sample = $conn->query("SELECT * FROM `$foundTable` LIMIT 5");
echo "<table border='1'>";
if ($sample && $sample->num_rows > 0) {
    $firstRow = $sample->fetch_assoc();
    echo "<tr>";
    foreach (array_keys($firstRow) as $key) {
        echo "<th>$key</th>";
    }
    echo "</tr>";
    
    // Reset and show all
    $sample->data_seek(0);
    while ($row = $sample->fetch_assoc()) {
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>" . (strlen($value) > 50 ? substr($value, 0, 50) . "..." : $value) . "</td>";
        }
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='10'>No requests found</td></tr>";
}
echo "</table>";

$conn->close();
?>

