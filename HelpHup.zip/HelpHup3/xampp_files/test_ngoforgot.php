<?php
/**
 * Test ngoforgot.php endpoint
 * This helps identify what's causing the 500 error
 */

// Enable all error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

echo "<h2>Testing ngoforgot.php</h2>";
echo "<pre>";

// Test 1: Check if config.php exists and works
echo "=== Test 1: Checking config.php ===\n";
if (file_exists('config.php')) {
    echo "✓ config.php exists\n";
    try {
        require_once 'config.php';
        echo "✓ config.php loaded successfully\n";
        echo "  Database: $database\n";
        echo "  Connection: " . ($conn ? "OK" : "FAILED") . "\n";
    } catch (Exception $e) {
        echo "✗ Error loading config.php: " . $e->getMessage() . "\n";
    }
} else {
    echo "✗ config.php NOT FOUND\n";
}

// Test 2: Check if email_config.php exists
echo "\n=== Test 2: Checking email_config.php ===\n";
if (file_exists('email_config.php')) {
    echo "✓ email_config.php exists\n";
    try {
        $emailConfigExists = @include_once 'email_config.php';
        if ($emailConfigExists) {
            echo "✓ email_config.php loaded\n";
        } else {
            echo "⚠ email_config.php exists but failed to load\n";
        }
        if (function_exists('sendOTPEmail')) {
            echo "✓ sendOTPEmail function exists\n";
        } else {
            echo "⚠ sendOTPEmail function NOT found\n";
        }
    } catch (Exception $e) {
        echo "✗ Error loading email_config.php: " . $e->getMessage() . "\n";
    }
} else {
    echo "⚠ email_config.php NOT FOUND (this is OK, will use fallback)\n";
}

// Test 3: Check database connection
echo "\n=== Test 3: Testing Database Connection ===\n";
if (isset($conn)) {
    if ($conn->connect_error) {
        echo "✗ Database connection failed: " . $conn->connect_error . "\n";
    } else {
        echo "✓ Database connected\n";
        
        // Test if ngo table exists
        $test = $conn->query("SHOW TABLES LIKE 'ngo'");
        if ($test && $test->num_rows > 0) {
            echo "✓ 'ngo' table exists\n";
        } else {
            echo "✗ 'ngo' table NOT FOUND\n";
        }
        
        // Test if password reset table exists
        $test = $conn->query("SHOW TABLES LIKE 'ngo_password_reset_tokens'");
        if ($test && $test->num_rows > 0) {
            echo "✓ 'ngo_password_reset_tokens' table exists\n";
        } else {
            echo "✗ 'ngo_password_reset_tokens' table NOT FOUND\n";
            echo "  Run: http://localhost/helphup/api/setup_password_reset_table.php\n";
        }
    }
} else {
    echo "✗ Database connection not available\n";
}

// Test 4: Simulate the actual request
echo "\n=== Test 4: Simulating Request ===\n";
$_SERVER['REQUEST_METHOD'] = 'POST';
$testEmail = 'test@example.com';
$testData = json_encode(['email' => $testEmail]);

// Capture any output
ob_start();
try {
    // Simulate the ngoforgot.php logic
    $data = json_decode($testData, true);
    $email = trim(strtolower($data['email'] ?? ''));
    
    if (empty($email)) {
        echo "✗ Email validation would fail\n";
    } else {
        echo "✓ Email validation passed: $email\n";
    }
    
    // Test email lookup
    if (isset($conn) && !$conn->connect_error) {
        $stmt = $conn->prepare("SELECT ngo_id FROM ngo WHERE LOWER(email) = LOWER(?)");
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            echo "✓ Email lookup query executed\n";
            echo "  Found records: " . $result->num_rows . "\n";
        } else {
            echo "✗ Email lookup query failed: " . $conn->error . "\n";
        }
    }
    
} catch (Exception $e) {
    echo "✗ Exception during simulation: " . $e->getMessage() . "\n";
    echo "  File: " . $e->getFile() . "\n";
    echo "  Line: " . $e->getLine() . "\n";
}
$output = ob_get_clean();
echo $output;

echo "\n=== Test Complete ===\n";
echo "</pre>";

if (isset($conn)) {
    $conn->close();
}
?>

