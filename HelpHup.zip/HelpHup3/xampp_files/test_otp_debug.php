<?php
/**
 * OTP Debug Tool
 * 
 * Use this to check what OTPs are in the database and test verification
 * 
 * Usage: http://localhost/helphup/api/test_otp_debug.php?email=your-email@example.com
 */

require_once 'config.php';

// Get email from URL
$email = trim(strtolower($_GET['email'] ?? ''));

if (empty($email)) {
    die('
    <html>
    <head>
        <title>OTP Debug Tool</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 40px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
            h1 { color: #22C55E; }
            .info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
            .error { background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px 0; color: #c62828; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
            th { background: #f0f0f0; }
            .form-group { margin: 20px 0; }
            input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
            button { background: #22C55E; color: white; padding: 12px 30px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔍 OTP Debug Tool</h1>
            <div class="info">
                <strong>Instructions:</strong><br>
                Enter an email address to see what OTPs are stored in the database for that email.
            </div>
            <form method="GET">
                <div class="form-group">
                    <label>Email Address:</label>
                    <input type="email" name="email" placeholder="user@example.com" required>
                </div>
                <button type="submit">Check OTPs</button>
            </form>
        </div>
    </body>
    </html>
    ');
}

echo '<html>
<head>
    <title>OTP Debug Results</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 40px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        h1 { color: #22C55E; }
        .info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .error { background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px 0; color: #c62828; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
        th { background: #f0f0f0; }
        .code { font-family: monospace; font-size: 18px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 OTP Debug Results</h1>
        <div class="info">
            <strong>Checking OTPs for:</strong> ' . htmlspecialchars($email) . '<br>
            <strong>Time:</strong> ' . date('Y-m-d H:i:s') . '
        </div>';

// Check all three tables
$tables = [
    'ngo_password_reset_tokens' => 'NGO',
    'donor_password_reset_tokens' => 'Donor',
    'volunteer_password_reset_tokens' => 'Volunteer'
];

foreach ($tables as $tableName => $userType) {
    echo "<h2>$userType OTPs</h2>";
    
    $stmt = $conn->prepare("SELECT id, email, otp, expires_at, used, created_at FROM $tableName WHERE email = ? ORDER BY created_at DESC LIMIT 10");
    if ($stmt === false) {
        echo '<div class="error">Error preparing query: ' . $conn->error . '</div>';
        continue;
    }
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo '<table>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>OTP</th>
                <th>OTP Length</th>
                <th>Created At</th>
                <th>Expires At</th>
                <th>Used</th>
                <th>Status</th>
            </tr>';
        
        while ($row = $result->fetch_assoc()) {
            $expiresAt = strtotime($row['expires_at']);
            $now = time();
            $isExpired = $expiresAt < $now;
            $isValid = !$isExpired && $row['used'] == 0;
            
            $status = $row['used'] == 1 ? '<span style="color: orange;">Used</span>' : 
                     ($isExpired ? '<span style="color: red;">Expired</span>' : 
                     '<span style="color: green;">Valid</span>');
            
            echo '<tr>
                <td>' . $row['id'] . '</td>
                <td>' . htmlspecialchars($row['email']) . '</td>
                <td class="code">' . htmlspecialchars($row['otp']) . '</td>
                <td>' . strlen($row['otp']) . '</td>
                <td>' . $row['created_at'] . '</td>
                <td>' . $row['expires_at'] . '</td>
                <td>' . ($row['used'] == 1 ? 'Yes' : 'No') . '</td>
                <td>' . $status . '</td>
            </tr>';
        }
        
        echo '</table>';
    } else {
        echo '<div class="info">No OTPs found for this email in ' . $userType . ' table.</div>';
    }
    
    $stmt->close();
}

echo '</div></body></html>';
$conn->close();
?>

