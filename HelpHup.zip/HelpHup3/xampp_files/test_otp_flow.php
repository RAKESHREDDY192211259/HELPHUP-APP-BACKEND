<?php
/**
 * Test OTP Flow - Complete End-to-End Test
 * 
 * This script tests the complete OTP flow:
 * 1. Generate OTP
 * 2. Verify OTP exists in database
 * 3. Verify OTP works
 * 
 * Usage: http://localhost/helphup/api/test_otp_flow.php?email=test@example.com
 */

require_once 'config.php';

header('Content-Type: application/json');

$email = $_GET['email'] ?? 'test@example.com';
$email = trim(strtolower($email));

echo "<h2>Testing OTP Flow for: $email</h2>";
echo "<pre>";

// Step 1: Check if tables exist
echo "\n=== Step 1: Checking Tables ===\n";
$tables = ['ngo_password_reset_tokens', 'donor_password_reset_tokens', 'volunteer_password_reset_tokens'];
foreach ($tables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        echo "✓ Table '$table' exists\n";
    } else {
        echo "✗ Table '$table' DOES NOT EXIST\n";
    }
}

// Step 2: Check existing OTPs
echo "\n=== Step 2: Existing OTPs in Database ===\n";
foreach ($tables as $table) {
    $stmt = $conn->prepare("SELECT * FROM $table WHERE LOWER(email) = LOWER(?) ORDER BY created_at DESC LIMIT 3");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo "\nTable: $table\n";
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $isExpired = strtotime($row['expires_at']) < time();
            $isValid = !$isExpired && $row['used'] == 0;
            echo "  OTP: {$row['otp']}, Expires: {$row['expires_at']}, Used: {$row['used']}, Valid: " . ($isValid ? 'YES' : 'NO') . "\n";
        }
    } else {
        echo "  No OTPs found\n";
    }
    $stmt->close();
}

// Step 3: Simulate OTP generation
echo "\n=== Step 3: Simulating OTP Generation ===\n";
$otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));
echo "Generated OTP: $otp\n";
echo "Expires at: $expires_at\n";

// Step 4: Test insertion
echo "\n=== Step 4: Testing OTP Insertion ===\n";
$testTable = 'ngo_password_reset_tokens';
$delete = $conn->prepare("DELETE FROM $testTable WHERE LOWER(email) = LOWER(?)");
$delete->bind_param("s", $email);
$delete->execute();
$delete->close();

$insert = $conn->prepare("INSERT INTO $testTable (email, otp, expires_at) VALUES (?, ?, ?)");
$insert->bind_param("sss", $email, $otp, $expires_at);
if ($insert->execute()) {
    echo "✓ OTP inserted successfully\n";
    
    // Verify it was saved
    $verify = $conn->prepare("SELECT * FROM $testTable WHERE LOWER(email) = LOWER(?) AND otp = ?");
    $verify->bind_param("ss", $email, $otp);
    $verify->execute();
    $verifyResult = $verify->get_result();
    if ($verifyResult->num_rows > 0) {
        echo "✓ OTP verified in database\n";
        $row = $verifyResult->fetch_assoc();
        echo "  Stored OTP: {$row['otp']}\n";
        echo "  Stored Email: {$row['email']}\n";
        echo "  Expires: {$row['expires_at']}\n";
    } else {
        echo "✗ OTP NOT FOUND in database after insertion!\n";
    }
    $verify->close();
} else {
    echo "✗ Failed to insert OTP: " . $insert->error . "\n";
}
$insert->close();

// Step 5: Test verification query
echo "\n=== Step 5: Testing Verification Query ===\n";
$verifyStmt = $conn->prepare("SELECT * FROM $testTable WHERE LOWER(email) = LOWER(?) AND otp = ? AND expires_at > NOW() AND used = 0");
$verifyStmt->bind_param("ss", $email, $otp);
$verifyStmt->execute();
$verifyResult = $verifyStmt->get_result();
if ($verifyResult->num_rows > 0) {
    echo "✓ OTP verification query SUCCESS\n";
    $row = $verifyResult->fetch_assoc();
    echo "  Found OTP: {$row['otp']}\n";
    echo "  Email: {$row['email']}\n";
} else {
    echo "✗ OTP verification query FAILED\n";
    echo "  Searching for: Email='$email', OTP='$otp'\n";
    
    // Check what's actually in the database
    $check = $conn->prepare("SELECT * FROM $testTable WHERE LOWER(email) = LOWER(?)");
    $check->bind_param("s", $email);
    $check->execute();
    $checkResult = $check->get_result();
    if ($checkResult->num_rows > 0) {
        $row = $checkResult->fetch_assoc();
        echo "  Found in DB: Email='{$row['email']}', OTP='{$row['otp']}'\n";
        echo "  Expires: {$row['expires_at']}\n";
        echo "  Used: {$row['used']}\n";
        $expiresAt = strtotime($row['expires_at']);
        $now = time();
        echo "  Time check: Now=$now, Expires=$expiresAt, Valid=" . ($expiresAt > $now ? 'YES' : 'NO') . "\n";
    }
    $check->close();
}
$verifyStmt->close();

echo "\n=== Test Complete ===\n";
echo "</pre>";

$conn->close();
?>

