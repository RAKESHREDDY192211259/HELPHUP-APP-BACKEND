<?php
require_once 'config.php';

// Test OTP verification logic
$testEmail = 'rakeshreddyk1259.sse@saveetha.com';
$testOtp = '071756'; // From the database

echo "=== OTP Verification Test ===\n\n";
echo "Email: $testEmail\n";
echo "OTP to verify: $testOtp\n\n";

// Normalize OTP (same as verification script)
$normalizedOtp = preg_replace('/[^0-9]/', '', $testOtp);
$normalizedOtp = str_pad($normalizedOtp, 6, '0', STR_PAD_LEFT);
echo "Normalized OTP: '$normalizedOtp' (length: " . strlen($normalizedOtp) . ")\n\n";

// Get from database
$email = strtolower(trim($testEmail));
$stmt = $conn->prepare("SELECT id, email, otp, expires_at, used, created_at, 
                        TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry,
                        LENGTH(otp) as otp_length,
                        HEX(otp) as otp_hex
                        FROM ngo_password_reset_tokens 
                        WHERE email = ? 
                        ORDER BY created_at DESC LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "=== Database Record ===\n";
    echo "ID: {$row['id']}\n";
    echo "Email (stored): '{$row['email']}'\n";
    echo "Email (searching): '$email'\n";
    echo "Email match: " . ($row['email'] === $email ? "YES" : "NO") . "\n\n";
    
    echo "OTP (stored): '{$row['otp']}'\n";
    echo "OTP (stored length): {$row['otp_length']}\n";
    echo "OTP (stored hex): {$row['otp_hex']}\n";
    echo "OTP (normalized): '$normalizedOtp'\n";
    echo "OTP (normalized length): " . strlen($normalizedOtp) . "\n";
    echo "OTP (normalized hex): " . bin2hex($normalizedOtp) . "\n";
    echo "OTP match: " . ($row['otp'] === $normalizedOtp ? "YES" : "NO") . "\n";
    echo "OTP match (trim): " . (trim($row['otp']) === trim($normalizedOtp) ? "YES" : "NO") . "\n\n";
    
    echo "Created: {$row['created_at']}\n";
    echo "Expires: {$row['expires_at']}\n";
    echo "Used: {$row['used']}\n";
    echo "Seconds until expiry: {$row['seconds_until_expiry']}\n\n";
    
    // Test the actual verification query
    echo "=== Testing Verification Query ===\n";
    $verifyStmt = $conn->prepare("SELECT *, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry 
                                   FROM ngo_password_reset_tokens 
                                   WHERE email = ? AND otp = ? AND used = 0");
    $verifyStmt->bind_param("ss", $email, $normalizedOtp);
    $verifyStmt->execute();
    $verifyResult = $verifyStmt->get_result();
    
    if ($verifyResult->num_rows > 0) {
        $verifyRow = $verifyResult->fetch_assoc();
        echo "✅ Query found record\n";
        echo "Seconds until expiry: {$verifyRow['seconds_until_expiry']}\n";
        if ($verifyRow['seconds_until_expiry'] > 0) {
            echo "✅ OTP is VALID\n";
        } else {
            echo "❌ OTP is EXPIRED\n";
        }
    } else {
        echo "❌ Query did NOT find record\n";
        
        // Test each condition separately
        echo "\nTesting individual conditions:\n";
        
        $test1 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ?");
        $test1->bind_param("s", $email);
        $test1->execute();
        $r1 = $test1->get_result()->fetch_assoc();
        echo "  Email match: {$r1['cnt']} records\n";
        
        $test2 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ?");
        $test2->bind_param("ss", $email, $normalizedOtp);
        $test2->execute();
        $r2 = $test2->get_result()->fetch_assoc();
        echo "  Email + OTP match: {$r2['cnt']} records\n";
        
        $test3 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ? AND used = 0");
        $test3->bind_param("ss", $email, $normalizedOtp);
        $test3->execute();
        $r3 = $test3->get_result()->fetch_assoc();
        echo "  Email + OTP + not used: {$r3['cnt']} records\n";
        
        // Try with stored OTP directly
        $test4 = $conn->prepare("SELECT COUNT(*) as cnt FROM ngo_password_reset_tokens WHERE email = ? AND otp = ?");
        $test4->bind_param("ss", $email, $row['otp']);
        $test4->execute();
        $r4 = $test4->get_result()->fetch_assoc();
        echo "  Email + stored OTP: {$r4['cnt']} records\n";
    }
    $verifyStmt->close();
} else {
    echo "❌ No record found for email: $email\n";
}

$stmt->close();
$conn->close();
?>

