<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h2>Password Reset & Login Flow Test</h2>";

$email = $_GET['email'] ?? 'rakeshreddyk1259.sse@saveetha.com';
$testPassword = $_GET['password'] ?? '123';
$newPassword = $_GET['newpassword'] ?? 'NewPass123';

echo "<h3>Testing for email: $email</h3>";

// Test 1: Check current password status
echo "<h4>1. Current Password Status:</h4>";
$volunteerTables = ['volunteer', 'volunteers'];
$tableName = null;

foreach ($volunteerTables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if ($tableName) {
    $stmt = $conn->prepare("SELECT volunteer_id, email, password, CHAR_LENGTH(password) as pwd_len, LEFT(password, 30) as pwd_preview FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<p>✓ Found in table: <strong>$tableName</strong></p>";
        echo "<p>Actual email in DB: <strong>" . htmlspecialchars($row['email']) . "</strong></p>";
        echo "<p>Password hash length: <strong>" . $row['pwd_len'] . "</strong> characters</p>";
        echo "<p>Password hash preview: <strong>" . htmlspecialchars($row['pwd_preview']) . "...</strong></p>";
        
        // Test current password
        $currentWorks = password_verify($testPassword, $row['password']);
        echo "<p>Current password '$testPassword' verification: <strong style='color: " . ($currentWorks ? 'green' : 'red') . ";'>" . ($currentWorks ? '✓ WORKS' : '✗ FAILS') . "</strong></p>";
        
        // Test new password
        $newWorks = password_verify($newPassword, $row['password']);
        echo "<p>New password '$newPassword' verification: <strong style='color: " . ($newWorks ? 'green' : 'red') . ";'>" . ($newWorks ? '✓ WORKS' : '✗ FAILS') . "</strong></p>";
        
    } else {
        echo "<p style='color: red;'>✗ Email NOT found in table '$tableName'</p>";
    }
    $stmt->close();
} else {
    echo "<p style='color: red;'>✗ Volunteer table not found</p>";
}

// Test 2: Check OTP tokens
echo "<h4>2. Recent OTP Tokens:</h4>";
$stmt = $conn->prepare("SELECT email, otp, used, created_at, expires_at, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_left FROM volunteer_password_reset_tokens WHERE LOWER(email) = LOWER(?) ORDER BY created_at DESC LIMIT 3");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    echo "<tr><th>Email</th><th>OTP</th><th>Used</th><th>Created</th><th>Expires</th><th>Time Left</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $expired = $row['seconds_left'] <= 0;
        $color = $expired ? 'red' : ($row['used'] ? 'orange' : 'green');
        echo "<tr style='color: $color;'>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td>" . htmlspecialchars($row['otp']) . "</td>";
        echo "<td>" . ($row['used'] ? 'Yes' : 'No') . "</td>";
        echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
        echo "<td>" . htmlspecialchars($row['expires_at']) . "</td>";
        echo "<td>" . ($expired ? 'EXPIRED' : $row['seconds_left'] . ' seconds') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No OTP tokens found for this email</p>";
}
$stmt->close();

// Test 3: Simulate password update
echo "<h4>3. Simulate Password Update:</h4>";
if ($tableName) {
    $hashedNew = password_hash($newPassword, PASSWORD_DEFAULT);
    echo "<p>New password hash length: <strong>" . strlen($hashedNew) . "</strong> characters</p>";
    echo "<p>New password hash preview: <strong>" . htmlspecialchars(substr($hashedNew, 0, 30)) . "...</strong></p>";
    
    // Check if update would work
    $check = $conn->prepare("SELECT email FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
    $check->bind_param("s", $email);
    $check->execute();
    $checkResult = $check->get_result();
    
    if ($checkResult->num_rows > 0) {
        $checkRow = $check->fetch_assoc();
        echo "<p>✓ Email would match for UPDATE: <strong>" . htmlspecialchars($checkRow['email']) . "</strong></p>";
        echo "<p style='color: orange;'>⚠ This is a simulation. No actual update performed.</p>";
    }
    $check->close();
}

// Test 4: Check password column length
echo "<h4>4. Password Column Information:</h4>";
if ($tableName) {
    $colInfo = $conn->query("SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$tableName' AND COLUMN_NAME = 'password'");
    if ($colInfo && $colInfo->num_rows > 0) {
        $col = $colInfo->fetch_assoc();
        echo "<p>Column Type: <strong>" . htmlspecialchars($col['COLUMN_TYPE']) . "</strong></p>";
        echo "<p>Max Length: <strong>" . ($col['CHARACTER_MAXIMUM_LENGTH'] ?? 'N/A') . "</strong></p>";
        
        if ($col['CHARACTER_MAXIMUM_LENGTH'] && $col['CHARACTER_MAXIMUM_LENGTH'] < 60) {
            echo "<p style='color: red;'>⚠ WARNING: Password column is too short! Bcrypt hashes need at least 60 characters. Current max: " . $col['CHARACTER_MAXIMUM_LENGTH'] . "</p>";
            echo "<p>Run this SQL to fix: <code>ALTER TABLE `$tableName` MODIFY COLUMN `password` VARCHAR(255) NOT NULL;</code></p>";
        } else {
            echo "<p style='color: green;'>✓ Password column length is sufficient</p>";
        }
    }
}

echo "<hr>";
echo "<p><strong>Usage:</strong></p>";
echo "<ul>";
echo "<li>Test current password: <code>?email=your@email.com&password=currentpass</code></li>";
echo "<li>Test new password: <code>?email=your@email.com&password=currentpass&newpassword=newpass</code></li>";
echo "</ul>";

$conn->close();
?>

