<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h2>Password Reset Diagnostic Test</h2>";

$email = $_GET['email'] ?? 'rakeshreddyk1259.sse@saveetha.com';
$testPassword = $_GET['password'] ?? '123';

echo "<h3>Testing for email: $email</h3>";

// Check volunteer table
echo "<h4>1. Checking Volunteer Table:</h4>";
$volunteerTables = ['volunteer', 'volunteers'];
foreach ($volunteerTables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        echo "<p>✓ Table '$table' exists</p>";
        
        // Check if email exists
        $stmt = $conn->prepare("SELECT volunteer_id, email, password, LEFT(password, 20) as password_preview FROM `$table` WHERE LOWER(email) = LOWER(?)");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "<p>✓ Email found in table '$table'</p>";
            echo "<p>Actual email in DB: " . htmlspecialchars($row['email']) . "</p>";
            echo "<p>Password hash preview: " . htmlspecialchars($row['password_preview']) . "...</p>";
            echo "<p>Password hash length: " . strlen($row['password']) . " characters</p>";
            
            // Test password verification
            if (password_verify($testPassword, $row['password'])) {
                echo "<p style='color: green;'>✓ Password '$testPassword' VERIFIES CORRECTLY</p>";
            } else {
                echo "<p style='color: red;'>✗ Password '$testPassword' DOES NOT VERIFY</p>";
                
                // Try with different passwords
                echo "<p>Testing other common passwords...</p>";
                $testPasswords = ['123456', 'password', '12345', 'admin'];
                foreach ($testPasswords as $pwd) {
                    if (password_verify($pwd, $row['password'])) {
                        echo "<p style='color: orange;'>⚠ Password '$pwd' verifies!</p>";
                    }
                }
            }
        } else {
            echo "<p style='color: red;'>✗ Email NOT found in table '$table'</p>";
        }
        $stmt->close();
        break;
    }
}

// Check donor table
echo "<h4>2. Checking Donor Table:</h4>";
$donorTables = ['donor', 'donors'];
foreach ($donorTables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        echo "<p>✓ Table '$table' exists</p>";
        
        // Check if email exists
        $stmt = $conn->prepare("SELECT donor_id, email, password, LEFT(password, 20) as password_preview FROM `$table` WHERE LOWER(email) = LOWER(?)");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "<p>✓ Email found in table '$table'</p>";
            echo "<p>Actual email in DB: " . htmlspecialchars($row['email']) . "</p>";
            echo "<p>Password hash preview: " . htmlspecialchars($row['password_preview']) . "...</p>";
            echo "<p>Password hash length: " . strlen($row['password']) . " characters</p>";
            
            // Test password verification
            if (password_verify($testPassword, $row['password'])) {
                echo "<p style='color: green;'>✓ Password '$testPassword' VERIFIES CORRECTLY</p>";
            } else {
                echo "<p style='color: red;'>✗ Password '$testPassword' DOES NOT VERIFY</p>";
            }
        } else {
            echo "<p style='color: red;'>✗ Email NOT found in table '$table'</p>";
        }
        $stmt->close();
        break;
    }
}

// Check recent password reset tokens
echo "<h4>3. Recent Password Reset Tokens:</h4>";
$tokenTables = [
    'volunteer_password_reset_tokens' => 'Volunteer',
    'donor_password_reset_tokens' => 'Donor'
];

foreach ($tokenTables as $table => $type) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $stmt = $conn->prepare("SELECT email, otp, used, created_at, expires_at FROM `$table` WHERE LOWER(email) = LOWER(?) ORDER BY created_at DESC LIMIT 5");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            echo "<p><strong>$type Tokens:</strong></p>";
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>Email</th><th>OTP</th><th>Used</th><th>Created</th><th>Expires</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                echo "<td>" . htmlspecialchars($row['otp']) . "</td>";
                echo "<td>" . ($row['used'] ? 'Yes' : 'No') . "</td>";
                echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
                echo "<td>" . htmlspecialchars($row['expires_at']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        $stmt->close();
    }
}

echo "<hr>";
echo "<p><strong>Usage:</strong> Add ?email=your@email.com&password=yourpassword to URL to test different credentials</p>";

$conn->close();
?>

