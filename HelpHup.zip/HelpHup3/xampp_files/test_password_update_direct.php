<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');

$email = $_GET['email'] ?? 'rakeshreddyk1259.sse@saveetha.com';
$newPassword = $_GET['password'] ?? 'NewPass123';

echo "<h2>Direct Password Update Test</h2>";
echo "<p>Email: $email</p>";
echo "<p>New Password: $newPassword</p><hr>";

$tableName = 'volunteers';

// Step 1: Get current email from database
echo "<h3>Step 1: Get Email from Database</h3>";
$getEmail = $conn->prepare("SELECT id, email, LEFT(password, 30) as old_pwd FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
$getEmail->bind_param("s", $email);
$getEmail->execute();
$emailResult = $getEmail->get_result();

if ($emailResult->num_rows == 0) {
    echo "<p style='color: red;'>Email not found</p>";
    exit;
}

$emailRow = $emailResult->fetch_assoc();
$actualEmail = $emailRow['email'];
$oldPwdHash = $emailRow['old_pwd'];

echo "<p>ID: {$emailRow['id']}</p>";
echo "<p>Actual email in DB: <strong>$actualEmail</strong></p>";
echo "<p>Old password hash: $oldPwdHash...</p>";
$getEmail->close();

// Step 2: Hash new password
echo "<h3>Step 2: Hash New Password</h3>";
$newHash = password_hash($newPassword, PASSWORD_DEFAULT);
echo "<p>New hash: " . substr($newHash, 0, 30) . "...</p>";
echo "<p>Hash length: " . strlen($newHash) . " characters</p>";

// Step 3: UPDATE
echo "<h3>Step 3: Execute UPDATE</h3>";
echo "<p>Query: UPDATE `$tableName` SET password = ? WHERE email = ?</p>";
echo "<p>Using email: <strong>$actualEmail</strong></p>";

$update = $conn->prepare("UPDATE `$tableName` SET password = ? WHERE email = ?");
$update->bind_param("ss", $newHash, $actualEmail);

if ($update->execute()) {
    $affected = $update->affected_rows;
    echo "<p style='color: " . ($affected > 0 ? 'green' : 'red') . ";'>Execute: " . ($affected > 0 ? 'SUCCESS' : 'FAILED') . "</p>";
    echo "<p>Affected rows: <strong>$affected</strong></p>";
    
    if ($affected > 0) {
        // Step 4: Verify
        echo "<h3>Step 4: Verify Update</h3>";
        $verify = $conn->prepare("SELECT password FROM `$tableName` WHERE email = ?");
        $verify->bind_param("s", $actualEmail);
        $verify->execute();
        $verifyResult = $verify->get_result();
        $verifyRow = $verifyResult->fetch_assoc();
        $verify->close();
        
        $dbHash = $verifyRow['password'];
        echo "<p>Password in DB now: " . substr($dbHash, 0, 30) . "...</p>";
        
        // Test password verification
        $newWorks = password_verify($newPassword, $dbHash);
        $oldWorks = password_verify('123', $dbHash); // assuming old password is '123'
        
        echo "<p>New password '$newPassword' verifies: <strong style='color: " . ($newWorks ? 'green' : 'red') . ";'>" . ($newWorks ? 'YES ✓' : 'NO ✗') . "</strong></p>";
        echo "<p>Old password '123' verifies: <strong style='color: " . ($oldWorks ? 'green' : 'red') . ";'>" . ($oldWorks ? 'YES ✓' : 'NO ✗') . "</strong></p>";
        
        if ($newWorks && !$oldWorks) {
            echo "<p style='color: green; font-weight: bold;'>✓ SUCCESS! Password updated correctly!</p>";
        } else if (!$newWorks) {
            echo "<p style='color: red; font-weight: bold;'>✗ PROBLEM: New password doesn't verify!</p>";
        } else if ($oldWorks) {
            echo "<p style='color: red; font-weight: bold;'>✗ PROBLEM: Old password still works!</p>";
        }
    } else {
        echo "<p style='color: red; font-weight: bold;'>✗ UPDATE failed - No rows affected!</p>";
    }
} else {
    echo "<p style='color: red;'>Execute failed: " . $update->error . "</p>";
}

$update->close();
$conn->close();
?>

