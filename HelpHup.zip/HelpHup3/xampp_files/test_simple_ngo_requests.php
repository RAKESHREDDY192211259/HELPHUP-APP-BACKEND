<?php
/**
 * SIMPLE TEST - Copy this to: C:\xampp\htdocs\helphup\api\
 * Then open: http://localhost/helphup/api/test_simple_ngo_requests.php
 * 
 * This will show you EXACTLY what's wrong
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

echo "<h1>Simple NGO Requests Test</h1>";
echo "<hr>";

// Step 1: Check config
echo "<h2>Step 1: Config File</h2>";
if (!file_exists('config.php')) {
    die("❌ config.php NOT FOUND!");
}
require_once 'config.php';
echo "✅ config.php loaded<br>";

// Step 2: Check connection
echo "<h2>Step 2: Database Connection</h2>";
if (!isset($conn) || $conn->connect_error) {
    die("❌ Connection failed: " . ($conn->connect_error ?? "No connection"));
}
echo "✅ Connected to database<br>";

// Step 3: Check tables
echo "<h2>Step 3: Check Tables</h2>";

// Check ngo_help_requests table
$tables = ['ngo_help_requests', 'ngoraisehelp', 'ngohelprequests'];
$requestTable = null;
foreach ($tables as $t) {
    $check = $conn->query("SHOW TABLES LIKE '$t'");
    if ($check && $check->num_rows > 0) {
        $requestTable = $t;
        echo "✅ Found request table: <strong>$t</strong><br>";
        break;
    }
}
if (!$requestTable) {
    die("❌ NO REQUEST TABLE FOUND! Create ngo_help_requests table first.");
}

// Check ngo table
$ngoTables = ['ngo', 'ngos'];
$ngoTable = null;
foreach ($ngoTables as $t) {
    $check = $conn->query("SHOW TABLES LIKE '$t'");
    if ($check && $check->num_rows > 0) {
        $ngoTable = $t;
        echo "✅ Found NGO table: <strong>$t</strong><br>";
        
        // Check columns
        $cols = $conn->query("SHOW COLUMNS FROM `$t`");
        echo "Columns: ";
        while ($col = $cols->fetch_assoc()) {
            echo $col['Field'] . " ";
        }
        echo "<br>";
        break;
    }
}
if (!$ngoTable) {
    echo "⚠️ NGO table not found (will use 'Unknown' for names)<br>";
}

// Step 4: Check columns
echo "<h2>Step 4: Check Column Names</h2>";

// Check request table primary key
$requestIdCol = 'request_id';
$check = $conn->query("SHOW COLUMNS FROM `$requestTable` LIKE 'request_id'");
if ($check && $check->num_rows == 0) {
    $check2 = $conn->query("SHOW COLUMNS FROM `$requestTable` LIKE 'id'");
    if ($check2 && $check2->num_rows > 0) {
        $requestIdCol = 'id';
    }
}
echo "Request table ID column: <strong>$requestIdCol</strong><br>";

// Check NGO table primary key
$ngoIdCol = 'ngo_id';
if ($ngoTable) {
    $check = $conn->query("SHOW COLUMNS FROM `$ngoTable` LIKE 'ngo_id'");
    if ($check && $check->num_rows == 0) {
        $check2 = $conn->query("SHOW COLUMNS FROM `$ngoTable` LIKE 'id'");
        if ($check2 && $check2->num_rows > 0) {
            $ngoIdCol = 'id';
            echo "✅ NGO table uses <strong>id</strong> column (NOT ngo_id)<br>";
        }
    } else {
        echo "✅ NGO table uses <strong>ngo_id</strong> column<br>";
    }
}

// Step 5: Try simple query WITHOUT JOIN first
echo "<h2>Step 5: Simple Query (No JOIN)</h2>";
$simpleSql = "SELECT * FROM `$requestTable` LIMIT 5";
$result = $conn->query($simpleSql);
if (!$result) {
    die("❌ Simple query failed: " . $conn->error);
}
echo "✅ Simple query works! Found " . $result->num_rows . " rows<br>";

// Step 6: Try query WITH JOIN
echo "<h2>Step 6: Query with JOIN</h2>";
if ($ngoTable) {
    $joinSql = "SELECT 
        nhr.$requestIdCol as request_id,
        nhr.ngo_id,
        COALESCE(n.full_name, 'Unknown') as ngo_name,
        COALESCE(n.org_name, 'Unknown') as org_name,
        nhr.request_title,
        nhr.category
    FROM `$requestTable` nhr
    LEFT JOIN `$ngoTable` n ON nhr.ngo_id = n.$ngoIdCol
    LIMIT 5";
    
    echo "<pre>SQL: " . htmlspecialchars($joinSql) . "</pre>";
    
    $result = $conn->query($joinSql);
    if (!$result) {
        echo "❌ JOIN query failed: <strong>" . $conn->error . "</strong><br>";
        echo "<p>This is the error we need to fix!</p>";
    } else {
        echo "✅ JOIN query works! Found " . $result->num_rows . " rows<br>";
        
        // Show data
        echo "<h3>Sample Data:</h3>";
        echo "<table border='1' cellpadding='5'>";
        $first = true;
        while ($row = $result->fetch_assoc()) {
            if ($first) {
                echo "<tr>";
                foreach (array_keys($row) as $key) {
                    echo "<th>$key</th>";
                }
                echo "</tr>";
                $first = false;
            }
            echo "<tr>";
            foreach ($row as $val) {
                echo "<td>" . htmlspecialchars(substr($val, 0, 30)) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    }
} else {
    echo "⚠️ Skipping JOIN test (no NGO table)<br>";
}

echo "<hr>";
echo "<h2>Summary</h2>";
echo "<p>✅ If you see errors above, those need to be fixed.</p>";
echo "<p>✅ If all tests pass, the main API should work.</p>";

$conn->close();
?>

