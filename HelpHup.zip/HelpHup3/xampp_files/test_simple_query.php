<?php
// Simple test to check if we can query the ngoraisehelp table
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Test simple query on ngoraisehelp table
    $result = $conn->query("SELECT id, ngo_id, request_title, category, created_at FROM ngoraisehelp ORDER BY created_at DESC LIMIT 5");
    
    $requests = array();
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $requests[] = $row;
        }
    }
    
    echo json_encode(array(
        'status' => true,
        'message' => 'Query successful',
        'data' => $requests,
        'count' => count($requests)
    ));
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
}

$conn->close();
?>

