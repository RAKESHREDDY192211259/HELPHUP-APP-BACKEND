<?php
require_once 'config.php';

// Test time comparison
echo "=== Time Comparison Test ===\n\n";

// Get database time
$dbTimeResult = $conn->query("SELECT NOW() as db_now, DATE_ADD(NOW(), INTERVAL 15 MINUTE) as db_plus_15");
if ($dbTimeResult && $dbTimeResult->num_rows > 0) {
    $dbRow = $dbTimeResult->fetch_assoc();
    echo "Database NOW(): " . $dbRow['db_now'] . "\n";
    echo "Database +15 min: " . $dbRow['db_plus_15'] . "\n";
}

// Get PHP time
echo "PHP time: " . date('Y-m-d H:i:s') . "\n";
echo "PHP +15 min: " . date('Y-m-d H:i:s', strtotime('+15 minutes')) . "\n\n";

// Check a sample OTP
$testEmail = 'rakeshreddyk1259.sse@saveetha.com';
$testStmt = $conn->prepare("SELECT otp, expires_at, created_at, used, TIMESTAMPDIFF(SECOND, NOW(), expires_at) as seconds_until_expiry FROM ngo_password_reset_tokens WHERE email = ? ORDER BY created_at DESC LIMIT 1");
$testStmt->bind_param("s", $testEmail);
$testStmt->execute();
$testResult = $testStmt->get_result();

if ($testResult->num_rows > 0) {
    $row = $testResult->fetch_assoc();
    echo "=== Latest OTP for $testEmail ===\n";
    echo "OTP: " . $row['otp'] . "\n";
    echo "Created: " . $row['created_at'] . "\n";
    echo "Expires: " . $row['expires_at'] . "\n";
    echo "Used: " . $row['used'] . "\n";
    echo "Seconds until expiry: " . $row['seconds_until_expiry'] . "\n";
    echo "Status: " . ($row['seconds_until_expiry'] > 0 ? "VALID" : "EXPIRED") . "\n";
} else {
    echo "No OTP found for $testEmail\n";
}

$conn->close();
?>

