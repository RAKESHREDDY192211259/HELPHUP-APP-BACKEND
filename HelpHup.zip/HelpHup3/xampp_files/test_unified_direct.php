<?php
// Direct test of unified tables
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "helphup");

if ($conn->connect_error) {
    echo json_encode([
        "status" => false,
        "message" => "Database connection failed: " . $conn->connect_error
    ]);
    exit();
}

// Check if unified_help_requests table exists
$checkTable = $conn->query("SHOW TABLES LIKE 'unified_help_requests'");
$tableExists = $checkTable && $checkTable->num_rows > 0;

if ($tableExists) {
    // Count records
    $countResult = $conn->query("SELECT COUNT(*) as count FROM unified_help_requests");
    $count = $countResult->fetch_assoc()['count'];
    
    echo json_encode([
        "status" => true,
        "message" => "Unified tables exist!",
        "record_count" => $count,
        "tables_found" => ["unified_help_requests", "request_status_history", "admin_notifications", "help_interactions"]
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Unified tables NOT found in database",
        "suggestion" => "Please import NEW_UNIFIED_HELP_SYSTEM.sql in phpMyAdmin"
    ]);
}

$conn->close();
?>
