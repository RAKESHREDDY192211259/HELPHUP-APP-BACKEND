<?php
/**
 * Test Update Profile Endpoints
 * 
 * Copy this file to: C:\xampp\htdocs\helphup\api\
 * Then open in browser: http://10.171.171.227/helphup/api/test_update_endpoints.php
 * 
 * This will check if all update profile files exist and are accessible.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

$baseDir = __DIR__;
$apiDir = $baseDir;

$results = [
    'server_info' => [
        'php_version' => phpversion(),
        'current_directory' => $baseDir,
        'server_time' => date('Y-m-d H:i:s')
    ],
    'file_checks' => [],
    'status' => 'checking'
];

$filesToCheck = [
    'update_ngo_profile.php',
    'update_donor_profile.php',
    'update_volunteer_profile.php',
    'get_ngo_profile.php',
    'get_donor_profile.php',
    'get_volunteer_profile.php',
    'config.php'
];

foreach ($filesToCheck as $file) {
    $filePath = $apiDir . DIRECTORY_SEPARATOR . $file;
    $exists = file_exists($filePath);
    $readable = $exists ? is_readable($filePath) : false;
    $size = $exists ? filesize($filePath) : 0;
    
    $results['file_checks'][$file] = [
        'exists' => $exists,
        'readable' => $readable,
        'size' => $size,
        'path' => $filePath,
        'url' => 'http://10.171.171.227/helphup/api/' . $file
    ];
}

// Count results
$existing = 0;
$missing = 0;
foreach ($results['file_checks'] as $file => $info) {
    if ($info['exists']) {
        $existing++;
    } else {
        $missing++;
    }
}

$results['summary'] = [
    'total_files' => count($filesToCheck),
    'existing' => $existing,
    'missing' => $missing,
    'all_exist' => ($missing === 0)
];

$results['status'] = $missing === 0 ? 'success' : 'error';

if ($missing > 0) {
    $results['missing_files'] = [];
    foreach ($results['file_checks'] as $file => $info) {
        if (!$info['exists']) {
            $results['missing_files'][] = $file;
        }
    }
    $results['instructions'] = [
        'step1' => 'Copy missing files from: D:\\Android\\Projects\\HelpHup3\\xampp_files\\',
        'step2' => 'Paste to: C:\\xampp\\htdocs\\helphup\\api\\',
        'step3' => 'Refresh this page to verify'
    ];
}

echo json_encode($results, JSON_PRETTY_PRINT);
?>

