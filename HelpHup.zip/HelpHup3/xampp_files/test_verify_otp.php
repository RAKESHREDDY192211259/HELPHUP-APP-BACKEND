<?php
/**
 * Test OTP Verification Endpoint
 * 
 * This file tests the ngo_verify_otp.php endpoint
 * Usage: Open in browser or use with Postman
 */

// Test data
$testEmail = "test@example.com"; // Replace with actual email from your database
$testOTP = "123456"; // Replace with actual OTP from database

// Create test request
$data = array(
    'email' => $testEmail,
    'otp' => $testOTP
);

// Convert to JSON
$jsonData = json_encode($data);

// Initialize cURL
$ch = curl_init('http://localhost/helphup/api/ngo_verify_otp.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Content-Length: ' . strlen($jsonData)
));

// Execute request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Display results
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test OTP Verification</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        .success { color: green; }
        .error { color: red; }
        .info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 10px 0; }
        pre { background: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 Test OTP Verification Endpoint</h1>
        
        <div class="info">
            <strong>Endpoint:</strong> ngo_verify_otp.php<br>
            <strong>HTTP Code:</strong> <?php echo $httpCode; ?><br>
            <strong>Test Email:</strong> <?php echo htmlspecialchars($testEmail); ?><br>
            <strong>Test OTP:</strong> <?php echo htmlspecialchars($testOTP); ?>
        </div>
        
        <h2>Response:</h2>
        <pre><?php echo htmlspecialchars($response); ?></pre>
        
        <?php
        $responseData = json_decode($response, true);
        if ($responseData) {
            if ($responseData['status']) {
                echo '<p class="success">✅ <strong>SUCCESS:</strong> ' . htmlspecialchars($responseData['message']) . '</p>';
            } else {
                echo '<p class="error">❌ <strong>ERROR:</strong> ' . htmlspecialchars($responseData['message']) . '</p>';
            }
        }
        ?>
        
        <div class="info">
            <h3>📝 Notes:</h3>
            <ul>
                <li>If you see "Email and OTP are required" - the endpoint is working correctly!</li>
                <li>To test with real data, update <code>$testEmail</code> and <code>$testOTP</code> in this file</li>
                <li>The OTP must exist in the <code>ngo_password_reset_tokens</code> table (or <code>donor_password_reset_tokens</code> / <code>volunteer_password_reset_tokens</code> depending on user type)</li>
                <li>The OTP must not be expired (expires_at > NOW())</li>
            </ul>
        </div>
        
        <h3>🔍 Direct Endpoint Test:</h3>
        <p>When you access the endpoint directly in browser (without POST data), you should see:</p>
        <pre>{"status":false,"message":"Email and OTP are required"}</pre>
        <p class="success">✅ This confirms the endpoint is working!</p>
    </div>
</body>
</html>

