<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => false,
        'message' => 'Only POST requests allowed'
    ]);
    exit();
}

try {
    // Include database configuration
    if (!file_exists('config.php')) {
        throw new Exception("config.php file not found");
    }
    require_once 'config.php';
    
    if (!isset($conn) && !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get JSON input
    $jsonInput = file_get_contents('php://input');
    $data = json_decode($jsonInput, true);
    
    if (!$data) {
        throw new Exception("Invalid JSON input");
    }
    
    // Validate required fields
    $requiredFields = ['request_id', 'status', 'admin_id'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }
    
    $requestId = (int)$data['request_id'];
    $newStatus = $data['status'];
    $adminId = (int)$data['admin_id'];
    $rejectionReason = isset($data['rejection_reason']) ? $data['rejection_reason'] : null;
    
    // Validate status
    $validStatuses = ['approved', 'rejected'];
    if (!in_array($newStatus, $validStatuses)) {
        throw new Exception("Invalid status. Must be: approved or rejected");
    }
    
    // Get current request details
    $currentSql = "SELECT status, requester_type, requester_id, requester_name, request_title 
                   FROM unified_help_requests 
                   WHERE request_id = ?";
    
    $currentStmt = $conn->prepare($currentSql);
    $currentStmt->bind_param('i', $requestId);
    $currentStmt->execute();
    $currentResult = $currentStmt->get_result();
    
    if ($currentResult->num_rows === 0) {
        throw new Exception("Request not found");
    }
    
    $currentData = $currentResult->fetch_assoc();
    $oldStatus = $currentData['status'];
    
    // Check if request is already processed
    if ($oldStatus !== 'pending') {
        throw new Exception("Request has already been processed");
    }
    
    // Begin transaction
    $conn->begin_transaction();
    
    try {
        // Update request status
        $updateSql = "UPDATE unified_help_requests 
                      SET status = ?, 
                          admin_id = ?, 
                          admin_reviewed_at = NOW(),
                          rejection_reason = ?,
                          updated_at = NOW()
                      WHERE request_id = ?";
        
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param('sisi', $newStatus, $adminId, $rejectionReason, $requestId);
        
        if (!$updateStmt->execute()) {
            throw new Exception("Failed to update request status");
        }
        
        // Create status history entry
        $historySql = "INSERT INTO request_status_history 
                       (request_id, old_status, new_status, changed_by, changed_by_id, change_reason, created_at) 
                       VALUES (?, ?, ?, 'admin', ?, ?, NOW())";
        
        $historyStmt = $conn->prepare($historySql);
        $changeReasonText = $newStatus === 'approved' ? 'Admin approved request' : 'Admin rejected request';
        $historyStmt->bind_param('issis', $requestId, $oldStatus, $newStatus, $adminId, $changeReasonText);
        
        if (!$historyStmt->execute()) {
            throw new Exception("Failed to create status history entry");
        }
        
        // Update admin notification as read
        $notificationSql = "UPDATE admin_notifications 
                            SET is_read = TRUE, admin_id = ? 
                            WHERE request_id = ? AND notification_type = 'new_request'";
        
        $notificationStmt = $conn->prepare($notificationSql);
        $notificationStmt->bind_param('ii', $adminId, $requestId);
        $notificationStmt->execute();
        
        // Create notification for requester in notifications table
        $requesterType = $currentData['requester_type'];
        $requesterId = $currentData['requester_id'];
        
        // Check if notifications table exists
        $checkTable = $conn->query("SHOW TABLES LIKE 'notifications'");
        if ($checkTable && $checkTable->num_rows > 0) {
            if ($newStatus === 'approved') {
                $title = "Request Approved";
                $message = "Your help request '{$currentData['request_title']}' has been approved and is now visible to other users who can help.";
                $rejectionReason = null;
            } else {
                $title = "Request Rejected";
                $message = "Your help request '{$currentData['request_title']}' has been rejected.";
                $rejectionReason = $rejectionReason; // Use the rejection reason from input
            }
            
            $notifSql = "INSERT INTO notifications 
                         (user_type, user_id, request_type, request_id, title, message, rejection_reason, is_read, created_at) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())";
            
            $notifStmt = $conn->prepare($notifSql);
            if ($notifStmt) {
                $notifStmt->bind_param('sisisss', 
                    $requesterType, 
                    $requesterId, 
                    $requesterType, 
                    $requestId, 
                    $title, 
                    $message, 
                    $rejectionReason
                );
                $notifStmt->execute();
                $notifStmt->close();
            }
        }
        
        // Commit transaction
        $conn->commit();
        
        // Return success response
        echo json_encode([
            'status' => true,
            'message' => "Request status updated to $newStatus successfully",
            'data' => [
                'request_id' => $requestId,
                'old_status' => $oldStatus,
                'new_status' => $newStatus,
                'requester_type' => $currentData['requester_type'],
                'requester_name' => $currentData['requester_name'],
                'request_title' => $currentData['request_title'],
                'admin_reviewed_at' => date('Y-m-d H:i:s')
            ]
        ]);
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => false,
        'message' => $e->getMessage()
    ]);
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>
