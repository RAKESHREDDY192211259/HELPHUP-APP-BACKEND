<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$donor_id = $data['donor_id'] ?? '';
$current_password = $data['current_password'] ?? '';
$new_password = $data['new_password'] ?? '';

if (empty($donor_id) || empty($current_password) || empty($new_password)) {
    sendResponse(false, "All fields are required");
}

// Try different possible table names
$tableNames = ['donor', 'donors'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Donor table not found.");
}

// Check which column exists - id or donor_id
$checkDonorId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'donor_id'");
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");

$donorIdColumn = 'id'; // default
if ($checkDonorId && $checkDonorId->num_rows > 0) {
    $donorIdColumn = 'donor_id';
} elseif ($checkId && $checkId->num_rows > 0) {
    $donorIdColumn = 'id';
}

// Verify current password
$stmt = $conn->prepare("SELECT password FROM `$tableName` WHERE $donorIdColumn = ?");
$stmt->bind_param("i", $donor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    sendResponse(false, "Donor not found");
}

$row = $result->fetch_assoc();
if (!password_verify($current_password, $row['password'])) {
    sendResponse(false, "Current password is incorrect");
}
$stmt->close();

// Update password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
$update = $conn->prepare("UPDATE `$tableName` SET password = ? WHERE $donorIdColumn = ?");
$update->bind_param("si", $hashed_password, $donor_id);

if ($update->execute()) {
    sendResponse(true, "Password updated successfully");
} else {
    sendResponse(false, "Password update failed: " . $conn->error);
}

$update->close();
$conn->close();
?>

