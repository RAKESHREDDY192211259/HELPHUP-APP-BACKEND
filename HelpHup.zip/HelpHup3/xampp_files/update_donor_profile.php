<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$donor_id = $data['donor_id'] ?? '';
$full_name = $data['full_name'] ?? '';
$phone = $data['phone'] ?? '';
$email = $data['email'] ?? '';
$address = $data['address'] ?? '';

// Validate required fields
if (empty($donor_id) || empty($full_name) || empty($phone) || empty($email) || empty($address)) {
    sendResponse(false, "All fields are required");
}

// Try different possible table names
$tableNames = ['donor', 'donors'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Donor table not found.");
}

// Check which column exists - id or donor_id
$checkDonorId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'donor_id'");
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");

$donorIdColumn = 'id'; // default
if ($checkDonorId && $checkDonorId->num_rows > 0) {
    $donorIdColumn = 'donor_id';
} elseif ($checkId && $checkId->num_rows > 0) {
    $donorIdColumn = 'id';
}

// Check if email is already used by another donor
$check = $conn->prepare("SELECT $donorIdColumn FROM `$tableName` WHERE email = ? AND $donorIdColumn != ?");
$check->bind_param("si", $email, $donor_id);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    sendResponse(false, "Email already registered to another account");
}
$check->close();

// Update profile in database - Replace old data with new data
// This UPDATE statement replaces all old field values with the new values provided
$stmt = $conn->prepare("UPDATE `$tableName` SET full_name = ?, phone = ?, email = ?, address = ? WHERE $donorIdColumn = ?");
$stmt->bind_param("ssssi", $full_name, $phone, $email, $address, $donor_id);

if ($stmt->execute()) {
    // Verify that the update actually affected a row
    if ($stmt->affected_rows > 0) {
        sendResponse(true, "Profile updated successfully");
    } else {
        sendResponse(false, "No changes were made. Please check if the profile exists.");
    }
} else {
    sendResponse(false, "Update failed: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

