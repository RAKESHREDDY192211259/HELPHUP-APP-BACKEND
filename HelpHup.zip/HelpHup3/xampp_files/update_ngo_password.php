<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$ngo_id = $data['ngo_id'] ?? '';
$current_password = $data['current_password'] ?? '';
$new_password = $data['new_password'] ?? '';

if (empty($ngo_id) || empty($current_password) || empty($new_password)) {
    sendResponse(false, "All fields are required");
}

// Verify current password
$stmt = $conn->prepare("SELECT password FROM ngo WHERE ngo_id = ?");
$stmt->bind_param("i", $ngo_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    sendResponse(false, "NGO not found");
}

$row = $result->fetch_assoc();
if (!password_verify($current_password, $row['password'])) {
    sendResponse(false, "Current password is incorrect");
}
$stmt->close();

// Update password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
$update = $conn->prepare("UPDATE ngo SET password = ? WHERE ngo_id = ?");
$update->bind_param("si", $hashed_password, $ngo_id);

if ($update->execute()) {
    sendResponse(true, "Password updated successfully");
} else {
    sendResponse(false, "Password update failed: " . $conn->error);
}

$update->close();
$conn->close();
?>

