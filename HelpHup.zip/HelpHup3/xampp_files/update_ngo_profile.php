<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$ngo_id = $data['ngo_id'] ?? '';
$full_name = $data['full_name'] ?? '';
$phone = $data['phone'] ?? '';
$email = $data['email'] ?? '';
$address = $data['address'] ?? '';
$org_name = $data['org_name'] ?? '';
$reg_number = $data['reg_number'] ?? '';

// Validate required fields
if (empty($ngo_id) || empty($full_name) || empty($phone) || empty($email) || 
    empty($address) || empty($org_name) || empty($reg_number)) {
    sendResponse(false, "All fields are required");
}

// Try different possible table names
$tableNames = ['ngo', 'ngos'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: NGO table not found.");
}

// Check which column exists - id or ngo_id
$checkNgoId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'ngo_id'");
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");

$ngoIdColumn = 'ngo_id'; // default
if ($checkId && $checkId->num_rows > 0) {
    $ngoIdColumn = 'id';
} elseif ($checkNgoId && $checkNgoId->num_rows > 0) {
    $ngoIdColumn = 'ngo_id';
}

// Check if email is already used by another NGO
$check = $conn->prepare("SELECT $ngoIdColumn FROM `$tableName` WHERE email = ? AND $ngoIdColumn != ?");
$check->bind_param("si", $email, $ngo_id);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    sendResponse(false, "Email already registered to another account");
}
$check->close();

// Update profile in database - Replace old data with new data
// This UPDATE statement replaces all old field values with the new values provided
$stmt = $conn->prepare("UPDATE `$tableName` SET full_name = ?, phone = ?, email = ?, address = ?, org_name = ?, reg_number = ? WHERE $ngoIdColumn = ?");
$stmt->bind_param("ssssssi", $full_name, $phone, $email, $address, $org_name, $reg_number, $ngo_id);

if ($stmt->execute()) {
    // Verify that the update actually affected a row
    if ($stmt->affected_rows > 0) {
        sendResponse(true, "Profile updated successfully");
    } else {
        sendResponse(false, "No changes were made. Please check if the profile exists.");
    }
} else {
    sendResponse(false, "Update failed: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

