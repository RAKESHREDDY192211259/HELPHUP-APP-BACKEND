<?php
/**
 * Unified endpoint for admin to update request status
 * Handles: verify, accept, reject actions
 * Works with: ngoraisehelp, volunteerraisehelp, donorraisehelp tables
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    require_once 'config.php';
    
    if (!isset($conn) || !$conn) {
        throw new Exception("Database connection not established");
    }
    
    // Get JSON input
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    if (!$data) {
        sendResponse(false, "Invalid JSON data");
    }
    
    $request_type = $data['request_type'] ?? ''; // 'ngo', 'volunteer', 'donor'
    $request_id = $data['request_id'] ?? '';
    $admin_id = $data['admin_id'] ?? 0;
    $status = $data['status'] ?? ''; // 'PENDING', 'APPROVED', 'REJECTED'
    $rejection_reason = $data['rejection_reason'] ?? null;
    
    // Validate required fields
    if (empty($request_type) || empty($request_id) || empty($admin_id) || empty($status)) {
        sendResponse(false, "Request type, request ID, admin ID, and status are required");
    }
    
    // Convert status to lowercase for database
    $statusLower = strtolower($status);
    
    // Determine table and column names based on actual table structure
    $tableName = '';
    $idColumn = '';
    $statusColumn = '';
    
    switch (strtolower($request_type)) {
        case 'ngo':
            // Check which table exists
            $checkTable1 = $conn->query("SHOW TABLES LIKE 'ngoraisehelp'");
            $checkTable2 = $conn->query("SHOW TABLES LIKE 'ngo_help_requests'");
            
            if ($checkTable1 && $checkTable1->num_rows > 0) {
                $tableName = 'ngoraisehelp';
                $idColumn = 'id';
                // Check if status column exists
                $checkStatus = $conn->query("SHOW COLUMNS FROM ngoraisehelp LIKE 'status'");
                $statusColumn = ($checkStatus && $checkStatus->num_rows > 0) ? 'status' : null;
            } else if ($checkTable2 && $checkTable2->num_rows > 0) {
                $tableName = 'ngo_help_requests';
                $idColumn = 'request_id';
                $statusColumn = 'status';
            } else {
                sendResponse(false, "NGO requests table not found");
            }
            break;
            
        case 'volunteer':
            // Check which table exists
            $checkTable1 = $conn->query("SHOW TABLES LIKE 'volunteerraisehelp'");
            $checkTable2 = $conn->query("SHOW TABLES LIKE 'volunteer_requests'");
            
            if ($checkTable1 && $checkTable1->num_rows > 0) {
                $tableName = 'volunteerraisehelp';
                $idColumn = 'id';
                $checkStatus = $conn->query("SHOW COLUMNS FROM volunteerraisehelp LIKE 'status'");
                $statusColumn = ($checkStatus && $checkStatus->num_rows > 0) ? 'status' : null;
            } else if ($checkTable2 && $checkTable2->num_rows > 0) {
                $tableName = 'volunteer_requests';
                $idColumn = 'request_id';
                $statusColumn = 'status';
            } else {
                sendResponse(false, "Volunteer requests table not found");
            }
            break;
            
        case 'donor':
            // Check which table exists
            $checkTable1 = $conn->query("SHOW TABLES LIKE 'donorraisehelp'");
            $checkTable2 = $conn->query("SHOW TABLES LIKE 'donor_campaigns'");
            
            if ($checkTable1 && $checkTable1->num_rows > 0) {
                $tableName = 'donorraisehelp';
                $idColumn = 'id';
                $checkStatus = $conn->query("SHOW COLUMNS FROM donorraisehelp LIKE 'status'");
                $statusColumn = ($checkStatus && $checkStatus->num_rows > 0) ? 'status' : null;
            } else if ($checkTable2 && $checkTable2->num_rows > 0) {
                $tableName = 'donor_campaigns';
                $idColumn = 'campaign_id';
                $statusColumn = 'status';
            } else {
                sendResponse(false, "Donor campaigns table not found");
            }
            break;
            
        default:
            sendResponse(false, "Invalid request type. Must be: ngo, volunteer, or donor");
    }
    
    // Convert request_id to integer
    $request_id_int = (int)$request_id;
    
    // Map status values
    $adminStatus = '';
    $publicStatus = '';
    
    switch ($statusLower) {
        case 'pending':
            $adminStatus = 'pending';
            $publicStatus = 'pending';
            break;
        case 'approved':
            $adminStatus = 'approved';
            $publicStatus = 'approved';
            break;
        case 'rejected':
            $adminStatus = 'rejected';
            $publicStatus = 'rejected';
            break;
        default:
            sendResponse(false, "Invalid status. Must be: PENDING, APPROVED, or REJECTED");
    }
    
    // Check which columns exist in the table
    $hasAdminReviewedAt = false;
    $hasRejectionReason = false;
    $hasAdminId = false;
    
    $checkColumns = $conn->query("SHOW COLUMNS FROM `$tableName`");
    if ($checkColumns) {
        while ($col = $checkColumns->fetch_assoc()) {
            if ($col['Field'] == 'admin_reviewed_at') $hasAdminReviewedAt = true;
            if ($col['Field'] == 'rejection_reason') $hasRejectionReason = true;
            if ($col['Field'] == 'admin_id') $hasAdminId = true;
        }
    }
    
    // First, verify the request exists and get current status
    $checkExists = $conn->prepare("SELECT `$idColumn`, COALESCE(admin_status, 'pending') as current_status FROM `$tableName` WHERE `$idColumn` = ?");
    $checkExists->bind_param("i", $request_id_int);
    $checkExists->execute();
    $existsResult = $checkExists->get_result();
    if ($existsResult->num_rows == 0) {
        $checkExists->close();
        sendResponse(false, "Request with ID $request_id_int not found in table $tableName (idColumn: $idColumn)");
    }
    $currentData = $existsResult->fetch_assoc();
    $checkExists->close();
    
    // Log for debugging
    error_log("Update Request Status: table=$tableName, idColumn=$idColumn, request_id=$request_id_int, current_status=" . ($currentData['current_status'] ?? 'unknown') . ", new_status=$adminStatus");
    
    // Build UPDATE query dynamically based on available columns
    $updateFields = array();
    $bindParams = array();
    $bindTypes = "";
    
    // Always update status field (single status system)
    $updateFields[] = "status = ?";
    $bindParams[] = $publicStatus;
    $bindTypes .= "s";
    
    // Update admin_id if column exists
    if ($hasAdminId) {
        $updateFields[] = "admin_id = ?";
        $bindParams[] = $admin_id;
        $bindTypes .= "i";
    }
    
    // Update admin_reviewed_at if column exists
    if ($hasAdminReviewedAt) {
        $updateFields[] = "admin_reviewed_at = NOW()";
    }
    
    // Update rejection_reason if column exists and provided
    if ($hasRejectionReason && $statusLower == 'rejected' && $rejection_reason) {
        $updateFields[] = "rejection_reason = ?";
        $bindParams[] = $rejection_reason;
        $bindTypes .= "s";
    }
    
    // Add WHERE clause parameter
    $bindParams[] = $request_id_int;
    $bindTypes .= "i";
    
    // Build and execute query
    $updateQuery = "UPDATE `$tableName` SET " . implode(", ", $updateFields) . " WHERE `$idColumn` = ?";
    $stmt = $conn->prepare($updateQuery);
    
    if (!$stmt) {
        throw new Exception("Failed to prepare query: " . $conn->error . " | Query: " . $updateQuery);
    }
    
    // Bind parameters dynamically
    $stmt->bind_param($bindTypes, ...$bindParams);
    
    if (!$stmt->execute()) {
        $errorMsg = $stmt->error;
        $stmt->close();
        throw new Exception("Failed to update request: $errorMsg | Query: $updateQuery");
    }
    
    $affectedRows = $stmt->affected_rows;
    $stmt->close();
    
    if ($affectedRows > 0) {
        // Create notification for the user
        $userId = 0;
        $userType = '';
        $userEmail = '';
        $userName = '';
        
        // Get user details based on request type
        if ($request_type == 'ngo') {
            $getUser = $conn->query("SELECT ngo_id FROM `$tableName` WHERE `$idColumn` = $request_id_int");
            if ($getUser && $getUser->num_rows > 0) {
                $userId = $getUser->fetch_assoc()['ngo_id'];
                $userType = 'ngo';
                // Get email from ngo table
                $getEmail = $conn->query("SELECT email, full_name FROM ngo WHERE ngo_id = $userId");
                if ($getEmail && $getEmail->num_rows > 0) {
                    $userData = $getEmail->fetch_assoc();
                    $userEmail = $userData['email'];
                    $userName = $userData['full_name'];
                }
            }
        } else if ($request_type == 'volunteer') {
            $getUser = $conn->query("SELECT volunteer_id FROM `$tableName` WHERE `$idColumn` = $request_id_int");
            if ($getUser && $getUser->num_rows > 0) {
                $userId = $getUser->fetch_assoc()['volunteer_id'];
                $userType = 'volunteer';
                $getEmail = $conn->query("SELECT email, full_name FROM volunteer WHERE volunteer_id = $userId");
                if ($getEmail && $getEmail->num_rows > 0) {
                    $userData = $getEmail->fetch_assoc();
                    $userEmail = $userData['email'];
                    $userName = $userData['full_name'];
                }
            }
        } else if ($request_type == 'donor') {
            $getUser = $conn->query("SELECT donor_id FROM `$tableName` WHERE `$idColumn` = $request_id_int");
            if ($getUser && $getUser->num_rows > 0) {
                $userId = $getUser->fetch_assoc()['donor_id'];
                $userType = 'donor';
                $getEmail = $conn->query("SELECT email, full_name FROM donor WHERE donor_id = $userId");
                if ($getEmail && $getEmail->num_rows > 0) {
                    $userData = $getEmail->fetch_assoc();
                    $userEmail = $userData['email'];
                    $userName = $userData['full_name'];
                }
            }
        }
        
        // Create notification if user found
        if ($userId > 0) {
            $title = '';
            $message = '';
            
            if ($statusLower == 'approved') {
                $title = "Request Approved";
                $message = "Your $request_type request has been approved by the admin.";
            } else if ($statusLower == 'rejected') {
                $title = "Request Rejected";
                $message = "Your $request_type request has been rejected. Reason: " . ($rejection_reason ?: "No reason provided");
            } else if ($statusLower == 'pending') {
                $title = "Request Verified";
                $message = "Your $request_type request has been verified and is under review.";
            }
            
            if ($title && $message) {
                // Check if notifications table exists
                $checkNotifications = $conn->query("SHOW TABLES LIKE 'notifications'");
                if ($checkNotifications && $checkNotifications->num_rows > 0) {
                    $notifStmt = $conn->prepare("INSERT INTO notifications (user_type, user_id, request_type, request_id, title, message, rejection_reason, is_read) VALUES (?, ?, ?, ?, ?, ?, ?, 0)");
                    $notifRejectionReason = ($statusLower == 'rejected') ? $rejection_reason : null;
                    $notifStmt->bind_param("sisisss", $userType, $userId, $request_type, $request_id_int, $title, $message, $notifRejectionReason);
                    $notifStmt->execute();
                }
            }
        }
        
        sendResponse(true, "Request status updated to $status successfully");
    } else {
        sendResponse(false, "No rows updated. Request ID may not exist or status is already set.");
    }
    
} catch (Exception $e) {
    error_log("Update Request Status Error: " . $e->getMessage());
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ));
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

