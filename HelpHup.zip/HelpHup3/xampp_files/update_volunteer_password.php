<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$volunteer_id = $data['volunteer_id'] ?? '';
$current_password = $data['current_password'] ?? '';
$new_password = $data['new_password'] ?? '';

if (empty($volunteer_id) || empty($current_password) || empty($new_password)) {
    sendResponse(false, "All fields are required");
}

// Try different possible table names
$tableNames = ['volunteer', 'volunteers'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Volunteer table not found.");
}

// Check which column exists - id or volunteer_id
$checkVolunteerId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'volunteer_id'");
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");

$volunteerIdColumn = 'id'; // default
if ($checkVolunteerId && $checkVolunteerId->num_rows > 0) {
    $volunteerIdColumn = 'volunteer_id';
} elseif ($checkId && $checkId->num_rows > 0) {
    $volunteerIdColumn = 'id';
}

// Verify current password
$stmt = $conn->prepare("SELECT password FROM `$tableName` WHERE $volunteerIdColumn = ?");
$stmt->bind_param("i", $volunteer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    sendResponse(false, "Volunteer not found");
}

$row = $result->fetch_assoc();
if (!password_verify($current_password, $row['password'])) {
    sendResponse(false, "Current password is incorrect");
}
$stmt->close();

// Update password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
$update = $conn->prepare("UPDATE `$tableName` SET password = ? WHERE $volunteerIdColumn = ?");
$update->bind_param("si", $hashed_password, $volunteer_id);

if ($update->execute()) {
    sendResponse(true, "Password updated successfully");
} else {
    sendResponse(false, "Password update failed: " . $conn->error);
}

$update->close();
$conn->close();
?>

