<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$volunteer_id = $data['volunteer_id'] ?? '';
$full_name = $data['full_name'] ?? '';
$phone = $data['phone'] ?? '';
$email = $data['email'] ?? '';
$skills = $data['skills'] ?? '';
$availability = $data['availability'] ?? '';

// Validate required fields
if (empty($volunteer_id) || empty($full_name) || empty($phone) || empty($email)) {
    sendResponse(false, "Full name, phone, and email are required");
}

// Try different possible table names
$tableNames = ['volunteer', 'volunteers'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break;
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Volunteer table not found.");
}

// Check which column exists - id or volunteer_id
$checkVolunteerId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'volunteer_id'");
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` LIKE 'id'");

$volunteerIdColumn = 'id'; // default
if ($checkVolunteerId && $checkVolunteerId->num_rows > 0) {
    $volunteerIdColumn = 'volunteer_id';
} elseif ($checkId && $checkId->num_rows > 0) {
    $volunteerIdColumn = 'id';
}

// Check if email is already used by another volunteer
$check = $conn->prepare("SELECT $volunteerIdColumn FROM `$tableName` WHERE email = ? AND $volunteerIdColumn != ?");
$check->bind_param("si", $email, $volunteer_id);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    sendResponse(false, "Email already registered to another account");
}
$check->close();

// Update profile in database - Replace old data with new data
// This UPDATE statement replaces all old field values with the new values provided
$stmt = $conn->prepare("UPDATE `$tableName` SET full_name = ?, phone = ?, email = ?, skills = ?, availability = ? WHERE $volunteerIdColumn = ?");
$stmt->bind_param("sssssi", $full_name, $phone, $email, $skills, $availability, $volunteer_id);

if ($stmt->execute()) {
    // Verify that the update actually affected a row
    if ($stmt->affected_rows > 0) {
        sendResponse(true, "Profile updated successfully");
    } else {
        sendResponse(false, "No changes were made. Please check if the profile exists.");
    }
} else {
    sendResponse(false, "Update failed: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

