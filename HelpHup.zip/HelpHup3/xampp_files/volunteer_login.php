<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');

require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Debug: Log received data (remove in production)
error_log("Volunteer Login - Raw JSON: " . $json);
error_log("Volunteer Login - Decoded data: " . print_r($data, true));

$email = isset($data['email']) ? trim($data['email']) : '';
$password = isset($data['password']) ? trim($data['password']) : '';

error_log("Volunteer Login - Email: '$email', Password length: " . strlen($password));

if (empty($email) || empty($password)) {
    sendResponse(false, "Email and password are required");
    exit;
}

// Try volunteers first (where data usually is), then volunteer
$tableNames = ['volunteers', 'volunteer'];
$tableName = null;

foreach ($tableNames as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $tableName = $table;
        break; // Use first table found
    }
}

if (!$tableName) {
    sendResponse(false, "Database error: Volunteer table not found.");
    exit;
}

// Detect primary key column name (id or volunteer_id)
$idColumn = 'id'; // default
$checkId = $conn->query("SHOW COLUMNS FROM `$tableName` WHERE `Key` = 'PRI'");
if ($checkId && $checkId->num_rows > 0) {
    $pkRow = $checkId->fetch_assoc();
    $idColumn = $pkRow['Field']; // Will be 'id' or 'volunteer_id'
}

// Query database - use case-insensitive email matching
$stmt = $conn->prepare("SELECT `$idColumn`, full_name, email, password FROM `$tableName` WHERE LOWER(email) = LOWER(?)");
if (!$stmt) {
    sendResponse(false, "Database error: " . $conn->error);
    exit;
}
$stmt->bind_param("s", $email);
if (!$stmt->execute()) {
    sendResponse(false, "Database error: " . $stmt->error);
    $stmt->close();
    exit;
}
$result = $stmt->get_result();

error_log("Volunteer Login - Query executed, rows found: " . $result->num_rows);
error_log("Volunteer Login - Searching for email: '$email'");

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        // Return response in format expected by Android app (volunteer at root level, not in data)
        header('Content-Type: application/json');
        echo json_encode(array(
            'status' => true,
            'message' => 'Login successful',
            'volunteer' => array(
                'id' => (int)$row[$idColumn],
                'name' => $row['full_name'],
                'email' => $row['email']
            )
        ));
        exit();
    } else {
        sendResponse(false, "Invalid password");
    }
} else {
    sendResponse(false, "Email not found");
}

$stmt->close();
$conn->close();
?>
