<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$volunteer_id = $data['volunteer_id'] ?? 0;
$request_title = $data['request_title'] ?? '';
$category = $data['category'] ?? '';
$description = $data['description'] ?? '';
$location = $data['location'] ?? '';
$help_date = $data['help_date'] ?? '';
$start_time = $data['start_time'] ?? '';
$volunteers_needed = $data['volunteers_needed'] ?? 0;

// Validate required fields
if (empty($volunteer_id) || empty($request_title) || empty($category) || 
    empty($description) || empty($location) || empty($help_date) || 
    empty($start_time) || empty($volunteers_needed)) {
    sendResponse(false, "All fields are required");
}

// Check if admin_status column exists
$checkColumn = $conn->query("SHOW COLUMNS FROM volunteer_requests LIKE 'admin_status'");
$hasAdminStatus = $checkColumn && $checkColumn->num_rows > 0;

// Build INSERT query based on column existence
if ($hasAdminStatus) {
    // Column exists - include it in INSERT
    $stmt = $conn->prepare("INSERT INTO volunteer_requests (volunteer_id, request_title, category, description, location, help_date, start_time, volunteers_needed, admin_status, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending')");
} else {
    // Column doesn't exist - insert without it (will need to run SQL script to add column)
    $stmt = $conn->prepare("INSERT INTO volunteer_requests (volunteer_id, request_title, category, description, location, help_date, start_time, volunteers_needed, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
}

if (!$stmt) {
    sendResponse(false, "Failed to prepare query: " . $conn->error);
}

$stmt->bind_param("issssssi", $volunteer_id, $request_title, $category, $description, $location, $help_date, $start_time, $volunteers_needed);

if ($stmt->execute()) {
    // If admin_status column doesn't exist, update it separately (if column was just added)
    if (!$hasAdminStatus) {
        // Try to add the column if it doesn't exist
        $conn->query("ALTER TABLE volunteer_requests ADD COLUMN admin_status VARCHAR(20) DEFAULT 'pending'");
        // Update the just-inserted record
        $lastId = $stmt->insert_id;
        $conn->query("UPDATE volunteer_requests SET admin_status = 'pending' WHERE request_id = $lastId");
    }
    sendResponse(true, "Help request submitted successfully. It will be reviewed by admin before being published.");
} else {
    sendResponse(false, "Failed to create help request: " . $stmt->error . " | " . $conn->error);
}

$stmt->close();
$conn->close();
?>

