<?php
require_once 'config.php';

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$full_name = $data['full_name'] ?? '';
$phone = $data['phone'] ?? '';
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';
$skills = $data['skills'] ?? array();
$availability = $data['availability'] ?? array();

// Validate required fields
if (empty($full_name) || empty($phone) || empty($email) || empty($password)) {
    sendResponse(false, "Full name, phone, email, and password are required");
}

// Check if email already exists
$check = $conn->prepare("SELECT volunteer_id FROM volunteer WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    sendResponse(false, "Email already registered");
}
$check->close();

// Convert arrays to comma-separated strings
$skills_str = is_array($skills) ? implode(',', $skills) : $skills;
$availability_str = is_array($availability) ? implode(',', $availability) : $availability;

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert into database
$stmt = $conn->prepare("INSERT INTO volunteer (full_name, phone, email, password, skills, availability) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $full_name, $phone, $email, $hashed_password, $skills_str, $availability_str);

if ($stmt->execute()) {
    sendResponse(true, "Registration successful");
} else {
    sendResponse(false, "Registration failed: " . $conn->error);
}

$stmt->close();
$conn->close();
?>

